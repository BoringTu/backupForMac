(function() {
  define(['jquery'], function($) {
    "use strict";
    var domain, isLocal;
    domain = location.hostname.replace(/^\w+\./, '');
    isLocal = +localStorage.getItem('isLocal');
    window.CSH = window.CSH || {};
    window.CSH = $.extend(true, CSH, {
      isLocal: isLocal,
      pageName: location.pathname.replace(/(^\/)|(\.html.*$)/g, ''),
      alert: void 0,
      confirm: void 0,
      utils: void 0,
      isMute: +localStorage.getItem('isMute'),
      models: {},
      collections: {},
      views: {},
      audios: {},
      data: {},
      xhrPool: [],
      $els: {},
      userInfo: {},
      path: {
        domain: domain,
        origin: location.origin + "/api",
        fapi: location.origin + "/fapi",
        speed: _speedLink,
        service: _serviceUrl,
        appdownload: _appDownload,
        ws: _wsUrl
      },
      paginate: {},
      routePath: [],
      face: {},
      betList: {},
      balance: {},
      menu: {},
      modeMap: {
        1: '元',
        2: '角',
        3: '分',
        4: '厘'
      },
      gameMap: {
        '100': {
          bg: 'ssc'
        },
        '101': {
          bg: 'ssc'
        },
        '103': {
          bg: 'ssc'
        },
        '104': {
          bg: 'fc'
        },
        '105': {
          bg: 'fc'
        },
        '106': {
          bg: '1d5fc'
        },
        '107': {
          bg: 'fc'
        },
        '108': {
          bg: 'fc'
        },
        '109': {
          bg: 'qtfc'
        },
        '110': {
          bg: '1d5fc'
        },
        '111': {
          bg: '1d5fc'
        },
        '112': {
          bg: '1d5fc'
        },
        '113': {
          bg: '1d5fc'
        },
        '114': {
          bg: '1d5fc'
        },
        '115': {
          bg: 'qtfc'
        },
        '116': {
          bg: 'qtfc'
        },
        '117': {
          bg: '5fc'
        },
        '118': {
          bg: '5fc'
        },
        '119': {
          bg: 'qtfc'
        },
        '120': {
          bg: '1d5fc'
        },
        '200': {
          bg: '3d'
        },
        '201': {
          bg: '3d'
        },
        '202': {
          bg: 'pl'
        },
        '203': {
          bg: '3d'
        },
        '300': {
          bg: '11x5'
        },
        '301': {
          bg: '11x5'
        },
        '302': {
          bg: '11x5'
        },
        '303': {
          bg: 'dlc'
        },
        '304': {
          bg: '11x5'
        },
        '306': {
          bg: 'ydj'
        },
        '401': {
          bg: 'pk10'
        },
        '402': {
          bg: 'pk10'
        },
        '501': {
          bg: 'k3'
        },
        '502': {
          bg: 'k3'
        },
        '601': {
          bg: 'lhc'
        },
        '602': {
          bg: 'lhc'
        }
      },
      methodMap: {
        2067: 'ZX5',
        2068: 'ZX5',
        2080: 'ZH4',
        2069: 'ZH5',
        2081: 'SXZU24',
        2082: 'SXZU12',
        2083: 'SXZU6',
        2084: 'SXZU4',
        2078: 'ZX4',
        2079: 'ZX4',
        2123: 'ZX3',
        2124: 'ZX3',
        2125: 'ZXHZ',
        2126: 'ZXKD',
        2127: 'ZH3',
        2134: 'ZU3BD',
        2070: 'WXZU120',
        2071: 'WXZU60',
        2072: 'WXZU30',
        2073: 'WXZU20',
        2074: 'WXZU10',
        874: 'WXZU5',
        2128: 'ZUS',
        2130: 'ZUS',
        2129: 'ZUL',
        2131: 'ZUL',
        2132: 'HHZX',
        2133: 'ZUHZ',
        2135: 'HZWS',
        2136: 'TSH3',
        2106: 'ZX3',
        2107: 'ZX3',
        2108: 'ZXHZ',
        2109: 'ZXKD',
        2111: 'ZUS',
        2113: 'ZUS',
        2112: 'ZUL',
        2114: 'ZUL',
        2115: 'HHZX',
        2116: 'ZUHZ',
        2118: 'HZWS',
        2119: 'TSH3',
        2088: 'ZX3',
        2089: 'ZX3',
        2090: 'ZXHZ',
        2091: 'ZXKD',
        2092: 'ZH3',
        2093: 'ZUS',
        2096: 'ZUS',
        2094: 'ZUL',
        2097: 'ZUL',
        2098: 'HHZX',
        2099: 'ZUHZ',
        2100: 'ZU3BD',
        2101: 'HZWS',
        2102: 'TSH3',
        2150: 'ZX2',
        2151: 'ZX2',
        2152: 'ZXHZ2',
        2153: 'ZXKD2',
        2154: 'ZU2',
        2155: 'ZU2',
        2156: 'ZUHZ2',
        2157: 'ZU2BD',
        2142: 'ZX2',
        2143: 'ZX2',
        2144: 'ZXHZ2',
        2145: 'ZXKD2',
        2146: 'ZU2',
        2147: 'ZU2',
        2148: 'ZUHZ2',
        2149: 'ZU2BD',
        2159: 'DWD',
        60: 'DWD',
        61: 'DWD',
        62: 'DWD',
        63: 'DWD',
        2165: 'BDW1',
        2163: 'BDW1',
        2164: 'BDW2',
        2166: 'BDW2',
        2167: 'BDW1',
        2168: 'BDW2',
        2169: 'BDW2',
        2170: 'BDW3',
        2173: 'DXDS',
        2175: 'DXDS',
        2172: 'DXDS',
        2174: 'DXDS',
        2184: 'BDW1',
        2185: 'HSCS',
        2186: 'SXBX',
        2187: 'SJFC',
        754: 'ZXHZ2',
        652: 'RZX2',
        2190: 'ZXHZ2',
        653: 'RZX2',
        2188: 'RZX2',
        2189: 'RZX2',
        746: 'ZXHZ2',
        747: 'ZXHZ2',
        645: 'RZX2',
        748: 'ZXHZ2',
        646: 'RZX2',
        749: 'ZXHZ2',
        647: 'RZX2',
        750: 'ZXHZ2',
        648: 'RZX2',
        751: 'ZXHZ2',
        649: 'RZX2',
        752: 'ZXHZ2',
        650: 'RZX2',
        753: 'ZXHZ2',
        651: 'RZX2',
        756: 'ZUHZ2',
        757: 'ZUHZ2',
        655: 'ZU2',
        758: 'ZUHZ2',
        656: 'ZU2',
        759: 'ZUHZ2',
        657: 'ZU2',
        760: 'ZUHZ2',
        658: 'ZU2',
        761: 'ZUHZ2',
        659: 'ZU2',
        762: 'ZUHZ2',
        660: 'ZU2',
        763: 'ZUHZ2',
        661: 'ZU2',
        764: 'ZUHZ2',
        662: 'ZU2',
        2193: 'ZUHZ2',
        663: 'ZU2',
        2191: 'ZU2',
        2192: 'ZU2',
        699: 'ZXHZ',
        700: 'ZXHZ',
        667: 'RZX3',
        701: 'ZXHZ',
        668: 'RZX3',
        702: 'ZXHZ',
        669: 'RZX3',
        703: 'ZXHZ',
        670: 'RZX3',
        704: 'ZXHZ',
        671: 'RZX3',
        705: 'ZXHZ',
        672: 'RZX3',
        706: 'ZXHZ',
        673: 'RZX3',
        707: 'ZXHZ',
        674: 'RZX3',
        2196: 'ZXHZ',
        675: 'RZX3',
        2194: 'RZX3',
        2195: 'RZX3',
        2197: 'ZUS',
        2198: 'ZUS',
        687: 'ZUL',
        688: 'ZUL',
        689: 'ZUL',
        690: 'ZUL',
        691: 'ZUL',
        692: 'ZUL',
        693: 'ZUL',
        694: 'ZUL',
        695: 'ZUL',
        2199: 'ZUL',
        2200: 'ZUL',
        766: 'HHZX',
        767: 'HHZX',
        768: 'HHZX',
        769: 'HHZX',
        770: 'HHZX',
        771: 'HHZX',
        772: 'HHZX',
        773: 'HHZX',
        774: 'HHZX',
        2202: 'HHZX',
        709: 'ZUHZ',
        710: 'ZUHZ',
        677: 'ZUS',
        711: 'ZUHZ',
        678: 'ZUS',
        712: 'ZUHZ',
        679: 'ZUS',
        713: 'ZUHZ',
        680: 'ZUS',
        714: 'ZUHZ',
        681: 'ZUS',
        715: 'ZUHZ',
        682: 'ZUS',
        716: 'ZUHZ',
        683: 'ZUS',
        717: 'ZUHZ',
        684: 'ZUS',
        2203: 'ZUHZ',
        685: 'ZUS',
        722: 'RZX4',
        723: 'RZX4',
        2205: 'RZX4',
        2204: 'RZX4',
        721: 'RZX4',
        726: 'SXZU24',
        727: 'SXZU24',
        728: 'SXZU24',
        729: 'SXZU24',
        2206: 'SXZU24',
        731: 'SXZU12',
        732: 'SXZU12',
        733: 'SXZU12',
        734: 'SXZU12',
        2207: 'SXZU12',
        736: 'SXZU6',
        737: 'SXZU6',
        738: 'SXZU6',
        739: 'SXZU6',
        2208: 'SXZU6',
        741: 'SXZU4',
        742: 'SXZU4',
        743: 'SXZU4',
        744: 'SXZU4',
        2209: 'SXZU4',
        3214: 'ZX3',
        3215: 'ZX3',
        3216: 'ZXHZ',
        3217: 'ZUS',
        3218: 'ZUS',
        3219: 'ZUL',
        3220: 'ZUL',
        3221: 'HHZX',
        3222: 'ZUHZ',
        3223: 'ZX2',
        3224: 'ZX2',
        3227: 'ZU2',
        3228: 'ZU2',
        3225: 'ZX2',
        3226: 'ZX2',
        3229: 'ZU2',
        3230: 'ZU2',
        3232: 'DWD',
        586: 'DWD',
        587: 'DWD',
        3233: 'BDW1',
        3234: 'BDW2',
        3235: 'DXDS',
        3236: 'DXDS',
        2059: 'LTZX3',
        2060: 'LTZX3',
        2061: 'LTZU3',
        2062: 'LTZU3',
        3202: 'LTDTZU3',
        2055: 'LTZX2',
        2056: 'LTZX2',
        2057: 'LTZU2',
        2058: 'LTZU2',
        3201: 'LTDTZU2',
        2063: 'LTBDW',
        2064: 'LTDWD',
        496: 'LTDWD',
        497: 'LTDWD',
        2054: 'LTDDS',
        3200: 'LTCZW',
        2030: 'LTRX1',
        2039: 'LTRX1',
        2031: 'LTRX2',
        2040: 'LTRX2',
        2047: 'LTRXDT2',
        2032: 'LTRX3',
        2041: 'LTRX3',
        2048: 'LTRXDT3',
        2033: 'LTRX4',
        2042: 'LTRX4',
        2049: 'LTRXDT4',
        2035: 'LTRX5',
        2043: 'LTRX5',
        2050: 'LTRXDT5',
        2036: 'LTRX6',
        2044: 'LTRX6',
        2051: 'LTRXDT6',
        2037: 'LTRX7',
        2045: 'LTRX7',
        2052: 'LTRXDT7',
        2038: 'LTRX8',
        2046: 'LTRX8',
        2053: 'LTRXDT8',
        3240: 'BDW1',
        3242: 'CGYJZX2',
        3243: 'CGYJZX2',
        3245: 'CGYJZX3',
        3246: 'CGYJZX3',
        3249: 'CGYJZX4',
        3250: 'CGYJZX4',
        3252: 'CGYJZX5',
        3253: 'CGYJZX5',
        3255: 'CGJDWD',
        3256: 'CGJDWD',
        3258: 'DXDS',
        3267: 'BDW1',
        3265: 'BDW1',
        3270: 'BDW1',
        3269: 'BDW1',
        3273: 'K3SBTHFU',
        3272: 'K3SBTHDU',
        3277: 'K3ETHDXFU',
        3275: 'K3ETHDU',
        3278: 'BDW1',
        3281: 'K3EBTHFU',
        3280: 'K3EBTHDU',
        3283: 'K3HV',
        3285: 'DXDS',
        3289: 'BDW1'
      }
    });
    return Object.defineProperties(CSH, {
      serverTime: {
        get: function() {
          if (CSH._serverTimeDV == null) {
            CSH._serverTimeDV = +localStorage.getItem('serverTimeDV');
          }
          return new Date(new Date().getTime() + CSH._serverTimeDV);
        }
      }
    });
  });

}).call(this);
