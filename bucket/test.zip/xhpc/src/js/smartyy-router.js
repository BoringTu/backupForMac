(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'backbone', 'common', 'views/_smartyy-body', 'views/_smartyy-header', 'views/_smartyy-sidebar'], function($, Backbone, Common, ViewBody, ViewHeader, ViewSideBar) {
    "use strict";
    var Router;
    Router = (function(superClass) {
      extend(Router, superClass);

      function Router() {
        return Router.__super__.constructor.apply(this, arguments);
      }

      Router.prototype.routes = {
        '': 'main',
        ':route1st': 'main',
        ':route1st/:route2nd': 'main',
        ':route1st/:route2nd/:route3rd': 'main'
      };

      Router.prototype.initialize = function() {
        Common.initialize();
        CSH.router = this;
        this.utils = CSH.utils;
        CSH.$els['window'] = $(window);
        CSH.$els['head'] = $('head');
        CSH.$els['body'] = $('body');
        CSH.$els['header'] = $('header');
        CSH.$els['footer'] = $('footer');
        CSH.$els['sidebar'] = $('.sidebar');
        CSH.$els['rightSidebar'] = $('.rightSidebar');
        CSH.$els['pageWrap'] = $('.pageWrap');
        CSH.$els['contentPanel'] = $('.contentPanel');
        CSH.$els['contentWindow'] = $('.contentWindow');
        CSH.$els['contentWrap'] = $('.contentWrap');
        CSH.$els['content'] = $('#content');
        CSH.$els['menu'] = CSH.$els['header'].find('.menu');
        CSH.views['body'] = this.body = new ViewBody({
          el: CSH.$els['body']
        });
        CSH.views['header'] = this.header = new ViewHeader({
          el: CSH.$els['header']
        });
        CSH.views['sidebar'] = this.sidebar = new ViewSideBar({
          el: CSH.$els['sidebar']
        });
        CSH.scrollToTop = function(speed) {
          if (speed == null) {
            speed = 0;
          }
          return CSH.$els['contentWindow'].animate({
            scrollTop: 0
          }, speed);
        };
        CSH.scrollTo = function(top, speed) {
          if (top == null) {
            top = 0;
          }
          if (speed == null) {
            speed = 0;
          }
          return CSH.$els['contentWindow'].animate({
            scrollTop: top
          }, speed);
        };
        CSH.async = function(fun, t) {
          if (t == null) {
            t = 0;
          }
          return setTimeout(fun, t);
        };
        CSH.refreshMenuStatus = (function(_this) {
          return function() {
            _this.header.refreshStatus();
            return _this.sidebar.refreshStatus();
          };
        })(this);
        CSH.xhrPool = [];
      };

      Router.prototype.refresh = function() {
        var hash;
        hash = location.hash.replace(/^#/, '');
        hash = hash.split('/');
        this.main.apply(this, hash);
      };

      Router.prototype.main = function() {
        var str;
        CSH.scrollToTop(200);
        CSH.routePath = (function() {
          var i, len, results;
          results = [];
          for (i = 0, len = arguments.length; i < len; i++) {
            str = arguments[i];
            if (str) {
              results.push(str);
            }
          }
          return results;
        }).apply(this, arguments);
        console.log('CSH.routePath: ', CSH.routePath);
        this.destroyPage();
        this.body.showLoading();
        $('> .modal', document.body).each(function() {
          var modalBox;
          modalBox = $(this);
          if (!(modalBox.hasClass('modal-initpwdmodify') || modalBox.hasClass('modal-notice'))) {
            return modalBox.modal('hide');
          }
        });
        CSH.refreshMenuStatus();
      };

      Router.prototype.destroyPage = function() {
        var ref;
        console.info('垃圾处理');
        _.each(CSH.xhrPool, function(xhr) {
          if (xhr.readyState > 0 && xhr.readyState < 4) {
            xhr.abort();
          }
        });
        CSH.xhrPool = [];
        _.each(CSH.models, function(obj, name) {
          return delete CSH.models[name];
        });
        _.each(CSH.collections, function(obj, name) {
          return delete CSH.collections[name];
        });
        if ((ref = this.ctrl) != null) {
          if (typeof ref.destroy === "function") {
            ref.destroy();
          }
        }
        return CSH.$els['content'].empty().off();
      };

      return Router;

    })(Backbone.Router);

    /*
    	new Router()
    	Backbone.history.start()
     */
    return Router;
  });

}).call(this);
