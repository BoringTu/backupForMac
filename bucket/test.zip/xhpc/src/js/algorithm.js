(function() {
  define(['jquery'], function($) {
    "use strict";
    var Algorithm;
    Algorithm = (function() {
      function Algorithm(view) {
        this.view = view;
      }

      Algorithm.prototype.type = '';

      Algorithm.prototype.multiple = 1;

      Algorithm.prototype.isrx = 0;

      Algorithm.prototype.methodName = '';

      Algorithm.prototype.placeCount = 0;

      Algorithm.prototype.error = [];

      Algorithm.prototype.getText = function(text) {
        var blankReg, isTen, ref;
        blankReg = /\s+/;
        isTen = (ref = +CSH.gType) === 3 || ref === 4;
        text = text.replace(/[０１２３４５６７８９]|\s*\,+\s*|\s*\;+\s*|\s*\|+\s*|\s*。+\s*|\s*、+\s*|\s*，+\s*|\s*；+\s*|\s*｜+\s*|\s+/g, (function(_this) {
          return function(chars) {
            var x;
            switch (chars) {
              case '０':
                return '0';
              case '１':
                return '1';
              case '２':
                return '2';
              case '３':
                return '3';
              case '４':
                return '4';
              case '５':
                return '5';
              case '６':
                return '6';
              case '７':
                return '7';
              case '８':
                return '8';
              case '９':
                return '9';
            }
            if (/\n/.test(chars)) {
              return '|';
            }
            x = chars.trim().split('')[0];
            if (x === ',' || x === ';' || x === '|' || x === '、' || x === '。' || x === '，' || x === '；' || x === '｜') {
              return '|';
            }
            if (blankReg.test(chars)) {
              if (isTen) {
                return ' ';
              } else {
                return '|';
              }
            }
          };
        })(this));
        text = text.replace(/(^\|+)|(\|+$)/g, '');
        return text;
      };

      Algorithm.prototype.getCount = function(data) {
        var aCodePosition, aCombo, aPositionCombo, aa, ab, ac, ad, ae, af, ag, ah, ai, aj, ak, al, am, an, ao, ap, aq, ar, as, at, au, av, aw, ax, ay, az, ba, bb, c0, c0_len, c0i, c1, c1_len, c1j, c2, c2_len, c2k, c3, c3_len, c3l, c4, c4_len, c4m, cc, codes, count, danlen, h, i, iComboLen, iLen, j, k, l, len, m, minchosen, money, n, p, q, ref, ref1, ref10, ref11, ref12, ref13, ref14, ref15, ref16, ref17, ref18, ref19, ref2, ref20, ref21, ref22, ref23, ref24, ref25, ref26, ref27, ref28, ref29, ref3, ref30, ref31, ref32, ref33, ref34, ref35, ref4, ref5, ref6, ref7, ref8, ref9, sellen, t, tmpNums, tmp_nums, tuolen, u, v, w, y, z;
        codes = data.codes;
        this.codes = codes;
        this.error = [];
        minchosen = data.minchosen;
        count = 0;
        if (this.type === 'input') {
          if (codes.length > 0) {
            switch (this.methodName) {
              case 'ZX5':
                count = this._inputCheck_Num(5, false);
                break;
              case 'ZX4':
                count = this._inputCheck_Num(4, false);
                break;
              case 'ZX3':
                count = this._inputCheck_Num(3, false);
                break;
              case 'ZUS':
                count = this._inputCheck_Num(3, false, this._ZUSDScheck, true);
                if (this.isrx) {
                  count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
                }
                break;
              case 'ZUL':
                count = this._inputCheck_Num(3, false, this._ZULDScheck, true);
                if (this.isrx) {
                  count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
                }
                break;
              case 'HHZX':
                count = this._inputCheck_Num(3, false, this._HHZXcheck, true);
                if (this.isrx) {
                  count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
                }
                break;
              case 'ZX2':
                count = this._inputCheck_Num(2, false);
                break;
              case 'ZU2':
                count = this._inputCheck_Num(2, false, this._HHZXcheck, true);
                if (this.isrx) {
                  count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 2);
                }
                break;
              case 'RZX2':
              case 'RZX3':
              case 'RZX4':
                sellen = +this.methodName.charAt(this.methodName.length - 1);
                count = this._inputCheck_Num(sellen, false);
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, sellen);
                break;
              case 'LTZX3':
                count = this._inputCheck_Num(8, false, this._SDinputCheck, false);
                break;
              case 'LTZU3':
                count = this._inputCheck_Num(8, false, this._SDinputCheck, true);
                break;
              case 'LTZX2':
                count = this._inputCheck_Num(5, false, this._SDinputCheck, false);
                break;
              case 'LTZU2':
                count = this._inputCheck_Num(5, false, this._SDinputCheck, true);
                break;
              case 'LTRX1':
                count = this._inputCheck_Num(2, false, this._SDinputCheck, false);
                break;
              case 'LTRX2':
                count = this._inputCheck_Num(5, false, this._SDinputCheck, true);
                break;
              case 'LTRX3':
                count = this._inputCheck_Num(8, false, this._SDinputCheck, true);
                break;
              case 'LTRX4':
                count = this._inputCheck_Num(11, false, this._SDinputCheck, true);
                break;
              case 'LTRX5':
                count = this._inputCheck_Num(14, false, this._SDinputCheck, true);
                break;
              case 'LTRX6':
                count = this._inputCheck_Num(17, false, this._SDinputCheck, true);
                break;
              case 'LTRX7':
                count = this._inputCheck_Num(20, false, this._SDinputCheck, true);
                break;
              case 'LTRX8':
                count = this._inputCheck_Num(23, false, this._SDinputCheck, true);
                break;
              case 'CGYJZX2':
                count = this._inputCheck_Num(5, false, this._SDinputCheck, false);
                break;
              case 'CGYJZX3':
                count = this._inputCheck_Num(8, false, this._SDinputCheck, false);
                break;
              case 'CGYJZX4':
                count = this._inputCheck_Num(11, false, this._SDinputCheck, false);
                break;
              case 'CGYJZX5':
                count = this._inputCheck_Num(14, false, this._SDinputCheck, false);
                break;
              case 'K3SBTHDU':
                count = this._inputCheck_Num(3, false, this._K3InputBTHCheck, false);
                break;
              case 'K3ETHDU':
                count = this._inputCheck_Num(3, false, this._K3InputTHCheck, false);
                break;
              case 'K3EBTHDU':
                count = this._inputCheck_Num(2, false, this._K3InputBTHCheck, false);
            }
          }
        } else {
          tmp_nums = 1;
          switch (this.methodName) {
            case 'ZH5':
            case 'ZH4':
            case 'ZH3':
              for (i = p = 0, ref = this.placeCount; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
                len = codes[i].length;
                if (len === 0) {
                  tmp_nums = 0;
                  break;
                }
                tmp_nums *= len;
              }
              count = tmp_nums * parseInt(this.methodName.charAt(this.methodName.length - 1));
              break;
            case 'WXZU120':
              len = codes[0].length;
              if (len > 4) {
                count += Math.combination(len, 5);
              }
              break;
            case 'WXZU60':
            case 'WXZU30':
            case 'WXZU20':
            case 'WXZU10':
            case 'WXZU5':
              if (codes[0].length >= minchosen[0] && codes[1].length >= minchosen[1]) {
                h = Array.intersection(codes[0], codes[1]).length;
                tmp_nums = Math.combination(codes[0].length, minchosen[0]) * Math.combination(codes[1].length, minchosen[1]);
                if (h > 0) {
                  if (this.methodName === 'WXZU60') {
                    tmp_nums -= Math.combination(h, 1) * Math.combination(codes[1].length - 1, 2);
                  } else if (this.methodName === 'WXZU30') {
                    tmp_nums -= Math.combination(h, 2) * Math.combination(2, 1);
                    if (codes[0].length - h > 0) {
                      tmp_nums -= Math.combination(h, 1) * Math.combination(codes[0].length - h, 1);
                    }
                  } else if (this.methodName === 'WXZU20') {
                    tmp_nums -= Math.combination(h, 1) * Math.combination(codes[1].length - 1, 1);
                  } else if (this.methodName === 'WXZU10' || this.methodName === 'WXZU5') {
                    tmp_nums -= Math.combination(h, 1);
                  }
                }
                count += tmp_nums;
              }
              break;
            case 'SXZU24':
              len = codes[0].length;
              if (len > 3) {
                count += Math.combination(len, 4);
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 4);
              }
              break;
            case 'SXZU6':
              if (codes[0].length >= minchosen[0]) {
                count += Math.combination(codes[0].length, minchosen[0]);
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 4);
              }
              break;
            case 'SXZU12':
            case 'SXZU4':
              if (codes[0].length >= minchosen[0] && codes[1].length >= minchosen[1]) {
                h = Array.intersection(codes[0], codes[1]).length;
                tmp_nums = Math.combination(codes[0].length, minchosen[0]) * Math.combination(codes[1].length, minchosen[1]);
                if (h > 0) {
                  if (this.methodName === 'SXZU12') {
                    tmp_nums -= Math.combination(h, 1) * Math.combination(codes[1].length - 1, 1);
                  } else if (this.methodName === 'SXZU4') {
                    tmp_nums -= Math.combination(h, 1);
                  }
                }
                count += tmp_nums;
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 4);
              }
              break;
            case 'ZXKD':
            case 'ZXKD2':
            case 'ZXHZ':
            case 'ZUHZ':
              if (this.methodName === 'ZXKD') {
                cc = {
                  0: 10,
                  1: 54,
                  2: 96,
                  3: 126,
                  4: 144,
                  5: 150,
                  6: 144,
                  7: 126,
                  8: 96,
                  9: 54
                };
                for (i = q = 0, ref1 = this.placeCount; 0 <= ref1 ? q < ref1 : q > ref1; i = 0 <= ref1 ? ++q : --q) {
                  len = codes[i].length;
                  for (j = t = 0, ref2 = len; 0 <= ref2 ? t < ref2 : t > ref2; j = 0 <= ref2 ? ++t : --t) {
                    count += cc[parseInt(codes[i][j], 10)];
                  }
                }
                break;
              }
              if (this.methodName === 'ZXKD2') {
                cc = {
                  0: 10,
                  1: 18,
                  2: 16,
                  3: 14,
                  4: 12,
                  5: 10,
                  6: 8,
                  7: 6,
                  8: 4,
                  9: 2
                };
                for (i = u = 0, ref3 = this.placeCount; 0 <= ref3 ? u < ref3 : u > ref3; i = 0 <= ref3 ? ++u : --u) {
                  len = codes[i].length;
                  for (j = v = 0, ref4 = len; 0 <= ref4 ? v < ref4 : v > ref4; j = 0 <= ref4 ? ++v : --v) {
                    count += cc[parseInt(codes[i][j], 10)];
                  }
                }
                break;
              }
              if (this.methodName === 'ZXHZ') {
                cc = {
                  0: 1,
                  1: 3,
                  2: 6,
                  3: 10,
                  4: 15,
                  5: 21,
                  6: 28,
                  7: 36,
                  8: 45,
                  9: 55,
                  10: 63,
                  11: 69,
                  12: 73,
                  13: 75,
                  14: 75,
                  15: 73,
                  16: 69,
                  17: 63,
                  18: 55,
                  19: 45,
                  20: 36,
                  21: 28,
                  22: 21,
                  23: 15,
                  24: 10,
                  25: 6,
                  26: 3,
                  27: 1
                };
              }
              if (this.methodName === 'ZUHZ') {
                cc = {
                  1: 1,
                  2: 2,
                  3: 2,
                  4: 4,
                  5: 5,
                  6: 6,
                  7: 8,
                  8: 10,
                  9: 11,
                  10: 13,
                  11: 14,
                  12: 14,
                  13: 15,
                  14: 15,
                  15: 14,
                  16: 14,
                  17: 13,
                  18: 11,
                  19: 10,
                  20: 8,
                  21: 6,
                  22: 5,
                  23: 4,
                  24: 2,
                  25: 2,
                  26: 1
                };
              }
              for (i = w = 0, ref5 = this.placeCount; 0 <= ref5 ? w < ref5 : w > ref5; i = 0 <= ref5 ? ++w : --w) {
                len = codes[i].length;
                for (j = y = 0, ref6 = len; 0 <= ref6 ? y < ref6 : y > ref6; j = 0 <= ref6 ? ++y : --y) {
                  count += cc[parseInt(codes[i][j], 10)];
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
              }
              break;
            case 'ZUS':
              for (i = z = 0, ref7 = this.placeCount; 0 <= ref7 ? z < ref7 : z > ref7; i = 0 <= ref7 ? ++z : --z) {
                len = codes[i].length;
                if (len > 1) {
                  count += len * (len - 1);
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
              }
              break;
            case 'ZUL':
              for (i = aa = 0, ref8 = this.placeCount; 0 <= ref8 ? aa < ref8 : aa > ref8; i = 0 <= ref8 ? ++aa : --aa) {
                len = codes[i].length;
                if (len > 2) {
                  count += len * (len - 1) * (len - 2) / 6;
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
              }
              break;
            case 'ZXHZ2':
              cc = {
                0: 1,
                1: 2,
                2: 3,
                3: 4,
                4: 5,
                5: 6,
                6: 7,
                7: 8,
                8: 9,
                9: 10,
                10: 9,
                11: 8,
                12: 7,
                13: 6,
                14: 5,
                15: 4,
                16: 3,
                17: 2,
                18: 1
              };
              for (i = ab = 0, ref9 = this.placeCount; 0 <= ref9 ? ab < ref9 : ab > ref9; i = 0 <= ref9 ? ++ab : --ab) {
                len = codes[i].length;
                for (j = ac = 0, ref10 = len; 0 <= ref10 ? ac < ref10 : ac > ref10; j = 0 <= ref10 ? ++ac : --ac) {
                  count += cc[parseInt(codes[i][j], 10)];
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 2);
              }
              break;
            case 'ZUHZ2':
              cc = {
                0: 0,
                1: 1,
                2: 1,
                3: 2,
                4: 2,
                5: 3,
                6: 3,
                7: 4,
                8: 4,
                9: 5,
                10: 4,
                11: 4,
                12: 3,
                13: 3,
                14: 2,
                15: 2,
                16: 1,
                17: 1,
                18: 0
              };
              for (i = ad = 0, ref11 = this.placeCount; 0 <= ref11 ? ad < ref11 : ad > ref11; i = 0 <= ref11 ? ++ad : --ad) {
                len = codes[i].length;
                for (j = ae = 0, ref12 = len; 0 <= ref12 ? ae < ref12 : ae > ref12; j = 0 <= ref12 ? ++ae : --ae) {
                  count += cc[parseInt(codes[i][j], 10)];
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 2);
              }
              break;
            case 'ZU3BD':
              count = codes[0].length * 54;
              break;
            case 'ZU2BD':
              count = codes[0].length * 9;
              break;
            case 'BDW3':
              for (i = af = 0, ref13 = this.placeCount; 0 <= ref13 ? af < ref13 : af > ref13; i = 0 <= ref13 ? ++af : --af) {
                len = codes[i].length;
                if (len > 2) {
                  count += Math.combination(codes[i].length, 3);
                }
              }
              break;
            case 'BDW2':
            case 'ZU2':
              for (i = ag = 0, ref14 = this.placeCount; 0 <= ref14 ? ag < ref14 : ag > ref14; i = 0 <= ref14 ? ++ag : --ag) {
                len = codes[i].length;
                if (len > 1) {
                  count += len * (len - 1) / 2;
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 2);
              }
              break;
            case 'DWD':
              for (i = ah = 0, ref15 = this.placeCount; 0 <= ref15 ? ah < ref15 : ah > ref15; i = 0 <= ref15 ? ++ah : --ah) {
                count += codes[i].length;
              }
              break;
            case 'RZX2':
            case 'RZX3':
            case 'RZX4':
              aCodePosition = [];
              for (i = ai = 0, ref16 = this.placeCount; 0 <= ref16 ? ai < ref16 : ai > ref16; i = 0 <= ref16 ? ++ai : --ai) {
                len = codes[i].length;
                if (len > 0) {
                  aCodePosition.push(i);
                }
              }
              sellen = this.methodName.substring(this.methodName.length - 1);
              aPositionCombo = this.getCombination(aCodePosition, sellen);
              iComboLen = aPositionCombo.length;
              aCombo = [];
              iLen = 0;
              tmpNums = 1;
              for (i = aj = 0, ref17 = iComboLen; 0 <= ref17 ? aj < ref17 : aj > ref17; i = 0 <= ref17 ? ++aj : --aj) {
                aCombo = aPositionCombo[i].split(',');
                iLen = aCombo.length;
                tmpNums = 1;
                for (j = ak = 0, ref18 = iLen; 0 <= ref18 ? ak < ref18 : ak > ref18; j = 0 <= ref18 ? ++ak : --ak) {
                  tmpNums *= codes[aCombo[j]].length;
                }
                count += tmpNums;
              }
              break;
            case 'CGYJZX5':
              c0 = codes[0];
              c1 = codes[1];
              c2 = codes[2];
              c3 = codes[3];
              c4 = codes[4];
              c0_len = c0.length;
              c1_len = c1.length;
              c2_len = c2.length;
              c3_len = c3.length;
              c4_len = c4.length;
              if (c0_len > 0 && c1_len > 0 && c2_len > 0 && c3_len > 0 && c4_len > 0) {
                for (i = al = 0, ref19 = c0_len; 0 <= ref19 ? al < ref19 : al > ref19; i = 0 <= ref19 ? ++al : --al) {
                  for (j = am = 0, ref20 = c1_len; 0 <= ref20 ? am < ref20 : am > ref20; j = 0 <= ref20 ? ++am : --am) {
                    for (k = an = 0, ref21 = c2_len; 0 <= ref21 ? an < ref21 : an > ref21; k = 0 <= ref21 ? ++an : --an) {
                      for (l = ao = 0, ref22 = c3_len; 0 <= ref22 ? ao < ref22 : ao > ref22; l = 0 <= ref22 ? ++ao : --ao) {
                        for (m = ap = 0, ref23 = c4_len; 0 <= ref23 ? ap < ref23 : ap > ref23; m = 0 <= ref23 ? ++ap : --ap) {
                          c0i = c0[i];
                          c1j = c1[j];
                          c2k = c2[k];
                          c3l = c3[l];
                          c4m = c4[m];
                          if (![c0i, c1j, c2k, c3l, c4m].unique(true)[1].length) {
                            count++;
                          }
                        }
                      }
                    }
                  }
                }
              }
              break;
            case 'CGYJZX4':
              c0 = codes[0];
              c1 = codes[1];
              c2 = codes[2];
              c3 = codes[3];
              c0_len = c0.length;
              c1_len = c1.length;
              c2_len = c2.length;
              c3_len = c3.length;
              if (c0_len > 0 && c1_len > 0 && c2_len > 0 && c3_len > 0) {
                for (i = aq = 0, ref24 = c0_len; 0 <= ref24 ? aq < ref24 : aq > ref24; i = 0 <= ref24 ? ++aq : --aq) {
                  for (j = ar = 0, ref25 = c1_len; 0 <= ref25 ? ar < ref25 : ar > ref25; j = 0 <= ref25 ? ++ar : --ar) {
                    for (k = as = 0, ref26 = c2_len; 0 <= ref26 ? as < ref26 : as > ref26; k = 0 <= ref26 ? ++as : --as) {
                      for (l = at = 0, ref27 = c3_len; 0 <= ref27 ? at < ref27 : at > ref27; l = 0 <= ref27 ? ++at : --at) {
                        c0i = c0[i];
                        c1j = c1[j];
                        c2k = c2[k];
                        c3l = c3[l];
                        if (![c0i, c1j, c2k, c3l].unique(true)[1].length) {
                          count++;
                        }
                      }
                    }
                  }
                }
              }
              break;
            case 'LTZX3':
            case 'CGYJZX3':
              c0 = codes[0];
              c1 = codes[1];
              c2 = codes[2];
              c0_len = c0.length;
              c1_len = c1.length;
              c2_len = c2.length;
              if (c0_len > 0 && c1_len > 0 && c2_len > 0) {
                for (i = au = 0, ref28 = c0_len; 0 <= ref28 ? au < ref28 : au > ref28; i = 0 <= ref28 ? ++au : --au) {
                  for (j = av = 0, ref29 = c1_len; 0 <= ref29 ? av < ref29 : av > ref29; j = 0 <= ref29 ? ++av : --av) {
                    for (k = aw = 0, ref30 = c2_len; 0 <= ref30 ? aw < ref30 : aw > ref30; k = 0 <= ref30 ? ++aw : --aw) {
                      c0i = c0[i];
                      c1j = c1[j];
                      c2k = c2[k];
                      if (![c0i, c1j, c2k].unique(true)[1].length) {
                        count++;
                      }
                    }
                  }
                }
              }
              break;
            case 'LTZX2':
            case 'CGYJZX2':
              c0 = codes[0];
              c1 = codes[1];
              c0_len = c0.length;
              c1_len = c1.length;
              if (c0_len > 0 && c1_len > 0) {
                h = Array.intersection(c0, c1).length;
                count = c0_len * c1_len - h;
              }
              break;
            case 'LTDWD':
            case 'LTDDS':
            case 'CGJDWD':
              for (i = ax = 0, ref31 = this.placeCount; 0 <= ref31 ? ax < ref31 : ax > ref31; i = 0 <= ref31 ? ++ax : --ax) {
                count += codes[i].length;
              }
              break;
            case 'LTZU3':
            case 'LTZU2':
            case 'LTBDW':
            case 'LTCZW':
            case 'LTRX1':
            case 'LTRX2':
            case 'LTRX3':
            case 'LTRX4':
            case 'LTRX5':
            case 'LTRX6':
            case 'LTRX7':
            case 'LTRX8':
              c0 = codes[0];
              c0_len = c0.length;
              if (c0_len >= minchosen[0]) {
                count += Math.combination(c0_len, minchosen[0]);
              }
              break;
            case 'LTDTZU3':
            case 'LTDTZU2':
            case 'LTRXDT2':
            case 'LTRXDT3':
            case 'LTRXDT4':
            case 'LTRXDT5':
            case 'LTRXDT6':
            case 'LTRXDT7':
            case 'LTRXDT8':
              danlen = codes[0].length;
              tuolen = codes[1].length;
              sellen = +this.methodName.charAt(this.methodName.length - 1);
              if (danlen < 1 || tuolen < 1 || danlen >= sellen) {
                count = 0;
              } else {
                count = Math.combination(tuolen, sellen - danlen);
              }
              break;
            case 'K3SBTHFU':
              for (i = ay = 0, ref32 = this.placeCount; 0 <= ref32 ? ay < ref32 : ay > ref32; i = 0 <= ref32 ? ++ay : --ay) {
                len = codes[i].length;
                if (len > 2) {
                  count += len * (len - 1) * (len - 2) / 6;
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 3);
              }
              break;
            case 'K3ETHDXFU':
              c0 = (function() {
                var az, len1, ref33, results;
                ref33 = codes[0];
                results = [];
                for (az = 0, len1 = ref33.length; az < len1; az++) {
                  n = ref33[az];
                  results.push(n.charAt(0));
                }
                return results;
              })();
              c1 = codes[1];
              c0_len = c0.length;
              c1_len = c1.length;
              if (c0_len > 0 && c1_len > 0) {
                h = Array.intersection(c0, c1).length;
                count = c0_len * c1_len - h;
              }
              break;
            case 'K3EBTHFU':
              c0 = codes[0];
              console.log(c0);
              c0_len = c0.length;
              if (c0_len >= minchosen[0]) {
                count += Math.combination(c0_len, minchosen[0]);
              }
              break;
            case 'K3HV':
              cc = {
                3: 1,
                4: 1,
                5: 2,
                6: 3,
                7: 4,
                8: 5,
                9: 6,
                10: 6,
                11: 6,
                12: 6,
                13: 5,
                14: 4,
                15: 3,
                16: 2,
                17: 1,
                18: 1
              };
              for (i = az = 0, ref33 = this.placeCount; 0 <= ref33 ? az < ref33 : az > ref33; i = 0 <= ref33 ? ++az : --az) {
                len = codes[i].length;
                for (j = ba = 0, ref34 = len; 0 <= ref34 ? ba < ref34 : ba > ref34; j = 0 <= ref34 ? ++ba : --ba) {
                  count += cc[parseInt(codes[i][j], 10)];
                }
              }
              if (this.isrx) {
                count *= this.defCount === 0 ? 0 : Math.combination(this.defCount, 2);
              }
              break;
            default:
              for (i = bb = 0, ref35 = this.placeCount; 0 <= ref35 ? bb < ref35 : bb > ref35; i = 0 <= ref35 ? ++bb : --bb) {
                if (codes[i].length === 0) {
                  tmp_nums = 0;
                  break;
                }
                tmp_nums *= codes[i].length;
              }
              count = tmp_nums;
          }
        }
        money = Math.round(this.multiple * count * 2 * 1000) / 1000;
        this.data = {
          count: count,
          money: money
        };
        console.log('checkNum: ', this.data);
        if (this.error.length) {
          console.warn('errorNum: ', this.error);
        }
        return this.data;
      };

      Algorithm.prototype._HHZXcheck = function(n, len) {
        var a;
        if (len === 2) {
          a = ['00', '11', '22', '33', '44', '55', '66', '77', '88', '99'];
        } else {
          a = ['000', '111', '222', '333', '444', '555', '666', '777', '888', '999'];
        }
        n = n.toString();
        if ($.inArray(n, a) === -1) {
          return true;
        }
        return false;
      };

      Algorithm.prototype._ZUSDScheck = function(n, len) {
        var first, i, p, ref, second, third;
        if (len !== 3) {
          return false;
        }
        first = '';
        second = '';
        third = '';
        i = 0;
        for (i = p = 0, ref = len; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
          switch (i) {
            case 0:
              first = n.substr(i, 1);
              break;
            case 1:
              second = n.substr(i, 1);
              break;
            case 2:
              third = n.substr(i, 1);
          }
        }
        if (first === second && second === third) {
          return false;
        }
        if (first === second || second === third || third === first) {
          return true;
        }
        return false;
      };

      Algorithm.prototype._ZULDScheck = function(n, len) {
        var first, i, p, ref, second, third;
        if (len !== 3) {
          return false;
        }
        first = '';
        second = '';
        third = '';
        i = 0;
        for (i = p = 0, ref = len; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
          switch (i) {
            case 0:
              first = n.substr(i, 1);
              break;
            case 1:
              second = n.substr(i, 1);
              break;
            case 2:
              third = n.substr(i, 1);
          }
        }
        if (first === second || second === third || third === first) {
          return false;
        } else {
          return true;
        }
      };

      Algorithm.prototype._SDinputCheck = function(n) {
        var i, j, len, num, nums, p, q, ref, ref1, ref2;
        nums = n.split(' ');
        len = nums.length;
        for (i = p = 0, ref = len; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
          num = +nums[i];
          if (num > 11 || num < 1) {
            return false;
          }
          for (j = q = ref1 = i + 1, ref2 = len; ref1 <= ref2 ? q < ref2 : q > ref2; j = ref1 <= ref2 ? ++q : --q) {
            if (num === +nums[j]) {
              return false;
            }
          }
        }
        return true;
      };

      Algorithm.prototype._K3InputTHCheck = function(n) {
        var i, len, num, nums, p, ref, temp;
        nums = n.split('');
        len = nums.length;
        for (i = p = 0, ref = len; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
          num = +nums[i];
          if (num > 6 || num < 1) {
            return false;
          }
        }
        temp = nums.unique(true);
        if (!(temp[0].length === 2 && temp[1].length === 1)) {
          return false;
        }
        return true;
      };

      Algorithm.prototype._K3InputBTHCheck = function(n) {
        var i, j, len, num, nums, p, q, ref, ref1, ref2;
        nums = n.split('');
        len = nums.length;
        for (i = p = 0, ref = len; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
          num = +nums[i];
          if (num > 6 || num < 1) {
            return false;
          }
          for (j = q = ref1 = i + 1, ref2 = len; ref1 <= ref2 ? q < ref2 : q > ref2; j = ref1 <= ref2 ? ++q : --q) {
            if (num === +nums[j]) {
              return false;
            }
          }
        }
        return true;
      };

      Algorithm.prototype._inputCheck_Num = function(standardLen, e, callback, toSort) {
        var codes, i, len, len1, newsel, num, p, partn, ref;
        codes = this.codes;
        len = codes.length;
        newsel = [];
        partn = /^\d{3}$/;
        if ((ref = +CSH.gType) === 3 || ref === 4) {
          if (standardLen === 2 || standardLen === 5 || standardLen === 8 || standardLen === 11 || standardLen === 14 || standardLen === 17 || standardLen === 20 || standardLen === 23) {
            partn = new RegExp("^[\\d\\s]{" + standardLen + "}$");
          }
        } else {
          if (standardLen === 2 || standardLen === 4 || standardLen === 5) {
            partn = new RegExp("^\\d{" + standardLen + "}$");
          }
        }
        callback = $.isFunction(callback) ? callback : function() {
          return true;
        };
        for (i = p = 0, len1 = codes.length; p < len1; i = ++p) {
          num = codes[i];
          if (partn.test(num) && callback(num, standardLen)) {
            if (toSort) {
              if (num.indexOf(' ') === -1) {
                num = num.split('');
                num.sort();
                num = num.join('');
              } else {
                num = num.split(' ');
                num.sort();
                num = num.join(' ');
              }
            }
            this.codes[i] = num;
            newsel.push(num);
          } else {
            if (num.length > 0) {
              this.error.push(num);
            }
            len -= 1;
          }
        }
        if (e) {
          this.codes = newsel;
          return this.error;
        }
        return len;
      };

      Algorithm.prototype.getCombination = function(o, c) {
        var a, b, d, e, f, g, h, l, p, q, r, ref, ref1, ref2, ref3, s, t, u;
        l = o.length;
        r = new Array();
        f = new Array();
        if (c > l) {
          return r;
        }
        if (c === 1) {
          return o;
        }
        if (l === c) {
          r[0] = o.join(',');
          return r;
        }
        a = '';
        b = '';
        s = '';
        for (g = p = 0, ref = c; 0 <= ref ? p < ref : p > ref; g = 0 <= ref ? ++p : --p) {
          a += '1';
          b += '1';
        }
        for (e = q = 0, ref1 = l - c; 0 <= ref1 ? q < ref1 : q > ref1; e = 0 <= ref1 ? ++q : --q) {
          a += '0';
        }
        for (d = t = 0, ref2 = c; 0 <= ref2 ? t < ref2 : t > ref2; d = 0 <= ref2 ? ++t : --t) {
          s += o[d] + ',';
        }
        r[0] = s.substr(0, s.length - 1);
        h = 1;
        s = '';
        while (true) {
          if (b === a.substr(a.length - c, c)) {
            break;
          }
          a = this.movestring(a);
          for (d = u = 0, ref3 = l; 0 <= ref3 ? u < ref3 : u > ref3; d = 0 <= ref3 ? ++u : --u) {
            if ('1' === a.substr(d, 1)) {
              s += o[d] + ',';
            }
          }
          r[h] = s.substr(0, s.length - 1);
          s = '';
          h++;
        }
        return r;
      };

      Algorithm.prototype.movestring = function(a) {
        var b, c, d, e, f, g, h, j, k, p, q, ref, ref1;
        h = '';
        k = '01';
        b = '';
        f = '';
        j = '';
        g = false;
        c = false;
        for (e = p = 0, ref = a.length; 0 <= ref ? p < ref : p > ref; e = 0 <= ref ? ++p : --p) {
          if (!g) {
            h += a.substr(e, 1);
          }
          if (g === false && '1' === a.substr(e, 1)) {
            c = true;
          } else {
            if (g === false && c === true && '0' === a.substr(e, 1)) {
              g = true;
            } else {
              if (g === true) {
                b += a.substr(e, 1);
              }
            }
          }
        }
        h = h.substr(0, h.length - 2);
        for (d = q = 0, ref1 = h.length; 0 <= ref1 ? q < ref1 : q > ref1; d = 0 <= ref1 ? ++q : --q) {
          if ('1' === h.substr(d, 1)) {
            f += h.substr(d, 1);
          } else {
            if ('0' === h.substr(d, 1)) {
              j += h.substr(d, 1);
            }
          }
        }
        h = f + j;
        return h + k + b;
      };

      return Algorithm;

    })();
    Object.defineProperties(Algorithm.prototype, {
      methodId: {
        set: function(id) {
          this._methodId = id;
          this.methodName = CSH.methodMap[id];
        },
        get: function() {
          return this._methodId;
        }
      }
    });
    return Algorithm;
  });

}).call(this);
