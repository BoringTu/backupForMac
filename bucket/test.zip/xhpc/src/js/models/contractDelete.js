(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/contract/delete',
      urlRoot: CSH.path.origin + "/contract/delete"
    });
  });

}).call(this);
