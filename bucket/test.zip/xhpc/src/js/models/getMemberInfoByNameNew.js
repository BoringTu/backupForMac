(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/agentmanage/getMemberInfoByNameNew'
    });
  });

}).call(this);
