(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/membertalk/contacts'
    });
  });

}).call(this);
