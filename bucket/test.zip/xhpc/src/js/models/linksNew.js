(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/links',
      urlRoot: CSH.path.origin + "/links"
    });
  });

}).call(this);
