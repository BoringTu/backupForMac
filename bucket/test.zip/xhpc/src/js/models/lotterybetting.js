(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/lotterys/lotterybetting',
      defaults: {
        'lt_issue_start': '',
        'lt_trace_if': 'no',
        'lt_trace_stop': 'yes',
        'lt_combuy_check': 0,
        'lt_self_commissionrate': 0,
        'OrderDataList': [],
        'TraceDataList': {
          'lt_trace_issues': 1,
          'lt_trace_Times': 0

          /*
          				 * 每个订单下的字段描述
          				 * type		[string] digital、input、digitalts、dxds
          				 * methodid	[int] 玩法ID
          				 * codes		[string] 所选号码
          				 * nums		[int] 注数
          				 * times		[int] 倍数
          				 * money		[float] 注额
          				 * mode		[int] 资金模式 1、元；2、角；3、分；4、厘
          				 * point		[string] 返点
          				 * position	[string] 号码位置 0、万；1、千；2、百；3、十；4、个
          				 * desc		[string] 投注描述
           */
        }
      }
    });
  });

}).call(this);
