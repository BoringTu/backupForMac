(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/lotterys/lotteryperiod/codestatistics'
    });
  });

}).call(this);
