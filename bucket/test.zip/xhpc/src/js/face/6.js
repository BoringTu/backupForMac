(function() {
  CSH.face['6'] = [
    {
      title: '特码',
      tag: 6000,
      methodIDs: [3292],
      name: 'tema',
      desc: '开奖号码的最后一位号码为特码。当开出特码与投注号码一致、即视为中奖（其余情况则视为不中奖）。',
      getRebate: function(rebate) {
        return (rebate / 2000 / (1 / 49)).accurate(2, false);
      },
      tools: ['setMoney', 'color1', 'dxdu', 'animals', 'filterNumber', 'rapidMoney']
    }, {
      title: '正码',
      methodIDs: [3294, 3295, 3296, 3297, 3298, 3299],
      name: 'vgma',
      desc: '开奖号码的前6个号码叫正码。第一号为正码1，依次叫正码2、正码3……正码6，不以大小排序。当开出正码1与投注号码一致、即视为中奖（其余情况则视为不中奖）。',
      getRebate: function(rebate) {
        return (rebate / 2000 / (1 / 49)).accurate(2, false);
      },
      tools: ['setMoney', 'color1', 'dxdu', 'animals', 'filterNumber', 'rapidMoney'],
      labels: [
        {
          title: '正码1',
          tag: 6100
        }, {
          title: '正码2',
          tag: 6101
        }, {
          title: '正码3',
          tag: 6102
        }, {
          title: '正码4',
          tag: 6103
        }, {
          title: '正码5',
          tag: 6104
        }, {
          title: '正码6',
          tag: 6105
        }
      ]
    }, {
      title: '半波',
      tag: 6200,
      methodIDs: [3301, 3302, 3303, 3304, 3306, 3307, 3314, 3315, 3316, 3317, 3318, 3319, 3308, 3309, 3310, 3311, 3312, 3313],
      name: 'bjbo',
      desc: '以特码色波和特码单双大小为一个投注组合。当开出的特码出现在其投注组合中，即视为中奖。<br>若开出特码为49号时，所有投注半波任意一个组合接会被视为和局，并返回全部本金（不派发返点）。',
      getRebate: function(rebate, count) {
        return (rebate / 2000 / (count / 48)).accurate(2, false);
      },
      tools: ['setMoney', 'color2', 'dxdu', 'he', 'rapidMoney']
    }, {
      title: '生肖',
      methodIDs: [[3321, 3322], [3323, 3324], [3325, 3326]],
      name: 'ugxc',
      tools: ['setMoney', 'animalDxnn', 'animal1', 'animal2', 'rapidMoney'],
      labels: [
        {
          title: '特肖',
          tag: 6300,
          desc: '以特码和生肖为一个投注组合。当开出的特码出现在其投注组合中，即视为中奖。',
          getRebate: function(rebate, count) {
            return (rebate / 2000 / (count / 49)).accurate(2, false);
          }
        }, {
          title: '一肖',
          tag: 6301,
          desc: '指开出的7个开奖号码中含有投注所属生肖的一个或多个号码，即视为中奖，不论同生肖的号码出现一个或多个，派彩只派一次。',
          getRebate: function(rebate, count) {
            var rate, sum1, sum2;
            sum1 = Math.combination(49, 7);
            sum2 = Math.combination(49 - count, 7);
            rate = (sum1 - sum2) / sum1;
            return (rebate / 2000 / rate).accurate(2, false);
          }
        }, {
          title: '六肖',
          tag: 6302,
          mincount: 6,
          desc: '最少6个生肖为一注，以特码+生肖为一个投注组合。当开出的特码出现在其投注组合中，即视为中奖。',
          getRebate: function(rebate, count) {
            return (rebate / 2000 / (count * 6 / 49)).accurate(2, false);
          },
          tools: ['animalDx', 'animal1', 'rapidMoney']
        }
      ]
    }, {
      title: '尾数',
      tag: 6400,
      methodIDs: [3328, 3329, 3330, 3331, 3332, 3333, 3334, 3335, 3336, 3337],
      name: 'wzuu',
      tools: ['setMoney', 'dxdu', 'rapidMoney'],
      desc: '指7个开奖号码中含有所属尾数的一个或多个号码，不论同尾数的号码出现一个或多个，派彩只派一次。',
      getRebate: function(rebate, count) {
        var rate, sum1, sum2;
        sum1 = Math.combination(49, 7);
        sum2 = Math.combination(49 - count, 7);
        rate = (sum1 - sum2) / sum1;
        return (rebate / 2000 / rate).accurate(2, false);
      }
    }, {
      title: '总分',
      tag: 6500,
      methodIDs: [3340, 3341, 3342, 3343, 3344, 3346, 3345, 3347],
      name: 'zsff',
      tools: ['setMoney', 'dxdu', 'rapidMoney'],
      desc: '所有7个开奖号码的数值总和叫做总分。',
      getRebate: function(rebate, count) {
        return (rebate / 2000 / (1 / 2 / count)).accurate(2, false);
      },
      items: [
        {
          name: '大',
          dx: 1,
          desc: '总分大于等于175的，即视为中奖。'
        }, {
          name: '小',
          dx: 0,
          desc: '总分小于等于174的，即视为中奖。'
        }, {
          name: '单',
          du: 1,
          desc: '总分是单数的，即视为中奖。'
        }, {
          name: '双',
          du: 0,
          desc: '总分是双数的，即视为中奖。'
        }, {
          name: '大单',
          dx: 1,
          du: 1,
          desc: '总分小于等于175且为单数的，即视为中奖。'
        }, {
          name: '大双',
          dx: 1,
          du: 0,
          desc: '总分大于等于175且为双数的，即视为中奖。'
        }, {
          name: '小单',
          dx: 0,
          du: 1,
          desc: '总分小于等于174且为单数的，即视为中奖。'
        }, {
          name: '小双',
          dx: 0,
          du: 0,
          desc: '总分小于等于174且为双数的，即视为中奖。'
        }
      ]
    }, {
      title: '不中',
      methodIDs: [3349, 3350, 3351, 3352, 3353, 3354],
      name: 'buvs',
      tools: ['color1', 'color2', 'dxdu', 'animals', 'rapidMoney'],
      getRebate: function(rebate, count) {
        var rate, sum1, sum2;
        sum1 = Math.combination(49, count);
        sum2 = Math.combination(49 - 7, count);
        rate = sum2 / sum1;
        return (rebate / 2000 / rate).accurate(2, false);
      },
      labels: [
        {
          title: '五不中',
          tag: 6600,
          count: 5,
          mincount: 5,
          desc: '所投注的每五个号码为一注，每注的五个号码中如果没有当期开奖的所有7个号码中的任意一个，则视为中奖；否则视为不中奖。例如开奖号码是：6,7,8,9,10,11,12，若你投的是1,2,3,4,5则中奖，而投1,2,3,4,6则不中奖。'
        }, {
          title: '六不中',
          tag: 6601,
          count: 6,
          mincount: 6,
          desc: '所投注的每六个号码为一注，每注的六个号码中如果没有当期开奖的所有7个号码中的任意一个，则视为中奖；否则视为不中奖。例如开奖号码是：6,7,8,9,10,11,12，若你投的是1,2,3,4,5,13则中奖，而投1,2,3,4,6则不中奖。'
        }, {
          title: '七不中',
          tag: 6602,
          count: 7,
          mincount: 7,
          desc: '所投注的每七个号码为一注，每注的七个号码中如果没有当期开奖的所有7个号码中的任意一个，则视为中奖；否则视为不中奖。例如开奖号码是：6,7,8,9,10,11,12，若你投的是1,2,3,4,5,13,14则中奖，而投1,2,3,4,6则不中奖。'
        }, {
          title: '八不中',
          tag: 6603,
          count: 8,
          mincount: 8,
          desc: '所投注的每八个号码为一注，每注的八个号码中如果没有当期开奖的所有7个号码中的任意一个，则视为中奖；否则视为不中奖。例如开奖号码是：6,7,8,9,10,11,12，若你投的是1,2,3,4,5,13,14,15则中奖，而投1,2,3,4,6则不中奖。'
        }, {
          title: '九不中',
          tag: 6604,
          count: 9,
          mincount: 9,
          desc: '所投注的每九个号码为一注，每注的九个号码中如果没有当期开奖的所有7个号码中的任意一个，则视为中奖；否则视为不中奖。例如开奖号码是：6,7,8,9,10,11,12，若你投的是1,2,3,4,5,13,14,15,16则中奖，而投1,2,3,4,6则不中奖。'
        }, {
          title: '十不中',
          tag: 6605,
          count: 10,
          mincount: 10,
          desc: '所投注的每十个号码为一注，每注的十个号码中如果没有当期开奖的所有7个号码中的任意一个，则视为中奖；否则视为不中奖。例如开奖号码是：6,7,8,9,10,11,12，若你投的是1,2,3,4,5,13,14,15,16,17则中奖，而投1,2,3,4,6则不中奖。'
        }
      ]
    }
  ];

}).call(this);
