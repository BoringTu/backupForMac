﻿CSH.face['5'] = [{
	isdefault: 1,
	title: '三连号',
	label: [{
		gtitle: '三连号',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '123&234&345&456',
					text: '三连号通选',
					place: 0
				}],
			},
			methodid: 3267,
			istx: 1,
			name: '三连号通选',
			methoddesc: '对所有三个相连的号码进行投注。',
			methodhelp: '开奖号码为三连号（123或234或345或456）即为中奖。',
			methodexample: '投注方案：三连号通选<br>开奖号码：123或234或345或456 即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}, {
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '123|234|345|456',
					place: 0
				}],
			},
			methodid: 3265,
			name: '三连号单选',
			methoddesc: '选择任意一组以上三位相连的号码。',
			methodhelp: '从123，234，345，456中选择任意一组或一组以上号码，若和开奖号相同即为中奖。',
			methodexample: '投注方案：123<br>开奖号码：123，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}, {
	title: '三同号',
	label: [{
		gtitle: '三同号',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '111&222&333&444&555&666',
					text: '三同号通选',
					place: 0
				}],
			},
			methodid: 3270,
			istx: 1,
			name: '三同号通选',
			methoddesc: '对所有三个相同的号码进行投注。',
			methodhelp: '开奖号码为三同号（111或222或333或444或555或666）即为中奖。',
			methodexample: '投注方案：三同号通选<br>开奖号码：111或222或333或444或555或666 即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}, {
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '111|222|333|444|555|666',
					place: 0
				}],
			},
			methodid: 3269,
			name: '三同号单选',
			methoddesc: '选择任意一组以上三个相同的号码。',
			methodhelp: '从111，222，333，444，555，666中选择任意一组或一组以上号码，若和开奖号相同即为中奖。',
			methodexample: '投注方案：111<br>开奖号码：111，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}, {
	title: '三不同号',
	label: [{
		gtitle: '三不同号',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '1|2|3|4|5|6',
					place: 0
				}],
			},
			methodid: 3273,
			name: '三不同号复式',
			methoddesc: '选择任意三个或以上的号码进行投注。',
			methodhelp: '从1-6中任意选择3个号码组成一注，顺序不限，即为中奖。',
			methodexample: '投注方案：2、5、6<br>开奖号码：2、5、6 (顺序不限)，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}, {
			selectarea: {
				type: 'input',
			},
			methodid: 3272,
			iszxdu: 1,
			name: '三不同号单式',
			methoddesc: '对三个各不相同的号码进行投注。',
			methodhelp: '从1-6中任意选择3个号码组成一注，顺序不限，即为中奖。',
			methodexample: '投注方案：256<br>开奖号码：2、5、6 (顺序不限)，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}, {
	title: '二同号',
	label: [{
		gtitle: '二同号单选',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '二同号',
					no: '11|22|33|44|55|66',
					place: 0
				}, {
					title: '不同号',
					no: '1|2|3|4|5|6',
					place: 1
				}],
			},
			methodid: 3277,
			name: '二同号单选复式',
			methoddesc: '选择1个对子和1个与之不同的号码投注。',
			methodhelp: '选择1个对子（11、22、33、44、55、66）和1个不同的号码(1、2、3、4、5、6)投注，选号与开奖号码一致即中奖。',
			methodexample: '投注方案：112<br>开奖号码：112或121或211，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}, {
			selectarea: {
				type: 'input',
			},
			methodid: 3275,
			iseth: 1,
			name: '二同号单选单式',
			methoddesc: '至少输入一个三位数号码组成一注。',
			methodhelp: '每组号码包含1个对子（11、22、33、44、55、66）和1个不同的号码(1、2、3、4、5、6)投注，选号与开奖号码一致即中奖。',
			methodexample: '投注方案：112<br>开奖号码：112或121或211，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}, {
		gtitle: '二同号复选',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '11*|22*|33*|44*|55*|66*',
					place: 0
				}],
			},
			methodid: 3278,
			name: '二同号复选',
			methoddesc: '选择对子(11*、22*、33*、44*、55*、66*)进行投注。',
			methodhelp: '选择对子(11*、22*、33*、44*、55*、66*)投注，开奖号码中包含选择的对子即中奖。',
			methodexample: '投注方案：11*<br>开奖号码：112或121或211，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}, {
	title: '二不同号',
	label: [{
		gtitle: '二不同号',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '1|2|3|4|5|6',
					place: 0,
					minchosen: 2
				}],
			},
			methodid: 3281,
			name: '二不同号复式',
			methoddesc: '从1-6中任意选择2个或2个以上号码。',
			methodhelp: '从1-6中任意选择2个号码组成一注，顺序不限。',
			methodexample: '投注方案：2、5<br>开奖号码：2、5、* (顺序不限)，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}, {
			selectarea: {
				type: 'input',
			},
			methodid: 3280,
			iszxdu: 1,
			name: '二不同号单式',
			methoddesc: '从1-6中任意选择2个或2个以上号码。',
			methodhelp: '从1-6中任意选择2个号码组成一注，顺序不限。',
			methodexample: '投注方案：25<br>开奖号码：2、5、* (顺序不限)，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}, {
	title: '和值',
	label: [{
		gtitle: '和值',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '',
					no: '3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
					place: 0
				}],
			},
			methodid: 3283,
			ishv: 1,
			name: '和值',
			methoddesc: '从3-18中任意选择1个或1个以上号码。',
			methodhelp: '所选数值等于开奖号码相加之和，即为中奖。',
			methodexample: '投注方案：和值4<br>开奖号码：112，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}, {
	title: '大小单双',
	label: [{
		gtitle: '大小单双',
		label: [{
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '大|小|单|双',
					place: 0
				}]
			},
			methodid: 3285,
			name: '大小单双',
			methoddesc: '对号码的三位数和值的大小单双形态进行投注。',
			methodhelp: '对号码的三位数和值的大小形态进行投注。<br>注：3<=和值<11，则为小；10<和值<=18,则为大。',
			methodexample: '投注方案：小<br>开奖号码：1、4、5，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '猜1个号',
	label: [{
		gtitle: '猜1个号',
		label: [{
			selectarea: {
				type: 'dice',
				layout: [{
					title: '',
					no: '1|2|3|4|5|6',
					place: 0
				}],
			},
			methodid: 3289,
			name: '猜1个号',
			methoddesc: '选择任意一个或以上的号码进行投注。',
			methodhelp: '选择一个或以上您认为一定会开出的号码，所选号码在开奖号码中出现。',
			methodexample: '投注方案：1<br>开奖号码：1、*、*，顺序不限，即为中奖。',
			maxcodecount: 0,
			defaultposition: '000'
		}]
	}]
}];
