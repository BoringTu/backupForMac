﻿CSH.face['4'] = [{
	title: '猜冠军',
	label: [{
		gtitle: '猜冠军',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '冠军',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}]
			},
			methodid: 3240,
			yllrType: [1, [0]],
			name: '猜冠军',
			methoddesc: '第一位至少选择1个号码。',
			methodhelp: '所选号码与当期顺序摇出的10个号码中的前1个号码相同即为中奖。',
			methodexample: '投注方案：第一位：01<br>开奖号码：01、*、*、*、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '猜冠亚军',
	label: [{
		gtitle: '猜冠亚军',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '冠军',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}, {
					title: '亚军',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 1
				}]
			},
			methodid: 3242,
			yllrType: [1, [0, 1]],
			name: '复式',
			methoddesc: '从第一位、第二位中至少各选择1个号码。',
			methodhelp: '从01-10共10个号码中选择2个不重复的号码组成一注，所选号码与当期顺序摇出的10个号码中的前2个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：第一位：01，第二位：02<br>开奖号码：01、02、*、*、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 3243,
			name: '单式',
			methoddesc: '至少输入1个两位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入2个号码组成一注，所输入的号码与当期顺序摇出的5个号码中的前2个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02<br>开奖号码：01、02、*、*、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	isdefault: 1,
	title: '猜前三名',
	label: [{
		gtitle: '猜前三名',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 1
				}, {
					title: '第三位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 2
				}]
			},
			methodid: 3245,
			yllrType: [1, [0, 1, 2]],
			name: '复式',
			methoddesc: '从第一位、第二位、第三位中至少各选择1个号码。',
			methodhelp: '从01-10共10个号码中选择3个不重复的号码组成一注，所选号码与当期顺序摇出的10个号码中的前3个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：第一位：01，第二位：02，第三位：03<br>开奖号码：01、02、03、*、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 3246,
			name: '单式',
			methoddesc: '至少输入1个三位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入3个号码组成一注，所输入的号码与当期顺序摇出的10个号码中的前3个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02 03<br>开奖号码：01、02、03、*、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '猜前四名',
	label: [{
		gtitle: '猜前四名',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 1
				}, {
					title: '第三位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 2
				}, {
					title: '第四位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 3
				}]
			},
			methodid: 3249,
			yllrType: [1, [0, 1, 2, 3]],
			name: '复式',
			methoddesc: '从第一位、第二位、第三位、第四位中各选择1个号码。',
			methodhelp: '冠军、亚军、第三名、第四名各选一个号码，所选号码与开奖号码前4名车号相同，且顺序一致，即中奖',
			methodexample: '投注方案：第一位：01，第二位：02，第三位：03，第四位：04<br>开奖号码：01、02、03、04、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 3250,
			name: '单式',
			methoddesc: '至少输入1个四位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入4个号码组成一注，所输入的号码与当期顺序摇出的10个号码中的前4个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02 03 04<br>开奖号码：01、02、03、04、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '猜前五名',
	label: [{
		gtitle: '猜前五名',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 1
				}, {
					title: '第三位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 2
				}, {
					title: '第四位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 3
				}, {
					title: '第五位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 4
				}]
			},
			methodid: 3252,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '复式',
			methoddesc: '从第一位、第二位、第三位、第四位、第五位中各选择1个号码。',
			methodhelp: '冠军、亚军、第三名、第四名、第五位各选一个号码，所选号码与开奖号码前5名车号相同，且顺序一致，即中奖',
			methodexample: '投注方案：第一位：01，第二位：02，第三位：03，第四位：04，第五位：05<br>开奖号码：01、02、03、04、05、*、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 3253,
			name: '单式',
			methoddesc: '至少输入1个五位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入5个号码组成一注，所输入的号码与当期顺序摇出的10个号码中的前5个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02 03 04 05<br>开奖号码：01、02、03、04、05、*、*、*、*、*，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '定位胆',
	label: [{
		gtitle: '定位胆',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 1
				}, {
					title: '第三位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 2
				}, {
					title: '第四位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 3
				}, {
					title: '第五位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 4
				}]
			},
			methodid: 3255,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '前五名',
			methoddesc: '在第一名，第二名，第三名，第四名，第五名任意位置上任意选择1个或1个以上号码。',
			methodhelp: '从第一名，第二名，第三名，第四名，第五名任意位置上至少选择1个以上号码，所选号码与相同位置上的开奖号码一致，即为中奖。',
			methodexample: '投注方案：第一名：1<br>开奖号码：第一名：1，即中定位胆第一名一等奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第六位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 0
				}, {
					title: '第七位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 1
				}, {
					title: '第八位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 2
				}, {
					title: '第九位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 3
				}, {
					title: '第十位',
					no: '01|02|03|04|05|06|07|08|09|10',
					place: 4
				}]
			},
			methodid: 3256,
			yllrType: [1, [5, 6, 7, 8, 9]],
			name: '后五名',
			methoddesc: '在第六名，第七名，第八名，第九名，第拾名任意位置上任意选择1个或1个以上号码。',
			methodhelp: '从第六名，第七名，第八名，第九名，第拾名任意位置上至少选择1个以上号码，所选号码与相同位置上的开奖号码一致，即为中奖。',
			methodexample: '投注方案：第六名：1<br>开奖号码：第六名：1，即中定位胆第六名一等奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '大小单双',
	label: [{
		gtitle: '大小单双',
		label: [{
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '第一名',
					no: '大|小|单|双',
					place: 0
				}, {
					title: '第二名',
					no: '大|小|单|双',
					place: 1
				}, {
					title: '第三名',
					no: '大|小|单|双',
					place: 2
				}]
			},
			methodid: 3258,
			yllrType: [2, [0, 1, 2]],
			name: '大小单双',
			methoddesc: '从第一名、第二名、第三名中的“大、小、单、双”中至少选一个组成一注。',
			methodhelp: '对第一名、第二名、第三的“大（6 7 8 9 10）小（1 2 3 4 5）、单（1 3 5 7 9）双（2 4 6 8 10）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。',
			methodexample: '投注方案：第一名：小<br>开奖号码：第一名：小，即中第一名大小单双一等奖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}];
