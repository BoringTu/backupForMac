CSH.face['1'] = [{
	title: '五星',
	label: [{
		gtitle: '五星直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 4
				}]
			},
			methodid: 2067,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '复式',
			methoddesc: '从万、千、百、十、个位各选一个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中选择一个5位数号码组成一注，所选号码与开奖号码全部相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：13456<br>开奖号码：13456，即中五星直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2068,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个五位数号码组成一注(一次最大可投注100000注)。',
			methodhelp: '手动输入一个5位数号码组成一注，所选号码的万、千、百、十、个位与开奖号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：23456<br>开奖号码：23456，即中五星直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'zhdxdu',
				layout: [{
					title: '选号',
					no: '总和大|总和小|总和单|总和双',
					place: 0
				}]
			},
			methodid: 2076,
			name: '总和大小单双',
			methoddesc: '选择一个号码形态。',
			methodhelp: '从四个形态中任意选择1个形态或多个形态组成一注，所选号码形态与开奖号码的总和形态一致，即为中奖。',
			methodexample: '投注方案：总和大<br>开奖号码：16568，开奖号码的总和26，即中总和大。',
			maxcodecount: 0,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 4
				}]
			},
			methodid: 2069,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '组合',
			methoddesc: '从万、千、百、十、个位各选一个号码组成五注。',
			methodhelp: '从万、千、百、十、个位中至少各选一个号码组成1-5星的组合，共五注，所选号码的个位与开奖号码全部相同，则中1个5等奖；所选号码的个位、十位与开奖号码相同，则中1个5等奖以及1个4等奖，依此类推，最高可中5个奖。',
			methodexample: '投注方案：购买4+5+6+7+8，该票共10元，由以下5注：45678(五星)、5678(四星)、678(三星)、78(二星)、8(一星)构成。<br>开奖号码：45678，即可中五星、四星、三星、二星、一星各1注',
			maxcodecount: 0,
			defaultposition: '00000',
		}*/]
	}, {
		gtitle: '五星组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选120',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 5
				}]
			},
			methodid: 2070,
			name: '组选120',
			methoddesc: '从0-9中选择5个号码组成一注。',
			methodhelp: '从0-9中任意选择5个号码组成一注，所选号码与开奖号码的万、千、百、十、个位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：10568<br>开奖号码：10568（顺序不限），即可中五星组选120。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 3
				}]
			},
			methodid: 2071,
			name: '组选60',
			methoddesc: '从“二重号”选择一个号码，“单号”中选择三个号码组成一注。',
			methodhelp: '选择1个二重号码和3个单号号码组成一注，所选的单号号码与开奖号码相同，且所选二重号码在开奖号码中出现了2次，即为中奖。',
			methodexample: '投注方案：二重号：8；单号：016<br>开奖号码：01688（顺序不限），即可中五星组选60。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 2
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 1
				}]
			},
			methodid: 2072,
			name: '组选30',
			methoddesc: '从“二重号”选择两个号码，“单号”中选择一个号码组成一注。',
			methodhelp: '选择2个二重号和1个单号号码组成一注，所选的单号号码与开奖号码相同，且所选的2个二重号码分别在开奖号码中出现了2次，即为中奖。',
			methodexample: '投注方案：二重号：68；单号：0<br>开奖号码：06688（顺序不限），即可中五星组选30。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '三重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 2
				}]
			},
			methodid: 2073,
			name: '组选20',
			methoddesc: '从“三重号”选择一个号码，“单号”中选择两个号码组成一注。',
			methodhelp: '选择1个三重号码和2个单号号码组成一注，所选的单号号码与开奖号码相同，且所选三重号码在开奖号码中出现了3次，即为中奖。',
			methodexample: '投注方案：三重号：8；单号：01<br>开奖号码：01888（顺序不限），即可中五星组选20。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '三重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 1
				}]
			},
			methodid: 2074,
			name: '组选10',
			methoddesc: '从“三重号”选择一个号码，“二重号”中选择一个号码组成一注。',
			methodhelp: '选择1个三重号码和1个二重号码，所选三重号码在开奖号码中出现3次，并且所选二重号码在开奖号码中出现了2次，即为中奖。',
			methodexample: '投注方案：三重号：8；二重号：1<br>开奖号码：11888（顺序不限），即可中五星组选10。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}, {
		gtitle: '五星特殊',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '一帆风顺',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2184,
			name: '一帆风顺',
			methoddesc: '从0-9中任意选择1个以上号码。',
			methodhelp: '从0-9中任意选择1个号码组成一注，只要开奖号码的万、千、百、十、个位中包含所选号码，即为中奖。',
			methodexample: '投注方案：8<br>开奖号码：至少出现1个8，即中一帆风顺。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '好事成双',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2185,
			name: '好事成双',
			methoddesc: '从0-9中任意选择1个以上的二重号码。',
			methodhelp: '从0-9中任意选择1个号码组成一注，只要所选号码在开奖号码的万、千、百、十、个位中出现2次，即为中奖。',
			methodexample: '投注方案：8<br>开奖号码：至少出现2个8，即中好事成双。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '三星报喜',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2186,
			name: '三星报喜',
			methoddesc: '从0-9中任意选择1个以上的三重号码。',
			methodhelp: '从0-9中任意选择1个号码组成一注，只要所选号码在开奖号码的万、千、百、十、个位中出现3次，即为中奖。',
			methodexample: '投注方案：8<br>开奖号码：至少出现3个8，即中三星报喜。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '四季发财',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2187,
			name: '四季发财',
			methoddesc: '从0-9中任意选择1个以上的四重号码。',
			methodhelp: '从0-9中任意选择1个号码组成一注，只要所选号码在开奖号码的万、千、百、十、个位中出现4次，即为中奖。',
			methodexample: '投注方案：8<br>开奖号码：至少出现4个8，即中四季发财。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}, {
	title: '四星',
	label: [{
		gtitle: '四星直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}]
			},
			methodid: 2078,
			yllrType: [1, [1, 2, 3, 4]],
			name: '复式',
			methoddesc: '从千、百、十、个位各选一个号码组成一注。',
			methodhelp: '从千、百、十、个位中选择一个4位数号码组成一注，所选号码与开奖号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：3456<br>开奖号码：3456，即中四星直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2079,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个四位数号码组成一注。',
			methodhelp: '手动输入一个4位数号码组成一注，所选号码的千、百、十、个位与开奖号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：3456<br>开奖号码：3456，即中四星直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}]
			},
			methodid: 2080,
			yllrType: [1, [1, 2, 3, 4]],
			name: '组合',
			methoddesc: '从千、百、十、个位各选一个号码组成四注。',
			methodhelp: '从千、百、十、个位中至少各选一个号码组成1-4星的组合，共四注，所选号码的个位与开奖号码相同，则中1个4等奖；<br>所选号码的个、十位与开奖号码相同，则中1个4等奖以及1个3等奖，依此类推，最高可中4个奖。',
			methodexample: '投注方案：购买5+6+7+8，该票共8元，由以下4注：5678(四星)、678(三星)、78(二星)、8(一星)构成。<br>开奖号码：5678，即可中四星、三星、二星、一星各1注',
			maxcodecount: 0,
			defaultposition: '00000',
		}*/]
	}, {
		gtitle: '后四组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选24',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 4
				}]
			},
			methodid: 2081,
			name: '组选24',
			methoddesc: '从0-9中选择4个号码组成一注。',
			methodhelp: '从0-9中任意选择4个号码组成一注，所选号码与开奖号码的千、百、十、个位相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：0568<br>开奖号码：*0568（顺序不限），即可中四星组选24。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 2
				}]
			},
			methodid: 2082,
			name: '组选12',
			methoddesc: '从“二重号”选择一个号码，“单号”中选择两个号码组成一注。',
			methodhelp: '选择1个二重号码和2个单号号码组成一注，所选号码与开奖号码的千、百、十、个位相同，且所选二重号码在开奖号码中出现了2次，即为中奖。',
			methodexample: '投注方案：二重号：8；单号：06<br>开奖号码：*0688（顺序不限），即可中四星组选12。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 2
				}]
			},
			methodid: 2083,
			name: '组选6',
			methoddesc: '从“二重号”中选择两个号码组成一注。',
			methodhelp: '选择2个二重号码组成一注，所选的2个二重号码在开奖号码的千、百、十、个位中分别出现了2次，即为中奖。',
			methodexample: '投注方案：二重号：28<br>开奖号码：*2288（顺序不限），即可中四星组选6。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '三重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 1
				}]
			},
			methodid: 2084,
			name: '组选4',
			methoddesc: '从“三重号”中选择一个号码，“单号”中选择一个号码组成一注。',
			methodhelp: '选择1个三重号码和1个单号号码组成一注，所选号码与开奖号码的千、百、十、个位相同，且所选三重号码在开奖号码中出现了3次，即为中奖。',
			methodexample: '投注方案：三重号：8；单号：2<br>开奖号码：*8828（顺序不限），即可中四星组选4。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}, {
	title: '后三',
	label: [{
		gtitle: '后三直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}]
			},
			methodid: 2123,
			yllrType: [1, [2, 3, 4]],
			name: '复式',
			methoddesc: '从百、十、个位各选一个号码组成一注。',
			methodhelp: '从百、十、个位中选择一个3位数号码组成一注，所选号码与开奖号码后3位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：345<br>开奖号码：345，即中后三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2124,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码组成一注。',
			methodhelp: '手动输入一个3位数号码组成一注，所选号码与开奖号码的百、十、个位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：345<br>开奖号码：345，即中后三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}]
			},
			methodid: 2127,
			yllrType: [1, [2, 3, 4]],
			name: '组合',
			methoddesc: '从百、十、个位各选一个号码组成三柱。',
			methodhelp: '从百、十、个位中至少各选择一个号码组成1-3星的组合共三注，当个位号码与开奖号码相同，则中1个3等奖；如果个位与十位号码与开奖号码相同，则中1个3等奖以及1个2等奖，依此类推，最高可中3个奖。',
			methodexample: '投注方案：购买：6+7+8，该票共6元，由以下3注：678(三星)、78(二星)、8(一星)构成<br>开奖号码：678，即可中三星、二星、一星各1注。',
			maxcodecount: 0,
			defaultposition: '00000',
		}*/, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
					place: 0
				}]
			},
			methodid: 2125,
			yllrType: [3, 0],
			name: '和值',
			methoddesc: '从0-27中任意选择1个或1个以上号码。',
			methodhelp: '所选数值等于开奖号码的百、十、个位三个数字相加之和，即为中奖。',
			methodexample: '投注方案：和值1<br>开奖号码：后三位001，010，100，即中后三直选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '跨度',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2126,
			yllrType: [3, 4],
			name: '跨度',
			methoddesc: '从0-9中选择1个以上号码。',
			methodhelp: '所选数值等于开奖号码的后3位最大与最小数字相减之差，即为中奖。',
			methodexample: '投注方案：跨度8<br>开奖号码：后三位0,8,X，其中X不等于9；或者后三位1,9,X，其中X不等于0，即可中后三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}, {
		gtitle: '后三组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组三',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2128,
			name: '组三复式',
			methoddesc: '从0-9中任意选择2个或2个以上号码。',
			methodhelp: '从0-9中选择2个数字组成两注，所选号码与开奖号码的百、十、个位相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：588<br>开奖号码：后三位588（顺序不限），即可中后三组选三。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2130,
			iszxdu: 1,
			name: '组三单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码（三个数字中必须有二个数字相同）。',
			methodhelp: '手动输入一个3位数号码组成一注，三个数字中必须有二个数字相同，输入号码与开奖号码的百、十、个位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：001<br>开奖号码：后三位 010（顺序不限），即中后三组选三。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组六',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2129,
			name: '组六复式',
			methoddesc: '从0-9中任意选择3个或3个以上号码。',
			methodhelp: '从0-9中任意选择3个号码组成一注，所选号码与开奖号码的百、十、个位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：258<br>开奖号码：后三位 852（顺序不限），即中后三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2131,
			iszxdu: 1,
			name: '组六单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码（三个数字完全不相同）。',
			methodhelp: '手动输入一个3位数号码组成一注，所选号码与开奖号码的百、十、个位相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：123<br>开奖号码：后三位 321（顺序不限），即中后三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2132,
			iszxdu: 1,
			name: '混合组选',
			methoddesc: '手动输入号码，至少输入1个三位数号码。',
			methodhelp: '手动输入一个3位数号码组成一注（不含豹子号），开奖号码的百、十、个位符合后三组三或者组六均为中奖。',
			methodexample: '投注方案：001 和 123<br>开奖号码：后三位 010（顺序不限）即中后三组选三，或者后三位 312（顺序不限）即中后三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
					place: 0
				}]
			},
			methodid: 2133,
			name: '组选和值',
			methoddesc: '从1-26中选择1个号码。',
			methodhelp: '所选数值等于开奖号码百、十、个位三个数字相加之和(非豹子号)，即为中奖。',
			methodexample: '投注方案：和值3<br>开奖号码：后三位 003（顺序不限）即中后三组选三，或者后三位 012（顺序不限）即中后三组选六。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '包胆',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2134,
			name: '组选包胆',
			methoddesc: '从0-9中选择1个号码。',
			methodhelp: '从0-9中任意选择1个包胆号码，开奖号码的百、十、个位中任意1位与所选包胆号码相同(不含豹子号)，即为中奖。',
			methodexample: '投注方案：包胆3<br>开奖号码：后三位 3XX 或者 33X，即中后三组选三，后三位 3XY，即中后三组选六。',
			maxcodecount: 1,
			defaultposition: '00000',
		}*/]
	}, {
		gtitle: '后三其它',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值尾数',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2135,
			name: '和值尾数',
			methoddesc: '从0-9中选择1个号码。',
			methodhelp: '所选数值等于开奖号码的百、十、个位三个数字相加之和的尾数，即为中奖。',
			methodexample: '投注方案：和值尾数 8<br>开奖号码：后三位 936，和值位数为8，即中和值尾数。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digitalts',
				layout: [{
					title: '特殊号',
					no: '豹子|顺子|对子',
					place: 0
				}]
			},
			methodid: 2136,
			name: '特殊号',
			methoddesc: '选择一个号码形态。',
			methodhelp: '所选的号码特殊属性和开奖号码后3位的属性一致，即为中奖。其中：1.顺子号的个、十、百位不分顺序；2.对子号指的是开奖号码的后三位当中，任意2位数字相同的三位数号码。',
			methodexample: '投注方案：豹子顺子对子<br>开奖号码：后三位 888，即中豹子；后三位 678，即中顺子；后三位 558，即中对子。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}
, {
	title: '中三',
	label: [{
		gtitle: '中三直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}]
			},
			methodid: 2106,
			yllrType: [1, [1, 2, 3]],
			name: '复式',
			methoddesc: '从千、百、十位各选一个号码组成一注。',
			methodhelp: '从千、百、十位中选择一个3位数号码组成一注，所选号码与开奖号码后3位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：中三位345<br>开奖号码：345，即中中三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2107,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码组成一注。',
			methodhelp: '手动输入一个3位数号码组成一注，所选号码与开奖号码的千、百、十位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：中三位345<br>开奖号码：345，即中中三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}]
			},
			methodid: 2127,
			yllrType: [1, [2, 3, 4]],
			name: '组合',
			methoddesc: '从百、十、个位各选一个号码组成三柱。',
			methodhelp: '从百、十、个位中至少各选择一个号码组成1-3星的组合共三注，当个位号码与开奖号码相同，则中1个3等奖；如果个位与十位号码与开奖号码相同，则中1个3等奖以及1个2等奖，依此类推，最高可中3个奖。',
			methodexample: '投注方案：购买：6+7+8，该票共6元，由以下3注：678(三星)、78(二星)、8(一星)构成<br>开奖号码：678，即可中三星、二星、一星各1注。',
			maxcodecount: 0,
			defaultposition: '00000',
		}*/, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
					place: 0
				}]
			},
			methodid: 2108,
			yllrType: [3, 0],
			name: '和值',
			methoddesc: '从0-27中任意选择1个或1个以上号码。',
			methodhelp: '所选数值等于开奖号码的千、百、十位三个数字相加之和，即为中奖。',
			methodexample: '投注方案：和值1<br>开奖号码：中三位001，010，100，即中中三直选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '跨度',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2109,
			yllrType: [3, 3],
			name: '跨度',
			methoddesc: '从0-9中选择1个以上号码。',
			methodhelp: '所选数值等于开奖号码的后3位最大与最小数字相减之差，即为中奖。',
			methodexample: '投注方案：跨度8<br>开奖号码：中三位0,8,X，其中X不等于9；或者中三位1,9,X，其中X不等于0，即可中中三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}
, {
		gtitle: '中三组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组三',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2111,
			name: '组三复式',
			methoddesc: '从0-9中任意选择2个或2个以上号码。',
			methodhelp: '从0-9中选择2个数字组成两注，所选号码与开奖号码的千、百、十位相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：588<br>开奖号码：中三位588（顺序不限），即可中中三组选三。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2113,
			iszxdu: 1,
			name: '组三单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码（三个数字中必须有二个数字相同）。',
			methodhelp: '手动输入一个3位数号码组成一注，三个数字中必须有二个数字相同，输入号码与开奖号码的千、百、十位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：001<br>开奖号码：中三位 010（顺序不限），即中中三组选三。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组六',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2112,
			name: '组六复式',
			methoddesc: '从0-9中任意选择3个或3个以上号码。',
			methodhelp: '从0-9中任意选择3个号码组成一注，所选号码与开奖号码的千、百、十位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：258<br>开奖号码：中三位 852（顺序不限），即中中三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2114,
			iszxdu: 1,
			name: '组六单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码（三个数字完全不相同）。',
			methodhelp: '手动输入一个3位数号码组成一注，所选号码与开奖号码的千、百、十位相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：123<br>开奖号码：中三位 321（顺序不限），即中中三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2115,
			iszxdu: 1,
			name: '混合组选',
			methoddesc: '手动输入号码，至少输入1个三位数号码。',
			methodhelp: '手动输入一个3位数号码组成一注（不含豹子号），开奖号码的千、百、十位符合中三组三或者组六均为中奖。',
			methodexample: '投注方案：001 和 123<br>开奖号码：中三位 010（顺序不限）即中中三组选三，或者中三位 312（顺序不限）即中中三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
					place: 0
				}]
			},
			methodid: 2116,
			name: '组选和值',
			methoddesc: '从1-26中选择1个号码。',
			methodhelp: '所选数值等于开奖号码千、百、十位三个数字相加之和(非豹子号)，即为中奖。',
			methodexample: '投注方案：和值3<br>开奖号码：中三位 003（顺序不限）即中中三组选三，或者中三位 012（顺序不限）即中中三组选六。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '包胆',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2134,
			name: '组选包胆',
			methoddesc: '从0-9中选择1个号码。',
			methodhelp: '从0-9中任意选择1个包胆号码，开奖号码的千、百、十位中任意1位与所选包胆号码相同(不含豹子号)，即为中奖。',
			methodexample: '投注方案：包胆3<br>开奖号码：中三位 3XX 或者 33X，即中中三组选三，中三位 3XY，即中中三组选六。',
			maxcodecount: 1,
			defaultposition: '00000',
		}*/]
}, {
		gtitle: '中三其它',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值尾数',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2118,
			name: '和值尾数',
			methoddesc: '从0-9中选择1个号码。',
			methodhelp: '所选数值等于开奖号码的中、百、个位三个数字相加之和的尾数，即为中奖。',
			methodexample: '投注方案：和值尾数 8<br>开奖号码：中三位 936，和值位数为8，即中和值尾数。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digitalts',
				layout: [{
					title: '特殊号',
					no: '豹子|顺子|对子',
					place: 0
				}]
			},
			methodid: 2119,
			name: '特殊号',
			methoddesc: '选择一个号码形态。',
			methodhelp: '所选的号码特殊属性和开奖号码后3位的属性一致，即为中奖。其中：1.顺子号的十、百、千位不分顺序；2.对子号指的是开奖号码的中三位当中，任意2位数字相同的三位数号码。',
			methodexample: '投注方案：豹子顺子对子<br>开奖号码：中三位 888，即中豹子；中三位 678，即中顺子；中三位 558，即中对子。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}
, {
	title: '前三',
	label: [{
		gtitle: '前三直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}]
			},
			methodid: 2088,
			yllrType: [1, [0, 1, 2]],
			name: '复式',
			methoddesc: '从万、千、百位各选一个号码组成一注。',
			methodhelp: '从万、千、百位中选择一个3位数号码组成一注，所选号码与开奖号码后3位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：345<br>开奖号码：前三位 345，即中前三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2089,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码组成一注。',
			methodhelp: '手动输入一个3位数号码组成一注，所选号码与开奖号码的万位、千位、百位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：345<br>开奖号码：前三位 345，即中前三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}]
			},
			methodid: 2092,
			yllrType: [1, [0, 1, 2]],
			name: '组合',
			methoddesc: '从万、千、百位各选一个号码组成三注。',
			methodhelp: '从万、千、百位中至少各选择一个号码组成1-3星的组合共三注，当百位号码与开奖号码相同，则中1个3等奖；<br>如果百位与千位号码与开奖号码相同，则中1个3等奖以及1个2等奖，依此类推，最高可中3个奖。',
			methodexample: '投注方案：购买：6+7+8，该票共6元，由以上3注：678(三星)、78(二星)、8(一星)构成<br>开奖号码：前三位 678，即可中三星、二星、一星各1注。',
			maxcodecount: 0,
			defaultposition: '00000',
		}*/, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
					place: 0
				}]
			},
			methodid: 2090,
			yllrType: [3, 1],
			name: '和值',
			methoddesc: '从0-27中任意选择1个或1个以上号码。',
			methodhelp: '所选数值等于开奖号码的万位、千位、百位三个数字相加之和，即为中奖。',
			methodexample: '投注方案：和值 1<br>开奖号码：前三位 001、010、100，即中前三直选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '跨度',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2091,
			yllrType: [3, 5],
			name: '跨度',
			methoddesc: '从0-9中选择1个号码。',
			methodhelp: '所选数值等于开奖号码的前3位最大与最小数字相减之差，即为中奖。',
			methodexample: '投注方案：跨度8<br>开奖号码：前三位0,8,X，其中X不等于9；或者前三位1,9,X，其中X不等于0，即可中前三直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}, {
		gtitle: '前三组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组三',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2093,
			name: '组三复式',
			methoddesc: '从0-9中任意选择2个或2个以上号码。',
			methodhelp: '从0-9中选择2个数字组成两注，所选号码与开奖号码的万、千、百位相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：588<br>开奖号码：前三位588（顺序不限），即可中前三组选三。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2096,
			iszxdu: 1,
			name: '组三单式',
			methoddesc: '手动输入号码，至少输入1个三位数号码（三个数字当中必须有二个数字相同）。',
			methodhelp: '手动输入一个3位数号码组成一注，三个数字当中必须有二个数字相同，所选号码与开奖号码的百、十、个位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：588<br>开奖号码：前三位588（顺序不限），即可中前三组选三。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组六',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2094,
			name: '组六复式',
			methoddesc: '从0-9中任意选择3个或3个以上号码。',
			methodhelp: '从0-9中任意选择3个号码组成一注，所选号码与开奖号码的万、千、百位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：258<br>开奖号码：前三位 852（顺序不限），即中前三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2097,
			iszxdu: 1,
			name: '组六单式',
			methoddesc: '手动输入号码，至少输入1个三位数号（三个数字全不相同）。',
			methodhelp: '手动输入一个3位数号码组成一注，所选号码与开奖号码的万、千、百位相同，顺序不限，即为中奖。',
			methodexample: '投注方案：123<br>开奖号码：前三位 312（顺序不限），即中前三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2098,
			iszxdu: 1,
			name: '混合组选',
			methoddesc: '手动输入号码，至少输入1个三位数号码。',
			methodhelp: '手动输入一个3位数号码组成一注（不含豹子号），开奖号码的万、千、百位符合前三组三或组六均为中奖。',
			methodexample: '投注方案：001 和 123<br>开奖号码：前三位 010（顺序不限）即中前三组选三，或者前三位 312（顺序不限）即中前三组选六。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
					place: 0
				}]
			},
			methodid: 2099,
			name: '组选和值',
			methoddesc: '从1-26中任意选择1个以上号码。',
			methodhelp: '所选数值等于开奖号码万、千、百位三个数字相加之和(非豹子号)，即为中奖。',
			methodexample: '投注方案：和值3<br>开奖号码：前三位 003（顺序不限）即中前三组选三，或者前三位 012（顺序不限）即中前三组选六。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '包胆',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2100,
			name: '组选包胆',
			methoddesc: '从0-9中任选1个号码。',
			methodhelp: '从0-9中任意选择1个包胆号码，开奖号码的万、千、百位中任意1位只要和所选包胆号码相同，即为中奖。',
			methodexample: '投注方案：包胆3<br>开奖号码：前三位 3XX 或者 33X，即中前三组选三，或者前三位 3XY，即中前三组选六。',
			maxcodecount: 1,
			defaultposition: '00000',
		}*/]
	}, {
		gtitle: '前三其它',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值尾数',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2101,
			name: '和值尾数',
			methoddesc: '从0-9中选择1个号码。',
			methodhelp: '所选数值等于开奖号码的万、千、百位三个数字相加之和的尾数，即为中奖。',
			methodexample: '投注方案：和值尾数 8开奖号码：前三位 936，和值位数为8，即中和值尾数。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digitalts',
				layout: [{
					title: '特殊号',
					no: '豹子|顺子|对子',
					place: 0
				}]
			},
			methodid: 2102,
			name: '特殊号',
			methoddesc: '选择一个号码形态。',
			methodhelp: '所选的号码特殊属性和开奖号码前3位的属性一致，即为中奖。<br>其中：1.顺子号的万、千、百位不分顺序；<br>2.对子号指的是开奖号码的前三位当中，任意2位数字相同的三位数号码。',
			methodexample: '投注方案：豹子顺子对子<br>开奖号码：前三位 888，即中豹子；前三位 678，即中顺子；前三位 558，即中对子。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}, {
	isdefault: 1,
	title: '后二',
	label: [{
		gtitle: '后二直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}]
			},
			methodid: 2150,
			yllrType: [1, [3, 4]],
			name: '复式',
			methoddesc: '从十、个位中至少各选1个号码组成一注。',
			methodhelp: '从十、个位中选择一个2位数号码组成一注，所选号码与开奖号码的前2位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：58<br>开奖号码：后二位 58，即中后二直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2151,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个二位数号码组成一注。',
			methodhelp: '手动输入一个2位数号码组成一注，输入号码的十、个位与开奖号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：58<br>开奖号码：后二位 58，即中后二直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
					place: 0
				}]
			},
			methodid: 2152,
			yllrType: [3, 2],
			name: '和值',
			methoddesc: '从0-18中任意选择1个或1个以上的和值号码。',
			methodhelp: '所选数值等于开奖号码的十、个位二个数字相加之和，即为中奖。',
			methodexample: '投注方案：和值1<br>开奖号码：后二位 01，10，即中后二直选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '跨度',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2153,
			yllrType: [3, 6],
			name: '跨度',
			methoddesc: '从0-9中任意选择1个号码组成一注。',
			methodhelp: '所选数值等于开奖号码的后2位最大与最小数字相减之差，即为中奖。',
			methodexample: '投注方案：跨度9<br>开奖号码：后二位 90或09，即中后二直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}, {
		gtitle: '后二组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2154,
			name: '复式',
			methoddesc: '从0-9中任意选择2个或2个以上号码。',
			methodhelp: '从0-9中选2个号码组成一注，所选号码与开奖号码的十、个位相同（不含对子号），顺序不限，即中奖。',
			methodexample: '投注方案：58<br>开奖号码：后二位 85 或者 58（顺序不限，不含对子号），即中后二组选。。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2155,
			iszxdu: 1,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个二位数号码组成一注。',
			methodhelp: '手动输入一个2位数号码组成一注，输入号码的十、个位与开奖号码相同（不含对子号），顺序不限，即为中奖。',
			methodexample: '投注方案：58<br>开奖号码：后二位 85 或者 58（顺序不限，不含对子号），即中后二组选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17',
					place: 0
				}]
			},
			methodid: 2156,
			name: '和值',
			methoddesc: '从1-17中任意选择1个或者1个以上号码。',
			methodhelp: '所选数值等于开奖号码的十、个位二个数字相加之和（不含对子号），即为中奖。',
			methodexample: '投注方案：和值 1<br>开奖号码：后二位 10 或者 01（顺序不限，不含对子号），即中后二组选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '包胆',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2157,
			name: '包胆',
			methoddesc: '从0-9中任意选择1个包胆号码。',
			methodhelp: '从0-9中任意选择1个包胆号码，开奖号码的十，个位中任意1位包含所选的包胆号码相同（不含对子号），即为中奖。',
			methodexample: '投注方案：包胆 8 <br>开奖号码：后二位 8X，且X不等于8，即中后二组选。',
			maxcodecount: 1,
			defaultposition: '00000',
		}*/]
	}]
}, {
	title: '前二',
	label: [{
		gtitle: '前二直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}]
			},
			methodid: 2142,
			yllrType: [1, [0, 1]],
			name: '复式',
			methoddesc: '从万、千位中至少各选1个号码组成一注。',
			methodhelp: '从万、千位中选择一个2位数号码组成一注，所选号码与开奖号码的前2位相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：58<br>开奖号码：前二位 58，即中前二直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2143,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个二位数号码组成一注。',
			methodhelp: '手动输入一个2位数号码组成一注，输入号码的万、千位与开奖号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：58<br>开奖号码：前二位 58，即中前二直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
					place: 0
				}]
			},
			methodid: 2144,
			yllrType: [3, 3],
			name: '和值',
			methoddesc: '从0-18中任意选择1个或1个以上的和值号码。',
			methodhelp: '所选数值等于开奖号码的万、千位二个数字相加之和，即为中奖。',
			methodexample: '投注方案：和值1<br>开奖号码：前二位 01，10，即中前二直选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '跨度',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2145,
			yllrType: [3, 7],
			name: '跨度',
			methoddesc: '从0-9中任意选择1个号码组成一注。',
			methodhelp: '所选数值等于开奖号码的前2位最大与最小数字相减之差，即为中奖。',
			methodexample: '投注方案：跨度9<br>开奖号码：前二位 90或09，即中前二直选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}, {
		gtitle: '前二组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2146,
			name: '复式',
			methoddesc: '从0-9中任意选择2个或2个以上号码。',
			methodhelp: '从0-9中选2个号码组成一注，所选号码与开奖号码的万、千位相同，顺序不限，即中奖。',
			methodexample: '投注方案：58<br>开奖号码：前二位 85 或者 58（顺序不限，不含对子号），即中前二组选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2147,
			iszxdu: 1,
			name: '单式',
			methoddesc: '手动输入号码，至少输入1个二位数号码组成一注。',
			methodhelp: '手动输入一个2位数号码组成一注，输入号码的万、千位与开奖号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：58<br>开奖号码：前二位 85 或者 58（顺序不限，不含对子号），即中前二组选。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17',
					place: 0
				}]
			},
			methodid: 2148,
			name: '和值',
			methoddesc: '从1-17中任意选择1个或者1个以上号码。',
			methodhelp: '所选数值等于开奖号码的万、千位二个数字相加之和（不含对子号），即为中奖。',
			methodexample: '投注方案：和值 1<br>开奖号码：前二位 10 或者 01（顺序不限，不含对子号），即中前二组选。',
			maxcodecount: 0,
			ishv: 1,
			defaultposition: '00000',
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '包胆',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}]
			},
			methodid: 2149,
			name: '包胆',
			methoddesc: '从0-9中任意选择1个包胆号码。',
			methodhelp: '从0-9中任意选择1个包胆号码，开奖号码的万，千位中任意1位包含所选的包胆号码相同（不含对子号），即为中奖。',
			methodexample: '投注方案：包胆 8 <br>开奖号码：前二位 8X，且X不等于8，即中前二组选。',
			maxcodecount: 1,
			defaultposition: '00000',
		}*/]
	}]
}, {
	title: '定位胆',
	label: [{
		gtitle: '定位胆',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 4
				}]
			},
			methodid: 2159,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '定位胆',
			methoddesc: '在万、千、百、十、个位任意位置上任意选择1个或1个以上号码。',
			methodhelp: '从万、千、百、十、个位任意位置上至少选择1个以上号码，所选号码与相同位置上的开奖号码一致，即为中奖。',
			methodexample: '投注方案：万位 1<br>开奖号码：万位 1，即中定位胆万位。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}, {
	title: '不定位',
	label: [{
			gtitle: '三星不定位',
			label: [{
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2163,
				name: '后三一码',
				methoddesc: '从0-9中任意选择1个以上号码。',
				methodhelp: '从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的百、十、个位中包含所选号码，即为中奖。',
				methodexample: '投注方案：1<br>开奖号码：后三位至少出现1个1，即中后三一码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2165,
				name: '前三一码',
				methoddesc: '从0-9中任意选择1个以上号码。',
				methodhelp: '从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的万、千、百位中包含所选号码，即为中奖。',
				methodexample: '投注方案：1<br>开奖号码：前三位，至少出现1个1，即中前三一码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2164,
				name: '后三二码',
				methoddesc: '从0-9中任意选择2个以上号码。',
				methodhelp: '从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的百、十、个位中同时包含所选的2个号码，即为中奖。',
				methodexample: '投注方案：12<br>开奖号码：后三位，至少出现1和2各1个，即中后三二码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2166,
				name: '前三二码',
				methoddesc: '从0-9中任意选择2个以上号码。',
				methodhelp: '从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的万、千、百位中同时包含所选的2个号码，即为中奖。',
				methodexample: '投注方案：12<br>开奖号码：前三位，至少出现1和2各1个，即中前三二码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}]
		}, {
			gtitle: '四星不定位',
			label: [{
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2167,
				name: '后四一码',
				methoddesc: '从0-9中任意选择1个以上号码。',
				methodhelp: '从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的千、百、十、个位中包含所选号码，即为中奖。',
				methodexample: '投注方案：1<br>开奖号码：后四位，至少出现1个1，即中后四一码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2168,
				name: '后四二码',
				methoddesc: '从0-9中任意选择2个以上号码。',
				methodhelp: '从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的千、百、十、个位中同时包含所选的2个号码，即为中奖。',
				methodexample: '投注方案：12<br>开奖号码：后四位，至少出现1和2各一个，即中后四二码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}]
		}, {
			gtitle: '五星不定位',
			label: [{
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2169,
				name: '五星二码',
				methoddesc: '从0-9中任意选择2个以上号码。',
				methodhelp: '从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的万、千、百、十、个位中同时包含所选的2个号码，即为中奖。',
				methodexample: '投注方案：12<br>开奖号码：至少出现1和2各一个，即中五星二码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '不定位',
						no: '0|1|2|3|4|5|6|7|8|9',
						place: 0
					}]
				},
				methodid: 2170,
				name: '五星三码',
				methoddesc: '从0-9中任意选择3个以上号码。',
				methodhelp: '从0-9中选择3个号码，每注由3个不同的号码组成，开奖号码的万、千、百、十、个位中同时包含所选的3个号码，即为中奖。',
				methodexample: '投注方案：123<br>开奖号码：至少出现1、2、3各1个，即中五星三码不定位。',
				maxcodecount: 0,
				defaultposition: '00000',
			}]
		}
	]
}, {
	title: '大小单双',
	label: [{
		gtitle: '大小单双',
		label: [{
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '万位',
					no: '大|小|单|双',
					place: 0
				}, {
					title: '千位',
					no: '大|小|单|双',
					place: 1
				}]
			},
			methodid: 2173,
			yllrType: [2, [0, 1]],
			name: '前二大小单双',
			methoddesc: '从万、千位中的“大、小、单、双”中至少各选一个组成一注。',
			methodhelp: '对万、千位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。',
			methodexample: '投注方案：小双<br>开奖号码：万位与千位“小双”，即中前二大小单双。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '十位',
					no: '大|小|单|双',
					place: 0
				}, {
					title: '个位',
					no: '大|小|单|双',
					place: 1
				}]
			},
			methodid: 2175,
			yllrType: [2, [3, 4]],
			name: '后二大小单双',
			methoddesc: '从十、个位中的“大、小、单、双”中至少各选一个组成一注。',
			methodhelp: '对十、个位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。',
			methodexample: '投注方案：大单<br>开奖号码：十位与个位“大单”，即中后二大小单双。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '万位',
					no: '大|小|单|双',
					place: 0
				}, {
					title: '千位',
					no: '大|小|单|双',
					place: 1
				}, {
					title: '百位',
					no: '大|小|单|双',
					place: 2
				}]
			},
			methodid: 2172,
			yllrType: [2, [0, 1, 2]],
			name: '前三大小单双',
			methoddesc: '从万、千、百位中的“大、小、单、双”中至少各选一个组成一注。',
			methodhelp: '对万、千、百位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。',
			methodexample: '投注方案：小双小<br>开奖号码：万位、千位、百位“小双小”，即中前三大小单双。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '百位',
					no: '大|小|单|双',
					place: 0
				}, {
					title: '十位',
					no: '大|小|单|双',
					place: 1
				}, {
					title: '个位',
					no: '大|小|单|双',
					place: 2
				}]
			},
			methodid: 2174,
			yllrType: [2, [2, 3, 4]],
			name: '后三大小单双',
			methoddesc: '从百、十、个位中的“大、小、单、双”中至少各选一个组成一注。',
			methodhelp: '对百、十、个位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。',
			methodexample: '投注方案：大单大<br>开奖号码：百位、十位、个位“大单大”，即中后三大小单双。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}, {
	title: '龙虎',
	label: [{
		gtitle: '龙虎',
		label: [{
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3357,
			name: '万千',
			methoddesc: '根据万、千位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对万、千位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：万位与千位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3358,
			name: '万百',
			methoddesc: '根据万、百位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对万、百位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：万位与百位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3359,
			name: '万十',
			methoddesc: '根据万、十位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对万、十位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：万位与十位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3360,
			name: '万个',
			methoddesc: '根据万、个位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对万、千位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：万位与个位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3361,
			name: '千百',
			methoddesc: '根据千、百位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对千、百位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：千位与百位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3362,
			name: '千十',
			methoddesc: '根据千、十位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对千、十位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：千位与十位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3363,
			name: '千个',
			methoddesc: '根据千、个位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对千、个位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：千位与个位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3364,
			name: '百十',
			methoddesc: '根据百、十位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对百、十位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：百位与十位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3365,
			name: '百个',
			methoddesc: '根据百、个位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对百、个位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：百位与个位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}, {
			selectarea: {
				type: 'dxds',
				layout: [{
					title: '',
					no: '龙|虎|和',
					place: 0
				}]
			},
			methodid: 3366,
			name: '十个',
			methoddesc: '根据十、个位的两个号码的形态，从“龙、虎、和”中至少各选一个组成一注。',
			methodhelp: '对十、个位的“龙（前一位比后一位大）虎（前一位比后一位小）、和（前一位与后一位相等）”形态进行购买，所选形态与开奖号码的对应的两个位置的形态相同，即为中奖。',
			methodexample: '投注方案：龙<br>开奖号码：十位与个位“85”，即为中奖。',
			maxcodecount: 0,
			defaultposition: '00000',
		}]
	}]
}, {
	isrx: 1,
	title: '任选二',
	label: [{
		gtitle: '任二直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 4
				}]
			},
			methodid: 2188,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '复式',
			methoddesc: '从万、千、百、十、个位中至少两位上各选1个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中至少两位上各选1个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：万位5，百位8<br>开奖号码：51812，即中任二直选。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00011',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2189,
			name: '单式',
			methoddesc: '至少选择两个位置，且至少手动输入一个两位数的号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择两个位置，且至少手动输入一个两位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位，输入号码58<br>开奖号码：51812，即中任二直选(单式)。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00011',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2190,
			name: '和值',
			methoddesc: '至少选择两个位置，且至少选择一个和值号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择两个位置，且至少选择一个和值号码构成一注，所选号码与开奖号码的和值相同，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位，选择和值号码13<br>开奖号码：51812，即中任二直选(单式)。',
			maxcodecount: 0,
			isrx: 1,
			ishv: 1,
			defaultposition: '00011',
		}]
	}, {
		gtitle: '任二组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2191,
			name: '复式',
			methoddesc: '至少选择两个位置，且号码区至少选择两个号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择两个位置，且号码区至少选择两个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位，选择号码85<br>开奖号码：51812或者81512，即中任二组选。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00011',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2192,
			iszxdu: 1,
			name: '单式',
			methoddesc: '至少选择两个位置，且至少手动输入一个两位数的号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择两个位置，且至少手动输入一个两位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位，输入号码85<br>开奖号码：51812或者81512，即中任二组选(单式)。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00011',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2193,
			name: '和值',
			methoddesc: '至少选择两个位置，且至少选择一个和值号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择两个位置，且至少选择一个和值号码构成一注，所选号码与开奖号码的和值相同，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位，选择和值号码13<br>开奖号码：51812，即中任二组选和值。',
			maxcodecount: 0,
			isrx: 1,
			ishv: 1,
			defaultposition: '00011',
		}]
	}]
}, {
	isrx: 1,
	title: '任选三',
	label: [{
		gtitle: '任三直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 4
				}]
			},
			methodid: 2194,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '复式',
			methoddesc: '从万、千、百、十、个位中至少三位上各选1个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中至少三位上各选1个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：万位5，百8,个位2<br>开奖号码：51812，即中任三直选。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2195,
			name: '单式',
			methoddesc: '至少选择三个位置，且至少手动输入一个三位数的号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且至少手动输入一个三位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位,个位，输入号码582<br>开奖号码：51812，即中任三直选(单式)。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2196,
			name: '和值',
			methoddesc: '至少选择三个位置，且至少选择一个和值号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且至少选择一个和值号码构成一注，所选号码与开奖号码的和值相同，即为中奖。',
			methodexample: '投注方案：位置选择万位、百位、个位，选择和值号码15<br>开奖号码：51812，即中任二直选(单式)。',
			maxcodecount: 0,
			isrx: 1,
			ishv: 1,
			defaultposition: '00111',
		}]
	}, {
		gtitle: '任三组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组三',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2197,
			name: '组三复式',
			methoddesc: '至少选择三个位置，且号码区至少选择两个号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且号码区至少选择两个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：选择位置万位、十位、个位,选择号码12<br>开奖号码：11812，即中任三组三。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2198,
			iszxdu: 1,
			name: '组三单式',
			methoddesc: '至少选择三个位置，且手动至少输入两个号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且手动至少输入两个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：选择位置万位、十位、个位,输入号码12<br>开奖号码：11812，即中任三组三(单式)。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组六',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2199,
			name: '组六复式',
			methoddesc: '至少选择三个位置，且号码区至少选择三个号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且号码区至少选择三个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：选择位置万位、十位、个位,选择号码512<br>开奖号码：51812，即中任三组六。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2200,
			iszxdu: 1,
			name: '组六单式',
			methoddesc: '至少选择三个位置，且手动至少输入三个号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且手动至少输入三个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：选择位置万位、十位、个位,输入号码512<br>开奖号码：51812，即中任三组六(单式)。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2202,
			iszxdu: 1,
			name: '混合组选',
			methoddesc: '至少选择三个位置，且至少输入三个号码构成一注(不包含豹子号)。',
			methodhelp: '从万、千、百、十、个位中至少选择三个位置，且至少输入三个号码构成一注(不包含豹子号)，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：选择位置万位、十位、个位,输入号码512<br>开奖号码：51812，即中任三混合组选。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '00111',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '和值',
					no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
					place: 0
				}],
				selPosition: true
			},
			methodid: 2203,
			name: '组选和值',
			methoddesc: '至少选择三个位置，且至少选择一个和值号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择两个位置，且至少选择一个和值号码构成一注，所选号码与开奖号码的和值(不包含豹子号)相同，即为中奖。',
			methodexample: '投注方案：选择位置万位、十位、个位,选择和值号码8<br>开奖号码：51812，即中任三组选和值。',
			maxcodecount: 0,
			isrx: 1,
			ishv: 1,
			defaultposition: '00111',
		}]
	}]
}, {
	isrx: 1,
	title: '任选四',
	label: [{
		gtitle: '任四直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '万位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0
				}, {
					title: '千位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1
				}, {
					title: '百位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 2
				}, {
					title: '十位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 3
				}, {
					title: '个位',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 4
				}]
			},
			methodid: 2204,
			yllrType: [1, [0, 1, 2, 3, 4]],
			name: '复式',
			methoddesc: '从万、千、百、十、个位中至少四位上各选1个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中至少四位上各选1个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：万位5，千位1,百位8,十位1<br>开奖号码：51812，即中任四直选。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '01111',
		}, {
			selectarea: {
				type: 'input',
				selPosition: true
			},
			methodid: 2205,
			name: '单式',
			methoddesc: '至少选择四个位置，且至少手动输入一个四位数的号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择四个位置，且至少手动输入一个四位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：选择万位、千位、百位、十位，输入号码5181<br>开奖号码：51812，即中任四直选(单式)。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '01111',
		}]
	}, {
		gtitle: '任四组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选24',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 4
				}],
				selPosition: true
			},
			methodid: 2206,
			name: '组选24',
			methoddesc: '至少选择四个位置，且号码区至少选择四个号码构成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择四个位置，且号码区至少选择四个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：位置选择千位、百位、十位、个位,号码选择0568<br>开奖号码：10568(指定位置号码顺序不限)，即可中任四组选24。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '01111',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 2
				}],
				selPosition: true
			},
			methodid: 2207,
			name: '组选12',
			methoddesc: '至少选择四个位置，且从“二重号”选择一个号码，“单号”中选择两个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择四个位置，且从“二重号”选择一个号码，“单号”中选择两个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：位置选择千位、百位、十位、个位,二重号：8；单号：06<br>开奖号码：10688(指定位置号码顺序不限)，即可中任四组选12。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '01111',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '二重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 2
				}],
				selPosition: true
			},
			methodid: 2208,
			name: '组选6',
			methoddesc: '至少选择四个位置，且从“二重号”中选择两个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择四个位置，且从“二重号”中选择两个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：位置选择千位、百位、十位、个位,二重号：28<br>开奖号码：12288(指定位置号码顺序不限)，即可中任四组选6。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '01111',
		}, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '三重号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 0,
					minchosen: 1
				}, {
					title: '单　号',
					no: '0|1|2|3|4|5|6|7|8|9',
					place: 1,
					minchosen: 1
				}],
				selPosition: true
			},
			methodid: 2209,
			name: '组选4',
			methoddesc: '至少选择四个位置，且从“三重号”中选择一个号码，“单号”中选择一个号码组成一注。',
			methodhelp: '从万、千、百、十、个位中至少选择四个位置，且从“三重号”中选择一个号码，“单号”中选择一个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。',
			methodexample: '投注方案：位置选择千位、百位、十位、个位,三重号：8；单号：2<br>开奖号码：18828(指定位置号码顺序不限)，即可中任四组选4。',
			maxcodecount: 0,
			isrx: 1,
			defaultposition: '01111',
		}]
	}]
}];
