﻿CSH.face['3'] = [{
	isdefault: 1,
	title: '三码',
	label: [{
		gtitle: '三码直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 1
				}, {
					title: '第三位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 2
				}]
			},
			methodid: 2059,
			yllrType: [1, [0, 1, 2]],
			name: '前三复式',
			methoddesc: '从第一位、第二位、第三位中至少各选择1个号码。',
			methodhelp: '从01-11共11个号码中选择3个不重复的号码组成一注，所选号码与当期顺序摇出的5个号码中的前3个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02 03<br>开奖号码：01 02 03 * *，即中前三直选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2060,
			name: '前三单式',
			methoddesc: '至少输入1个三位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入3个号码组成一注，所输入的号码与当期顺序摇出的5个号码中的前3个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02 03<br>开奖号码：01 02 03 * *，即中前三直选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}, {
		gtitle: '三码组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0,
					minchosen: 3
				}]
			},
			methodid: 2061,
			name: '前三复式',
			methoddesc: '从01-11中任意选择3个或3个以上号码。',
			methodhelp: '从01-11中共11个号码中选择3个号码，所选号码与当期顺序摇出的5个号码中的前3个号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：01 02 03<br>开奖号码：03 01 02 * *（前三顺序不限），即中前三组选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2062,
			iszxdu: 1,
			name: '前三单式',
			methoddesc: '至少输入1个三位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入3个号码组成一注，所输入的号码与当期顺序摇出的5个号码中的前3个号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：01 02 03<br>开奖号码：03 01 02 * *（前三顺序不限），即中前三组选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '胆码',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0
				}, {
					title: '拖码',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 1
				}],
				isDanTuo: true
			},
			methodid: 3202,
			name: '前三组选胆拖',
			methoddesc: '从01-11中，选取3个及以上的号码进行投注，每注需至少包括1个胆码及2个拖码。',
			methodhelp: '从01-11中，选取3个及以上的号码进行投注，每注需至少包括1个胆码及2个拖码。<br>所选单注号码与当期顺序摇出的5个号码中的前3个号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：胆码 02，拖码 01 06<br>开奖号码：02 01 06 * *（前三顺序不限），即中前三组选胆拖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}*/]
	}]
}, {
	title: '二码',
	label: [{
		gtitle: '二码直选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 1
				}]
			},
			methodid: 2055,
			yllrType: [1, [0, 1]],
			name: '前二复式',
			methoddesc: '从第一位、第二位中至少各选择1个号码。',
			methodhelp: '从01-11共11个号码中选择2个不重复的号码组成一注，所选号码与当期顺序摇出的5个号码中的前2个号码相同，且顺序一致，即中奖。',
			methodexample: '投注方案：01 02<br>开奖号码：01 02 * * *，即中前二直选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2056,
			name: '前二单式',
			methoddesc: '至少输入1个两位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入2个号码组成一注，所输入的号码与当期顺序摇出的5个号码中的前2个号码相同，且顺序一致，即为中奖。',
			methodexample: '投注方案：01 02<br>开奖号码：01 02 * * *，即中前二直选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}, {
		gtitle: '二码组选',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '组选',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0,
					minchosen: 2
				}]
			},
			methodid: 2057,
			name: '前二复式',
			methoddesc: '从01-11中任意选择2个或2个以上号码。',
			methodhelp: '从01-11中共11个号码中选择2个号码，所选号码与当期顺序摇出的5个号码中的前2个号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：01 02<br>开奖号码：02 01 * * *，（前二顺序不限），即中前二组选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}, {
			selectarea: {
				type: 'input'
			},
			methodid: 2058,
			iszxdu: 1,
			name: '前二单式',
			methoddesc: '至少输入1个两位数号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
			methodhelp: '手动输入2个号码组成一注，所输入的号码与当期顺序摇出的5个号码中的前2个号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：01 02<br>开奖号码：02 01 * * *，（前二顺序不限），即中前二组选。',
			maxcodecount: 0,
			defaultposition: '00000'
		}/*, {
			selectarea: {
				type: 'digital',
				layout: [{
					title: '胆码',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0
				}, {
					title: '拖码',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 1
				}],
				isDanTuo: true
			},
			methodid: 3201,
			name: '前二组选胆拖',
			methoddesc: '从01-11中，选取2个及以上的号码进行投注，每注需至少包括1个胆码及1个拖码。',
			methodhelp: '从01-11中，选取2个及以上的号码进行投注，每注需至少包括1个胆码及1个拖码。<br>所选单注号码与当期顺序摇出的5个号码中的前2个号码相同，顺序不限，即为中奖。',
			methodexample: '投注方案：胆码 01，拖码 06<br>开奖号码：06 01 * * *，（前二顺序不限），即中前二组选胆拖。',
			maxcodecount: 0,
			defaultposition: '00000'
		}*/]
	}]
}, {
	title: '不定位',
	label: [{
		gtitle: '不定位',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '前三位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0,
					minchosen: 1
				}]
			},
			methodid: 2063,
			name: '前三位',
			methoddesc: '从01-11中任意选择1个或1个以上号码。',
			methodhelp: '从01-11中共11个号码中选择1个号码，每注由1个号码组成，只要当期顺序摇出的第一位、第二位、第三位开奖号码中包含所选号码，即为中奖。',
			methodexample: '投注方案：01<br>开奖号码：01 * * * *，* 01 * * *，* * 01 * *，即中前三位。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
}, {
	title: '定位胆',
	label: [{
		gtitle: '定位胆',
		label: [{
			selectarea: {
				type: 'digital',
				layout: [{
					title: '第一位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 0
				}, {
					title: '第二位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 1
				}, {
					title: '第三位',
					no: '01|02|03|04|05|06|07|08|09|10|11',
					place: 2
				}]
			},
			methodid: 2064,
			yllrType: [1, [0, 1, 2]],
			name: '定位胆',
			methoddesc: '从第一位，第二位，第三位任意位置上任意选择1个或1个以上号码。',
			methodhelp: '从第一位，第二位，第三位任意1个位置或多个位置上选择1个号码，所选号码与相同位置上的开奖号码一致，即为中奖。',
			methodexample: '投注方案：第一位 01<br>开奖号码：01 * * * *，即中定位胆。',
			maxcodecount: 0,
			defaultposition: '00000'
		}]
	}]
},
	{
		title: '任选复式',
		label: [{
			gtitle: '任选复式',
			label: [{
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选1中1',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 1
					}]
				},
				methodid: 2030,
				name: '任选一中一',
				methoddesc: '从01-11中任意选择1个或1个以上号码。',
				methodhelp: '从01-11共11个号码中选择1个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05<br>开奖号码：08 04 11 05 03，即中任选一中一。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选2中2',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 2
					}]
				},
				methodid: 2031,
				name: '任选二中二',
				methoddesc: '从01-11中任意选择2个或2个以上号码。',
				methodhelp: '从01-11共11个号码中选择2个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 04<br>开奖号码：08 04 11 05 03，即中任选二中二。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选3中3',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 3
					}]
				},
				methodid: 2032,
				name: '任选三中三',
				methoddesc: '从01-11中任意选择3个或3个以上号码。',
				methodhelp: '从01-11共11个号码中选择3个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 04 11<br>开奖号码：08 04 11 05 03，即中任选三中三。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选4中4',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 4
					}]
				},
				methodid: 2033,
				name: '任选四中四',
				methoddesc: '从01-11中任意选择4个或4个以上号码。',
				methodhelp: '从01-11共11个号码中选择4个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 04 08 03<br>开奖号码：08 04 11 05 03，即中任选四中四。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选5中5',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 5
					}]
				},
				methodid: 2035,
				name: '任选五中五',
				methoddesc: '从01-11中任意选择5个或5个以上号码。',
				methodhelp: '从01-11共11个号码中选择5个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 04 11 03 08<br>开奖号码：08 04 11 05 03，即中任选五中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选6中5',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 6
					}]
				},
				methodid: 2036,
				name: '任选六中五',
				methoddesc: '从01-11中任意选择6个或6个以上号码。',
				methodhelp: '从01-11共11个号码中选择6个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 10 04 11 03 08<br>开奖号码：08 04 11 05 03，即中任选六中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选7中5',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 7
					}]
				},
				methodid: 2037,
				name: '任选七中五',
				methoddesc: '从01-11中任意选择7个或7个以上号码。',
				methodhelp: '从01-11共11个号码中选择7个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 10 04 11 03 08 09<br>开奖号码：08 04 11 05 03，即中任选七中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '选8中5',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0,
						minchosen: 8
					}]
				},
				methodid: 2038,
				name: '任选八中五',
				methoddesc: '从01-11中任意选择8个或8个以上号码。',
				methodhelp: '从01-11共11个号码中选择8个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所选号码，即为中奖。',
				methodexample: '投注方案：05 10 04 11 03 08 09 01<br>开奖号码：08 04 11 05 03，即中任选八中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}]
		}]
	}, {
		title: '任选单式',
		label: [{
			gtitle: '任选单式',
			label: [{
				selectarea: {
					type: 'input'
				},
				methodid: 2039,
				iszxdu: 1,
				name: '任选一中一',
				methoddesc: '从01-11中任意输入1个号码组成一注，每注号码之间用 逗号[,] 进行分隔。',
				methodhelp: '从01-11中手动输入1个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05<br>开奖号码：08 04 11 05 03，即中任选一中一。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2040,
				iszxdu: 1,
				name: '任选二中二',
				methoddesc: '从01-11中任意输入2个号码组成一注。',
				methodhelp: '从01-11中手动输入2个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 04<br>开奖号码：08 04 11 05 03，即中任选二中二。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2041,
				iszxdu: 1,
				name: '任选三中三',
				methoddesc: '从01-11中任意输入3个号码组成一注。',
				methodhelp: '从01-11中手动输入3个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 04 11<br>开奖号码：08 04 11 05 03，即中任选三中三。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2042,
				iszxdu: 1,
				name: '任选四中四',
				methoddesc: '从01-11中任意输入4个号码组成一注。',
				methodhelp: '从01-11中手动输入4个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 04 08 03<br>开奖号码：08 04 11 05 03，即中任选四中四。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2043,
				iszxdu: 1,
				name: '任选五中五',
				methoddesc: '从01-11中任意输入5个号码组成一注。',
				methodhelp: '从01-11中手动输入5个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 04 11 03 08<br>开奖号码：08 04 11 05 03，即中任选五中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2044,
				iszxdu: 1,
				name: '任选六中五',
				methoddesc: '从01-11中任意输入6个号码组成一注。',
				methodhelp: '从01-11中手动输入6个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 10 04 11 03 08<br>开奖号码：08 04 11 05 03，即中任选六中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2045,
				iszxdu: 1,
				name: '任选七中五',
				methoddesc: '从01-11中任意输入7个号码组成一注。',
				methodhelp: '从01-11中手动输入7个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 10 04 11 03 08 09<br>开奖号码：08 04 11 05 03，即中任选七中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'input'
				},
				methodid: 2046,
				iszxdu: 1,
				name: '任选八中五',
				methoddesc: '从01-11中任意输入8个号码组成一注。',
				methodhelp: '从01-11中手动输入8个号码进行购买，只要当期顺序摇出的5个开奖号码中包含所输入号码，即为中奖。',
				methodexample: '投注方案：05 10 04 11 03 08 09 01<br>开奖号码：08 04 11 05 03，即中任选八中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}]
		}]
	}/*, {
		title: '任选胆拖',
		label: [{
			gtitle: '任选胆拖',
			label: [{
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2047,
				name: '任选二中二',
				methoddesc: '从01-11中，选取2个及以上的号码进行投注，每注需至少包括1个胆码及1个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和1个拖码组成一注，只要当期顺序摇出的5个开奖号码中同时包含所选的1个胆码和1个拖码，所选胆码必须全中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 06<br>开奖号码：06 08 11 09 02，即中任选二中二。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2048,
				name: '任选三中三',
				methoddesc: '从01-11中，选取3个及以上的号码进行投注，每注需至少包括1个胆码及2个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和2个拖码组成一注，只要当期顺序摇出的5个开奖号码中同时包含所选的1个胆码和2个拖码，所选胆码必须全中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 06 11<br>开奖号码：06 08 11 09 02，即中任选三中三。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2049,
				name: '任选四中四',
				methoddesc: '从01-11中，选取4个及以上的号码进行投注，每注需至少包括1个胆码及3个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和3个拖码组成一注，只要当期顺序摇出的5个开奖号码中同时包含所选的1个胆码和3个拖码，所选胆码必须全中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 06 09 11 <br>开奖号码：06 08 11 09 02，即中任选四中四。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2050,
				name: '任选五中五',
				methoddesc: '从01-11中，选取5个及以上的号码进行投注，每注需至少包括1个胆码及4个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和4个拖码组成一注，只要当期顺序摇出的5个开奖号码中同时包含所选的1个胆码和4个拖码，所选胆码必须全中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 02 06 09 11 <br>开奖号码：06 08 11 09 02，即中任选五中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2051,
				name: '任选六中五',
				methoddesc: '从01-11中，选取6个及以上的号码进行投注，每注需至少包括1个胆码及5个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和5个拖码组成一注，只要当期顺序摇出的5个开奖号码同时存在于胆码和拖码的任意组合中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 02 05 06 09 11<br>开奖号码：06 08 11 09 02，即中任选六中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2052,
				name: '任选七中五',
				methoddesc: '从01-11中，选取7个及以上的号码进行投注，每注需至少包括1个胆码及6个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和6个拖码组成一注，只要当期顺序摇出的5个开奖号码同时存在于胆码和拖码的任意组合中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 01 02 05 06 09 11<br>开奖号码：06 08 11 09 02，即中任选七中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}, {
				selectarea: {
					type: 'digital',
					layout: [{
						title: '胆码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 0
					}, {
						title: '拖码',
						no: '01|02|03|04|05|06|07|08|09|10|11',
						place: 1
					}],
					isDanTuo: true
				},
				methodid: 2053,
				name: '任选八中五',
				methoddesc: '从01-11中，选取8个及以上的号码进行投注，每注需至少包括1个胆码及7个拖码。',
				methodhelp: '分别从胆码和拖码的01-11中，至少选择1个胆码和7个拖码组成一注，只要当期顺序摇出的5个开奖号码同时存在于胆码和拖码的任意组合中，即为中奖。',
				methodexample: '投注方案：胆码 08，拖码 01 02 03 05 06 09 11 <br>开奖号码：06 08 11 09 02，即中任选八中五。',
				maxcodecount: 0,
				defaultposition: '00000'
			}]
		}]
	}*/
];
