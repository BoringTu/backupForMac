(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['default-router', 'views/default-userCenter', 'views/subsets/default-userCenter_agencyHome', 'views/subsets/default-userCenter_contract', 'views/subsets/default-userCenter_dayMoney', 'views/subsets/default-userCenter_extractMoney', 'views/subsets/default-userCenter_gameRecords', 'views/subsets/default-userCenter_memberManagement', 'views/subsets/default-userCenter_message', 'views/subsets/default-userCenter_personalReport', 'views/subsets/default-userCenter_promotionAccount', 'views/subsets/default-userCenter_property', 'views/subsets/default-userCenter_recharge', 'views/subsets/default-userCenter_security', 'views/subsets/default-userCenter_teamCheck', 'views/subsets/default-userCenter_teamReports', 'views/subsets/default-userCenter_trackRecords', 'views/subsets/default-userCenter_transferAccounts'], function(BaseRouter, Ctrl) {
    var Router;
    Router = (function(superClass) {
      extend(Router, superClass);

      function Router() {
        return Router.__super__.constructor.apply(this, arguments);
      }

      Router.prototype.main = function() {
        Router.__super__.main.apply(this, arguments);
        return this.ctrl = new Ctrl({
          el: CSH.$els['content']
        });
      };

      return Router;

    })(BaseRouter);
    new Router();
    return Backbone.history.start();
  });

}).call(this);
