(function() {
  var start, test;

  start = function($) {
    var els, fix, go, platform;
    fix = location.hostname.match(/(?:^\w+\.|)(\w+)(?:\.\w+$)/);
    fix = fix[1].toLowerCase();
    fix = /test/.test(fix) ? 'rg' : fix.replace(/\d|dev|pvw/g, '');
    platform = (function() {
      switch (fix) {
        case 'rg':
          return 'RG游戏';
        case 'xh':
          return '新皇游戏';
        case 'df':
          return '东泛游戏';
        case 'bfylcai':
          return '百分娱乐';
      }
    })();
    els = {};
    els.body = $('body');
    els.bd = $('<div class="ie-blocker-backgrop">');
    els.ieb = $("<div class=\"ie-blocker\">\n	<div class=\"ie-blocker-dialog\">\n		<img class=\"brand\" src=\"/images/loginReg/brand-" + fix + ".jpg\" width=\"74\" height=\"80\" />\n		<h3>您的浏览器需要更新</h3>\n		<p>为了保证功能正常使用并保护您的信息安全，请使用<br>以下最新浏览器访问【" + platform + "】网站</p>\n		<div class=\"box\">\n			<div class=\"item\">\n				<span class=\"logo logo-chrome\"></span>\n				<span class=\"name\">Chrome<i></i></span>\n				<span class=\"text\">谷歌全新推出的高速浏览器</span>\n				<a target=\"_blank\" href=\"http://www.google.cn/chrome\">官网下载</a>\n			</div>\n			<div class=\"item\">\n				<span class=\"logo logo-opera\"></span>\n				<span class=\"name\">Opera</span>\n				<span class=\"text\">地球上最快的浏览器 内置广告拦截功能</span>\n				<a target=\"_blank\" href=\"http://www.opera.com/zh-cn\">官网下载</a>\n			</div>\n			<div class=\"item\">\n				<span class=\"logo logo-firefox\"></span>\n				<span class=\"name\">Firefox</span>\n				<span class=\"text\">Firefox注重您的信息安全</span>\n				<a target=\"_blank\" href=\"http://www.firefox.com.cn\">官网下载</a>\n			</div>\n		</div>\n	</div>\n</div>");
    els.dialog = els.ieb.find('> .ie-blocker-dialog');
    els.body.css({
      overflow: 'hidden'
    }).append(els.bd).append(els.ieb);
    go = function() {
      els.bd.fadeIn(200);
      return els.dialog.css({
        marginTop: -100,
        opacity: 0
      }).delay(200).animate({
        marginTop: 270,
        opacity: 1
      }, 200);
    };
    return go();
  };

  test = function() {
    return setTimeout(function() {
      if (jQuery) {
        return start(jQuery);
      } else {
        return test();
      }
    }, 100);
  };

  test();

}).call(this);
