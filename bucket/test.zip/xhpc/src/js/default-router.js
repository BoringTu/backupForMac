(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'backbone', 'common', 'views/_default-body', 'views/_default-navbar', 'views/_default-menu'], function($, Backbone, Common, ViewBody, ViewNavbar, ViewMenu) {
    "use strict";
    var Router;
    Router = (function(superClass) {
      extend(Router, superClass);

      function Router() {
        return Router.__super__.constructor.apply(this, arguments);
      }

      Router.prototype.routes = {
        '': 'main',
        ':route1st': 'main',
        ':route1st/:route2nd': 'main',
        ':route1st/:route2nd/:route3rd': 'main'
      };

      Router.prototype.initialize = function() {
        Common.initialize();
        CSH.router = this;
        this.utils = CSH.utils;
        CSH.$els['window'] = $(window);
        CSH.$els['html'] = $('html');
        CSH.$els['head'] = $('head');
        CSH.$els['body'] = $('body');
        CSH.$els['header'] = $('header');
        CSH.$els['footer'] = $('footer');
        CSH.$els['pageWrap'] = $('.pageWrap');
        CSH.$els['content'] = $('.content');
        CSH.$els['navbar'] = CSH.$els['header'].find('.navbar');
        CSH.$els['menu'] = CSH.$els['header'].find('.menu');
        CSH.views['body'] = this.body = new ViewBody({
          el: CSH.$els['body']
        });
        CSH.views['navbar'] = this.navbar = new ViewNavbar({
          el: CSH.$els['navbar']
        });
        CSH.views['menu'] = this.menu = new ViewMenu({
          el: CSH.$els['menu']
        });
        CSH.scrollToTop = function(speed) {
          if (speed == null) {
            speed = 0;
          }
          CSH.$els.html.animate({
            scrollTop: 0
          }, speed);
          return CSH.$els.body.animate({
            scrollTop: 0
          }, speed);
        };
        CSH.xhrPool = [];
      };

      Router.prototype.refresh = function() {
        var hash;
        hash = location.hash.replace(/^#/, '');
        hash = hash.split('/');
        this.main.apply(this, hash);
      };

      Router.prototype.main = function() {
        var str;
        CSH.scrollToTop(200);
        CSH.routePath = (function() {
          var i, len, results;
          results = [];
          for (i = 0, len = arguments.length; i < len; i++) {
            str = arguments[i];
            if (str) {
              results.push(str);
            }
          }
          return results;
        }).apply(this, arguments);
        console.log('CSH.routePath: ', CSH.routePath);
        this.destroyPage();
        this.body.showLoading();
        $('> .modal', document.body).each(function() {
          var modalBox;
          modalBox = $(this);
          if (!(modalBox.hasClass('modal-initpwdmodify') || modalBox.hasClass('modal-notice'))) {
            return modalBox.modal('hide');
          }
        });
        this.menu.refreshMenuStyle();

        /*
        			 * Show 404 Page
        			 * TODO
        			switch route1st
        				when '404'
        					CSH.$els['body'].removeAttr 'route-name'
        					return @body.show404()
        				when 'timeout'
        					CSH.$els['body'].removeAttr 'route-name'
        					return @body.showTimeout()
        
        			 * 按需加载所需 Controller View
        			require [if route1st then "views/#{ route1st }" else ''], (@Ctrl) =>
        				CSH.$els['body'].attr 'route-name': route1st
        				CSH.$els['pageWrap'].removeAttr 'style'
        				CSH.$els['content']
        					.removeClass @oldRoute
        					.addClass route1st
        				@oldRoute = route1st
        
        				 * Remove .errortitle Div Element
        				@body.removeErrorPage()
        
        				 * 实例化 Controller View
        				@ctrl = new @Ctrl el: CSH.$els['content'] if @Ctrl
        					
        				return
        			, =>
        				console.error "Error: 404 Not Found - views/#{ route1st }"
        				 * 换一种方式，不修改 location.hash
        				if history.replaceState
        					history.replaceState null, null, '#404'
        					@main '404'
        				else
        					location.hash = '404'
         */
      };

      Router.prototype.destroyPage = function() {
        var ref;
        console.info('垃圾处理');
        _.each(CSH.xhrPool, function(xhr) {
          if (xhr.readyState > 0 && xhr.readyState < 4) {
            xhr.abort();
          }
        });
        CSH.xhrPool = [];
        _.each(CSH.models, function(obj, name) {
          return delete CSH.models[name];
        });
        _.each(CSH.collections, function(obj, name) {
          return delete CSH.collections[name];
        });
        if ((ref = this.ctrl) != null) {
          if (typeof ref.destroy === "function") {
            ref.destroy();
          }
        }
        return CSH.$els['content'].empty().off();
      };

      return Router;

    })(Backbone.Router);

    /*
    	new Router()
    	Backbone.history.start()
     */
    return Router;
  });

}).call(this);
