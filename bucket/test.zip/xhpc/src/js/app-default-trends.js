(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['default-router', 'views/default-trends'], function(BaseRouter, Ctrl) {
    var Router;
    Router = (function(superClass) {
      extend(Router, superClass);

      function Router() {
        return Router.__super__.constructor.apply(this, arguments);
      }

      Router.prototype.main = function() {
        Router.__super__.main.apply(this, arguments);
        return this.ctrl = new Ctrl({
          el: CSH.$els['content']
        });
      };

      return Router;

    })(BaseRouter);
    new Router();
    return Backbone.history.start();
  });

}).call(this);
