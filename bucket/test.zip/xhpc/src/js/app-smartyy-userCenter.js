(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['smartyy-router', 'views/smartyy-userCenter', 'views/subsets/smartyy-userCenter_agencyHome', 'views/subsets/smartyy-userCenter_contract', 'views/subsets/smartyy-userCenter_dayMoney', 'views/subsets/smartyy-userCenter_extractMoney', 'views/subsets/smartyy-userCenter_gameRecords', 'views/subsets/smartyy-userCenter_memberManagement', 'views/subsets/smartyy-userCenter_message', 'views/subsets/smartyy-userCenter_personalReport', 'views/subsets/smartyy-userCenter_promotionAccount', 'views/subsets/smartyy-userCenter_property', 'views/subsets/smartyy-userCenter_recharge', 'views/subsets/smartyy-userCenter_security', 'views/subsets/smartyy-userCenter_teamCheck', 'views/subsets/smartyy-userCenter_teamReports', 'views/subsets/smartyy-userCenter_teamLottery', 'views/subsets/smartyy-userCenter_trackRecords', 'views/subsets/smartyy-userCenter_transferAccounts'], function(BaseRouter, Ctrl) {
    var Router;
    Router = (function(superClass) {
      extend(Router, superClass);

      function Router() {
        return Router.__super__.constructor.apply(this, arguments);
      }

      Router.prototype.main = function() {
        Router.__super__.main.apply(this, arguments);
        return this.ctrl = new Ctrl({
          el: CSH.$els['content']
        });
      };

      return Router;

    })(BaseRouter);
    new Router();
    return Backbone.history.start();
  });

}).call(this);
