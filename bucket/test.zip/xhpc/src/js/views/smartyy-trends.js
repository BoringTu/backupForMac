(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  define(['jquery', 'underscore', 'backbone', 'doT', 'algorithmMark6', 'collections/history', 'text!../../templates/smartyy-trends.tpl', 'text!../../templates/subsets/smartyy-trends_list.tpl', 'text!../../templates/_smartyy-contentLoading.tpl'], function($, _, Backbone, doT, AlgorithmMark6, CollectionHistory, TplContent, TplList, TplLoading) {
    "use strict";
    var Algorithm, View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.eventMMoveTableBox = bind(this.eventMMoveTableBox, this);
        this.eventMUpTableBox = bind(this.eventMUpTableBox, this);
        this.resetMenu = bind(this.resetMenu, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        list: doT.template(TplList)
      };

      View.prototype.events = {
        'click .headBox .menuList a': 'eventSwitchLottery',
        'click .headBox .methodBox a': 'eventSwitchMethod',
        'mouseenter .headBox button.scrollX': 'eventStartScroll',
        'mouseleave .headBox button.scrollX': 'eventStopScroll',
        'click .headBox button.chooseRange': 'eventChooseRange',
        'click .headBox button.search': 'eventQueryWithRange',
        'change .headBox button.checkbox input': 'eventConditionChanged',
        'mousedown .tableBox': 'eventMDownTableBox'
      };

      View.prototype.initialize = function() {
        window.v = this;
        CSH.gID = CSH.routePath[0];
        CSH.gType = CSH.gID.charAt(0);
        CSH.$els.fixedToolbar.addClass('nosee');
        this.data = {};
        this.data.methodMap = {
          1: {
            nums: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            places: ['万位', '千位', '百位', '十位', '个位'],
            methods: [
              {
                text: '五星',
                place: [0, 1, 2, 3, 4],
                items: ['issue', 'codes', 'places']
              }, {
                text: '四星',
                place: [1, 2, 3, 4],
                items: ['issue', 'codes', 'places']
              }, {
                text: '前三',
                place: [0, 1, 2],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'vh', '012', 'bz', 'z3', 'z6', 'kd', 'hv', 'hvwu']
              }, {
                text: '中三',
                place: [1, 2, 3],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'vh', '012', 'bz', 'z3', 'z6', 'kd', 'hv', 'hvwu']
              }, {
                text: '后三',
                place: [2, 3, 4],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'vh', '012', 'bz', 'z3', 'z6', 'kd', 'hv', 'hvwu']
              }, {
                text: '前二',
                place: [0, 1],
                items: ['issue', 'codes', 'places', 'kdzu', 'hv']
              }, {
                text: '后二',
                place: [3, 4],
                items: ['issue', 'codes', 'places', 'kdzu', 'hv']
              }
            ]
          },
          2: {
            nums: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            places: ['百位', '十位', '个位'],
            methods: [
              {
                text: '三星',
                place: [0, 1, 2],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'vh', '012', 'bz', 'z3', 'z6', 'kd', 'hv', 'hvwu']
              }
            ]
          },
          3: {
            nums: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11'],
            places: ['一位', '二位', '三位', '四位', '五位'],
            methods: [
              {
                text: '五星',
                place: [0, 1, 2, 3, 4],
                items: ['issue', 'codes', 'places']
              }
            ]
          },
          4: {
            nums: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10'],
            places: ['冠军', '亚军', '第三名', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名'],
            methods: [
              {
                text: '冠亚军',
                place: [0, 1],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'upj']
              }, {
                text: '前五名',
                place: [0, 1, 2, 3, 4],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'upj']
              }, {
                text: '后五名',
                place: [5, 6, 7, 8, 9],
                items: ['issue', 'codes', 'places', 'dx', 'du', 'upj']
              }
            ]
          },
          5: {
            nums: ['1', '2', '3', '4', '5', '6'],
            places: ['百位', '十位', '个位'],
            methods: [
              {
                text: '三星',
                place: [0, 1, 2],
                items: ['issue', 'codes', 'places', 'hv', 'bz', 'dz', 'uz', 'sbt']
              }
            ]
          },
          6: {
            nums: [],
            places: ['正1', '正2', '正3', '正4', '正5', '正6', '特码'],
            methods: [
              {
                text: '',
                place: [0, 1, 2, 3, 4, 5, 6],
                items: ['issue', 'time', '6places', '6tm', '6hv']
              }
            ]
          }
        };
        this.data.itemMap = {
          'issue': {
            text: '期号',
            type: 'issue'
          },
          'time': {
            text: '开奖时间',
            type: 'time'
          },
          'codes': {
            text: '开奖号',
            type: 'codes'
          },
          'places': {
            text: '号码分布',
            type: 'places'
          },
          '6places': {
            text: "<div class=\"m6wrap\">\n	<span class=\"m6\">正1</span>\n	<span class=\"m6\">正2</span>\n	<span class=\"m6\">正3</span>\n	<span class=\"m6\">正4</span>\n	<span class=\"m6\">正5</span>\n	<span class=\"m6\">正6</span>\n	<span class=\"m6\">特码</span>\n</div>",
            type: 'places'
          },
          'dx': {
            text: '大小',
            type: 'dx'
          },
          'du': {
            text: '单双',
            type: 'du'
          },
          'vh': {
            text: '质合',
            type: 'vh'
          },
          '012': {
            text: '012',
            type: '012'
          },
          'bz': {
            text: '豹子',
            type: 'bz'
          },
          'uz': {
            text: '顺子',
            type: 'uz'
          },
          'dz': {
            text: '对子',
            type: 'dz'
          },
          'z3': {
            text: '组三',
            type: 'z3'
          },
          'z6': {
            text: '组六',
            type: 'z6'
          },
          'kd': {
            text: '跨度',
            type: 'kd'
          },
          'hv': {
            text: '和值',
            type: 'hv'
          },
          'hvwu': {
            text: '和值尾数',
            type: 'hvwu'
          },
          'kdzu': {
            text: '跨度走势',
            type: 'kdzu'
          },
          'upj': {
            text: '升平降',
            type: 'upj'
          },
          'sbt': {
            text: '三不同',
            type: 'sbt'
          },
          '6tm': {
            text: '特码',
            type: '6tm'
          },
          '6hv': {
            text: '和值',
            type: '6hv'
          }
        };
        this.data.conditions = {
          lostNum: 0,
          trendLine: 0,
          subline: 0,
          temperature: 0,
          lostLine: 0
        };
        return this.render();
      };

      View.prototype.destroy = function() {
        CSH.$els.window.off('resize', this.resetMenu);
        return CSH.$els.fixedToolbar.removeClass('nosee');
      };

      View.prototype.render = function() {
        var gameList, id, k, n, nameList, obj, ref, temp, v;
        gameList = [];
        ref = CSH.gameMap;
        for (id in ref) {
          if (!hasProp.call(ref, id)) continue;
          obj = ref[id];
          temp = {
            id: id
          };
          for (k in obj) {
            if (!hasProp.call(obj, k)) continue;
            v = obj[k];
            temp[k] = v;
          }
          gameList.push(temp);
        }
        this.$el.html(this.tpls.content({
          gameList: gameList
        }));
        this.els = {};
        this.els.headBox = this.$el.find('> .headBox');
        this.els.menuBox = this.els.headBox.find('> .menuBox');
        this.els.menuList = this.els.menuBox.find('> .menuList');
        this.els.toolBox = this.els.headBox.find('> .toolBox');
        this.els.methodBox = this.els.toolBox.find('.methodBox > ul');
        this.els.dates = this.els.toolBox.find('input.datetimepicker');
        this.els.btnSearch = this.els.toolBox.find('button.search');
        this.els.conditions = this.els.toolBox.find('input[type="checkbox"]');
        this.els.tableBox = this.$el.find('> .tableBox');
        this.initDateTimePicker();
        CSH.$els.window.on('resize', this.resetMenu);
        this.resetMenu(true);
        nameList = ['lostNum', 'trendLine', 'subline'];
        this.els.conditions.filter(((function() {
          var l, len1, results;
          results = [];
          for (l = 0, len1 = nameList.length; l < len1; l++) {
            n = nameList[l];
            results.push("[data-type=\"" + n + "\"]");
          }
          return results;
        })()).join(',')).click();
        return this.refresh();
      };

      View.prototype.refresh = function() {
        this.data.methodInfo = this.data.methodMap[CSH.gType];
        this.renderMethods();
        return this.els.headBox.find('button.chooseRange:eq(0)').removeClass('selected').click();
      };

      View.prototype.renderMethods = function() {
        var box, i, info, l, len1, list, ref, str, wrap;
        str = '';
        ref = this.data.methodInfo.methods;
        for (i = l = 0, len1 = ref.length; l < len1; i = ++l) {
          info = ref[i];
          str += "<li><a href=\"#" + CSH.gID + "/" + i + "\">" + info.text + "</a></li>";
        }
        list = $(str);
        box = this.els.methodBox;
        wrap = box.closest('.dropdown');
        wrap.toggle(+CSH.gType !== 6);
        this.els.conditions.filter('[data-type!="subline"]').closest('label').toggle(+CSH.gType !== 6);
        box.empty().append(list);
        return list.first().find('a').click();
      };

      View.prototype.renderTrendData = function() {
        this.els.tableBox.html(this.tpls.list({
          data: this.data.list,
          info: this.data.methodInfo,
          index: this.data.methodIndex,
          itemMap: this.data.itemMap,
          content: new Algorithm(this).generate()
        }));
        return this.els.table = this.els.tableBox.find('> table');
      };

      View.prototype.initDateTimePicker = function() {
        this.els.dates.datetimepicker({
          showClear: false,
          format: 'YYYY-MM-DD'
        });
        return this.els.dates.on('dp.change', (function(_this) {
          return function(event) {
            var el, isStart, other;
            el = $(event.currentTarget);
            other = _this.els.dates.not(el);
            isStart = 'ds' === el.attr('data-type');
            if (!other.val()) {
              other.val(el.val());
            }
            return other.data('DateTimePicker')[isStart ? 'minDate' : 'maxDate'](event.date);
          };
        })(this));
      };

      View.prototype.resetMenu = function(isInit) {
        var li, ml, ow, ul, w;
        ml = this.els.menuBox.find('> .menuList');
        ul = ml.find('> ul');
        li = ul.find('> li');
        w = 112 * li.length;
        ow = this.$el.width();
        if (w > ow) {
          ul.css({
            width: w
          });
          ml.css({
            width: ow - 18 * 2
          });
        } else {
          ul.css({
            width: ow
          });
          ml.css({
            width: ow
          });
        }
        if (isInit) {
          return li.filter("[data-id=\"" + CSH.gID + "\"]").addClass('active');
        }
      };

      View.prototype.eventSwitchLottery = function(event) {
        var el, li;
        event.preventDefault();
        el = $(event.currentTarget);
        if ('#xxx' === el.attr('href')) {
          return;
        }
        li = el.parent();
        if (li.hasClass('active')) {
          return;
        }
        CSH.gID = li.attr('data-id');
        CSH.gType = CSH.gID.charAt(0);
        this.data.list = null;
        li.addClass('active').siblings('.active').removeClass('active');
        return this.refresh();
      };

      View.prototype.eventSwitchMethod = function(event) {
        var el, href, text;
        event.preventDefault();
        el = $(event.currentTarget);
        href = el.attr('href');
        text = el.text();
        history.replaceState(null, null, href);
        el.parent().addClass('active').siblings('.active').removeClass('active');
        el.closest('.methodBox').siblings('.text').text(text);
        this.data.methodIndex = el.parent().index();
        if (this.data.list) {
          return this.renderTrendData();
        }
      };

      View.prototype.eventStartScroll = function(event) {
        var b, el, maxLeft, target, wBox, wCon;
        el = $(event.currentTarget);
        b = +el.attr('data-type');
        target = this.els.menuList;
        wBox = target.width();
        wCon = target.find('> ul').outerWidth(true);
        maxLeft = wCon - wBox;
        return target.data('handle', (function() {
          if (b) {
            return setInterval(function() {
              var left;
              left = target.scrollLeft() + 10;
              if (!(left < maxLeft)) {
                left = maxLeft;
              }
              return target.scrollLeft(left);
            }, 10);
          } else {
            return setInterval(function() {
              var left;
              left = target.scrollLeft() - 10;
              if (!(left > 0)) {
                left = 0;
              }
              return target.scrollLeft(left);
            }, 10);
          }
        })());
      };

      View.prototype.eventStopScroll = function(event) {
        var target;
        target = this.els.menuList;
        return clearInterval(target.data('handle'));
      };

      View.prototype.eventChooseRange = function(event) {
        var data, el, today, val;
        el = $(event.currentTarget);
        if (el.hasClass('selected')) {
          return;
        }
        el.addClass('selected').siblings('.selected').removeClass('selected');
        val = el.attr('data-value');
        if (val === 'today') {
          today = new Date().getFormatDate();
          data = {
            ds: today,
            de: today,
            count: 100
          };
        } else {
          data = {
            count: +val
          };
        }
        this.els.dates.val('');
        return this.fetchHistory(data);
      };

      View.prototype.eventQueryWithRange = function(event) {
        var data, el, l, len1, o, ref, val;
        el = $(event.currentTarget);
        data = {
          count: 100
        };
        ref = this.els.dates;
        for (l = 0, len1 = ref.length; l < len1; l++) {
          o = ref[l];
          o = $(o);
          val = o.val();
          if (!val) {
            CSH.hint('请选择开始/结束时间');
            return;
          }
          data[o.attr('data-type')] = val;
        }
        this.els.toolBox.find('button.chooseRange.selected').removeClass('selected');
        return this.fetchHistory(data);
      };

      View.prototype.eventConditionChanged = function(event) {
        var b, el, type;
        el = $(event.currentTarget);
        type = el.attr('data-type');
        b = el.prop('checked');
        this.data.conditions[type] = +b;
        return this.els.tableBox[b ? 'addClass' : 'removeClass'](type);
      };

      View.prototype.fetchHistory = function(data) {
        var btn, count, ref;
        this.els.tableBox.html(TplLoading);
        btn = this.els.btnSearch.prop('disabled', true);
        this.data.list = null;
        count = data.count;
        delete data.count;
        if ((ref = this.xhr) != null) {
          ref.abort();
        }
        return new CollectionHistory().setUrl(CSH.gID, count, 1).fetch({
          reset: true,
          data: data.ds ? data : null,
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              btn.prop('disabled', false);
              _this.data.list = data.toJSON().data;
              return _this.renderTrendData();
            };
          })(this)
        });
      };

      View.prototype.eventMDownTableBox = function(event) {
        var el, t;
        el = $(event.currentTarget);
        t = el.children('table');
        el.addClass('dragging');
        el.data('startX', event.clientX);
        el.data('startLeft', el.scrollLeft());
        return CSH.$els.body.on('mousemove', this.eventMMoveTableBox).on('mouseup', this.eventMUpTableBox);
      };

      View.prototype.eventMUpTableBox = function(event) {
        var el;
        el = this.els.tableBox;
        el.removeClass('dragging');
        return CSH.$els.body.off('mousemove', this.eventMMoveTableBox);
      };

      View.prototype.eventMMoveTableBox = function(event) {
        var curX, el, left, startL, startX;
        el = this.els.tableBox;
        startX = el.data('startX');
        startL = el.data('startLeft');
        curX = event.clientX;
        left = startX - curX + startL;
        return el.scrollLeft(left);
      };

      return View;

    })(Backbone.View);
    Algorithm = (function() {
      function Algorithm(view) {
        var l, results;
        this.view = view;
        this.generateTemperatureAndLostLine = bind(this.generateTemperatureAndLostLine, this);
        if (+CSH.gType === 6) {
          this.alM6 = new AlgorithmMark6();
        }
        this.data = {
          list: this.view.data.list,
          info: this.view.data.methodInfo,
          index: this.view.data.methodIndex,
          itemMap: this.view.data.itemMap
        };
        switch (+CSH.gType) {
          case 1:
          case 2:
            this.range = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
            break;
          case 3:
            this.range = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
            break;
          case 4:
            this.range = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
            break;
          case 5:
            this.range = [1, 2, 3, 4, 5, 6];
            break;
          case 6:
            this.range = (function() {
              results = [];
              for (l = 1; l <= 49; l++){ results.push(l); }
              return results;
            }).apply(this);
        }
      }

      Algorithm.prototype.checkSmall = function(n) {
        var i, l, ref;
        n = +n;
        for (i = l = 0, ref = Math.floor(this.range.length / 2 - 1); 0 <= ref ? l <= ref : l >= ref; i = 0 <= ref ? ++l : --l) {
          if (n === this.range[i]) {
            return true;
          }
        }
        return false;
      };

      Algorithm.prototype.checkOdd = function(n) {
        if (n % 2) {
          return true;
        } else {
          return false;
        }
      };

      Algorithm.prototype.checkPrime = function(n) {
        n = +n;
        if (n === 0) {
          return false;
        }
        if (n === 1) {
          return true;
        }
        return n.isPrime();
      };

      Algorithm.prototype.check012 = function(n) {
        return n % 3;
      };

      Algorithm.prototype.checkTriple = function(list) {
        var ref;
        return (list[0] === (ref = list[1]) && ref === list[2]);
      };

      Algorithm.prototype.checkDouble = function(list) {
        list.sort();
        return list[0] === list[1] || list[1] === list[2];
      };

      Algorithm.prototype.checkSerial = function(list) {
        list.sort();
        return list[1] - list[0] === 1 && list[2] - list[1] === 1;
      };

      Algorithm.prototype.checkZ3 = function(list) {
        var i, l, len1, n, temp;
        temp = [];
        for (i = l = 0, len1 = list.length; l < len1; i = ++l) {
          n = list[i];
          temp[i] = n;
        }
        temp.sort();
        return (temp[0] === temp[1]) !== (temp[1] === temp[2]);
      };

      Algorithm.prototype.checkZ6 = function(list) {
        var i, j, l, m, ref;
        for (i = l = 0; l <= 3; i = ++l) {
          if (!(i < 3)) {
            continue;
          }
          for (j = m = ref = i + 1; ref <= 3 ? m <= 3 : m >= 3; j = ref <= 3 ? ++m : --m) {
            if (list[i] === list[j]) {
              return false;
            }
          }
        }
        return true;
      };

      Algorithm.prototype.checkSBT = function(list) {
        return list[0] !== list[1] && list[1] !== list[2] && list[2] !== list[0];
      };

      Algorithm.prototype.checkUPJ = function(cur, bef) {
        var temp;
        temp = cur - bef;
        switch (true) {
          case temp > 0:
            return 1;
          case temp === 0:
            return 0;
          case temp < 0:
            return -1;
        }
      };

      Algorithm.prototype.getSpan = function(list) {
        var i, l, len1, n, temp;
        temp = [];
        for (i = l = 0, len1 = list.length; l < len1; i = ++l) {
          n = list[i];
          temp[i] = n;
        }
        temp.sort();
        return temp.last() - temp[0];
      };

      Algorithm.prototype.getSum = function(list) {
        var l, len1, n, sum;
        sum = 0;
        for (l = 0, len1 = list.length; l < len1; l++) {
          n = list[l];
          sum += +n;
        }
        return sum;
      };

      Algorithm.prototype.generate = function() {
        var alM6, codes, data, dataI, dataLen, fn, getSummary, issue, l, len1, lostMap, method, nums, numsL, re, ref, summaryMap, time;
        window.a = this;
        getSummary = function(k, pi) {
          var summary;
          if (pi != null) {
            return summaryMap[k][pi] || (summaryMap[k][pi] = {
              total: 0,
              lost: [],
              states: [],
              count: 0
            });
          } else {
            summary = summaryMap[k];
            if (summary.states && summary.states.length) {
              return summary;
            } else {
              return summaryMap[k] = {
                total: 0,
                lost: [],
                states: []
              };
            }
          }
        };
        re = '<tbody class="list">';
        lostMap = {};
        summaryMap = {};
        nums = this.data.info.nums;
        numsL = nums.length;
        method = this.data.info.methods[this.data.index];
        dataLen = this.data.list.length;
        if (+CSH.gType === 6) {
          alM6 = this.alM6;
        }
        ref = this.data.list;
        fn = (function(_this) {
          return function() {
            var aa, ab, ac, ad, ae, base, codesBef, fName, hv, hvBef, i, j, kd, len, len10, len11, len2, len3, len4, len5, len6, len7, len8, len9, ln, m, n, name, name1, p, pi, place, pn, q, r, ref1, ref10, ref11, ref12, ref13, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, results, s, specificCodes, state, summary, temp, u, y, z;
            specificCodes = [];
            ref1 = method.place;
            for (m = 0, len2 = ref1.length; m < len2; m++) {
              place = ref1[m];
              specificCodes.push(codes[place]);
            }
            ref2 = method.items;
            results = [];
            for (p = 0, len3 = ref2.length; p < len3; p++) {
              name = ref2[p];
              if (name === 'issue' || name === 'time' || name === 'codes' || name === 'places' || name === '6places') {
                switch (name) {
                  case 'issue':
                    re += "<td>" + issue + "</td>";
                    break;
                  case 'time':
                    re += "<td>" + time + "</td>";
                    break;
                  case 'codes':
                    (function() {
                      var cls, i, n, ref3, temp;
                      cls = function(i) {
                        if (indexOf.call(method.place, i) >= 0) {
                          return ' class="text-red"';
                        } else {
                          return '';
                        }
                      };
                      temp = (function() {
                        var len4, q, results1;
                        results1 = [];
                        for (i = q = 0, len4 = codes.length; q < len4; i = ++q) {
                          n = codes[i];
                          results1.push("<span" + (cls(i)) + ">" + n + "</span>");
                        }
                        return results1;
                      })();
                      return re += "<td>" + (temp.join((ref3 = +CSH.gType) === 3 || ref3 === 4 ? ' ' : '')) + "</td>";
                    })();
                    break;
                  case 'places':
                    (function() {
                      var code, len4, ln, pi, pn, q, ref3, results1, summary;
                      ref3 = method.place;
                      results1 = [];
                      for (q = 0, len4 = ref3.length; q < len4; q++) {
                        place = ref3[q];
                        if (!lostMap[place]) {
                          lostMap[place] = [];
                        }
                        if (!summaryMap[place]) {
                          summaryMap[place] = [];
                        }
                        code = codes[place];
                        results1.push((function() {
                          var base, base1, len5, name1, results2, s;
                          results2 = [];
                          for (pi = s = 0, len5 = nums.length; s < len5; pi = ++s) {
                            pn = nums[pi];
                            summary = getSummary(place, pi);
                            if (summary.total == null) {
                              summary.total = 0;
                            }
                            if (!summary.lost.length) {
                              summary.lost.length = 1;
                            }
                            if ((base = summary.lost)[name1 = summary.lost.length - 1] == null) {
                              base[name1] = 0;
                            }
                            summary.states.push(pn === code);
                            if (pn === code) {
                              lostMap[place][pi] = 0;
                              re += "<td class=\"code" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\"><div><span>" + pn + "</span></div></td>";
                              summary.total++;
                              results2.push(summary.lost[summary.lost.length] = 0);
                            } else {
                              if ((base1 = lostMap[place])[pi] == null) {
                                base1[pi] = 0;
                              }
                              ln = ++lostMap[place][pi];
                              re += "<td class=\"lost" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + ln + "</td>";
                              results2.push(summary.lost[summary.lost.length - 1]++);
                            }
                          }
                          return results2;
                        })());
                      }
                      return results1;
                    })();
                    (function() {
                      var base, base1, code, count, len4, len5, ln, name1, pi, pn, q, ref3, results1, s, summary, temp;
                      if (!lostMap['hmfb']) {
                        lostMap['hmfb'] = [];
                      }
                      if (!summaryMap['hmfb']) {
                        summaryMap['hmfb'] = [];
                      }
                      temp = {};
                      ref3 = method.place;
                      for (q = 0, len4 = ref3.length; q < len4; q++) {
                        place = ref3[q];
                        code = codes[place];
                        if (!temp[code]) {
                          temp[code] = 0;
                        }
                        temp[code]++;
                      }
                      results1 = [];
                      for (pi = s = 0, len5 = nums.length; s < len5; pi = ++s) {
                        pn = nums[pi];
                        count = temp[pn];
                        summary = getSummary('hmfb', pi);
                        if (summary.total == null) {
                          summary.total = 0;
                        }
                        if (!summary.lost.length) {
                          summary.lost.length = 1;
                        }
                        if ((base = summary.lost)[name1 = summary.lost.length - 1] == null) {
                          base[name1] = 0;
                        }
                        summary.states.push(count);
                        if (count) {
                          lostMap['hmfb'][pi] = 0;
                          if (count === 1) {
                            re += "<td class=\"hmfb" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\"><span>" + pn + "</span></td>";
                          } else {
                            re += "<td class=\"hmfb multiple" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\"><span>" + pn + "<i>" + count + "</i></span></td>";
                          }
                          summary.total += count;
                          results1.push(summary.lost[summary.lost.length] = 0);
                        } else {
                          if ((base1 = lostMap['hmfb'])[pi] == null) {
                            base1[pi] = 0;
                          }
                          ln = ++lostMap['hmfb'][pi];
                          re += "<td class=\"lost" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + ln + "</td>";
                          results1.push(summary.lost[summary.lost.length - 1]++);
                        }
                      }
                      return results1;
                    })();
                    break;
                  case '6places':
                    (function() {
                      var code, i, len4, q;
                      re += "<td><div class=\"m6wrap\">";
                      for (i = q = 0, len4 = codes.length; q < len4; i = ++q) {
                        code = codes[i];
                        re += "<span class=\"m6\">\n	<span class=\"num\" data-color=\"" + (alM6.getColor(code)) + "\">" + code + "</span>\n	<span class=\"animal\">" + alM6.map[alM6.getAnimal(code)] + "</span>\n</span>";
                      }
                      return re += "</div></td>";
                    })();
                }
                continue;
              }
              if (name !== 'dx' && name !== 'du' && name !== 'vh' && name !== 'kd' && name !== 'hv' && name !== 'hvwu') {
                if (name === 'kdzu') {
                  if (lostMap[name] == null) {
                    lostMap[name] = [];
                  }
                  if (!summaryMap[name]) {
                    summaryMap[name] = [];
                  }
                } else {
                  if (lostMap[name] == null) {
                    lostMap[name] = [];
                  }
                  if (!summaryMap[name]) {
                    summaryMap[name] = {};
                  }
                  summary = getSummary(name);
                  if (summary.total == null) {
                    summary.total = 0;
                  }
                  if (!summary.lost.length) {
                    summary.lost.length = 1;
                  }
                  if ((base = summary.lost)[name1 = summary.lost.length - 1] == null) {
                    base[name1] = 0;
                  }
                }
              }
              switch (name) {
                case 'dx':
                  re += "<td class=\"others\">";
                  ref3 = method.place;
                  for (q = 0, len4 = ref3.length; q < len4; q++) {
                    place = ref3[q];
                    if (_this.checkSmall(codes[place])) {
                      re += "<span class=\"char\">小</span>";
                    } else {
                      re += "<span class=\"char text-orange\">大</span>";
                    }
                  }
                  results.push(re += "</td>");
                  break;
                case 'du':
                  re += "<td class=\"others\">";
                  ref4 = method.place;
                  for (s = 0, len5 = ref4.length; s < len5; s++) {
                    place = ref4[s];
                    if (_this.checkOdd(codes[place])) {
                      re += "<span class=\"char\">单</span>";
                    } else {
                      re += "<span class=\"char text-orange\">双</span>";
                    }
                  }
                  results.push(re += "</td>");
                  break;
                case 'vh':
                  re += "<td class=\"others\">";
                  ref5 = method.place;
                  for (u = 0, len6 = ref5.length; u < len6; u++) {
                    place = ref5[u];
                    if (_this.checkPrime(codes[place])) {
                      re += "<span class=\"char\">质</span>";
                    } else {
                      re += "<span class=\"char text-orange\">合</span>";
                    }
                  }
                  results.push(re += "</td>");
                  break;
                case '012':
                  re += "<td class=\"others\">";
                  ref6 = method.place;
                  for (y = 0, len7 = ref6.length; y < len7; y++) {
                    place = ref6[y];
                    re += "<span class=\"char\">" + (_this.check012(codes[place])) + "</span>";
                  }
                  results.push(re += "</td>");
                  break;
                case 'bz':
                case 'dz':
                case 'uz':
                case 'z3':
                case 'z6':
                case 'sbt':
                  switch (name) {
                    case 'bz':
                      fName = 'checkTriple';
                      break;
                    case 'dz':
                      fName = 'checkDouble';
                      break;
                    case 'uz':
                      fName = 'checkSerial';
                      break;
                    case 'z3':
                      fName = 'checkZ3';
                      break;
                    case 'z6':
                      fName = 'checkZ6';
                      break;
                    case 'sbt':
                      fName = 'checkSBT';
                  }
                  state = _this[fName](specificCodes);
                  summary.states.push(state);
                  if (state) {
                    re += "<td class=\"others\"><span class=\"char icon icon-right text-red\"></span></td>";
                    lostMap[name] = 0;
                    summary.total++;
                    results.push(summary.lost[summary.lost.length] = 0);
                  } else {
                    ln = ++lostMap[name];
                    re += "<td class=\"others lost\"><span class=\"char\">" + ln + "</span></td>";
                    results.push(summary.lost[summary.lost.length - 1]++);
                  }
                  break;
                case 'kd':
                  temp = [];
                  len = specificCodes.length;
                  for (i = z = 0, ref7 = len; 0 <= ref7 ? z < ref7 : z > ref7; i = 0 <= ref7 ? ++z : --z) {
                    for (j = aa = ref8 = i + 1, ref9 = len; ref8 <= ref9 ? aa < ref9 : aa > ref9; j = ref8 <= ref9 ? ++aa : --aa) {
                      temp.push(Math.abs(specificCodes[i] - specificCodes[j]));
                    }
                  }
                  results.push(re += "<td class=\"others\">" + (Math.max.apply(null, temp)) + "</td>");
                  break;
                case 'hv':
                case 'hvwu':
                  r = 0;
                  for (ab = 0, len8 = specificCodes.length; ab < len8; ab++) {
                    n = specificCodes[ab];
                    r += +n;
                  }
                  if (name === 'hvwu') {
                    r = ("" + r).split('').last();
                  }
                  results.push(re += "<td class=\"others\">" + r + "</td>");
                  break;
                case 'kdzu':
                  kd = Math.abs(specificCodes[0] - specificCodes[1]);
                  if (!lostMap[name]) {
                    lostMap[name] = [];
                  }
                  if (!summaryMap[name]) {
                    summaryMap[name] = [];
                  }
                  results.push((function() {
                    var ac, base1, base2, len9, name2, results1;
                    results1 = [];
                    for (pi = ac = 0, len9 = nums.length; ac < len9; pi = ++ac) {
                      pn = nums[pi];
                      state = kd === +pn;
                      summary = getSummary(name, pi);
                      if (summary.total == null) {
                        summary.total = 0;
                      }
                      if (!summary.lost.length) {
                        summary.lost.length = 1;
                      }
                      if ((base1 = summary.lost)[name2 = summary.lost.length - 1] == null) {
                        base1[name2] = 0;
                      }
                      summary.states.push(state);
                      if (state) {
                        lostMap[name][pi] = 0;
                        re += "<td class=\"kd" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + pn + "</td>";
                        summary.total++;
                        results1.push(summary.lost[summary.lost.length] = 0);
                      } else {
                        if ((base2 = lostMap[name])[pi] == null) {
                          base2[pi] = 0;
                        }
                        ln = ++lostMap[name][pi];
                        re += "<td class=\"lost" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + ln + "</td>";
                        results1.push(summary.lost[summary.lost.length - 1]++);
                      }
                    }
                    return results1;
                  })());
                  break;
                case 'upj':
                  re += "<td class=\"others\">";
                  codesBef = (ref10 = _this.data.list[dataI + 1]) != null ? ref10.openNumber.split(',') : void 0;
                  ref11 = method.place;
                  for (ac = 0, len9 = ref11.length; ac < len9; ac++) {
                    place = ref11[ac];
                    if (codesBef) {
                      r = _this.checkUPJ(codes[place], codesBef[place]);
                      switch (true) {
                        case r > 0:
                          re += "<span class=\"char text-red\">升</span>";
                          break;
                        case r === 0:
                          re += "<span class=\"char\">平</span>";
                          break;
                        case r < 0:
                          re += "<span class=\"char text-blue\">降</span>";
                      }
                    } else {
                      re += "<span class=\"char\">-</span>";
                    }
                  }
                  results.push(re += "</td>");
                  break;
                case '6tm':
                  re += "<td class=\"others\">";
                  if (_this.checkSmall(codes[6])) {
                    re += "<span class=\"char\">小</span>";
                  } else {
                    re += "<span class=\"char text-orange\">大</span>";
                  }
                  re += "</td>";
                  re += "<td class=\"others\">";
                  if (_this.checkOdd(codes[6])) {
                    re += "<span class=\"char\">单</span>";
                  } else {
                    re += "<span class=\"char text-orange\">双</span>";
                  }
                  re += "</td>";
                  re += "<td class=\"others\">";
                  codesBef = (ref12 = _this.data.list[dataI + 1]) != null ? ref12.openNumber.split(',') : void 0;
                  if (codesBef) {
                    r = _this.checkUPJ(codes[6], codesBef[6]);
                    switch (true) {
                      case r > 0:
                        re += "<span class=\"char text-red\">升</span>";
                        break;
                      case r === 0:
                        re += "<span class=\"char\">平</span>";
                        break;
                      case r < 0:
                        re += "<span class=\"char text-blue\">降</span>";
                    }
                  } else {
                    re += "<span class=\"char\">-</span>";
                  }
                  results.push(re += "</td>");
                  break;
                case '6hv':
                  hv = 0;
                  for (ad = 0, len10 = codes.length; ad < len10; ad++) {
                    n = codes[ad];
                    hv += +n;
                  }
                  re += "<td class=\"others\">";
                  if (hv < 175) {
                    re += "<span class=\"char\">小</span>";
                  } else {
                    re += "<span class=\"char text-orange\">大</span>";
                  }
                  re += "</td>";
                  re += "<td class=\"others\">";
                  if (_this.checkOdd(hv)) {
                    re += "<span class=\"char\">单</span>";
                  } else {
                    re += "<span class=\"char text-orange\">双</span>";
                  }
                  re += "</td>";
                  re += "<td class=\"others\">";
                  codesBef = (ref13 = _this.data.list[dataI + 1]) != null ? ref13.openNumber.split(',') : void 0;
                  if (codesBef) {
                    hvBef = 0;
                    for (ae = 0, len11 = codesBef.length; ae < len11; ae++) {
                      n = codesBef[ae];
                      hvBef += +n;
                    }
                    r = _this.checkUPJ(hv, hvBef);
                    switch (true) {
                      case r > 0:
                        re += "<span class=\"char text-red\">升</span>";
                        break;
                      case r === 0:
                        re += "<span class=\"char\">平</span>";
                        break;
                      case r < 0:
                        re += "<span class=\"char text-blue\">降</span>";
                    }
                  } else {
                    re += "<span class=\"char\">-</span>";
                  }
                  re += "</td>";
                  results.push(re += "<td class=\"others\">" + hv + "</td>");
                  break;
                default:
                  results.push(void 0);
              }
            }
            return results;
          };
        })(this);
        for (dataI = l = 0, len1 = ref.length; l < len1; dataI = ++l) {
          data = ref[dataI];
          re += '<tr>';
          issue = data.periodName;
          if (+CSH.gType === 6) {
            time = data.betEndDate.replace(/\//g, '-');
          }
          codes = data.openNumber.split(',');

          /*
          				 * 期号
          				re	+= "<td>#{ issue }</td>"
          
          				 * 开奖号
          				do ->
          					temp	= ("""<span#{ if i in method.place then ' class="text-red"' else '' }>#{ n }</span>""" for n, i in codes)
          					re		+= """<td>#{ temp.join if +CSH.gType in [3, 4] then ' ' else '' }</td>"""
          				 * 遍历 place
          				do ->
          					for place in method.place
          						lostMap[place]		= [] unless lostMap[place]
          						summaryMap[place]	= [] unless summaryMap[place]
          						code	= codes[place]
          						for pn, pi in nums
          							summary	= getSummary place, pi
          							summary.total	?= 0
          							summary.lost.length	= 1 unless summary.lost.length
          							summary.lost[summary.lost.length - 1]	?= 0
          							summary.states.push pn is code
          							if pn is code
          								lostMap[place][pi]	= 0
          								re	+= """<td class="code#{ if pi + 1 is numsL then ' endOfPlaces' else '' }"><div><span>#{ pn }</span></div></td>"""
          								summary.total++
          								summary.lost[summary.lost.length]	= 0
          							else
          								lostMap[place][pi]	?= 0
          								 * 当前遗漏数
          								ln	= ++lostMap[place][pi]
          								re	+= """<td class="lost#{ if pi + 1 is numsL then ' endOfPlaces' else '' }">#{ ln }</td>"""
          								summary.lost[summary.lost.length - 1]++
          				 * 号码分布
          				do ->
          					lostMap['hmfb']		= [] unless lostMap['hmfb']
          					summaryMap['hmfb']	= [] unless summaryMap['hmfb']
          					temp	= {}
          					for place in method.place
          						code	= codes[place]
          						temp[code]	= 0 unless temp[code]
          						temp[code]++
          					for pn, pi in nums
          						count	= temp[pn]
          						summary	= getSummary 'hmfb', pi
          						summary.total	?= 0
          						summary.lost.length	= 1 unless summary.lost.length
          						summary.lost[summary.lost.length - 1]	?= 0
          						summary.states.push count
          						if count
          							lostMap['hmfb'][pi]	= 0
          							if count is 1
          								re	+= """<td class="hmfb#{ if pi + 1 is numsL then ' endOfPlaces' else '' }"><span>#{ pn }</span></td>"""
          							else
          								re	+= """<td class="hmfb multiple#{ if pi + 1 is numsL then ' endOfPlaces' else '' }"><span>#{ pn }<i>#{ count }</i></span></td>"""
          							summary.total	+= count
          							summary.lost[summary.lost.length]	= 0
          						else
          							lostMap['hmfb'][pi]	?= 0
          							 * 当前遗漏数
          							ln	= ++lostMap['hmfb'][pi]
          							re	+= """<td class="lost#{ if pi + 1 is numsL then ' endOfPlaces' else '' }">#{ ln }</td>"""
          							summary.lost[summary.lost.length - 1]++
           */
          fn();
          re += '</tr>';
        }
        re += '</tbody>';
        if (+CSH.gType === 6) {
          return re;
        }
        re += '<tbody class="summary">';
        re += this.generateTotal(method, nums, numsL, summaryMap);
        re += this.generateLostAvg(method, nums, numsL, summaryMap);
        re += this.generateLostMax(method, nums, numsL, summaryMap);
        re += this.generateSerialMax(method, nums, numsL, summaryMap);
        re += '</tbody>';
        (function(_this) {
          return (function() {
            var b, count, i, len2, m, obj, place, ref1, results, temp, tl;
            tl = _this.data.tl = {};
            ref1 = method.place;
            results = [];
            for (m = 0, len2 = ref1.length; m < len2; m++) {
              place = ref1[m];
              tl[place] = [];
              results.push((function() {
                var len3, len4, p, q, ref2, ref3, results1;
                ref2 = summaryMap[place];
                results1 = [];
                for (i = p = 0, len3 = ref2.length; p < len3; i = ++p) {
                  temp = ref2[i];
                  obj = tl[place][i] = {};
                  count = 0;
                  ref3 = temp.states;
                  for (q = 0, len4 = ref3.length; q < len4; q++) {
                    b = ref3[q];
                    if (b) {
                      break;
                    }
                    count++;
                  }
                  obj.lostCount = count;
                  results1.push(obj.total = temp.total);
                }
                return results1;
              })());
            }
            return results;
          });
        })(this)();
        setTimeout(this.generateTemperatureAndLostLine, 0);
        return re;
      };

      Algorithm.prototype.generateTotal = function(method, nums, numsL, summaryMap) {
        var l, len1, len2, len3, len4, len5, m, name, p, pi, place, pn, q, re, ref, ref1, s;
        re = '<tr><td>出现总次数</td><td>&nbsp;</td>';
        ref = method.place;
        for (l = 0, len1 = ref.length; l < len1; l++) {
          place = ref[l];
          for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
            pn = nums[pi];
            re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + summaryMap[place][pi].total + "</td>";
          }
        }
        for (pi = p = 0, len3 = nums.length; p < len3; pi = ++p) {
          pn = nums[pi];
          re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + summaryMap['hmfb'][pi].total + "</td>";
        }
        ref1 = method.items;
        for (q = 0, len4 = ref1.length; q < len4; q++) {
          name = ref1[q];
          switch (name) {
            case 'dx':
            case 'du':
            case 'vh':
            case '012':
            case 'kd':
            case 'hv':
            case 'hvwu':
            case 'upj':
              re += '<td>&nbsp;</td>';
              break;
            case 'bz':
            case 'dz':
            case 'uz':
            case 'z3':
            case 'z6':
            case 'sbt':
              re += "<td class=\"others\">" + summaryMap[name].total + "</td>";
              break;
            case 'kdzu':
              for (pi = s = 0, len5 = nums.length; s < len5; pi = ++s) {
                pn = nums[pi];
                re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + summaryMap[name][pi].total + "</td>";
              }
          }
        }
        re += '</tr>';
        return re;
      };

      Algorithm.prototype.generateLostAvg = function(method, nums, numsL, summaryMap) {
        var avg, fun, l, len1, len2, lost, m, name, pi, pn, re, ref;
        re = '<tr><td>平均遗漏值</td><td>&nbsp;</td>';
        fun = function(lost) {
          var c, l, len1, sum;
          sum = 0;
          for (l = 0, len1 = lost.length; l < len1; l++) {
            c = lost[l];
            sum += c;
          }
          return Math.round(sum / lost.length);
        };
        (function() {
          var avg, l, len1, lost, pi, place, pn, ref, results;
          ref = method.place;
          results = [];
          for (l = 0, len1 = ref.length; l < len1; l++) {
            place = ref[l];
            results.push((function() {
              var len2, m, results1;
              results1 = [];
              for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
                pn = nums[pi];
                lost = summaryMap[place][pi].lost;
                avg = fun(lost);
                results1.push(re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + avg + "</td>");
              }
              return results1;
            })());
          }
          return results;
        })();
        (function() {
          var avg, l, len1, lost, pi, pn, results;
          results = [];
          for (pi = l = 0, len1 = nums.length; l < len1; pi = ++l) {
            pn = nums[pi];
            lost = summaryMap['hmfb'][pi].lost;
            avg = fun(lost);
            results.push(re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + avg + "</td>");
          }
          return results;
        })();
        ref = method.items;
        for (l = 0, len1 = ref.length; l < len1; l++) {
          name = ref[l];
          switch (name) {
            case 'dx':
            case 'du':
            case 'vh':
            case '012':
            case 'kd':
            case 'hv':
            case 'hvwu':
            case 'upj':
              re += '<td>&nbsp;</td>';
              break;
            case 'bz':
            case 'dz':
            case 'uz':
            case 'z3':
            case 'z6':
            case 'sbt':
              lost = summaryMap[name].lost;
              avg = fun(lost);
              re += "<td class=\"others\">" + avg + "</td>";
              break;
            case 'kdzu':
              for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
                pn = nums[pi];
                lost = summaryMap[name][pi].lost;
                avg = fun(lost);
                re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + avg + "</td>";
              }
          }
        }
        re += '</tr>';
        return re;
      };

      Algorithm.prototype.generateLostMax = function(method, nums, numsL, summaryMap) {
        var l, len1, len2, lost, m, max, name, pi, pn, re, ref;
        re = '<tr><td>最大遗漏值</td><td>&nbsp;</td>';
        (function() {
          var l, len1, lost, max, pi, place, pn, ref, results;
          ref = method.place;
          results = [];
          for (l = 0, len1 = ref.length; l < len1; l++) {
            place = ref[l];
            results.push((function() {
              var len2, m, results1;
              results1 = [];
              for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
                pn = nums[pi];
                lost = summaryMap[place][pi].lost;
                max = Math.max.apply(null, lost);
                results1.push(re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + max + "</td>");
              }
              return results1;
            })());
          }
          return results;
        })();
        (function() {
          var l, len1, lost, max, pi, pn, results;
          results = [];
          for (pi = l = 0, len1 = nums.length; l < len1; pi = ++l) {
            pn = nums[pi];
            lost = summaryMap['hmfb'][pi].lost;
            max = Math.max.apply(null, lost);
            results.push(re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + max + "</td>");
          }
          return results;
        })();
        ref = method.items;
        for (l = 0, len1 = ref.length; l < len1; l++) {
          name = ref[l];
          switch (name) {
            case 'dx':
            case 'du':
            case 'vh':
            case '012':
            case 'kd':
            case 'hv':
            case 'hvwu':
            case 'upj':
              re += '<td>&nbsp;</td>';
              break;
            case 'bz':
            case 'dz':
            case 'uz':
            case 'z3':
            case 'z6':
            case 'sbt':
              lost = summaryMap[name].lost;
              max = Math.max.apply(null, lost);
              re += "<td class=\"others\">" + max + "</td>";
              break;
            case 'kdzu':
              for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
                pn = nums[pi];
                lost = summaryMap[name][pi].lost;
                max = Math.max.apply(null, lost);
                re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + max + "</td>";
              }
          }
        }
        re += '</tr>';
        return re;
      };

      Algorithm.prototype.generateSerialMax = function(method, nums, numsL, summaryMap) {
        var fun, l, len1, len2, m, max, name, pi, pn, re, ref;
        re = '<tr><td>最大连出数</td><td>&nbsp;</td>';
        fun = function(summary) {
          var b, l, len1, serial, states;
          states = summary.states;
          serial = [0];
          for (l = 0, len1 = states.length; l < len1; l++) {
            b = states[l];
            if (b) {
              serial[serial.length - 1]++;
            } else {
              serial[serial.length] = 0;
            }
          }
          return Math.max.apply(null, serial);
        };
        (function() {
          var l, len1, max, pi, place, pn, ref, results;
          ref = method.place;
          results = [];
          for (l = 0, len1 = ref.length; l < len1; l++) {
            place = ref[l];
            results.push((function() {
              var len2, m, results1;
              results1 = [];
              for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
                pn = nums[pi];
                max = fun(summaryMap[place][pi]);
                results1.push(re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + max + "</td>");
              }
              return results1;
            })());
          }
          return results;
        })();
        (function() {
          var l, len1, max, pi, pn, results;
          results = [];
          for (pi = l = 0, len1 = nums.length; l < len1; pi = ++l) {
            pn = nums[pi];
            max = fun(summaryMap['hmfb'][pi]);
            results.push(re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + max + "</td>");
          }
          return results;
        })();
        ref = method.items;
        for (l = 0, len1 = ref.length; l < len1; l++) {
          name = ref[l];
          switch (name) {
            case 'dx':
            case 'du':
            case 'vh':
            case '012':
            case 'kd':
            case 'hv':
            case 'hvwu':
            case 'upj':
              re += '<td>&nbsp;</td>';
              break;
            case 'bz':
            case 'dz':
            case 'uz':
            case 'z3':
            case 'z6':
            case 'sbt':
              max = fun(summaryMap[name]);
              re += "<td class=\"others\">" + max + "</td>";
              break;
            case 'kdzu':
              for (pi = m = 0, len2 = nums.length; m < len2; pi = ++m) {
                pn = nums[pi];
                max = fun(summaryMap[name][pi]);
                re += "<td class=\"" + (pi + 1 === numsL ? ' endOfPlaces' : '') + "\">" + max + "</td>";
              }
          }
        }
        re += '</tr>';
        return re;
      };

      Algorithm.prototype.generateTemperatureAndLostLine = function() {
        var arr, ball1, ball2, balls, box, cC, cCount, cH, cM, cName, canvas, context, data, dvX, dvY, h, hcmData, i, l, left, len, len1, len2, len3, len4, m, method, nCount, nums, obj, p, pCount, pi, place, placeI, pn, q, ref, ref1, ref2, results, s, sLeft, table, tbody, tdEl, tdEls, tdI, temp, temp1, temp2, trEl, trEls, trI, u, w, x, x1, x2, xBox, y, y1, y2, yBox;
        table = this.view.els.table;
        box = table.parent();
        tbody = table.find('> tbody.list');
        nums = this.data.info.nums;
        method = this.data.info.methods[this.data.index];
        nCount = nums.length;
        pCount = method.place.length;
        cCount = nCount * pCount;
        data = this.data.tl;
        hcmData = {};
        balls = {};
        temp = box.offset();
        xBox = temp.left;
        yBox = temp.top;
        sLeft = box.scrollLeft();
        switch (+CSH.gType) {
          case 1:
          case 2:
          case 4:
            cH = 3;
            cC = 3;
            cM = 4;
            break;
          case 3:
            cH = 3;
            cC = 3;
            cM = 5;
            break;
          case 5:
            cH = 2;
            cC = 2;
            cM = 2;
        }
        for (place in data) {
          if (!hasProp.call(data, place)) continue;
          obj = data[place];
          temp = hcmData[place] = {
            hot: [],
            medium: [],
            cold: []
          };
          temp1 = [];
          temp2 = new Stack();
          for (pi = l = 0, len1 = nums.length; l < len1; pi = ++l) {
            pn = nums[pi];
            obj[pi].p = pn;
            temp1.push(obj[pi]);
          }
          temp1.sort(function(a, b) {
            if (a.total === b.total) {
              return a.lostCount < b.lostCount;
            } else {
              return a.total > b.total;
            }
          });
          for (m = 0, len2 = temp1.length; m < len2; m++) {
            x = temp1[m];
            temp2.push(x.p);
          }
          for (i = p = 0, ref = cH; 0 <= ref ? p < ref : p > ref; i = 0 <= ref ? ++p : --p) {
            temp.hot.push(temp2.pop());
          }
          for (i = q = 0, ref1 = cM; 0 <= ref1 ? q < ref1 : q > ref1; i = 0 <= ref1 ? ++q : --q) {
            temp.medium.push(temp2.pop());
          }
          for (i = s = 0, ref2 = cC; 0 <= ref2 ? s < ref2 : s > ref2; i = 0 <= ref2 ? ++s : --s) {
            temp.cold.push(temp2.pop());
          }
        }
        trEls = tbody.find('> tr');
        for (trI = u = 0, len3 = trEls.length; u < len3; trI = ++u) {
          trEl = trEls[trI];
          trEl = $(trEl);
          tdEls = trEl.find('> td');
          for (tdI = y = 0, len4 = tdEls.length; y < len4; tdI = ++y) {
            tdEl = tdEls[tdI];
            if (tdI < 2) {
              continue;
            }
            if (tdI > cCount + 2 - 1) {
              break;
            }
            tdEl = $(tdEl);
            placeI = Math.floor((tdI - 2) / nCount);
            place = method.place[placeI];
            pi = (tdI - 2) % nCount;
            pn = nums[pi];
            cName = (function() {
              if (indexOf.call(hcmData[place].hot, pn) >= 0) {
                return 'state-hot';
              } else if (indexOf.call(hcmData[place].medium, pn) >= 0) {
                return 'state-medium';
              } else if (indexOf.call(hcmData[place].cold, pn) >= 0) {
                return 'state-cold';
              }
            })();
            if (tdEl.hasClass('code')) {
              tdEl.addClass(cName);
              if (balls[place] == null) {
                balls[place] = [];
              }
              balls[place].push(tdEl);
            } else {
              if (!(trI > data[place][pi].lostCount - 1)) {
                tdEl.addClass('lostItem');
              }
            }
          }
        }
        results = [];
        for (place in balls) {
          if (!hasProp.call(balls, place)) continue;
          arr = balls[place];
          len = arr.length;
          results.push((function() {
            var len5, results1, z;
            results1 = [];
            for (i = z = 0, len5 = arr.length; z < len5; i = ++z) {
              ball1 = arr[i];
              if (!(i + 1 < len)) {
                break;
              }
              ball2 = arr[i + 1];
              if (typeof w === "undefined" || w === null) {
                w = ball1.outerWidth(true);
                h = ball1.outerHeight(true);
              }
              temp = ball1.offset();
              x1 = temp.left - xBox + w / 2;
              y1 = temp.top - yBox + h / 2;
              temp = ball2.offset();
              x2 = temp.left - xBox + w / 2;
              y2 = temp.top - yBox + h / 2;
              dvX = x2 - x1;
              dvY = y2 - y1;
              canvas = $("<canvas width=\"" + (dvX ? Math.abs(dvX) : 2) + "\" height=\"" + (Math.abs(dvY)) + "\">");
              context = canvas[0].getContext('2d');
              context.strokeStyle = '#d74241';
              context.lineWidth = 2;
              if (dvX < 0) {
                canvas.css({
                  left: x1 + sLeft - -dvX,
                  top: y1
                });
                context.moveTo(-dvX, 0);
                context.lineTo(0, dvY);
              } else {
                left = x1 + sLeft;
                canvas.css({
                  left: left,
                  top: y1
                });
                context.moveTo(0, 0);
                context.lineTo(dvX, dvY);
              }
              context.stroke();
              results1.push(canvas.appendTo(box));
            }
            return results1;
          })());
        }
        return results;
      };

      return Algorithm;

    })();
    return View;
  });

}).call(this);
