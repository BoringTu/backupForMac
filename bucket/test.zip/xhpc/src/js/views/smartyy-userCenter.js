(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/balance', 'models/safesetschecks', 'models/getuserfreeze', 'models/info_contract', 'models/safelevel', 'text!../../templates/smartyy-userCenter.tpl', 'text!../../templates/_smartyy-contentLoading.tpl'], function($, _, Backbone, doT, ModelsBalance, ModelSafesetschecks, ModelGetuserfreeze, ModelInfo_contract, Modelsafelevel, TplContent, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .reportEntry a': 'eventLoadView',
        'click .status.weak a': 'eventLoadView',
        'click .moneyList a.loadView': 'eventLoadView',
        'click .widget .tabTitle .record': 'eventTriggerLoadSubView',
        'click .moneyList .icons .icon-refresh': 'refreshBalance',
        'click .moneyList .icons .balanceVisibility': 'eventToggleCapitalVisibility'
      };

      View.prototype.initialize = function(data) {
        CSH.views.userCenter = this;
        if (CSH.pageName !== 'userCenter') {
          return;
        }
        this.data = {};
        return this.render();
      };

      View.prototype.destroy = function() {
        return delete CSH.views.userCenter;
      };

      View.prototype.render = function() {
        var it;
        it = {};
        it.username = localStorage.getItem('username');
        it.rebate = localStorage.getItem('rebate');
        return new ModelInfo_contract().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var isContract;
              data = data.toJSON();
              it.contract = data;
              isContract = +data.code === 1 ? 0 : data.data.state;
              localStorage.setItem('contractState', isContract);
              new ModelGetuserfreeze().setUrl().fetch({
                dataFilter: function(data) {
                  var allText, name, ref, text;
                  data = data.toJSON();
                  _this.freezeNum = data.data.freeze;
                  allText = "";
                  _this.freeze = {};

                  /*
                  								@freezeNum
                  								1: 账号冻结
                  								2： 资金冻结
                  								4： 登录冻结
                  								8： 取款冻结
                  								16：转账冻结
                  								32：购彩冻结
                  								64：分红冻结
                  								128：日工资冻结
                  								256： 虚拟冻结
                  
                  								0 || 256 锁不显示
                   */
                  if ((_this.freezeNum & 8) === 8) {
                    _this.freeze.extractMoney = '取款';
                  }
                  if ((_this.freezeNum & 16) === 16) {
                    _this.freeze.transferAccounts = '转账';
                  }
                  if ((_this.freezeNum & 128) === 128) {
                    _this.freeze.dayMoney = '日工资';
                  }
                  for (text in _this.freeze) {
                    allText += _this.freeze[text] + "、";
                  }
                  allText = allText.substring(0, allText.length - 1);
                  if ((_this.freezeNum & 2) === 2) {
                    _this.freeze.transferAccounts = _this.freeze.extractMoney = '资金';
                    allText = _this.freeze.transferAccounts;
                  }
                  if ((_this.freezeNum & 64) === 64) {
                    _this.freeze.contract = '分红';
                    it.freezeText = "您的分红发放未完成，请完成分红";
                  } else if ((ref = _this.freezeNum) !== 0 && ref !== 256) {
                    it.freezeText = "您的" + allText + "已经冻结, 请联系客服解决";
                  }
                  _this.$el.html(_this.tpls.content(it));
                  _this.els = {};
                  _this.els.content = _this.$el.find('.content');
                  _this.els.freezeText = _this.$el.find('.rightBox .freezeText');
                  _this.els.defaultUserCenter = _this.$el.find('.reportEntry .defaultUserCenter');
                  _this.els.moneyList = _this.$el.find('.moneyList');
                  _this.els.balance = _this.els.moneyList.find('.balance');
                  _this.els.balanceVisibility = _this.els.moneyList.find('.balanceVisibility');
                  _this.btn = false;
                  _this.getInfo();
                  CSH.views.body.initChangeBalanceDOM(_this.els.balance, _this.els.balanceVisibility);
                  name = CSH.routePath[0];
                  if (name) {
                    return _this.loadView(name);
                  } else {
                    name = 'security';
                    _this.loadView(name, true);
                    return CSH.refreshMenuStatus();
                  }
                }
              });
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventTriggerLoadSubView = function(event) {
        var el;
        el = $(event.currentTarget);
        CSH.data.targetTab = el.attr('data-targettab');
        this.eventLoadView(event);
      };

      View.prototype.loadView = function(name, isInit) {
        var order, ref;
        if (+localStorage.getItem('isNormalUser') === 2) {
          if (name === 'recharge' || name === 'extractMoney') {
            CSH.hint('亲，试玩账户不享有该权限哦！');
            this.els.defaultUserCenter.trigger('click');
            return;
          }
          if (name === 'transferAccounts' && +localStorage.getItem('userType') === 1) {
            CSH.hint('亲，试玩账户不享有该权限哦！');
            this.els.defaultUserCenter.trigger('click');
            return;
          }
        }
        if (name === 'extractMoney' || name === 'transferAccounts') {
          if ((this.freezeNum & 2) === 2) {
            return CSH.hint("您的" + this.freeze.transferAccounts + "已冻结");
          }
        }
        if ((name === 'extractMoney') && (this.freezeNum & 8) === 8) {
          return CSH.hint("您的" + this.freeze.extractMoney + "已冻结");
        }
        if ((name === 'transferAccounts') && (this.freezeNum & 16) === 16) {
          return CSH.hint("您的" + this.freeze.transferAccounts + "已冻结");
        }
        if ((name === 'transferAccounts' || name === 'extractMoney') && (this.freezeNum & 64) === 64) {
          return CSH.hint("您有下级分红未发放,不能提现／转账");
        }
        if ((name === 'transferAccounts' || name === 'extractMoney') && (this.freezeNum & 128) === 128) {
          return CSH.hint("您的" + this.freeze.dayMoney + "已冻结,不能提现／转账／购彩");
        }
        if (+localStorage.getItem('contractState') === 5 && name === 'contract') {
          return CSH.hint('您的契约已关闭');
        }
        if ((ref = this.oldView) != null) {
          if (typeof ref.destroy === "function") {
            ref.destroy();
          }
        }
        this.showLoading();
        if (isInit) {
          order = 'replaceState';
          CSH.routePath = [name];
        } else {
          order = 'pushState';
        }
        history[order](null, null, "#" + name);
        return require(["views/subsets/smartyy-" + CSH.pageName + "_" + name], (function(_this) {
          return function(View) {
            _this.oldView = new View({
              el: _this.els.content,
              pView: _this
            });
            _this.els.content.addClass(name);
            return _this.oldName = name;
          };
        })(this));
      };

      View.prototype.showLoading = function() {
        return this.els.content.off().empty().removeClass(this.oldName).html(TplLoading);
      };

      View.prototype.eventLoadView = function(event) {
        var el, href, name, ref;
        el = $(event.currentTarget);
        event.preventDefault();
        if (this.btn) {
          return;
        }
        this.btn = true;
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 500);
        href = el.attr('href');
        if (href === 'javascript:;') {
          return;
        }
        name = href.replace(/^.*#/, '');
        CSH.routePath[0] = name;
        CSH.refreshMenuStatus();
        if (name === 'recharge' && CSH.data.recharge_isPaying) {
          if ((ref = this.oldView) != null) {
            if (typeof ref.showAdvice === "function") {
              ref.showAdvice(0);
            }
          }
          return;
        }
        CSH.data.recharge_isPaying = false;
        return this.loadView(name);
      };

      View.prototype.getInfo = function() {
        new ModelSafesetschecks().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var safesetschecks;
              data = data.toJSON();
              safesetschecks = JSON.stringify(data.data[0]);
              return localStorage.setItem('safesetschecks', safesetschecks);
            };
          })(this)
        });
        return new Modelsafelevel().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var number;
              data = data.toJSON();
              number = data.data;
              return localStorage.setItem('safetyValue', number);
            };
          })(this)
        });
      };

      View.prototype.refreshBalance = function(event) {
        var el;
        el = $(event.currentTarget);
        el.addClass('icon-spin');
        return CSH.refreshBalance(null, el);
      };

      View.prototype.eventToggleCapitalVisibility = function() {
        return CSH.views.body.toggleCapitalVisibility();
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
