(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'text!../../templates/download.tpl', 'qrcode'], function($, _, Backbone, doT, TplContent) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .w3_btns a': 'eventshowFeature'
      };

      View.prototype.initialize = function() {
        return this.render();
      };

      View.prototype.destroy = function() {
        if (this.handle != null) {
          clearTimeout(this.handle);
        }
        return CSH.$els.window.off('scroll', this.winScroll);
      };

      View.prototype.render = function() {
        this.loadAppVersion();
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.dlAs = this.$el.find('.dlAnchor');
        this.els.items = this.$el.find('.w3_con_phone');
        this.els.btns = this.$el.find('.w3_btns a');
        this.els.w2t = this.$el.find('.w2_t');
        this.els.phone = this.$el.find('.aniPhoneFlow img');
        this.els.phone.attr({
          src: "/images/download/p_drop-" + CSH.fix + ".png"
        });
        this.flagFirst1 = true;
        this.flagFirst2 = true;
        this.generateQRCode();
        return this.pageAnimationInit();
      };

      View.prototype.generateQRCode = function() {
        var target;
        target = this.$el.find('.qrcode');
        return setTimeout(function() {
          return target.qrcode({
            text: location.origin + "/download.html",
            render: 'div',
            ecLevel: 'H',
            size: 118,
            minVersion: 8,
            background: '#fff'
          });
        }, 250);
      };

      View.prototype.loadAppVersion = function() {
        var fun;
        $.ajax({
          url: CSH.path.fapi + "/appLatestVersion",
          contentType: 'application/json',
          dataFilter: function(data) {
            return fun(data.toJSON().data.version);
          }
        });
        return fun = (function(_this) {
          return function(v) {
            var a, href, j, len, ref, results, type;
            ref = _this.els.dlAs;
            results = [];
            for (j = 0, len = ref.length; j < len; j++) {
              a = ref[j];
              a = $(a);
              type = a.attr('data-type');
              if (type === 'ios') {
                continue;
              }
              href = a.attr('href');
              results.push(a.attr({
                href: href + "?v=" + v
              }));
            }
            return results;
          };
        })(this);
      };

      View.prototype.eventshowFeature = function(event) {
        var el, index;
        el = $(event.currentTarget);
        index = el.index();
        el.addClass('active').siblings('.active').removeClass('active');
        this.els.items.filter('.show').removeClass('show').end().eq(index).addClass('show');
        if (this.handle != null) {
          clearTimeout(this.handle);
        }
        return this.transformFeature();
      };

      View.prototype.transformFeature = function() {
        return this.handle = setTimeout((function(_this) {
          return function() {
            var i;
            i = _this.els.btns.filter('.active').index() + 1;
            if (!(i < 3)) {
              i = 0;
            }
            return _this.els.btns.eq(i).click();
          };
        })(this), 6000);
      };

      View.prototype.pageAnimationInit = function() {
        var fixedMenu, imgRag, mSightH, moveEl, rootEl, sBgPos, top1, top2, w;
        rootEl = document.documentElement;
        w = CSH.$els.window;
        fixedMenu = 50;
        top1 = this.els.w2t.offset().top;
        top2 = this.$el.find('.w3').offset().top;
        moveEl = this.$el.find('.w2_moveBg');
        sBgPos = parseInt(moveEl.css('background-position-y'));
        mSightH = 395;
        imgRag = 1048 - mSightH;
        this.winScroll = (function(_this) {
          return function() {
            var ch, n, pageRag, sScr, sh, x;
            sh = w.scrollTop();
            ch = rootEl.clientHeight;
            sScr = top1 - ch;
            pageRag = rootEl.clientHeight + mSightH - fixedMenu;
            if (top1 - sh < ch && top2 - sh > fixedMenu) {
              n = sh - sScr;
              x = imgRag / pageRag * n;
              moveEl.css('background-position-y', sBgPos - x);
            }
            if (_this.flagFirst1 && top1 - sh < ch - 230) {
              _this.flagFirst1 = false;
              _this.els.w2t.addClass('aniW2t');
            }
            if (_this.flagFirst2 && top2 - sh < ch - 420) {
              _this.flagFirst2 = false;
              return _this.els.btns.first().click();
            }
          };
        })(this);
        return w.on('scroll', this.winScroll);
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
