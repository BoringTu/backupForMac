(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', '../algorithm', 'views/subsets/default-lottery_headbar', 'views/subsets/default-lottery_betting', 'views/subsets/default-lottery_wallet', 'views/subsets/default-lottery_listBox1', 'views/subsets/default-lottery_listBox2', 'text!../../templates/default-lottery.tpl'], function($, _, Backbone, doT, Algorithm, ViewHeadbar, ViewBetting, ViewWallet, ViewListBox1, ViewListBox2, TplContent) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.initialize = function() {
        window.v = this;
        CSH.gID = CSH.routePath[0];
        CSH.gType = CSH.gID.charAt(0);
        CSH.balance = localStorage.getItem('balance');
        this.data = {};
        this.views = {};
        this.algorithm = new Algorithm(this);
        this.resetWS();
        return this.render();
      };

      View.prototype.destroy = function() {
        var k, ref, ref1, v;
        clearInterval(this._interval);
        console.warn('headbar destroy');
        ref = this.views;
        for (k in ref) {
          if (!hasProp.call(ref, k)) continue;
          v = ref[k];
          if (typeof v.destroy === "function") {
            if ((ref1 = v.destroy()) != null) {
              ref1.remove();
            }
          }
        }
        this.ws.onopen = null;
        this.ws.onerror = null;
        this.ws.onclose = null;
        this.ws.onmessage = null;
        CSH.ws_number = null;
        this._activeToClose = 1;
        return this.ws.close();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.headbar = this.$el.find('.headbar');
        this.els.betting = this.$el.find('.bettingContainer');
        this.els.wallet = this.$el.find('.walletContainer');
        this.els.listBox1 = this.$el.find('.listBox1');
        this.els.listBox2 = this.$el.find('.listBox2');
        this.views.headbar = new ViewHeadbar({
          el: this.els.headbar,
          parent: this
        });
        this.views.betting = new ViewBetting({
          el: this.els.betting,
          parent: this,
          algorithm: this.algorithm
        });
        this.views.wallet = new ViewWallet({
          el: this.els.wallet,
          parent: this
        });
        this.views.listBox1 = new ViewListBox1({
          el: this.els.listBox1,
          parent: this
        });
        return this.views.records = new ViewListBox2({
          el: this.els.listBox2,
          parent: this
        });
      };

      View.prototype.resetWS = function() {
        var _abortedCount, _close, _createNewWS, _error, _message, switchCZ, view;
        view = this;
        _abortedCount = 0;
        switchCZ = (function(_this) {
          return function() {
            _this.ws.send(JSON.stringify({
              model: 1,
              msgType: 2,
              target: {
                targetCategory: CSH.gID
              }
            }));
            return _this._interval = setInterval((function() {
              return _this.ws.send('{}');
            }), 30000);
          };
        })(this);
        _message = function(event) {
          var codes, data, issue, listBox1;
          if (event.data === 'Connect successful!') {
            return;
          }
          data = event.data.toJSON();
          if (data.msgType !== 2) {
            return;
          }
          codes = data.msg.split(',');
          issue = data.fromSource;
          view.views.headbar.showLotteryNumbers(issue, codes);
          view.views.betting.refreshYllr();
          listBox1 = view.views.listBox1;
          if (listBox1.data.type === 'lotteryRecords') {
            return listBox1.fetch_lotteryRecords();
          }
        };
        _error = function() {
          console.error('error', arguments);
          return _createNewWS();
        };
        _close = function() {
          console.error('closed', arguments);
          if (!this._activeToClose) {
            return _createNewWS();
          }
        };
        _createNewWS = (function(_this) {
          return function() {
            var ws;
            if (_abortedCount++ > 5) {
              return;
            }
            _this.ws = ws = CSH.ws_number = new WebSocket(CSH.path.ws);
            ws.onmessage = _message;
            ws.onerror = _error;
            ws.onclose = _close;
            if (ws.readyState === 1) {
              return switchCZ();
            } else {
              return ws.onopen = switchCZ;
            }
          };
        })(this);
        return _createNewWS();
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
