(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/info', 'models/safelevel', 'models/currentperiodallinfo', 'models/balance', 'models/activitys', 'models/adList', 'collections/announceByPage', 'text!../../templates/index.tpl', 'text!../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelUserInfo, ModelSafeLevel, ModelCurrentPeriodAllInfo, ModelBalance, ModelActivitys, ModelAdList, CollectionAnnounceByPage, TplContent, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.refreshSwitchPositionPoster = bind(this.refreshSwitchPositionPoster, this);
        this.refreshSwitchPositionBanner = bind(this.refreshSwitchPositionBanner, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .swipe.banner .position i': 'eventSwitchoverBanner',
        'click .swipe.poster .position i': 'eventSwitchoverPoster',
        'click .balanceVisibility': 'eventToggleBalanceVisibility',
        'click .refreshBalance': 'eventRefreshBalance',
        'click .dataListBox h4 .title': 'eventLoadDataList',
        'mouseenter .lotteryBox > a': 'eventShowCZCountDown',
        'mouseleave .lotteryBox > a': 'eventHideCZCountDown'
      };

      View.prototype.initialize = function() {
        this.data = {};
        this.fetchUserInfo();
        this.fetchSafeLevel();
        this.fetchGamesRecentOpen();
        this.render();
        this.time = false;
        this.els.rBalance.click();
        if (!JSON.parse(localStorage.getItem('visibility-capital'))) {
          this.els.bVisibility.addClass('icon-visible').removeClass('icon-invisible');
        }
        return window.v = this;
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content({
          username: localStorage.getItem('username')
        }));
        this.els = {};
        this.els.banner = this.$el.find('.banner');
        this.els.poster = this.$el.find('.poster');
        this.els.lotteryBox = this.$el.find('.lotteryBox');
        this.els.infoBox = this.$el.find('.infoBox');
        this.els.balanceBox = this.$el.find('.balanceBox');
        this.els.safetyBox = this.$el.find('.safetyBox');
        this.els.dataListBox = this.$el.find('.dataListBox');
        this.els.demo = this.$el.find('.demo');
        this.els.rBalance = this.els.balanceBox.find('.refreshBalance');
        this.els.bVisibility = this.els.balanceBox.find('.balanceVisibility');
        CSH.$els.balance.index = this.els.balanceBox;
        this.els.capitalVisibility = $('.capitalVisibility');
        this.els.dataListBox.find('h4 .title:first-child').click();
        this.loadLotteryCountDown();
        this.bannerTransformationInit();
        this.posterTransformationInit();
        return this.rangeBarAnimationInit();
      };

      View.prototype.destroy = function() {
        var handle, j, len, ref;
        clearInterval(this.data.bHandle);
        clearInterval(this.data.pHandle);
        ref = this.data.pHandles;
        for (j = 0, len = ref.length; j < len; j++) {
          handle = ref[j];
          clearTimeout(handle);
        }
        return CSH.$els.window.off('scroll', this.data.rbFn);
      };

      View.prototype.refreshUserInfo = function(data) {
        var el, i, j, len, percent, ref;
        ref = this.els.infoBox.find('p span');
        for (i = j = 0, len = ref.length; j < len; i = ++j) {
          el = ref[i];
          el = $(el);
          switch (i) {
            case 0:
              el.html(data.userType === 2 ? '代理' : '玩家');
              break;
            case 1:
              el.html(data.rebateRate);
              break;
            case 2:
              percent = data.dayPercent * 100;
              if (data.userType === 2 && percent !== 0) {
                el.html((percent.accurate(2)) + "%");
                el.parent().show();
              }
          }
        }
        return this.els.safetyBox.find('.lastLoginAddress').text(localStorage.getItem('lastLoginAddress'));
      };

      View.prototype.refreshBalance = function(balance) {
        var dEls, dQueue, decimal, el, els, i, invBool, j, k, l, len, len1, len2, n, num, o, rEls, rStack, ref, results, round, temp;
        if (balance == null) {
          balance = CSH.balance;
        }
        els = this.els.balanceBox.find('.box span');
        rEls = els.filter('.round');
        dEls = els.filter('.decimal');
        temp = ("" + balance).split('.');
        round = temp[0].split('');
        decimal = temp[1] ? temp[1].split('') : '';
        invBool = this.data.invisible;
        rStack = new Stack();
        for (j = 0, len = round.length; j < len; j++) {
          n = round[j];
          rStack.push(n);
        }
        for (i = k = ref = rEls.length - 1; ref <= 0 ? k <= 0 : k >= 0; i = ref <= 0 ? ++k : --k) {
          el = $(rEls[i]);
          num = rStack.pop();
          if (num == null) {
            num = '';
          }
          el.attr({
            'data-value': num
          });
          el.html(invBool ? '*' : num);
        }
        dQueue = new Queue();
        for (l = 0, len1 = decimal.length; l < len1; l++) {
          n = decimal[l];
          dQueue.enqueue(n);
        }
        results = [];
        for (o = 0, len2 = dEls.length; o < len2; o++) {
          el = dEls[o];
          el = $(el);
          num = dQueue.dequeue();
          if (num == null) {
            num = '0';
          }
          el.attr({
            'data-value': num
          });
          results.push(el.html(invBool ? '*' : num));
        }
        return results;
      };

      View.prototype.refreshSafety = function(score) {
        var covered, level, name, text;
        level = this.els.safetyBox.find('.safetyLevel');
        covered = this.els.safetyBox.find('.rangeBar .covered');
        if (score < 50) {
          text = '低';
          name = 'safety-low';
        } else if ((50 <= score && score <= 70)) {
          text = '中';
          name = 'safety-medium';
        } else if (score > 70) {
          text = '高';
          name = 'safety-high';
        }
        this.els.safetyBox.addClass(name);
        covered.css({
          width: score + "%"
        });
        return level.text(text + "（" + score + "%）");
      };

      View.prototype.fetchUserInfo = function() {
        return new ModelUserInfo().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON().data;
              localStorage.setItem('userType', data.userType);
              localStorage.setItem('isNormalUser', data.isNormalUser);
              if (+data.isNormalUser === 2 && +data.userType === 1) {
                $('.username').text(data.userName + " (试玩)");
                _this.els.demo.css('display', 'block');
              }
              return _this.refreshUserInfo(data);
            };
          })(this)
        });
      };

      View.prototype.fetchSafeLevel = function() {
        return new ModelSafeLevel().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              return _this.refreshSafety(+data.toJSON().data);
            };
          })(this)
        });
      };

      View.prototype.loadLotteryCountDown = function() {
        var aEl, aEls, el, id, j, len, map, results, temp;
        aEls = this.els.lotteryBox.children('a[data-value]');
        map = this.data.countDownMap = {};
        results = [];
        for (j = 0, len = aEls.length; j < len; j++) {
          el = aEls[j];
          aEl = $(el);
          id = aEl.attr('data-value');
          temp = $("<span class=\"info\">\n	<h4>" + CSH.gameMap[id].text + "</h4>\n	<p>\n		<i class=\"icon icon-count-down\"></i>\n		<label>距离开奖</label>\n	</p>\n	<ul class=\"box\">\n		<li data-type=\"hour\">00</li>\n		<li class=\"icon icon-time-delimiter\"></li>\n		<li data-type=\"minute\">00</li>\n		<li class=\"icon icon-time-delimiter\"></li>\n		<li data-type=\"second\">00</li>\n	</ul>\n</span>");
          temp.insertAfter(aEl.find('.cz'));
          results.push(map[id] = {
            hour: temp.find('li[data-type="hour"]'),
            minute: temp.find('li[data-type="minute"]'),
            second: temp.find('li[data-type="second"]')
          });
        }
        return results;
      };

      View.prototype.refreshLotteryCountDown = function(id, time) {
        var h, m, map, s;
        h = "" + (Math.floor(time / 60 / 60));
        m = "" + (Math.floor(time / 60 % 60));
        s = "" + (Math.floor(time % 60));
        map = this.data.countDownMap[id];
        map.hour.text("" + (h.length === 1 ? '0' + h : h));
        map.minute.text("" + (m.length === 1 ? '0' + m : m));
        return map.second.text("" + (s.length === 1 ? '0' + s : s));
      };

      View.prototype.fetchGamesRecentOpen = function() {
        var xhr;
        xhr = null;
        return new ModelCurrentPeriodAllInfo().setUrl().fetch({
          beforeSend: function(x) {
            return xhr = x;
          },
          dataFilter: (function(_this) {
            return function(data) {
              var czTime, id, info, j, k, len, len1, now, ref, time;
              data = data.toJSON().data;
              now = new Date(xhr.getResponseHeader('Date')).getTime();
              czTime = {};
              ref = [100, 306, 401, 200, 104, 105];
              for (j = 0, len = ref.length; j < len; j++) {
                id = ref[j];
                for (k = 0, len1 = data.length; k < len1; k++) {
                  info = data[k];
                  if (info.gameId === id) {
                    time = new Date(info.saleend).getTime() - now;
                    time = Math.round(time / 1000);
                    czTime[id] = time;
                    break;
                  }
                }
              }
              return _this.data.czHandle = setInterval(function() {
                var beginTime, endTime, results, s, temp;
                results = [];
                for (id in czTime) {
                  if (!hasProp.call(czTime, id)) continue;
                  time = czTime[id];
                  czTime[id] = --time;
                  if (!(time < 0)) {
                    _this.refreshLotteryCountDown(id, time);
                    continue;
                  }
                  if (!CSH.serverTime) {
                    continue;
                  }
                  now = CSH.serverTime.getTime();
                  switch (+id) {
                    case 100:
                      beginTime = new Date(new Date(now).setHours(9)).setMinutes(50);
                      endTime = new Date(new Date(now).setHours(22)).setMinutes(0);
                      s = 5 * 60;
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      }
                      break;
                    case 306:
                      beginTime = new Date(new Date(now).setHours(8)).setMinutes(55);
                      endTime = new Date(new Date(now).setHours(21)).setMinutes(55);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        temp = new Date(beginTime);
                        temp = temp.setDate(temp.getDate() + 1);
                        s = temp - now;
                      }
                      break;
                    case 401:
                      beginTime = new Date(new Date(now).setHours(9)).setMinutes(2);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(57);
                      if ((beginTime < now && now < endTime)) {
                        s = 5 * 60;
                      } else {
                        temp = new Date(beginTime);
                        temp = temp.setDate(temp.getDate() + 1);
                        s = temp - now;
                      }
                      break;
                    case 200:
                      temp = new Date(now);
                      temp = new Date(temp.setDate(temp.getDate + 1));
                      temp = new Date(temp.setHours(20));
                      temp = new Date(temp.setMinutes(0));
                      s = temp - now;
                      break;
                    case 104:
                      s = 60;
                      break;
                    case 105:
                      s = 60 * 3;
                  }
                  time = s + time;
                  czTime[id] = time;
                  results.push(_this.refreshLotteryCountDown(id, time));
                }
                return results;
              }, 1000);
            };
          })(this)
        });
      };

      View.prototype.eventToggleBalanceVisibility = function(event) {
        var el, els, isInvisible;
        if (this.time) {
          return;
        }
        this.time = true;
        setTimeout((function(_this) {
          return function() {
            return _this.time = false;
          };
        })(this), 500);
        el = $(event.currentTarget);
        els = this.els.balanceBox.find('.box span[data-value]');
        el.toggleClass('icon-visible icon-invisible');
        isInvisible = !JSON.parse(localStorage.getItem('visibility-capital'));
        localStorage.setItem('visibility-capital', isInvisible);
        CSH.views.body.indexRefreshBalance();
        return this.els.capitalVisibility.trigger('click');
      };

      View.prototype.eventRefreshBalance = function(event) {
        return CSH.views.body.refreshBalance(event);
      };

      View.prototype.eventLoadDataList = function(event) {
        var box, el, i, mor;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        i = el.index();
        box = el.parent().next();
        box.html(TplLoading);
        el.addClass('active').siblings('.active').removeClass('active');
        mor = el.siblings('.more');
        switch (i) {
          case 0:
            mor.attr('href', '/na.html#notice');
            return new CollectionAnnounceByPage().setUrl(1, 5).fetch({
              dataFilter: (function(_this) {
                return function(data) {
                  var info, j, len, list, temp;
                  list = data.toJSON().data;
                  temp = "<ul>";
                  for (i = j = 0, len = list.length; j < len; i = ++j) {
                    info = list[i];
                    if (!(i < 5)) {
                      break;
                    }
                    temp += "<li class=\"clear\">\n	<a href=\"/na.html#notice/" + info.id + "\"" + (info.announceType === 1 ? ' class="text-red"' : '') + ">" + info.announceName + "</a>\n	<span class=\"date\">" + (info.addTime.match(/^\d{4}\/(\d{2}\/\d{2})/)[1]) + "</span>\n</li>";
                  }
                  temp += "</ul>";
                  return box.html(temp);
                };
              })(this)
            });
          case 1:
            mor.attr('href', '/na.html#activity');
            return new ModelActivitys().setUrl().save({
              pageIndex: 1,
              pageSize: 5,
              type: 0
            }, {
              dataFilter: (function(_this) {
                return function(data) {
                  var info, j, len, list, temp;
                  list = data.toJSON().data;
                  temp = "<ul>";
                  for (i = j = 0, len = list.length; j < len; i = ++j) {
                    info = list[i];
                    if (!(i < 5)) {
                      break;
                    }
                    temp += "<li class=\"clear\">\n	" + (info.act_Url ? "<a href=\"" + info.act_Url + "\">" + info.act_Title + "</a>" : "<a href=\"/na.html#activity/" + info.id + "\">" + info.act_Title + "</a>") + "\n	<span class=\"date\">" + (info.addTime.match(/^\d{4}\/(\d{2}\/\d{2})/)[1]) + "</span>\n</li>";
                  }
                  temp += "</ul>";
                  return box.html(temp);
                };
              })(this)
            });
        }
      };

      View.prototype.eventShowCZCountDown = function(event) {
        var czEl, el, infoEl;
        el = $(event.currentTarget);
        czEl = el.children('.cz');
        infoEl = el.children('.info');
        el.animate({
          scrollTop: '158px'
        }, 200);
        czEl.animate({
          opacity: 0
        }, 100);
        return setTimeout((function() {
          return infoEl.animate({
            opacity: 1
          }, 200);
        }), 100);
      };

      View.prototype.eventHideCZCountDown = function(event) {
        var czEl, el, infoEl;
        el = $(event.currentTarget);
        czEl = el.children('.cz');
        infoEl = el.children('.info');
        el.animate({
          scrollTop: 0
        }, 200);
        setTimeout((function() {
          return czEl.animate({
            opacity: 1
          }, 200);
        }), 100);
        return infoEl.animate({
          opacity: 0
        }, 100);
      };

      View.prototype.bannerTransformationInit = function() {
        return new ModelAdList().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var api, fun, i, imgLis, index, item, j, k, len, liEls, liStr, ref, ref1, speed, target;
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              imgLis = '';
              ref = data.data;
              for (index = j = 0, len = ref.length; j < len; index = ++j) {
                item = ref[index];
                imgLis += '<li>';
                if (item.sourceUrl) {
                  imgLis += "<a href=\"" + item.sourceUrl + "\" target=\"_blank\">";
                }
                imgLis += "<img width=\"800\" height=\"400\" alt=\"" + (item.sourceText || '') + "\" src=\"" + item.source + "\" />";
                if (item.sourceUrl) {
                  imgLis += "</a>";
                }
                imgLis += "</li>";
              }
              _this.els.banner.find('ul.swipe-wrap').html(imgLis);
              speed = 3000;
              _this.data.bHandle = null;
              target = _this.els.banner.Swipe({
                callback: _this.refreshSwitchPositionBanner
              });
              api = target.data('Swipe');
              liStr = '';
              for (i = k = 1, ref1 = api.getNumSlides(); 1 <= ref1 ? k <= ref1 : k >= ref1; i = 1 <= ref1 ? ++k : --k) {
                liStr += "<li" + (i === 1 ? ' class="active"' : '') + "><i>&nbsp;</i></li>";
              }
              liEls = $(liStr).appendTo(target.find('> .position ul'));
              fun = function() {
                return _this.data.bHandle = setInterval(function() {
                  return api.next();
                }, speed);
              };
              target.on('mouseenter', function() {
                return clearInterval(_this.data.bHandle);
              }).on('mouseleave', function() {
                return fun();
              });
              fun();
              _this.data.banner = api;
              return _this.data.bannerLis = liEls;
            };
          })(this)
        });
      };

      View.prototype.posterTransformationInit = function() {
        var api, fun, i, j, liEls, liStr, ref, speed, target;
        speed = 3000;
        this.data.pHandle = null;
        this.data.pHandles = [];
        target = this.els.poster.Swipe({
          callback: this.refreshSwitchPositionPoster
        });
        api = target.data('Swipe');
        liStr = '';
        for (i = j = 1, ref = api.getNumSlides(); 1 <= ref ? j <= ref : j >= ref; i = 1 <= ref ? ++j : --j) {
          liStr += "<li" + (i === 1 ? ' class="active"' : '') + "><i>&nbsp;</i></li>";
        }
        liEls = $(liStr).appendTo(target.find('> .position ul'));
        fun = (function(_this) {
          return function() {
            return _this.data.pHandle = setInterval(function() {
              return api.next();
            }, speed);
          };
        })(this);
        this.els.poster.data('fun', (function(_this) {
          return function() {
            var ref1, ul, xC, xO;
            i = _this.els.poster.data('curIndex');
            ul = _this.els.poster.find('ul.swipe-wrap');
            xC = ul.find("li:eq(" + i + ") div");
            if (!_this.els.poster.data('isNotIn')) {
              _this.data.pHandles = [];
            }
            _this.data.pHandles.push(setTimeout((function() {
              return xC.css({
                left: 0,
                opacity: 1
              });
            }), 500));
            if ((ref1 = _this.els.poster.data('isNotIn')) === 1 || ref1 === (void 0)) {
              _this.data.pHandles.push(setTimeout((function() {
                return xC.css({
                  top: '320px',
                  opacity: 0
                });
              }), 2900));
              _this.data.pHandles.push(setTimeout((function() {
                return xC.css({
                  top: 0,
                  left: '180px'
                });
              }), 4000));
            }
            if (!_this.els.poster.data('isNotIn')) {
              xO = ul.find("li:not(:eq(" + i + ")) div");
              return setTimeout((function() {
                return xO.css({
                  top: 0,
                  left: '180px',
                  opacity: 1
                });
              }), 200);
            }
          };
        })(this));
        target.on('mouseenter', (function(_this) {
          return function() {
            var h, k, len, ref1, results;
            _this.els.poster.data('isNotIn', 0);
            clearInterval(_this.data.pHandle);
            ref1 = _this.data.pHandles;
            results = [];
            for (k = 0, len = ref1.length; k < len; k++) {
              h = ref1[k];
              results.push(clearTimeout(h));
            }
            return results;
          };
        })(this)).on('mouseleave', (function(_this) {
          return function() {
            _this.els.poster.data('isNotIn', 1);
            fun();
            return _this.els.poster.data('fun')();
          };
        })(this));
        fun();
        this.data.poster = api;
        this.data.posterLis = liEls;
        return this.refreshSwitchPositionPoster(0);
      };

      View.prototype.refreshSwitchPositionBanner = function(i) {
        this.data.bannerLis.filter(":eq(" + i + ")").addClass('active').siblings('.active').removeClass('active');
      };

      View.prototype.refreshSwitchPositionPoster = function(i) {
        this.els.poster.data('curIndex', i);
        this.els.poster.data('fun')();
        this.data.posterLis.filter(":eq(" + i + ")").addClass('active').siblings('.active').removeClass('active');
      };

      View.prototype.eventSwitchoverBanner = function(event) {
        var el, i;
        el = $(event.currentTarget);
        i = el.parent().index();
        return this.data.banner.slide(i);
      };

      View.prototype.eventSwitchoverPoster = function(event) {
        var el, i, oi;
        el = $(event.currentTarget);
        i = el.parent().index();
        oi = el.parent().siblings('.active').index();
        this.els.poster.find("ul.swipe-wrap li:eq(" + oi + ") div").css({
          opacity: 0
        });
        return this.data.poster.slide(i);
      };

      View.prototype.rangeBarAnimationInit = function() {
        var barTop, bars, rootEl, w;
        rootEl = document.documentElement;
        w = CSH.$els.window;
        bars = this.$el.find('.row4 .rangeBar');
        barTop = bars.offset().top;
        this.data.rbFn = (function(_this) {
          return function() {
            if (!(barTop - w.scrollTop() < rootEl.clientHeight - 20)) {
              return;
            }
            w.off('scroll', _this.data.rbFn);
            return bars.addClass('triggerAnimate');
          };
        })(this);
        return w.on('scroll', this.data.rbFn);
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
