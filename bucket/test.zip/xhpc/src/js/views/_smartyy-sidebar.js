(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT'], function($, _, Backbone, doT) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.initSidebar = bind(this.initSidebar, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.events = {
        'click .sidebarWrap[data-type="expand"] .menuWrap li > a': 'eventToggleExpandWrap',
        'click .sidebarWrap[data-type="expand"] .expandWrap a': 'eventChooseMenu',
        'mouseenter .sidebarWrap[data-type="expand"] .userContent': 'eventSlideUpUserBox',
        'mouseleave .sidebarWrap[data-type="expand"] .userContent': 'eventSlideDownUserBox',
        'click .sidebarWrap[data-type="expand"] .balanceBox': 'eventToggleMoneyBox',
        'click .arrowWrap .handle': 'eventToggleSidebarState',
        'click button.balanceVisibility': 'eventToggleCapitalVisibility',
        'click button.refreshBalance': 'refreshBalance'
      };

      View.prototype.initialize = function() {
        this.data = {};
        this.data.userMinHeight = 190;
        return this.render();
      };

      View.prototype.render = function() {
        this.data.isRendered = 1;
        this.els = {};
        this.els.sidebarWrap = this.$el.find('.sidebarWrap');
        this.els.userWrap = this.els.sidebarWrap.children('.userWrap');
        this.els.userContent = this.els.userWrap.children('.userContent');
        this.els.lotteryBox = this.$el.find('.lotteryBox');
        this.els.lotterys = this.els.lotteryBox.find('a');
        this.els.head = this.$el.find('img.userHead');
        this.els.balanceBox = this.$el.find('.balanceBox');
        this.els.moneyBox = this.$el.find('.moneyBox');
        this.els.anchorBox = this.$el.find('.anchorBox');
        this.els.values = this.$el.find('[data-type="value"]');
        this.els.menuWrap = this.els.sidebarWrap.children('.menuWrap');
        this.els.menuWrapLi = this.els.menuWrap.find('ul li');
        this.els.userCenter = this.els.menuWrapLi.filter('[data-name="userCenter"]');
        this.els.anchors = this.els.menuWrap.find('a[hrep!="javascript:;"]');
        this.initSidebar();
        return this.els.userContent.trigger('mouseleave');
      };

      View.prototype.initSidebar = function() {
        var isAgent, userType;
        userType = +localStorage.getItem('userType');
        isAgent = userType === 2;
        switch (CSH.fix) {
          case 'bj':
            this.els.head.attr({
              src: "/images/" + CSH.fix + "/" + (isAgent ? '04' : '02') + ".png"
            });
            break;
          default:
            this.els.head.attr({
              src: "/images/head/" + (isAgent ? '04' : '02') + ".jpg"
            });
        }
        this.els.values.filter('[data-name="userName"]').text(localStorage.getItem('username'));
        this.els.values.filter('[data-name="userType"]').text(isAgent ? '代理' : '玩家');
        this.els.values.filter('[data-name="rebate"]').text(localStorage.getItem('rebate'));
        CSH.views.body.initChangeBalanceDOM(this.els.values.filter('[data-name="balance"]'), this.els.userContent.find('.balanceVisibility'));
        this.els.values.filter('[data-name="lastLoginAddress"]').text(localStorage.getItem('lastLoginAddress'));
        this.els.anchorBox.children("[data-type=\"" + userType + "\"]").show().siblings(':hidden').remove();
        if (isAgent) {
          this.els.userCenter.find('.expandWrap [data-type="2"]').css('display', 'flex');
        }
        return this.welfare();
      };

      View.prototype.welfare = function() {
        CSH.menu.welfare.sidebar = {};
        return CSH.menu.welfare.sidebar = {
          salary: this.els.userCenter.find('[data-type="salary"]'),
          contract: this.els.userCenter.find('[data-type="contract"]'),
          welfareStep: this.els.userCenter.find('[data-type="welfare"]')
        };
      };

      View.prototype.refreshStatus = function() {
        var aEl, anchors, liEl, selector, target;
        selector = CSH.pageName + ".html";
        if (CSH.pageName === 'help') {
          selector = '';
        }
        if (CSH.routePath.length) {
          selector += "#" + (CSH.routePath.join('/'));
        }
        if (CSH.pageName === 'help' && !CSH.routePath.length) {
          selector += "#11";
        }
        anchors = this.els.anchors;
        anchors.removeClass('active');
        target = anchors.filter("[href=\"" + selector + "\"]");
        liEl = target.closest('li');
        aEl = liEl.children('a');
        target.addClass('active');
        if (!liEl.hasClass('expand')) {
          return aEl.trigger('click');
        }
      };

      View.prototype.eventToggleExpandWrap = function(event) {
        var aEl, liEl, old, target, ulEl;
        aEl = $(event.currentTarget);
        liEl = aEl.parent();
        target = aEl.siblings('.expandWrap');
        if (!target[0]) {
          return;
        }
        old = liEl.siblings('.expand');
        ulEl = liEl.parent();
        if (old[0]) {
          old.children('a').trigger('click');
        }
        return setTimeout(function() {
          liEl.toggleClass('expand');
          return target.slideToggle(200, function() {
            var sTop;
            sTop = aEl.offset().top - CSH.$els.header.outerHeight(true);
            return ulEl.stop(true).animate({
              scrollTop: sTop
            }, 200);
          });
        }, old[0] ? 200 : 0);
      };

      View.prototype.eventChooseMenu = function(event) {
        var base, el, hash;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return false;
        }
        if (el.hasClass('externalLottery')) {
          return;
        }
        hash = el.attr('href').split('#');
        el.closest('.expandWrap').find('.active').removeClass('active');
        el.addClass('active');
        if (CSH.pageName === 'help') {
          if (typeof (base = CSH.router.ctrl).chooseMenu === "function") {
            base.chooseMenu(el.attr('href'));
          }
          return false;
        } else if (hash[0] === 'userCenter.html' && CSH.views.userCenter) {
          CSH.views.userCenter.eventLoadView(event);
          return false;
        }
      };

      View.prototype.eventSlideUpUserBox = function(event) {
        if (!this.data.isRendered) {
          return;
        }
        return this.els.userWrap.addClass('expand').css({
          bottom: 0
        });
      };

      View.prototype.eventSlideDownUserBox = function(event) {
        var box, fun;
        if (!this.data.isRendered) {
          return;
        }
        box = this.els.userWrap;
        fun = (function(_this) {
          return function() {
            return box.removeClass('expand').css({
              bottom: _this.data.userMinHeight - box.height()
            });
          };
        })(this);
        if (this.els.moneyBox.is(':hidden')) {
          return fun();
        } else {
          this.els.balanceBox.trigger('click');
          return setTimeout(fun, 250);
        }
      };

      View.prototype.eventToggleMoneyBox = function(event) {
        var el;
        el = $(event.currentTarget);
        el.toggleClass('expand');
        return this.els.moneyBox.slideToggle(200);
      };

      View.prototype.eventToggleSidebarState = function(event) {
        var deg, el, icon, ref, type;
        el = $(event.currentTarget);
        icon = el.find('.icon');
        deg = icon.attr('data-deg') || 180;
        deg = +deg;
        deg += 180;
        type = deg % 360 ? 'expand' : 'collapse';
        this.els.sidebarWrap.filter("[data-type=\"" + type + "\"]").siblings('.sidebarWrap').hide().end().show();
        icon.attr('data-deg', deg).css({
          transform: "rotate(" + deg + "deg)"
        });
        return (ref = CSH.views.rSidebar) != null ? ref.resetState() : void 0;
      };

      View.prototype.refreshBalance = function(event) {
        var el;
        el = $(event.currentTarget);
        el.addClass('icon-spin');
        return CSH.refreshBalance(null, el);
      };

      View.prototype.eventToggleCapitalVisibility = function() {
        return CSH.toggleCapitalVisibility();
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
