(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/balance', 'models/safesetschecks', 'models/safelevel', 'models/getMyDaySalaryAttribute', 'models/getuserfreeze', 'models/info_contract', 'text!../../templates/userCenter.tpl', 'text!../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelsBalance, ModelSafesetschecks, Modelsafelevel, ModelGetMyDaySalaryAttribute, ModelGetuserfreeze, ModelInfo_contract, TplContent, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .reportEntry a': 'eventLoadView',
        'click .status.weak a': 'eventLoadView',
        'click .rightBox .widget .tabTitle .record': 'eventTriggerLoadSubView',
        'click .rightBox .refresh': 'eventRefresh',
        'click #userHead': 'eventToUserSecu'
      };

      View.prototype.initialize = function(data) {
        if (CSH.pageName !== 'userCenter') {
          return;
        }
        this.data = {};
        return this.render();
      };

      View.prototype.render = function() {
        var it;
        it = {};
        it.username = localStorage.getItem('username');
        it.time = this.time();
        it.rebate = localStorage.getItem('rebate');
        return new ModelInfo_contract().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var isContract;
              data = data.toJSON();
              it.contract = data;
              isContract = +data.code === 1 ? 0 : data.data.state;
              localStorage.setItem('contractState', isContract);
              new ModelGetuserfreeze().setUrl().fetch({
                dataFilter: function(data) {
                  var allText, name, ref, text;
                  data = data.toJSON();
                  _this.freezeNum = data.data.freeze;
                  allText = "";
                  _this.freeze = {};

                  /*
                  								@freezeNum
                  								1: 账号冻结
                  								2： 资金冻结
                  								4： 登录冻结
                  								8： 取款冻结
                  								16：转账冻结
                  								32：购彩冻结
                  								64：分红冻结
                  								128：日工资冻结
                  								256： 虚拟冻结
                  
                  								0 || 256 锁不显示
                   */
                  if ((_this.freezeNum & 8) === 8) {
                    _this.freeze.extractMoney = '取款';
                  }
                  if ((_this.freezeNum & 16) === 16) {
                    _this.freeze.transferAccounts = '转账';
                  }
                  if ((_this.freezeNum & 128) === 128) {
                    _this.freeze.dayMoney = '日工资';
                  }
                  for (text in _this.freeze) {
                    allText += _this.freeze[text] + "、";
                  }
                  allText = allText.substring(0, allText.length - 1);
                  if ((_this.freezeNum & 2) === 2) {
                    _this.freeze.transferAccounts = _this.freeze.extractMoney = '资金';
                    allText = _this.freeze.transferAccounts;
                  }
                  if ((_this.freezeNum & 64) === 64) {
                    _this.freeze.contract = '分红';
                    it.freezeText = "您的分红发放未完成，请完成分红";
                  } else if ((ref = _this.freezeNum) !== 0 && ref !== 256) {
                    it.freezeText = "您的" + allText + "已经冻结, 请联系客服解决";
                  }
                  _this.$el.html(_this.tpls.content(it));
                  _this.els = {};
                  _this.els.content = _this.$el.find('.content');
                  _this.els.property = _this.$el.find('.leftBox .reportForm a[data-href="property"]');
                  _this.els.userSecu = _this.$el.find('.leftBox .account a[href="/userCenter.html#security"]');
                  _this.els.freezeText = _this.$el.find('.rightBox .freezeText');
                  _this.els.defaultUserCenter = _this.$el.find('.reportEntry .defaultUserCenter');
                  _this.btn = false;
                  _this.getInfo();
                  CSH.$els.balance.userCenter = _this.$el.find('.moneyList .realTimeBalance');
                  _this.eventRefresh();
                  name = CSH.routePath[0];
                  if (name) {
                    return _this.loadView(name);
                  } else {
                    name = 'security';
                    return _this.loadView(name, true);
                  }
                }
              });
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventToUserSecu = function(event) {
        event.preventDefault();
        this.els.userSecu.click();
      };

      View.prototype.eventTriggerLoadSubView = function(event) {
        var el;
        event.preventDefault();
        el = $(event.currentTarget);
        CSH.data.targetTab = el.attr('data-targettab');
        this.els.property.click();
      };

      View.prototype.loadView = function(name, isInit) {
        var order, ref;
        if (+localStorage.getItem('isNormalUser') === 2) {
          if (name === 'recharge' || name === 'extractMoney') {
            CSH.hint('亲，试玩账户不享有该权限哦！');
            this.els.defaultUserCenter.trigger('click');
            return;
          }
          if (name === 'transferAccounts' && +localStorage.getItem('userType') === 1) {
            CSH.hint('亲，试玩账户不享有该权限哦！');
            this.els.defaultUserCenter.trigger('click');
            return;
          }
        }
        if (name === 'extractMoney' || name === 'transferAccounts') {
          if ((this.freezeNum & 2) === 2) {
            return CSH.hint("您的" + this.freeze.transferAccounts + "已冻结");
          }
        }
        if ((name === 'extractMoney') && (this.freezeNum & 8) === 8) {
          return CSH.hint("您的" + this.freeze.extractMoney + "已冻结");
        }
        if ((name === 'transferAccounts') && (this.freezeNum & 16) === 16) {
          return CSH.hint("您的" + this.freeze.transferAccounts + "已冻结");
        }
        if ((name === 'transferAccounts' || name === 'extractMoney') && (this.freezeNum & 64) === 64) {
          return CSH.hint("您有下级分红未发放,不能提现／转账");
        }
        if ((name === 'transferAccounts' || name === 'extractMoney') && (this.freezeNum & 128) === 128) {
          return CSH.hint("您的" + this.freeze.dayMoney + "已冻结,不能提现／转账／购彩");
        }
        if (+localStorage.getItem('contractState') === 5 && name === 'contract') {
          return CSH.hint('您的契约已关闭');
        }
        if ((ref = this.oldView) != null) {
          if (typeof ref.destroy === "function") {
            ref.destroy();
          }
        }
        this.showLoading();
        if (isInit) {
          order = 'replaceState';
        } else {
          order = 'pushState';
        }
        history[order](null, null, "#" + name);
        return require(["views/subsets/" + CSH.pageName + "_" + name], (function(_this) {
          return function(View) {
            _this.oldView = new View({
              el: _this.els.content,
              pView: _this
            });
            _this.els.content.addClass(name);
            return _this.oldName = name;
          };
        })(this));
      };

      View.prototype.showLoading = function() {
        return this.els.content.off().empty().removeClass(this.oldName).html(TplLoading);
      };

      View.prototype.eventLoadView = function(event) {
        var el, href, name, ref;
        event.preventDefault();
        if (this.btn) {
          return;
        }
        this.btn = true;
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 500);
        el = $(event.currentTarget);
        href = el.attr('href');
        if (href === 'javascript:;') {
          return;
        }
        name = href.replace(/^.*#/, '');
        if (name === 'recharge' && CSH.data.recharge_isPaying) {
          if ((ref = this.oldView) != null) {
            if (typeof ref.showAdvice === "function") {
              ref.showAdvice(0);
            }
          }
          return;
        }
        CSH.data.recharge_isPaying = false;
        return this.loadView(name);
      };

      View.prototype.getInfo = function() {
        new ModelSafesetschecks().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var $QA, $card, $realname, $safeState, $safety, $weixin, className, complete, safesetschecks;
              data = data.toJSON();
              complete = data.data[0];
              className = "complete";
              $safeState = _this.$el.find('.safeState');
              $realname = $safeState.find('.icon-realname');
              $safety = $safeState.find('.icon-safety');
              $card = $safeState.find('.icon-card');
              $QA = $safeState.find('.icon-QA2');
              $weixin = $safeState.find('.icon-wechat2');
              if (!complete.isWithPwd) {
                $safety.addClass(className).attr('title', '资金密码已设置');
              }
              if (!complete.isBankAccount) {
                $card.addClass(className).attr('title', '银行卡已绑定');
              }
              if (!complete.isCredentials) {
                $realname.addClass(className).attr('title', '实名已认证');
              }
              if (!complete.isSafeQuestions) {
                $QA.addClass(className).attr('title', '安全问题已设置');
              }
              if (!complete.isBindWeiXin) {
                $weixin.addClass(className).attr('title', '微信已绑定');
              }
              safesetschecks = JSON.stringify(complete);
              return localStorage.setItem('safesetschecks', safesetschecks);
            };
          })(this)
        });
        return new Modelsafelevel().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var $aBtn, $hade, $prompt, $status, color, number, prompt;
              data = data.toJSON();
              number = data.data;
              color = '#f15a59';
              prompt = '% 低';
              $hade = _this.$el.find('.leftBox .hade .status');
              $status = $hade.find('.safeLine');
              $prompt = $hade.find('.prompt span');
              $aBtn = $hade.find('a');
              localStorage.setItem('safetyValue', number);
              if (number >= 50 && number <= 70) {
                prompt = '% 中';
                color = '#FDA027';
              } else if (number > 70) {
                prompt = '% 高';
                color = '#57ba60';
              }
              if (number === 100) {
                $aBtn.remove();
              }
              $prompt.text(number + prompt).css('color', color);
              return $status.width(number + '%').css('backgroundColor', color);
            };
          })(this)
        });
      };

      View.prototype.eventRefresh = function(event) {
        return CSH.views.body.refreshBalance(event);
      };

      View.prototype.time = function() {
        var holle, iHours, iMin, myTime, now;
        myTime = new Date();
        iHours = myTime.getHours();
        iMin = myTime.getMinutes();
        now = this.toTow(iHours) + this.toTow(iMin);
        holle = null;
        if (now < 600) {
          holle = '晚上好';
        } else if (now < 1130) {
          holle = '上午好';
        } else if (now < 1400) {
          holle = '中午好';
        } else if (now < 1700) {
          holle = '下午好';
        } else {
          holle = '晚上好';
        }
        return holle;
      };

      View.prototype.toTow = function(n) {
        if (n < 10) {
          return '0' + n;
        } else {
          return '' + n;
        }
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
