(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT'], function($, _, Backbone, doT) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.refreshStatus = bind(this.refreshStatus, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.events = {
        'click .mute': 'eventSwitchMuteState',
        'click .menu .more a': 'eventUserCenterViewsJump'
      };

      View.prototype.initialize = function() {
        this.data = {};
        return this.render();
      };

      View.prototype.render = function() {
        this.els = {};
        this.els.btnMute = this.$el.find('.mute');
        this.els.lotteryBox = this.$el.find('.lotteryBox');
        this.els.menu = this.$el.find('ul.menu');
        this.els.anchors = this.els.menu.find('a[data-route]');
        this.els.agent = this.els.anchors.filter('.agent');
        this.els.salary = this.els.anchors.filter('.salary');
        this.els.contract = this.els.anchors.filter('.contract');
        this.$el.find('a[target="service"]').attr({
          href: _serviceUrl || ''
        });
        this.initAuthorty();
        return this.initSwitchMuteState();
      };

      View.prototype.refreshStatus = function() {
        var anchors, arr, pName;
        pName = CSH.pageName;
        arr = [pName];
        if (CSH.routePath.length) {
          arr.push(CSH.routePath[0]);
        }
        if (pName === 'help' || pName === 'trends') {
          arr.length = 1;
        }
        anchors = this.els.anchors;
        anchors.filter('.active').removeClass('active');
        return anchors.filter("[data-route=\"" + (arr.join('-')) + "\"]").addClass('active');
      };

      View.prototype.initSwitchMuteState = function() {
        if (CSH.isMute) {
          return this.els.btnMute.click();
        }
      };

      View.prototype.initAuthorty = function() {
        var isAgent, userType;
        userType = +localStorage.getItem('userType');
        isAgent = userType === 2;
        if (isAgent) {
          this.els.agent.css({
            display: 'block'
          });
        } else {
          this.els.agent.remove();
        }
        CSH.menu.welfare.header = {};
        return CSH.menu.welfare.header = {
          salary: this.els.salary,
          contract: this.els.contract
        };
      };

      View.prototype.eventSwitchMuteState = function(event) {
        var el, isMute;
        el = $(event.currentTarget);
        el.toggleClass('icon-ring icon-mute');
        isMute = +el.hasClass('icon-mute');
        CSH.isMute = isMute;
        localStorage.setItem('isMute', isMute);
        return el.find('span').text("声音已" + (isMute ? '关闭' : '开启'));
      };

      View.prototype.eventUserCenterViewsJump = function(event) {
        var el, hash;
        el = $(event.currentTarget);
        hash = el.attr('href').split('#');
        if (hash[0] === 'userCenter.html' && CSH.views.userCenter) {
          CSH.views.userCenter.eventLoadView(event);
          return event.preventDefault();
        }
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
