(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'text!../../templates/_default-menu.tpl'], function($, _, Backbone, doT, TplContent) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.refreshMenuStyle = bind(this.refreshMenuStyle, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .lotteryBox a': 'eventSwitchLottery'
      };

      View.prototype.initialize = function() {
        this.data = {};
        this.data.gID = CSH.utils.getRoutePath().split('/').last();
        return this.render();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content({
          list: window._lotteryList
        }));
        this.els = {};
        return this.els.lotteryBox = this.$el.find('.lotteryBox');
      };

      View.prototype.refreshMenuStyle = function() {
        $('li', this.$el).removeClass('active').find("[href*=\"" + CSH.pageName + ".html\"]").parent().addClass('active');
      };

      View.prototype.eventSwitchLottery = function(event) {
        var el, gID, href;
        el = $(event.currentTarget);
        href = el.attr('href');
        gID = href.split('/').last();
        if (gID === this.data.gID && !/javascript:;/.test(href)) {
          CSH.router.refresh();
        }
        this.data.gID = gID;
        this.els.lotteryBox.addClass('hidding');
        setTimeout((function(_this) {
          return function() {
            return _this.els.lotteryBox.removeClass('hidding').css({
              'transition': 'initial'
            }).hide();
          };
        })(this), 200);
        return setTimeout(((function(_this) {
          return function() {
            return _this.els.lotteryBox.removeAttr('style');
          };
        })(this)), 1000);
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
