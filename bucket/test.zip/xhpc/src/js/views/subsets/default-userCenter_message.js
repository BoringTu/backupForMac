(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/membertalkList', 'text!../../../templates/subsets/default-userCenter_message.tpl', 'text!../../../templates/subsets/default-userCenter_message_list.tpl', 'text!../../../templates/subsets/default-userCenter_message_groupMsgBox.tpl', 'text!../../../templates/_default-modal.tpl', 'text!../../../templates/_default-contentLoading.tpl', 'text!../../../templates/_default-paginate.tpl'], function($, _, Backbone, doT, ModelMembertalkList, TplContent, TplList, TplGroupMsgBox, TplModal, TplLoading, TplPaginate) {
    "use struct";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        modal: doT.template(TplModal),
        list: doT.template(TplList),
        groupMsgBox: doT.template(TplGroupMsgBox),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'keyup .paginate input': 'eventKeyupPaginate',
        'click .tabTitle li': 'eventSwithTab',
        'click .tabTitle .sendMsg': 'eventShowSendMsg',
        'click .tabContent tbody tr': 'eventShowConversation',
        'click .tabContent .markRead button.all': 'eventMarkReaded'
      };

      View.prototype.initialize = function() {
        this.data = {};
        return this.render();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.tabContent = this.$el.find('.tabContent');
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventSwithTab = function(event) {
        var el, type;
        el = $(event.currentTarget);
        type = el.attr('data-type');
        this.els.tabContent.attr({
          'data-type': type
        });
        el.addClass('active').siblings('.active').removeClass('active');
        if (type === 'normal') {
          return this.fetchMembertalkList();
        } else if (type === 'advice') {
          return this.fetchSuggest();
        }
      };

      View.prototype.eventShowSendMsg = function(event) {
        CSH.views.body.showSendMsgPanel();
      };

      View.prototype.fetchMembertalkList = function(p) {
        var param;
        if (p == null) {
          p = 1;
        }
        this.els.tabContent.html(TplLoading);
        param = {
          pageIndex: p,
          pageSize: 12
        };
        return new ModelMembertalkList().setUrl().save(param, {
          dataFilter: (function(_this) {
            return function(data) {
              var pInfo, temp;
              console.log('消息列表', data.toJSON());
              temp = data.toJSON();
              data = temp.data;
              pInfo = temp.pageInfo;
              return _this.els.tabContent.html(_this.tpls.list({
                data: data,
                paginate: _this.tpls.paginate({
                  info: pInfo,
                  notice: '* 将为您保留近 1 个月消息'
                })
              }));
            };
          })(this)
        });
      };

      View.prototype.eventShowConversation = function(event) {
        var el, gMsg, id, modalBox, type;
        el = $(event.currentTarget);
        id = +el.attr('data-id');
        type = +el.attr('data-type');
        switch (type) {
          case 0:
          case -1:
            return CSH.views.body.showConversation(id, type);
          case 1:
            gMsg = {};
            gMsg.toName = el.find('.name').html();
            gMsg.tim = el.find('.tim').html();
            gMsg.msg = el.find('.msgBtn').html();
            modalBox = $(this.tpls.groupMsgBox(gMsg));
            modalBox.on('hidden', function() {
              return modalBox.off().remove();
            }).appendTo(CSH.$els.body);
            return modalBox.modal('show');
        }
      };

      View.prototype.eventMarkReaded = function(event) {
        return CSH.views.body.reportReaded(-1, CSH.views.body.freshPageMsg);
      };

      View.prototype.fetchSuggest = function(p) {
        if (p == null) {
          p = 1;
        }
        return this.els.tabContent.html(TplLoading);
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchMembertalkList(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchMembertalkList(p);
        }
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
