(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/history', 'models/announceByPage', 'models/lotteryperiod', 'text!../../../templates/subsets/default-lottery_headbar.tpl', 'text!../../../templates/subsets/default-lottery_lotteryNumbers.tpl', 'text!../../../templates/_default-contentLoading.tpl'], function($, _, Backbone, doT, ModelHistory, ModelAnnounceByPage, ModelLotteryperiod, TplContent, TplLotteryNumbers, TplLoading) {
    "use strict";
    var TransitionBall, TransitionCar, TransitionDice, View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.showLotteryNumbers = bind(this.showLotteryNumbers, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        lotteryNumbers: doT.template(TplLotteryNumbers)
      };

      View.prototype.initialize = function(data) {
        var map;
        window.vh = this;
        this.parent = data.parent;
        this.data = {};
        this.data.oldTime = {};
        this.data.issues = {
          before: '',
          current: ''
        };
        map = {
          1: 5,
          2: 3,
          3: 5,
          4: 10,
          5: 3
        };
        this.data.placeCount = map[+CSH.gType];
        map = {
          1: {
            min: 0,
            max: 9
          },
          2: {
            min: 0,
            max: 9
          },
          3: {
            min: 1,
            max: 11
          },
          4: {
            min: 1,
            max: 10
          }
        };
        this.data.numRange = map[+CSH.gType];
        switch (+CSH.gType) {
          case 4:
            this.data.numType = 'car';
            break;
          case 5:
            this.data.numType = 'dice';
            break;
          default:
            this.data.numType = 'ball';
        }
        CSH.audios.issueOver = new CSH.utils.Audio('/audios/issueOver.mp3');
        CSH.audios.ticktack = new CSH.utils.Audio('/audios/ticktack.mp3');
        this.xhr = {};
        return this.render();
      };

      View.prototype.render = function() {
        var issues;
        this.$el.html(this.tpls.content({
          gID: +CSH.gID,
          numType: this.data.numType,
          list: window._lotteryList
        }));
        this.els = {};
        this.els.sbBox = this.$el.find('.scoreboardBox');
        this.els.sbs = {};
        this.els.sbs.h = this.els.sbBox.find('.scoreboard[data-type="h"]');
        this.els.sbs.m = this.els.sbBox.find('.scoreboard[data-type="m"]');
        this.els.sbs.s = this.els.sbBox.find('.scoreboard[data-type="s"]');
        issues = this.$el.find('.issueNumber');
        this.els.issues = {
          before: issues.eq(1),
          current: issues.eq(0)
        };
        this.els.numBox = this.$el.find('.numBox');
        this.sbs = {};
        return this.fetchGameInfo(true);
      };

      View.prototype.destroy = function() {
        var j, k, l, len, len1, len2, o, p, ref, ref1, ref2, ref3;
        ref = this.sbs;
        for (k in ref) {
          if (!hasProp.call(ref, k)) continue;
          o = ref[k];
          if (typeof o.destroy === "function") {
            o.destroy();
          }
        }
        ref1 = this.tbs || [];
        for (j = 0, len = ref1.length; j < len; j++) {
          o = ref1[j];
          o.destroy();
        }
        ref2 = this.tcs || [];
        for (l = 0, len1 = ref2.length; l < len1; l++) {
          o = ref2[l];
          o.destroy();
        }
        ref3 = this.tds || [];
        for (p = 0, len2 = ref3.length; p < len2; p++) {
          o = ref3[p];
          o.destroy();
        }
        clearInterval(this.data.czHandle);
        CSH.audios.issueOver.remove();
        CSH.audios.ticktack.remove();
        clearInterval(this.handleGI);
        return this;
      };

      View.prototype.fetchGameInfo = function(isInit) {
        var ref;
        if ((ref = this.xhr.gi) != null) {
          ref.abort();
        }
        return new ModelLotteryperiod().setUrl(CSH.gID).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              if (!isInit) {
                return _this.xhr.gi = xhr;
              }
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var code;
              data = data.toJSON().data;
              if (!isInit) {
                if (_this.data.issues.current !== data[0].issue) {
                  _this.data.issues.current = data[0].issue;
                  _this.refreshIssues('cur');
                }
                _this.resetCountDownTime(new Date(data[0].saleend.replace(/-/g, '/')).getTime());
                return;
              }
              _this.initScoreboard(data[0]);
              code = data[1].code;
              _this.data.lotteryNumbers = code ? code.split(',') : [];
              if (!(_this.data.issues.before === data[1].issue && _this.data.issues.current === data[0].issue)) {
                _this.data.issues.before = data[1].issue;
                _this.data.issues.current = data[0].issue;
                _this.refreshIssues('init');
              }
              _this.els.numBox.html(_this.tpls.lotteryNumbers({
                type: _this.data.numType,
                count: _this.data.placeCount
              }));
              switch (_this.data.numType) {
                case 'ball':
                  _this.els.places = _this.els.numBox.find('.nums');
                  break;
                case 'car':
                  _this.els.places = _this.els.numBox.find('.car');
                  break;
                case 'dice':
                  _this.els.places = _this.els.numBox.find('.dice');
              }
              if (!_this.data.isStarting) {
                _this.startRandom();
              }
              if (_this.data.lotteryNumbers.length) {
                _this.showLotteryNumbers(_this.data.issues.before);
              }
              return _this.handleGI = setInterval((function() {
                return _this.fetchGameInfo();
              }), 10000);
            };
          })(this)
        });
      };

      View.prototype.refreshIssues = function(data) {
        var format, issues;
        format = function(issue) {
          return issue.replace(/^\d{8}/, '$&-');
        };
        issues = this.data.issues;
        if (data === 'init' || data === 'cur') {
          this.els.issues.current.html(format(issues.current));
          this.parent.views.betting.refreshCurrentIssue();
        }
        if (data === 'init' || data === 'bef') {
          return this.els.issues.before.html(format(issues.before));
        }
      };

      View.prototype.startRandom = function() {
        var car, delay, dice, i, j, l, len, len1, len2, len3, len4, len5, nums, p, q, r, range, ref, ref1, ref2, results, results1, results2, t, tb, tbs, tc, tcs, td, tds;
        this.data.isStarting = 1;
        range = this.data.numRange;
        switch (this.data.numType) {
          case 'ball':
            this.tbs = tbs = [];
            window.tbs = tbs;
            ref = this.els.places;
            for (j = 0, len = ref.length; j < len; j++) {
              nums = ref[j];
              tbs.push(new TransitionBall({
                el: $(nums),
                range: range
              }));
            }
            results = [];
            for (l = 0, len1 = tbs.length; l < len1; l++) {
              tb = tbs[l];
              results.push(tb.shake({
                delay: Math.intRange(0, 400)
              }));
            }
            return results;
            break;
          case 'car':
            this.tcs = tcs = [];
            window.tcs = tcs;
            ref1 = this.els.places;
            for (i = p = 0, len2 = ref1.length; p < len2; i = ++p) {
              car = ref1[i];
              tcs.push(new TransitionCar({
                el: $(car),
                range: range,
                index: i
              }));
            }
            results1 = [];
            for (q = 0, len3 = tcs.length; q < len3; q++) {
              tc = tcs[q];
              results1.push(tc.shake());
            }
            return results1;
            break;
          case 'dice':
            this.tds = tds = [];
            window.tds = tds;
            delay = -200;
            ref2 = this.els.places;
            for (i = r = 0, len4 = ref2.length; r < len4; i = ++r) {
              dice = ref2[i];
              tds.push(new TransitionDice({
                el: $(dice),
                index: i
              }));
            }
            results2 = [];
            for (t = 0, len5 = tds.length; t < len5; t++) {
              td = tds[t];
              results2.push(td.shake(delay += 200));
            }
            return results2;
        }
      };

      View.prototype.showLotteryNumbers = function(issue, codes) {
        this.data.issues.before = issue;
        this.refreshIssues('bef');
        if (!this.data.isStarting) {
          this.startRandom();
        }
        this.data.isStarting = 0;
        delete this.showLotteryNumbersDelay;
        if (codes) {
          this.data.lotteryNumbers = codes;
        }
        codes = this.data.lotteryNumbers;
        return setTimeout((function(_this) {
          return function() {
            var delay, i, j, l, len, len1, len2, p, ref, ref1, ref2, results, results1, results2, tb, tc, td;
            switch (_this.data.numType) {
              case 'ball':
                ref = _this.tbs;
                results = [];
                for (i = j = 0, len = ref.length; j < len; i = ++j) {
                  tb = ref[i];
                  results.push(tb.result(+codes[i]));
                }
                return results;
                break;
              case 'car':
                delay = -400;
                ref1 = _this.tcs;
                results1 = [];
                for (i = l = 0, len1 = ref1.length; l < len1; i = ++l) {
                  tc = ref1[i];
                  results1.push(tc.result(+codes[i], delay += 400));
                }
                return results1;
                break;
              case 'dice':
                delay = -400;
                ref2 = _this.tds;
                results2 = [];
                for (i = p = 0, len2 = ref2.length; p < len2; i = ++p) {
                  td = ref2[i];
                  results2.push(td.result(+codes[i], delay += 400));
                }
                return results2;
            }
          };
        })(this), 1000);
      };

      View.prototype.resetCountDownTime = function(data) {
        var time;
        time = data - CSH.serverTime.getTime();
        time = Math.round(time / 1000);
        return this.data.time = time;
      };

      View.prototype.initScoreboard = function(data) {
        var modalBox;
        this.sbs.h = new Scoreboard(this.els.sbs.h);
        this.sbs.m = new Scoreboard(this.els.sbs.m);
        this.sbs.s = new Scoreboard(this.els.sbs.s);
        this.resetCountDownTime(new Date(data.saleend.replace(/-/g, '/')).getTime());
        modalBox = null;
        return this.data.czHandle = setInterval((function(_this) {
          return function() {
            var beginTime, endTime, gID, i, isNextDay, iss, issues, max, now, nowDate, s, temp, time;
            time = --_this.data.time;
            if (time < 0) {
              nowDate = CSH.serverTime;
              now = nowDate.getTime();
              isNextDay = false;
              switch (+CSH.gID) {
                case 100:
                  beginTime = new Date(new Date(now).setHours(9)).setMinutes(50);
                  endTime = new Date(new Date(now).setHours(22)).setMinutes(0);
                  s = 5 * 60;
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  }
                  break;
                case 101:
                case 300:
                case 303:
                  beginTime = new Date(new Date(now).setHours(9)).setMinutes(0);
                  endTime = new Date(new Date(now).setHours(23)).setMinutes(0);
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 103:
                  beginTime = new Date(new Date(now).setHours(0)).setMinutes(0);
                  endTime = new Date(new Date(now).setHours(2)).setMinutes(0);
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  } else {
                    beginTime = new Date(new Date(now).setHours(10)).setMinutes(0);
                    endTime = new Date(new Date(now).setHours(24)).setMinutes(0);
                    if ((beginTime < now && now < endTime)) {
                      s = 10 * 60;
                    } else {
                      temp = new Date(beginTime);
                      s = temp - now;
                    }
                  }
                  break;
                case 109:
                case 119:
                  s = 45;
                  break;
                case 104:
                case 107:
                case 108:
                case 203:
                case 304:
                case 502:
                  s = 60;
                  break;
                case 106:
                case 110:
                case 111:
                case 112:
                case 113:
                case 114:
                case 120:
                case 402:
                  s = 60 * 1.5;
                  break;
                case 115:
                  s = 60 * 2;
                  break;
                case 105:
                case 116:
                  s = 60 * 3;
                  break;
                case 117:
                  beginTime = new Date(new Date(now).setHours(9)).setMinutes(5);
                  endTime = new Date(new Date(now).setHours(23)).setMinutes(55);
                  if ((beginTime < now && now < endTime)) {
                    s = 60 * 5;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 118:
                  beginTime = new Date(new Date(now).setHours(7)).setMinutes(5);
                  endTime = new Date(new Date(now).setHours(23)).setMinutes(55);
                  if ((beginTime < now && now < endTime)) {
                    s = 60 * 5;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 200:
                case 202:
                  temp = new Date(now);
                  temp = new Date(temp.setDate(temp.getDate + 1));
                  temp = new Date(temp.setHours(20));
                  temp = new Date(temp.setMinutes(0));
                  s = temp - now;
                  break;
                case 201:
                  beginTime = new Date(new Date(now).setHours(10)).setMinutes(0);
                  endTime = new Date(new Date(now).setHours(21)).setMinutes(30);
                  if ((beginTime < now && now < endTime)) {
                    s = 30 * 60;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 301:
                  beginTime = new Date(new Date(now).setHours(8)).setMinutes(50);
                  endTime = new Date(new Date(now).setHours(23)).setMinutes(50);
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 302:
                  beginTime = new Date(new Date(now).setHours(8)).setMinutes(50);
                  endTime = new Date(new Date(now).setHours(23)).setMinutes(0);
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 306:
                  beginTime = new Date(new Date(now).setHours(8)).setMinutes(55);
                  endTime = new Date(new Date(now).setHours(21)).setMinutes(55);
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 401:
                  beginTime = new Date(new Date(now).setHours(9)).setMinutes(2);
                  endTime = new Date(new Date(now).setHours(23)).setMinutes(57);
                  if ((beginTime < now && now < endTime)) {
                    s = 5 * 60;
                  } else {
                    isNextDay = true;
                  }
                  break;
                case 501:
                  beginTime = new Date(new Date(now).setHours(8)).setMinutes(40);
                  endTime = new Date(new Date(now).setHours(22)).setMinutes(10);
                  if ((beginTime < now && now < endTime)) {
                    s = 10 * 60;
                  } else {
                    isNextDay = true;
                  }
              }
              if (isNextDay) {
                temp = new Date(beginTime);
                temp = temp.setDate(temp.getDate() + 1);
                s = temp - now;
              }
              gID = +CSH.gID;
              issues = _this.data.issues;
              issues.before = '';
              max = "" + CSH.gameMap[gID].count;
              if (gID === 104 || gID === 203 || gID === 304) {
                issues.current = "" + (++issues.current);
              } else if (issues.current.match(new RegExp("\\d{" + max.length + "}$"))[0] === max) {
                iss = issues.current;
                iss = iss.slice(0, iss.length - max.length);
                iss += (((function() {
                  var j, ref, results;
                  results = [];
                  for (i = j = 0, ref = max.length - 1; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
                    results.push('0');
                  }
                  return results;
                })()).join('')) + "1";
                issues.current = iss;
              } else {
                issues.current = "" + (++issues.current);
              }
              _this.refreshIssues('cur');
              _this.data.lotteryNumbers = [];
              time = s + time;
              _this.data.time = time;
              if (modalBox != null) {
                modalBox.modal('hide');
              }
              modalBox = null;
            } else if ((1 < time && time < 11)) {
              if (!CSH.audios.ticktack.state) {
                CSH.audios.ticktack.play();
                CSH.audios.ticktack.state = 1;
              }
              if (modalBox != null) {
                modalBox.modal('hide');
              }
              modalBox = null;
            } else if (time < 2) {
              if (CSH.audios.ticktack.state) {
                CSH.audios.ticktack.stop();
                CSH.audios.ticktack.state = 0;
              }
              if (!modalBox) {
                modalBox = $("<div class=\"modal fade modal-lottery-bet-loading2\" tabindex=\"-1\">\n	<div class=\"modal-dialog\">\n		<div class=\"head openEye\"></div>\n		<div class=\"main\">\n			<p>" + (_this.data.issues.current.replace(/^\d{8}/, '$&-')) + " 期已结束</p>\n			<p>请等待开奖</p>\n			<p class=\"con2\">即将进入下一期 <i></i><i class=\"one\"></i><i class=\"two\"></i></p>\n		</div>\n	</div>\n</div>");
                modalBox.appendTo(CSH.$els.body);
                modalBox.on('hidden', function() {
                  return $(this).remove();
                });
                modalBox.modal('show');
                CSH.audios.issueOver.play();
              }

              /*
              					else
              						modalBox.find '.circle'
              							.html time
              						modalBox.find('.modal-dialog').find('.head').removeClass 'openEye' if time is 1
               */
            } else {
              if (modalBox != null) {
                modalBox.modal('hide');
              }
              modalBox = null;
            }
            return _this.flipScoreboard(time);
          };
        })(this), 1000);
      };

      View.prototype.flipScoreboard = function(time) {
        var h, m, s;
        h = "" + (Math.floor(time / 60 / 60));
        m = "" + (Math.floor(time / 60 % 60));
        s = "" + (Math.floor(time % 60));
        if (this.data.oldTime.h !== h) {
          this.sbs.h.flip("" + (h.length === 1 ? '0' + h : h));
        }
        if (this.data.oldTime.m !== m) {
          this.sbs.m.flip("" + (m.length === 1 ? '0' + m : m));
        }
        this.sbs.s.flip("" + (s.length === 1 ? '0' + s : s));
        this.data.oldTime.h = h;
        return this.data.oldTime.m = m;
      };

      return View;

    })(Backbone.View);
    TransitionBall = (function() {
      function TransitionBall(data1) {
        var count, j, last, max, min, n, ref, ref1, str, temp;
        this.data = data1;
        this._showResult = bind(this._showResult, this);
        this.box = this.data.el;
        min = this.data.range.min;
        max = this.data.range.max;
        count = max - min + 1;
        str = '';
        this.data.count = count;
        this.data.total = 50 * count;
        this.data.speed = 200;
        temp = '';
        last = null;
        for (n = j = ref = min, ref1 = max; ref <= ref1 ? j <= ref1 : j >= ref1; n = ref <= ref1 ? ++j : --j) {
          n = "" + n;
          if (+CSH.gType === 3 && n.length === 1) {
            n = '0' + n;
          }
          temp = "<span>" + n + "</span>";
          if (+n === max) {
            last = temp;
          }
          str += temp;
        }
        str = last + str;
        this.box.html(str);
      }

      TransitionBall.prototype.destroy = function() {
        this._destroy = 1;
        delete this.data;
        return delete this.box;
      };

      TransitionBall.prototype.shake = function(param) {
        var _result, box, data, fun, k, self, speed, top, total, v;
        if (param == null) {
          param = {
            delay: 0
          };
        }
        data = this.data;
        for (k in param) {
          if (!hasProp.call(param, k)) continue;
          v = param[k];
          data[k] = v;
        }
        box = this.box;
        top = parseInt(box.css('marginTop'));
        speed = data.speed;
        total = data.total;
        _result = this._showResult;
        self = this;
        fun = function() {
          if (self._destroy) {
            return;
          }
          top += 50;
          box.animate({
            marginTop: top
          }, speed, 'linear', function() {
            if (data.r) {
              _result();
              return;
            }
            if (top === 0) {
              top = -total;
              box.css({
                marginTop: top
              });
            }
            return fun();
          });
        };
        this._reset();
        box.stop(true).css({
          marginTop: top
        });
        return setTimeout(fun, data.delay);
      };

      TransitionBall.prototype.result = function(num) {
        var data;
        data = this.data;
        data.r = true;
        return data.n = num;
      };

      TransitionBall.prototype._reset = function() {
        var data;
        data = this.data;
        data.r = false;
        return data.n = null;
      };

      TransitionBall.prototype._showResult = function() {
        var box, cTop, data, dvCount, dvCount0, dvCount1, dvTop, dvTop0, dvTop1, rTop, speed, speed0, speed1;
        data = this.data;
        box = this.box;
        cTop = parseInt(box.css('marginTop'));
        rTop = -(data.n - data.range.min + 1) * 50;
        if (rTop < cTop) {
          dvTop0 = -cTop;
          dvCount0 = dvTop0 / 50;
          speed0 = data.speed * dvCount0;
          dvTop1 = data.total - Math.abs(rTop);
          dvCount1 = dvTop1 / 50;
          speed1 = data.speed * dvCount1;
          return box.animate({
            marginTop: 0
          }, speed0, 'linear', function() {
            box.css({
              marginTop: -data.total
            });
            return box.animate({
              marginTop: rTop
            }, speed1, 'linear');
          });
        } else {
          dvTop = Math.abs(cTop) - Math.abs(rTop);
          dvCount = dvTop / 50;
          speed = data.speed * dvCount;
          return box.animate({
            marginTop: rTop
          }, speed, 'linear');
        }
      };

      return TransitionBall;

    })();
    TransitionCar = (function() {
      function TransitionCar(data1) {
        var count, max, min;
        this.data = data1;
        this._showResult = bind(this._showResult, this);
        this.els = {};
        this.els.car = this.data.el;
        this.els.p = this.els.car.parent();
        min = this.data.range.min;
        max = this.data.range.max;
        count = max - min + 1;
        this.data.count = count;
        this.data.total = 90 * count + 25;
        this.data.speed = 500;
      }

      TransitionCar.prototype.destroy = function() {
        this._destroy = 1;
        delete this.data;
        return delete this.els;
      };

      TransitionCar.prototype.shake = function() {
        var _result, data, fun, self, speed, target, total, x;
        data = this.data;
        target = this.els.p;
        x = -90 * data.index + parseInt(target.css('backgroundPositionX'));
        speed = data.speed;
        total = data.total;
        _result = this._showResult;
        self = this;
        fun = function() {
          if (self._destroy) {
            return;
          }
          x -= 90;
          target.animate({
            backgroundPositionX: x
          }, speed, 'linear', function() {
            if (data.r) {
              _result();
              return;
            }
            if (x <= -total) {
              x += 90 * 10;
              target.css({
                backgroundPositionX: x
              });
            }
            return fun();
          });
        };
        this._reset();
        target.stop(true).css({
          backgroundPositionX: x
        });
        return setTimeout(fun, 0);
      };

      TransitionCar.prototype.result = function(num, delay) {
        var data;
        data = this.data;
        data.r = true;
        data.n = num;
        return data.delay = delay;
      };

      TransitionCar.prototype._reset = function() {
        var data;
        data = this.data;
        data.r = false;
        data.n = null;
        data.delay = 0;
        this.els.p.removeClass('show');
        return this.els.car.removeClass('changing show');
      };

      TransitionCar.prototype._showResult = function() {
        var car, data, target;
        data = this.data;
        car = this.els.car;
        target = this.els.p;
        car.css({
          backgroundPositionX: -data.n * 90 + 90 - 6
        });
        return target.fadeOut(200, function() {
          target.show().addClass('show');
          return setTimeout(function() {
            car.addClass('changing');
            return car.addClass('show');
          }, 20 + data.delay);
        });
      };

      return TransitionCar;

    })();
    TransitionDice = (function() {
      function TransitionDice(data1) {
        this.data = data1;
        this.els = {};
        this.els.dice = this.data.el;
        this.els.imgWrap = this.data.el.siblings('.imgWrap');
        this.data.src = "<img src=\"/images/lottery_dice" + this.data.index + ".gif\" width=\"66\" height=\"80\" />";
      }

      TransitionDice.prototype.destroy = function() {
        this._destroy = 1;
        delete this.data;
        return delete this.els;
      };

      TransitionDice.prototype.shake = function(delay) {
        return setTimeout((function(_this) {
          return function() {
            if (_this._destroy) {
              return;
            }
            return _this.els.dice.fadeOut(200, function() {
              if (_this._destroy) {
                return;
              }
              return _this.els.imgWrap.html(_this.data.src).fadeIn(200);
            });
          };
        })(this), delay);
      };

      TransitionDice.prototype.result = function(num, delay) {
        return setTimeout((function(_this) {
          return function() {
            if (_this._destroy) {
              return;
            }
            return _this.els.imgWrap.fadeOut(200, function() {
              if (_this._destroy) {
                return;
              }
              _this.els.imgWrap.empty();
              _this.els.dice.attr({
                'data-value': num
              }).addClass('shaking').fadeIn(200);
              return setTimeout(function() {
                if (_this._destroy) {
                  return;
                }
                return _this.els.dice.removeClass('shaking');
              }, 1000);
            });
          };
        })(this), 800 + delay);
      };

      return TransitionDice;

    })();
    return View;
  });

}).call(this);
