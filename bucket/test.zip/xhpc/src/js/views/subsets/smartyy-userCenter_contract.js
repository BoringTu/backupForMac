(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/getsubbonustotal', 'models/getCurrentAmount', 'models/info_contract', 'models/getBonusLst', 'models/getSubUserList', 'models/signcontract', 'models/getSubBondLstByPeriod', 'models/bounsPeriodlist', 'models/getSublstContract', 'models/balance', 'models/gaveOutBonus', 'models/infobyid', 'models/contractDelete', 'models/getMemberBonusInfo', 'models/currentBounsPeriod', 'models/updatecontract', 'models/getUpBonus', 'collections/getBonusLst', 'collections/getSubBondLstByPeriod', 'collections/getSublstContract', 'text!../../../templates/subsets/smartyy-userCenter_contract_myContract.tpl', 'text!../../../templates/subsets/smartyy-userCenter_contract_info.tpl', 'text!../../../templates/subsets/smartyy-userCenter_contract_history.tpl', 'text!../../../templates/subsets/smartyy-userCenter_contract_subordinateList.tpl', 'text!../../../templates/subsets/smartyy-userCenter_contract_management.tpl', 'text!../../../templates/subsets/smartyy-userCenter_contract_alert.tpl', 'text!../../../templates/subsets/_smartyy-userCenter_tab.tpl', 'text!../../../templates/_smartyy-paginate.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-noResult.tpl'], function($, _, Backbone, doT, ModelGetsubbonustotal, ModelGetCurrentAmount, ModelInfo, ModelGetBonusLst, ModelGetSubUserList, ModelSigncontract, ModelGetSubBondLstByPeriod, ModelBounsPeriodlist, ModelGetSublstContract, ModelBalance, ModelGaveOutBonus, ModelInfobyid, ModelContractDelete, ModelGetMemberBonusInfo, ModelCurrentBounsPeriod, ModelUpdatecontract, ModelGetUpBonus, CollectionGetBonusLst, CollectionGetSubBondLstByPeriod, CollectionGetSublstContract, TplMyContract, TplInfo, TplHistory, TplSubordinateList, TplManagement, TplAlert, TplContent, TplPaginate, TplLoading, TplNoResult) {
    "use struct";
    var view;
    return view = (function(superClass) {
      var tabOption;

      extend(view, superClass);

      function view() {
        return view.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'myContract',
          text: '我的契约'
        }, {
          dataName: 'subordinateList',
          text: '下级契约'
        }, {
          dataName: 'management',
          text: '契约管理'
        }
      ];

      view.prototype.tpls = {
        content: doT.template(TplContent),
        info: doT.template(TplInfo),
        history: doT.template(TplHistory),
        alert: doT.template(TplAlert),
        paginate: doT.template(TplPaginate),
        myContract: doT.template(TplMyContract),
        subordinateList: doT.template(TplSubordinateList),
        management: doT.template(TplManagement),
        noResult: doT.template(TplNoResult)
      };

      view.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'mouseover .contentLoss div h1 span': 'eventDateShow',
        'mouseout .contentLoss div h1 span': 'eventDateHide',
        'click .addContract button': 'eventAddContract',
        'change .toolbar .month': 'eventMonthSelect',
        'change .toolbar .type': 'eventTypeSelect',
        'change .toolbar .stage': 'eventStageSelect',
        'change .toolbar .aBonus': 'eventBonusSelect',
        'change .toolbar .contarctStatus': 'eventContarctStatusSelect',
        'click .toolbar button.search': 'eventSearchSelect',
        'click .toolbar button.scatteredBtn': 'eventScatteredBtn',
        'click .dataContent table tbody tr td:last-of-type button.btn': 'eventPersonBonus',
        'click .dataContent table tbody tr td:last-of-type a.modify': 'eventsModifyContract',
        'click .dataContent table tbody tr td:last-of-type a.modify2': 'eventsModifyContract2',
        'click .dataContent table tbody tr td:last-of-type a.details': 'eventsDetailsContract',
        'click .dataContent table tbody tr td:last-of-type a.delete': 'eventsDestroyContract',
        'click .dataContent table tbody tr td:last-of-type a.modifyIng': 'eventsModifyIng',
        'click .dataContent table .sort i.icon': 'eventsSort',
        'click .myContractHistory table tbody tr td:last-of-type button.getMoney': 'eventgetMoneyContract',
        'click .myContractHistory table tbody tr td:last-of-type a.details': 'eventsDetailsContract',
        'click .myContractHistory table tbody tr td:nth-last-child(2) button.giveOutMoney': 'eventScatteredBtn'
      };

      view.prototype.initialize = function(data) {
        this.nowDate = 0;
        this.btn = false;
        return new ModelCurrentBounsPeriod().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON().data;
              if (data) {
                _this.nowDate = data.periodName;
              }
              if (!data) {
                return;
              }
              return new ModelGetsubbonustotal().setUrl(data.periodName).fetch({
                dataFilter: function(data) {
                  data = data.toJSON();
                  _this.$el.html(_this.tpls.info(data.data)).find('.option').html(_this.tpls.content(tabOption));
                  _this.li = _this.$el.find('.option .tabTitle li');
                  _this.li.eq(0).trigger('click');
                }
              });
            };
          })(this)
        });
      };

      view.prototype.nowViewName = function(viewName) {
        return this.li.filter("[data-name=\"" + this.viewName + "\"]").trigger('click');
      };

      view.prototype.eventsTabSwithc = function(event) {
        var el;
        el = $(event.currentTarget);
        this.viewName = el.attr('data-name');
        el.addClass('active').siblings('li').removeClass('active');
        this.els = {};
        this.els.tabContent = this.$el.find('.tabContent');
        this.toolbar = {};
        return this.fetchData();
      };

      view.prototype.fetchData = function(curPage) {
        var parameter, sortas;
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.xhr) {
          this.xhr.abort();
        }
        if (this.viewName === 'myContract') {
          new ModelGetCurrentAmount().setUrl().fetch({
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON().data;
                _this.els.tabContent.html(_this.tpls[_this.viewName]({
                  data: data
                }));
                setTimeout(function() {
                  return _this.countTime(data.currentPeriod);
                }, 0);
                _this.getDate();
                return _this.getHistory();
              };
            })(this)
          });
        }
        if (this.viewName === 'subordinateList') {
          new ModelBounsPeriodlist().setUrl().fetch({
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                var month, parameter, sortas;
                data = data.toJSON();
                month = data.data;
                parameter = {};
                parameter.sortas = _this.toolbar.sortas;
                switch (+_this.toolbar.sortas) {
                  case 1:
                    sortas = 'asc';
                    break;
                  case 0:
                    sortas = 'desc';
                }
                if (_this.toolbar.contract_Type) {
                  parameter.contract_Type = _this.toolbar.contract_Type;
                } else {
                  delete parameter.contract_Type;
                }
                if (_this.toolbar.step < 0) {
                  delete parameter.step;
                } else {
                  parameter.step = _this.toolbar.step;
                }
                if (_this.toolbar.state) {
                  parameter.state = _this.toolbar.state;
                }
                if (_this.toolbar.userName) {
                  parameter = {};
                  parameter.userName = _this.toolbar.userName.encodeHTML();
                } else {
                  delete parameter.userName;
                }
                parameter.periodName = _this.toolbar.periodName ? _this.toolbar.periodName : month[0];
                return new ModelGetSubBondLstByPeriod().setUrl("12/" + curPage).save(parameter, {
                  dataFilter: function(data) {
                    var C;
                    data = data.toJSON();
                    C = new CollectionGetSubBondLstByPeriod().reset(data);
                    _this.els.tabContent.html(_this.tpls[_this.viewName]({
                      data: C.toJSON().data,
                      month: month,
                      total: C.toJSON(),
                      sort: sortas,
                      parameter: parameter,
                      paginate: _this.tpls.paginate({
                        info: data.pageInfo,
                        notice: '* 将为您保留最近 6 个月数据'
                      }),
                      noResult: _this.tpls.noResult()
                    }));
                    return _this.els.tabContent.find('select').select2();
                  }
                });
              };
            })(this)
          });
        }
        if (this.viewName === 'management') {
          parameter = {};
          if (this.toolbar.userName) {
            parameter.receive_User = this.toolbar.userName;
          }
          if (this.toolbar.contract_Type) {
            parameter.contract_Type = this.toolbar.contract_Type;
          }
          if (this.toolbar.state) {
            parameter.state = this.toolbar.state;
          }
          parameter.sortas = this.toolbar.sortas;
          switch (+this.toolbar.sortas) {
            case 1:
              sortas = 'asc';
              break;
            case 0:
              sortas = 'desc';
          }
          return new ModelGetSublstContract().setUrl("12/" + curPage).save(parameter, {
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                var C;
                data = data.toJSON();
                C = new CollectionGetSublstContract().reset(data);
                data = C.toJSON();
                return _this.els.tabContent.html(_this.tpls.management({
                  data: data.data,
                  parameter: parameter,
                  sort: sortas,
                  total: data.pageInfo.totalAmount,
                  paginate: _this.tpls.paginate({
                    info: data.pageInfo,
                    notice: ''
                  }),
                  noResult: _this.tpls.noResult()
                })).find('select').select2();
              };
            })(this)
          });
        }
      };

      view.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      view.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        if (this.viewName === 'myContract') {
          this.getHistory(p);
        }
        if (this.viewName === 'subordinateList' || this.viewName === 'management') {
          return this.fetchData(p);
        }
      };

      view.prototype.countTime = function(target) {
        var implement;
        target = target.endDate.split(' ');
        this.els.dateColor = this.els.tabContent.find('.myContractTitle .time .dateColor');
        this.els.day = this.els.tabContent.find('.myContractTitle .day');
        implement = (function(_this) {
          return function() {
            var branch, numberDay, targetDay, targetTime, time, today, todayTime, totime;
            if (_this.viewName === 'myContract') {
              todayTime = new Date().getFormatDateAndTime().split(' ');
              today = todayTime[0].split('-');
              targetDay = target[0].split('/');
              totime = todayTime[1].split(':');
              targetTime = target[1].split(':');
              numberDay = targetDay[2] - today[2];
              time = targetTime[0] - totime[0];
              branch = targetTime[1] - totime[1];
              _this.els.day.html(target.periodName);
              _this.els.dateColor.eq(0).html(numberDay);
              _this.els.dateColor.eq(1).html(time);
              _this.els.dateColor.eq(2).html(branch);
              return setTimeout(function() {
                return implement();
              }, 60000);
            }
          };
        })(this);
        return implement();
      };

      view.prototype.eventDateShow = function(event) {
        var el, left, parent;
        el = $(event.currentTarget);
        parent = el.closest('h1');
        left = parent.position().left + parent.width() + 20;
        return this.els.profitLoss.show().css({
          left: left
        });
      };

      view.prototype.eventDateHide = function() {
        return this.els.profitLoss.hide();
      };

      view.prototype.getDate = function() {
        if (this.viewName === 'myContract') {
          this.els.profitLoss = this.els.tabContent.find('.contentLoss .profitLoss');
          this.els.myContractHistory = this.els.tabContent.find('.myContractHistory');
        }
      };

      view.prototype.getHistory = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        return new ModelGetBonusLst().setUrl(8. + "/" + curPage).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var C;
              data = data.toJSON();
              C = new CollectionGetBonusLst().reset(data);
              return _this.els.myContractHistory.html(_this.tpls.history({
                data: C.toJSON().data,
                paginate: _this.tpls.paginate({
                  info: data.pageInfo,
                  notice: '* 将为您保留最近 6 个月数据'
                })
              }));
            };
          })(this)
        });
      };

      view.prototype.eventgetMoneyContract = function(event) {
        var el, nowDate;
        this.nowViewName();
        el = $(event.currentTarget);
        el.attr('disabled', true);
        nowDate = el.closest('tr').attr('data-date');
        return new ModelGetUpBonus().setUrl(nowDate).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                CSH.hint({
                  msg: '领取成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                return _this.nowViewName();
              }
            };
          })(this)
        });
      };

      view.prototype.eventMonthSelect = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            _this.toolbar = {};
            _this.toolbar.periodName = _this.nowDate = el.val();
            _this.deleteName();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventStageSelect = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.step = el.val();
            _this.deleteName();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventBonusSelect = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            if (el.val() !== '0') {
              _this.toolbar.state = el.val();
            } else {
              delete _this.toolbar.state;
            }
            _this.deleteName();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventContarctStatusSelect = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            if (!(el.val() < 0)) {
              _this.toolbar.state = el.val();
            } else {
              delete _this.toolbar.state;
            }
            _this.deleteName();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventTypeSelect = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            if (el.val() !== '0') {
              _this.toolbar.contract_Type = el.val();
            } else {
              delete _this.toolbar.contract_Type;
            }
            _this.deleteName();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventSearchSelect = function(event) {
        var periodName;
        if (this.toolbar.periodName) {
          periodName = this.toolbar.periodName;
        }
        this.toolbar = {};
        this.els.searchName = this.els.tabContent.find('input.searchName');
        this.toolbar.userName = this.els.searchName.val();
        if (this.viewName === 'subordinateList') {
          this.toolbar.periodName = periodName;
        }
        return this.fetchData();
      };

      view.prototype.deleteName = function() {
        return delete this.toolbar.userName;
      };

      view.prototype.eventScatteredBtn = function(event) {
        var el, parameter;
        if (this.btn) {
          return;
        }
        this.btn = true;
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 1000);
        el = $(event.currentTarget);
        el.attr('disabled', true);
        parameter = {};
        if (this.viewName === 'myContract') {
          parameter.periodName = this.toolbar.periodName = el.closest('tr').attr('data-date');
        } else {
          parameter.periodName = this.toolbar.periodName;
        }
        parameter.state = 1;
        return new ModelGetSubBondLstByPeriod().setUrl("99999/1").save(parameter, {
          dataFilter: (function(_this) {
            return function(data) {
              var C;
              data = data.toJSON();
              C = new CollectionGetSubBondLstByPeriod().reset(data);
              data = C.toJSON();
              if (+data.data.length) {
                _this.bounsList(data);
              } else {
                CSH.hint('暂时没有用户达标');
              }
              return el.attr('disabled', false);
            };
          })(this)
        });
      };

      view.prototype.eventPersonBonus = function(event) {
        var data, el, tr;
        el = $(event.currentTarget);
        el.attr('disabled', true);
        tr = el.closest('tr');
        data = {};
        data.data = [];
        data.data.push({
          userName: tr.attr('data-name'),
          totalBonus: tr.attr('data-m')
        });
        this.bounsList(data);
        return setTimeout(function() {
          return el.attr('disabled', false);
        }, 1000);
      };

      view.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.toolbar.sortas === el.attr('data-sort')) {
          return;
        }
        this.toolbar.sortas = el.attr('data-sort');
        return this.fetchData();
      };

      view.prototype.bounsList = function(data) {
        var els, modalBox;
        modalBox = CSH.alert({
          title: '契约分红',
          content: this.tpls.alert({
            name: 'payMoney',
            data: data.data
          }),
          className: 'payMoney publicRed',
          ok: {
            text: '确定分红',
            autohide: false,
            callback: (function(_this) {
              return function() {
                data = {};
                data.lstReciveUser = [];
                els.isTrue.each(function(index, event) {
                  var el;
                  el = $(event);
                  if (el.prop('checked')) {
                    return data.lstReciveUser.push(el.closest('li').attr('data-name'));
                  }
                });
                if (!data.lstReciveUser.length) {
                  CSH.hint({
                    msg: '请选择用户',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                } else if (els.balance.text().replace(/[^\d.]/g, '') - els.result.text() < 0) {
                  CSH.hint({
                    msg: '金额不足',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                } else {
                  data.periodName = _this.toolbar.periodName;
                  new ModelGaveOutBonus().setUrl().save(data, {
                    dataFilter: function(data) {
                      data = data.toJSON();
                      if (data.code === 0) {
                        CSH.hint({
                          msg: '发放成功',
                          type: 'success',
                          icon: 'icon icon-ok'
                        });
                        return CSH.router.refresh();
                      } else {
                        return CSH.hint({
                          msg: data.message,
                          type: 'error',
                          icon: 'icon icon-close'
                        });
                      }
                    }
                  });
                }
                return modalBox.modal('hide');
              };
            })(this)
          }
        });
        els = {};
        els.allBtn = modalBox.find('.title button');
        els.lisBtn = modalBox.find('ul.list li button');
        els.isTrue = modalBox.find('ul.list li button input');
        els.result = modalBox.find('.total .result');
        els.balance = modalBox.find('.total .balance');
        new ModelBalance().setUrl().fetch({
          dataFilter: function(data) {
            data = data.toJSON();
            return els.balance.text('账户余额：' + data.data);
          }
        });
        els.allBtn.on('mousedown', function(event) {
          var allMoney, el;
          el = $(event.currentTarget);
          if (!el.find('input').prop('checked')) {
            els.lisBtn.addClass('checked');
            els.isTrue.prop('checked', true);
            allMoney = 0;
            els.lisBtn.each(function(index, event) {
              var moeny;
              el = $(event);
              moeny = el.closest('li').attr('data-m');
              return allMoney += +moeny;
            });
            return els.result.text(+allMoney.toFixed(4));
          } else {
            els.lisBtn.removeClass('checked');
            els.isTrue.prop('checked', false);
            return els.result.text(0);
          }
        });
        return modalBox.delegate('ul.list li button', 'mousedown', function(event) {
          var allMoney, el, isTrue, li, money;
          el = $(event.currentTarget);
          li = el.closest('li');
          isTrue = el.find('input').prop('checked');
          money = +li.attr('data-m');
          allMoney = +els.result.text();
          money = isTrue ? allMoney - money : allMoney + money;
          return els.result.text(+money.accurate(4));
        });
      };

      view.prototype.eventsDetailsContract = function(event) {
        var el, loading, nowDate, username;
        if (this.btn) {
          return;
        }
        this.btn = true;
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 1000);
        el = $(event.currentTarget);
        if (this.viewName === 'myContract') {
          username = localStorage.getItem('username');
          nowDate = el.closest('tr').attr('data-date');
        } else {
          username = el.closest('tr').attr('data-name');
          nowDate = this.nowDate;
        }
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        return new ModelGetMemberBonusInfo().setUrl(nowDate + "/" + username).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var els, maxH, modalBox, scrollHeight, surplus;
              loading.data('hide')();
              data = data.toJSON();
              modalBox = CSH.alert({
                title: '契约详情',
                content: _this.tpls.alert({
                  data: data.data,
                  name: 'details'
                }),
                className: 'details'
              });
              els = {};
              els.$window = $(window);
              els.modalBody = modalBox.find('.modal-body');
              surplus = 106;
              maxH = els.modalBody.height();
              scrollHeight = function() {
                var modalBodyH, windowH;
                windowH = els.$window.height() * 0.9;
                modalBodyH = els.modalBody.outerHeight();
                if (modalBodyH + surplus > windowH || modalBodyH < maxH) {
                  return els.modalBody.css({
                    height: windowH - surplus
                  });
                }
              };
              scrollHeight();
              els.$window.on('resize', scrollHeight);
              return '{}';
            };
          })(this)
        });
      };

      view.prototype.eventsModifyIng = function() {
        return CSH.hint('已生成有变更契约');
      };

      view.prototype.eventsDestroyContract = function(event) {
        var el, id, loading;
        el = $(event.currentTarget);
        id = el.closest('tr').attr('data-id');
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        return new ModelContractDelete({
          id: id
        }).destroy({
          dataFilter: (function(_this) {
            return function(data) {
              loading.data('hide')();
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              CSH.hint('删除成功');
              return _this.$el.find('.tabTitle li').eq(2).trigger('click');
            };
          })(this)
        });
      };

      view.prototype.eventsModifyContract = function(event) {
        var el, id, loading;
        if (this.btn) {
          return;
        }
        this.btn = true;
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 1000);
        el = $(event.currentTarget);
        id = el.closest('tr').attr('data-id');
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        return new ModelInfobyid().setUrl(id).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              loading.data('hide')();
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              return _this.contractAdjustment(null, data, null, 0);
            };
          })(this)
        });
      };

      view.prototype.eventsModifyContract2 = function(event) {
        var el, id, loading;
        if (this.btn) {
          return;
        }
        this.btn = true;
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 1000);
        el = $(event.currentTarget);
        id = el.closest('tr').attr('data-id');
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        return new ModelInfobyid().setUrl(id).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              loading.data('hide')();
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              return _this.contractAdjustment(null, data, id, 1);
            };
          })(this)
        });
      };

      view.prototype.eventAddContract = function(event) {
        var el;
        el = $(event.currentTarget);
        el.attr('disabled', true);
        return this.contractAdjustment(el, null, null, 1);
      };

      view.prototype.contractAdjustment = function(whatEl, subordinateDate, id, num) {
        var btnText, loading;
        subordinateDate = subordinateDate ? subordinateDate : null;
        btnText = +num === 1 ? '确认发布' : '变更契约';
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        return new ModelInfo().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var contractInfo, ratio;
              loading.data('hide')();
              data = data.toJSON();
              contractInfo = data.data.contractInfo;
              ratio = {};
              ratio.max = contractInfo[contractInfo.length - 1].ratio;
              if (CSH.fix === 'bj' && ratio.max > 0.35) {
                ratio.max = 0.35;
              }
              return new ModelGetSubUserList().setUrl().fetch({
                dataFilter: function(data) {
                  var els, isChecked, modalBox, posData, stage;
                  data = data.toJSON();
                  modalBox = null;
                  els = {};
                  posData = {};
                  stage = subordinateDate ? subordinateDate.data.contractInfo.length - 1 : 1;
                  isChecked = false;
                  modalBox = CSH.alert({
                    title: '契约分红',
                    content: _this.tpls.alert({
                      subordinateList: data.data,
                      ratio: ratio,
                      sdDate: subordinateDate,
                      stage: stage,
                      change: num,
                      name: 'addContract'
                    }),
                    className: 'contractRed publicRed',
                    ok: {
                      text: btnText,
                      autohide: false,
                      callback: function() {
                        var i, j, l, m, posDate, ref, ref1, ref2, strHint, thanBigSmall, type, val, valBuyMoney, valPeople;
                        strHint = function(i, str) {
                          els.contractWrap.animate({
                            scrollTop: els.task.eq(i).position().top
                          });
                          return CSH.hint(str);
                        };
                        val = {};
                        val.buyMoney = [];
                        val.people = [];
                        val.ratio = [];
                        type = els.type.val();
                        for (i = j = 0, ref = stage; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                          if (+type === 1) {
                            valBuyMoney = +els.buyMoney.eq(i).val();
                            valPeople = +els.people.eq(i).val();
                            if (valBuyMoney === 0 && valPeople === 0) {
                              if (i !== 0) {
                                strHint(i, '请输入有效的并且大于1万的 团队亏损量');
                                return;
                              }
                            }
                            val.people.push(+valPeople);
                          } else {
                            valBuyMoney = els.lossMoney.eq(i).val();
                            if (valBuyMoney < 1) {
                              if (i !== 0) {
                                strHint(i, '请输入有效的并且大于1万的 团队亏损量');
                                return;
                              }
                            }
                          }
                          val.buyMoney.push(+valBuyMoney);
                          val.ratio.push(parseInt(els.ratio.eq(i).val()));
                        }
                        strHint = function(i, str) {
                          els.contractWrap.animate({
                            scrollTop: els.task.eq(i).position().top
                          });
                          return CSH.hint(str);
                        };
                        thanBigSmall = function(val) {
                          var buyMoney, isBuyMoney, isPeople, k, l, m, people, ref1, ref2, ref3, valRatio;
                          els.buyMoney.attr('style', '');
                          els.people.attr('style', '');
                          els.task.find('.select2-selection__rendered').attr('style', '');
                          for (i = l = 0, ref1 = stage; 0 <= ref1 ? l <= ref1 : l >= ref1; i = 0 <= ref1 ? ++l : --l) {
                            for (k = m = ref2 = i, ref3 = stage; ref2 <= ref3 ? m <= ref3 : m >= ref3; k = ref2 <= ref3 ? ++m : --m) {
                              if (i === k) {
                                continue;
                              }
                              if (+type === 1) {
                                buyMoney = val['buyMoney'];
                                people = val['people'];
                                isBuyMoney = buyMoney[i] >= buyMoney[k];
                                isPeople = people[i] >= people[k];
                                if (isBuyMoney && isPeople) {
                                  els.buyMoney.eq(i).css('color', '#D85354').end().eq(k).css('color', '#D85354');
                                  els.people.eq(i).css('color', '#D85354').end().eq(k).css('color', '#D85354');
                                  strHint(i, '下阶数值需大于上阶');
                                  return true;
                                }
                              }
                              if (+type === 2) {
                                buyMoney = val['buyMoney'];
                                if (buyMoney[i] >= buyMoney[k]) {
                                  els.buyMoney.eq(i).css('color', '#D85354').end().eq(k).css('color', '#D85354');
                                  strHint(i, '下阶数值需大于上阶');
                                  return true;
                                }
                              }
                              valRatio = val['ratio'];
                              if (valRatio[i] >= valRatio[k]) {
                                els.task.eq(i).find('.select2-selection__rendered').css('color', '#D85354');
                                els.task.eq(k).find('.select2-selection__rendered').css('color', '#D85354');
                                strHint(i, '下阶数值需大于上阶');
                                return true;
                              }
                            }
                          }
                          return false;
                        };
                        if (thanBigSmall(val)) {
                          return;
                        }
                        if (!els.agreeWrapBtn.find('input').eq(0).prop('checked')) {
                          return CSH.hint('请阅读并且同意契约条款');
                        }
                        posDate = {};
                        posDate.loss_Num = +els.addUp.val();
                        posDate.contractInfo = [];
                        if (+type === 1) {
                          for (i = l = 0, ref1 = stage; 0 <= ref1 ? l <= ref1 : l >= ref1; i = 0 <= ref1 ? ++l : --l) {
                            posDate.contractInfo.push({
                              contract_Type: +type,
                              step: i + 1,
                              ratio: val.ratio[i] / 100,
                              memberCount: +val.people[i],
                              target_Amount: val.buyMoney[i] * 10000
                            });
                          }
                        }
                        if (+type === 2) {
                          for (i = m = 0, ref2 = stage; 0 <= ref2 ? m <= ref2 : m >= ref2; i = 0 <= ref2 ? ++m : --m) {
                            posDate.contractInfo.push({
                              contract_Type: +type,
                              step: i + 1,
                              ratio: val.ratio[i] / 100,
                              target_Amount: val.buyMoney[i] * 10000
                            });
                          }
                        }
                        if (!id) {
                          posDate.ismain = num;
                          if (els.name.val() !== 'default') {
                            posDate.receive_User = els.name.val().encodeHTML();
                          } else {
                            CSH.hint({
                              msg: '请选择一个下级用户',
                              type: 'error',
                              icon: 'icon icon-close'
                            });
                            return;
                          }
                          return new ModelSigncontract().setUrl().save(posDate, {
                            dataFilter: function(data) {
                              var msg;
                              data = data.toJSON();
                              msg = +num === 1 ? '创建成功' : '调整成功';
                              if (data.code === 0) {
                                CSH.hint({
                                  msg: msg,
                                  type: 'success',
                                  icon: 'icon icon-ok'
                                });
                                modalBox.modal('hide');
                                if (whatEl) {
                                  _this.li.eq(2).trigger('click');
                                  return whatEl.attr('disabled', false);
                                } else {
                                  return _this.nowViewName();
                                }
                              } else if (data.code === 4) {
                                return CSH.hint(data.message);
                              }
                            }
                          });
                        } else {
                          return new ModelUpdatecontract().setUrl(id).save(posDate, {
                            dataFilter: function(data) {
                              data = data.toJSON();
                              if (data.code === 0) {
                                CSH.hint({
                                  msg: '修改成功',
                                  type: 'success',
                                  icon: 'icon icon-ok'
                                });
                                modalBox.modal('hide');
                                return _this.nowViewName();
                              }
                            }
                          });
                        }
                      }
                    }
                  });
                  return setTimeout(function() {
                    var maxVal, nowVal1, nowVal2, resetRatio, scrollHeight, taskLengt;
                    els.$window = $(window);
                    els.dialog = modalBox.find('.modal-dialog');
                    els.contractWrap = els.dialog.find('.contractWrap');
                    els.inputNumber = els.contractWrap.find('input[type="number"]');
                    els.selectType = els.contractWrap.find('select.type');
                    els.taskWrap = els.contractWrap.find('.taskWrap');
                    els.task = els.taskWrap.find('.task');
                    els.buyMoney = els.task.find('.buyMoney');
                    els.people = els.task.find('.people');
                    els.lossMoney = els.task.find('.lossMoney');
                    els.addRule = els.dialog.find('.addRule');
                    els.taskRight = els.task.find('.taskRight');
                    els.ratioWrap = els.taskRight.find('label');
                    els.ratio = els.ratioWrap.find('select');
                    els.closeBtn = els.task.find('.close');
                    els.contract = els.contractWrap.find('.contract');
                    els.name = els.contract.find('#name');
                    els.addUp = els.contract.find('.addUp');
                    els.type = els.contract.find('.type');
                    els.lossLabelVal = els.contract.find('.lossLabel input');
                    els.agreeTextWrap = modalBox.find('.agreeTextWrap');
                    els.closeTextBtn = els.agreeTextWrap.find('.icon-wrong');
                    els.textWrap = els.agreeTextWrap.find('.textWrap');
                    els.agreeWrap = modalBox.find('.agreeWrap');
                    els.agreeWrapBtn = els.agreeWrap.find('button');
                    els.alertText = els.agreeWrap.find('a');
                    els.btnPrimary = modalBox.find('.modal-footer .btn-primary');
                    modalBox.find('select').select2().on('click', function() {
                      return $('.select2-container--open').css('zIndex', 1600);
                    });
                    taskLengt = els.task.length;
                    els.people.on('keyup', (function(_this) {
                      return function(event) {
                        var el;
                        el = $(event.currentTarget);
                        if (!/^\d+$/.test(el.val())) {
                          return el.val('');
                        }
                      };
                    })(this));
                    if (whatEl) {
                      modalBox.on('keyup', function(event) {
                        if (+event.keyCode === 27) {
                          return whatEl.attr('disabled', false);
                        }
                      });
                      modalBox.find('.close').on('click', function() {
                        return whatEl.attr('disabled', false);
                      });
                      modalBox.find('#name').select2({
                        minimumResultsForSearch: 1
                      });
                    }
                    setTimeout(function() {
                      modalBox.find('.contract .select2').css({
                        height: 46
                      }).find('span').css({
                        height: 46
                      });
                      return modalBox.find('.contract .select2-selection__rendered').css({
                        lineHeight: '46px'
                      });
                    }, 100);
                    scrollHeight = (function(_this) {
                      return function() {
                        var windowH;
                        windowH = els.$window.height() * 0.9;
                        windowH = windowH - 178;
                        windowH = windowH > 550 ? 550 : windowH;
                        els.contractWrap.css({
                          height: windowH,
                          overflow: 'auto'
                        });
                        return els.textWrap.css({
                          height: windowH * 0.8,
                          overflow: 'auto'
                        });
                      };
                    })(this);
                    scrollHeight();
                    els.$window.on('resize', scrollHeight);
                    modalBox.find('input[type="number"]').on('blur', function(event) {
                      var el, index, val;
                      els.inputNumber.attr('style', '');
                      el = $(event.currentTarget);
                      index = el.attr('data-index');
                      val = el.val();
                      if (val) {
                        if (index >= 1) {
                          switch (el.attr('class')) {
                            case 'people':
                              if (!(+val >= +els.people.eq(index - 1).val())) {
                                CSH.hint('请输入有效人数');
                                el.focus().css('color', '#D85354');
                                return els.btnPrimary.prop('disabled', true);
                              } else {
                                return els.btnPrimary.prop('disabled', false);
                              }
                              break;
                            case 'buyMoney':
                              if (!(+val >= +els.buyMoney.eq(index - 1).val())) {
                                CSH.hint('请输入有效购彩量');
                                el.focus().css('color', '#D85354');
                                return els.btnPrimary.prop('disabled', true);
                              } else {
                                return els.btnPrimary.prop('disabled', false);
                              }
                              break;
                            case 'lossMoney':
                              if (!(+val >= +els.lossMoney.eq(index - 1).val())) {
                                CSH.hint('请输入有效亏损量');
                                el.focus().css('color', '#D85354');
                                return els.btnPrimary.prop('disabled', true);
                              } else {
                                return els.btnPrimary.prop('disabled', false);
                              }
                          }
                        }
                      }
                    });
                    els.selectType.on('change', function(event) {
                      var el;
                      el = $(event.currentTarget);
                      if (+el.val() === 2) {
                        return els.taskWrap.removeClass('amount').addClass('loss');
                      } else {
                        return els.taskWrap.removeClass('loss').addClass('amount');
                      }
                    });
                    els.closeBtn.on('click', function(event) {
                      var el, index, now, prev;
                      el = $(event.currentTarget);
                      index = el.attr('data-index');
                      if (stage !== +index) {
                        return CSH.hint("请先关闭第" + (stage + 1) + "阶段");
                      }
                      resetRatio();
                      prev = els.ratio.eq(stage);
                      stage--;
                      now = els.ratioWrap.eq(stage);
                      now.text('').append('分红').append(prev);
                      prev.select2();
                      resetRatio();
                      els.addRule.slideDown();
                      el.closest('.task').slideUp();
                      els.contractWrap.removeAttr('style');
                      return scrollHeight();
                    });
                    els.addRule.on('click', function(event) {
                      var i, j, max, now, option, prev, prevVal, ratioWrap, ref, select, val;
                      resetRatio();
                      ratioWrap = els.ratioWrap.eq(stage);
                      val = parseInt(ratioWrap.find('select').val());
                      max = 1;
                      option = '';
                      select = $("<select></select>");
                      for (i = j = 1, ref = ratio.max; 1 <= ref ? j <= ref : j >= ref; i = 1 <= ref ? ++j : --j) {
                        option += "<option " + (i === val ? 'selected="true"' : void 0) + " >" + i + "%<option>";
                      }
                      ratioWrap.append(select.append(option));
                      select.select2().on('click', function() {
                        return $('.select2-container--open').css('zIndex', 1600);
                      });
                      prev = els.ratio.eq(stage);
                      stage++;
                      now = els.ratioWrap.eq(stage);
                      now.text('').append('分红').append(prev);
                      prevVal = ratio.max === parseInt(prev.val()) ? (parseInt(prev.val())) + "%" : (parseInt(prev.val()) + 1) + "%";
                      prev.select2().val(prevVal).trigger('change');
                      resetRatio();
                      els.task.eq(stage).slideDown();
                      setTimeout(function() {
                        return els.contractWrap.animate({
                          'scrollTop': els.contractWrap.scrollTop() + 120
                        });
                      }, 500);
                      if (stage === taskLengt - 1) {
                        els.addRule.slideUp();
                      }
                      return scrollHeight();
                    });
                    resetRatio = (function(_this) {
                      return function() {
                        delete els.ratio;
                        return els.ratio = els.ratioWrap.find('select');
                      };
                    })(this);
                    els.agreeWrapBtn.find('input').on('change', function(event) {
                      var el;
                      el = $(event.currentTarget);
                      if (el.prop('checked')) {
                        return els.agreeWrapBtn.addClass('checked').find('input').prop('checked', true);
                      } else {
                        return els.agreeWrapBtn.removeClass('checked').find('input').prop('checked', false);
                      }
                    });
                    els.alertText.on('click', function(event) {
                      return els.agreeTextWrap.show();
                    });
                    els.closeTextBtn.on('click', function(event) {
                      return els.agreeTextWrap.hide();
                    });
                    maxVal = 0;
                    nowVal1 = 0;
                    return nowVal2 = 0;
                  }, 0);
                }
              });
            };
          })(this)
        });
      };

      return view;

    })(Backbone.View);
  });

}).call(this);
