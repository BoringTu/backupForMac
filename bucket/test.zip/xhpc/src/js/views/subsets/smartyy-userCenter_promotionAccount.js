(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'clipboard', 'models/register', 'models/username', 'models/addLinks', 'models/openaccount', 'models/linksNew', 'models/links', 'collections/linksNew', 'text!../../../templates/subsets/_smartyy-userCenter_tab.tpl', 'text!../../../templates/subsets/smartyy-userCenter_promotionAccount_accurate.tpl', 'text!../../../templates/subsets/smartyy-userCenter_promotionAccount_link.tpl', 'text!../../../templates/subsets/smartyy-userCenter_promotionAccount_linksManage.tpl', 'text!../../../templates/subsets/smartyy-userCenter_promotionAccount_alert.tpl', 'text!../../../templates/_smartyy-paginate.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-noResult.tpl', 'models/linkstate'], function($, _, Backbone, doT, Clipboard, ModelRegister, ModelUsername, ModelAddLinks, ModelOpenAccount, ModelLinksNew, ModelLinks, CollectionLinksNew, TplContent, TplAccurate, TplLink, TplLinksManage, TplAlert, TplPaginate, TplLoading, TplNoResult, ModelLinkState) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'accurate',
          text: '精准开户'
        }, {
          dataName: 'link',
          text: '链接开户'
        }, {
          dataName: 'linksManage',
          text: '链接管理'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        accurate: doT.template(TplAccurate),
        link: doT.template(TplLink),
        linksManage: doT.template(TplLinksManage),
        paginate: doT.template(TplPaginate),
        alert: doT.template(TplAlert),
        noResult: doT.template(TplNoResult)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'keyup .paginate input': 'eventKeyupPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'click .table .changeStatus': 'eventsChangeSattus',
        'click .table .remoUrl': 'eventsRemoUrl',
        'mouseup .selectWrap': 'eventToggle',
        'keyup .selectWrap .adjustBtn': 'eventInput',
        'click .subject .btn': 'eventAddDaySalary',
        'click .selectType .type': 'eventSelectType',
        'keyup .subject input.name': 'eventCheckUserName',
        'mousedown.slide .roundBtn': 'eventsSlide',
        'click .agreement a': 'eventOpenAgreement'
      };

      View.prototype.initialize = function(data) {
        window.v = this;
        this.$el.html(this.tpls.content(tabOption));
        this.m = null;
        this.c = null;
        this.viewName = null;
        this.nameLinksManage = 'linksManage';
        this.$el.find('.tabTitle ul li').eq(0).trigger('click');
        this.slides = {};
        this.slides.myRebate = +localStorage.getItem('rebate');
        this.slides.mySalary = +localStorage.getItem('salary');
        this.slides.salaryD = this.slides.mySalary * 1000 * 1000;
        this.slides.minRebate = 1850;
        if (CSH.fix === 'bj') {
          this.slides.salaryD = this.slides.salaryD >= 15000 ? 15000 : this.slides.salaryD;
        }
        this.slides.rebateD = this.slides.myRebate - this.slides.minRebate;
        this.slides.xMin = 0;
        return this.slides.xMax = 260;
      };

      View.prototype.render = function(pageInfo) {
        var clipboard;
        if (this.nameLinksManage === this.viewName) {
          this.els.tabContent.html(this.tpls[this.viewName]({
            data: this.c.toJSON(),
            people: pageInfo.totalAmount,
            paginate: this.tpls.paginate({
              info: pageInfo,
              notice: ''
            }),
            noResult: this.tpls.noResult()
          }));
          clipboard = new Clipboard('.btns');
          clipboard.on('success', function() {
            return CSH.hint('复制成功');
          });
        } else {
          this.els.tabContent.html(this.tpls[this.viewName]());
          this.dayBox();
          return this.getDate();
        }
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.nameLinksManage === this.viewName) {
          return this.m.setUrl(curPage).fetch({
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                if (data.code !== 0) {
                  return;
                }
                _this.c.reset(data.data);
                _this.render(data.pageInfo);
                return '{}';
              };
            })(this)
          });
        } else {
          return this.render();
        }
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventsTabSwithc = function(event) {
        var el;
        el = $(event.currentTarget);
        this.viewName = el.attr('data-name');
        el.addClass('active').siblings('li').removeClass('active');
        this.els = {};
        if (this.nameLinksManage === this.viewName) {
          this.c = new CollectionLinksNew();
          this.m = new ModelLinksNew();
        }
        this.els.tabContent = this.$el.find('.tabContent');
        return this.fetchData();
      };

      View.prototype.eventsRemoUrl = function(event) {
        var el, id;
        el = $(event.currentTarget);
        id = el.closest('tr').attr('data-urlId');
        new ModelLinks({
          id: id
        }).destroy({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              CSH.hint('删除成功');
              return _this.$el.find('.tabTitle ul li').eq(2).trigger('click');
            };
          })(this)
        });
      };

      View.prototype.eventsChangeSattus = function(event) {
        var data, el;
        el = $(event.currentTarget);
        data = {};
        data.state = el.attr('data-state');
        data.lid = el.closest('tr').attr('data-urlId');
        new ModelLinkState().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              CSH.hint('修改成功');
              _this.$el.find('.tabTitle ul li').eq(2).trigger('click');
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.eventToggle = function(event) {
        var adjustBtn, el, speed, wrapAdjust;
        speed = 200;
        el = $(event.target);
        wrapAdjust = $(el.closest('.wrapAdjust')[0]);
        adjustBtn = $(el.closest('.adjustBtn')[0]);
        this.els.adjustBtn.addClass('arrow').removeClass('arrowTopple');
        if (adjustBtn.hasClass('arrow')) {
          adjustBtn.addClass('arrowTopple').removeClass('arrow');
          if (el.hasClass('salary')) {
            return this.els.stageWrap.animate({
              'scrollTop': el.closest('.stage').position().top + this.els.stageWrap.scrollTop()
            });
          }
        } else {
          return adjustBtn.removeClass('arrowTopple').addClass('arrow');
        }
      };

      View.prototype.eventInput = function(event) {
        var aLLrebate, el, rebate, salary, sun, val, wi;
        el = $(event.currentTarget);
        val = el.val();
        sun = (function(_this) {
          return function() {
            var bg, btn;
            bg = el.next('.wrapAdjust').find('.bg');
            btn = el.next('.wrapAdjust').find('.roundBtn');
            bg.css('width', wi);
            return btn.css('left', wi);
          };
        })(this);
        if (val.length >= 4) {
          if (el.closest('.rebate')[0]) {
            if (!/^1/.test(val)) {
              el.val('');
            }
            if (this.slides.minRebate > val) {
              el.val(this.slides.minRebate);
            }
            if (this.slides.myRebate < val) {
              el.val(this.slides.myRebate);
            }
            val = el.val();
            rebate = val - this.slides.minRebate;
            aLLrebate = this.slides.myRebate - this.slides.minRebate;
            wi = rebate / aLLrebate;
          }
        }
        if (val.length > 4) {
          if (!el.closest('.rebate')[0]) {
            val = parseFloat(el.val());
            el.val(Number.isNaN(val) ? 0 : val);
            salary = this.slides.salaryD / 100 / 100;
            if (+salary < val) {
              el.val(salary);
            }
            val = +el.val();
            wi = val / salary;
            wi = wi * this.slides.xMax;
          }
        }
        if (String(val).length >= 5) {
          el.val(0);
        }
        return sun();
      };

      View.prototype.eventsSlide = function(event) {
        var bg, el, xInte;
        event.stopPropagation();
        el = $(event.currentTarget);
        xInte = event.clientX - el.position().left;
        bg = el.prev('.wrapBg').find('.bg');
        this.els.tabContent.on('mousemove.slide', (function(_this) {
          return function(event) {
            var dValue, elWrapAdjust, nowRebate, rebate, salary, text, xNow;
            xNow = event.clientX - xInte;
            if (xNow < _this.slides.xMin) {
              xNow = _this.slides.xMin;
            }
            if (xNow > _this.slides.xMax) {
              xNow = _this.slides.xMax;
            }
            dValue = xNow / _this.slides.xMax;
            elWrapAdjust = el.closest('.wrapAdjust');
            rebate = elWrapAdjust.prev('.rebate');
            if (rebate[0]) {
              nowRebate = Math.round(dValue * _this.slides.rebateD);
              nowRebate = nowRebate % 2 ? nowRebate + 1 : nowRebate;
              rebate.val(nowRebate + _this.slides.minRebate);
            }
            salary = elWrapAdjust.prev('.salary');
            if (salary[0]) {
              text = dValue * _this.slides.salaryD;
              text = Math.round(text * 0.01);
              text = text * 0.01;
              salary.val(text.accurate(2));
            }
            el.css('left', xNow);
            return bg.css('width', xNow);
          };
        })(this));
        return this.els.tabContent.on('mouseup.slide', (function(_this) {
          return function(event) {
            return _this.els.tabContent.off('.slide');
          };
        })(this));
      };

      View.prototype.eventSelectType = function(event) {
        var el;
        el = $(event.currentTarget);
        this.type = el.attr('data-type');
        el.addClass('select').find('button').addClass('checked').end().siblings('.select').removeClass('select').find('button').removeClass('checked');
        if (this.els.dayMoney[0] && +this.type === 1) {
          return this.els.dayMoney.find('.stageRight').addClass('type');
        } else {
          return this.els.dayMoney.find('.stageRight').removeClass('type');
        }
      };

      View.prototype.eventAddDaySalary = function(event) {
        var el, element, i, j, k, l, m, ref, ref1, ref2, ref3, type, val;
        el = $(event.currentTarget);
        type = el.attr('data-btn');
        val = [];
        element = (function(_this) {
          return function(i) {
            var amount, people, ratio;
            ratio = parseFloat(_this.els.salary.eq(i).val());
            people = +_this.els.people.eq(i).val();
            amount = +_this.els.amount.eq(i).val();
            if (people < 0) {
              return CSH.hint({
                msg: '人数不能为负数'
              });
            }
            if (amount < 0) {
              return CSH.hint({
                msg: '购彩量不能为负'
              });
            }
            if (!ratio) {
              return CSH.hint({
                msg: '日工资比例不能设置为0.00%'
              });
            }
            val.push({
              step: i + 1,
              ratio: +(ratio * 0.01).accurate(4),
              memberCount: people != null ? people : 0,
              targetAmount: amount * 10000
            });
            return false;
          };
        })(this);
        if (+localStorage.getItem('salaryState') !== 0) {
          if (+this.type === 2) {
            if (!this.els.dayMoney.find('.dayMoneyBottom').is(':hidden')) {
              if (!(this.els.people.eq(0).val() || this.els.amount.eq(0).val())) {
                return CSH.hint('请输入正确购彩量或者活跃用户');
              }
              for (i = j = 0, ref = this.stage - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                if (element(i) !== false) {
                  return;
                }
              }
              if (this.stage !== 1) {
                for (i = k = 0, ref1 = this.stage - 2; 0 <= ref1 ? k <= ref1 : k >= ref1; i = 0 <= ref1 ? ++k : --k) {
                  if (val[i].ratio >= val[i + 1].ratio) {
                    return CSH.hint('上一阶段日工资比例不能比下一阶段低');
                  }
                  if (val[i].memberCount === val[i + 1].memberCount && val[i].targetAmount === val[i + 1].targetAmount) {
                    return CSH.hint('上一阶段不能跟下一阶相同');
                  } else if (val[i].memberCount > val[i + 1].memberCount || val[i].targetAmount > val[i + 1].targetAmount) {
                    return CSH.hint('上一阶不能低于下一阶');
                  }
                }
              }
            }
          } else {
            if (!this.els.dayMoney.find('.dayMoneyBottom').is(':hidden')) {
              if (!this.els.amount.eq(0).val()) {
                return CSH.hint('请输入正确购彩量');
              }
              for (i = l = 0, ref2 = this.stage - 1; 0 <= ref2 ? l <= ref2 : l >= ref2; i = 0 <= ref2 ? ++l : --l) {
                if (element(i) !== false) {
                  return;
                }
              }
              if (this.stage !== 1) {
                for (i = m = 0, ref3 = this.stage - 2; 0 <= ref3 ? m <= ref3 : m >= ref3; i = 0 <= ref3 ? ++m : --m) {
                  if (val[i].ratio >= val[i + 1].ratio) {
                    return CSH.hint('上一阶段日工资比例不能比下一阶段低');
                  }
                  if (val[i].targetAmount >= val[i + 1].targetAmount) {
                    return CSH.hint('上一阶不能低于或等于下一阶');
                  }
                }
              }
            }
          }
        }
        this["add_" + type](val);
      };

      View.prototype.add_member = function(val) {
        var data, loading, password, userRegex, userVal;
        userRegex = /^[a-zA-Z]\w{5,13}$/;
        userVal = this.els.username.val();
        if (!userRegex.test(userVal)) {
          this.els.username.trigger('keyup');
          if (this.els.username.val().length < 6) {
            this.els.resultsName.show().addClass('icon-wrong').removeClass('icon-right').css('color', '#D54345').html($('<span style="margin-left:5px;">字母开头：6~14位字母、数字组成</span>'));
          }
          return;
        }
        if (this.resultsAmount()) {
          return;
        }
        password = 'x123456';
        data = {};
        data.userName = userVal.encodeHTML();
        data.password = password.encodeHTML();
        data.rebateRate = +this.els.adjustBtnRebate.val();
        data.userType = +this.type;
        data.salarylist = val;
        if (data.rebateRate > this.slides.myRebate) {
          return CSH.hint('返点值不能大于自身');
        }
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        new ModelOpenAccount().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              loading.data('hide')();
              if (data.code === 0) {
                CSH.hint({
                  msg: '创建成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                _this.els.tabTitleUlLi.eq(0).trigger('click');
              } else {
                CSH.hint({
                  msg: '创建失败',
                  type: 'error',
                  icon: 'icon icon-close'
                });
              }
              return '{}';
            };
          })(this)
        });
        return;
        el.attr('disabled', true);
        return;
        return new ModelRegister().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                CSH.hint({
                  msg: '创建成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                _this.els.tabTitleUlLi.eq(0).trigger('click');
              } else {
                CSH.hint({
                  msg: '创建失败',
                  type: 'error',
                  icon: 'icon icon-close'
                });
              }
              return setTimeout(function() {
                return el.attr('disabled', false, 1000);
              });
            };
          })(this)
        });
      };

      View.prototype.add_link = function(val) {
        var data, el, loading;
        el = $(event.currentTarget);
        if (this.resultsAmount()) {
          return;
        }
        data = {};
        data.userType = +this.type;
        data.rebateRate = +this.els.adjustBtnRebate.val();
        data.memo = this.els.memo.val();
        data.listSalarySet = val;
        if (data.rebateRate > this.slides.myRebate) {
          return CSH.hint('返点值不能大于自身');
        }
        loading = CSH.hint({
          icon: 'loading',
          duration: Infinity
        });
        new ModelAddLinks().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              loading.data('hide')();
              if (data.code === 0) {
                CSH.hint({
                  msg: '创建成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                _this.els.tabTitleUlLi.eq(0).trigger('click');
              } else {
                CSH.hint({
                  msg: '创建失败',
                  type: 'error',
                  icon: 'icon icon-close'
                });
              }
              return '{}';
            };
          })(this)
        });
        return;
        el.attr('disabled', true);
        return;
        return new ModelRegister().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                CSH.hint({
                  msg: '创建成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                _this.els.tabTitleUlLi.eq(0).trigger('click');
              } else {
                CSH.hint({
                  msg: '创建失败',
                  type: 'error',
                  icon: 'icon icon-close'
                });
              }
              return setTimeout(function() {
                return el.attr('disabled', false, 1000);
              });
            };
          })(this)
        });
      };

      View.prototype.add_link = function(val) {
        var data, el;
        el = $(event.currentTarget);
        if (this.resultsAmount()) {
          return;
        }
        data = {};
        data.userType = +this.type;
        data.rebateRate = +this.els.adjustBtnRebate.val();
        data.memo = this.els.memo.val();
        data.listSalarySet = val;
        if (data.rebateRate > this.slides.myRebate) {
          return CSH.hint('返点值不能大于自身');
        }
        return new ModelAddLinks().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                CSH.hint({
                  msg: '创建成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                _this.els.tabTitleUlLi.eq(2).trigger('click');
              } else {
                CSH.hint({
                  msg: '创建失败',
                  type: 'error',
                  icon: 'icon icon-close'
                });
                setTimeout(function() {
                  return el.attr('disabled', false, 1000);
                });
              }
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.resultsAmount = function() {
        var AmountRegex;
        AmountRegex = /^[1-9]?\d*$/;
        if (!this.els.targetAmount.val()) {
          return false;
        }
        if (!AmountRegex.test(this.els.targetAmount.val())) {
          this.els.resultsAmount.show().addClass('icon-wrong').css('color', '#d54345').html($('<span style="margin-left:5px">大于0的整数数字</span>'));
          return true;
        } else {
          this.els.resultsAmount.hide();
          return false;
        }
      };

      View.prototype.eventCheckUserName = function(event) {
        var MinsixRegex, el, userFirstRegex, val;
        el = $(event.currentTarget);
        val = el.val().encodeHTML();
        userFirstRegex = /^[A-Za-z]/;
        MinsixRegex = /^\w{6,}/;
        if (!val) {
          this.els.resultsName.show().addClass('icon-wrong').removeClass('icon-right').css('color', '#D54345').html($('<span style="margin-left:5px;">请输入用户名</span>'));
          return;
        } else if (!userFirstRegex.test(val)) {
          this.els.resultsName.show().addClass('icon-wrong').removeClass('icon-right').css('color', '#D54345').html($('<span style="margin-left:5px;">字母开头：6~14位字母、数字组成</span>'));
          return;
        }
        if (!MinsixRegex.test(val)) {
          return;
        } else {
          this.els.resultsName.show().addClass('icon-right').removeClass('icon-wrong').css('color', '#5ABC69').text('');
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        return new ModelUsername().setUrl(val).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var temp;
              temp = data.toJSON();
              if (!+temp.code) {
                return _this.els.resultsName.show().addClass('icon-wrong').removeClass('icon-right').css('color', '#D54345').text(temp.message);
              } else {
                return _this.els.resultsName.text('');
              }
            };
          })(this)
        });
      };

      View.prototype.dayBox = function() {
        return setTimeout((function(_this) {
          return function() {
            var els, getDate;
            _this.stage = 2;
            els = {};
            els.dayMoneyTopRadio = _this.els.dayMoney.find('.dayMoneyTop .btns button');
            els.dayMoneyBottom = _this.els.dayMoney.find('.dayMoneyBottom');
            els.stageWrap = els.dayMoneyBottom.find('.stageWrap');
            els.stage = els.stageWrap.find('.stage');
            els.salary = els.stage.find('.salary');
            els.amount = els.stage.find('input[data-type="amount"]');
            els.people = els.stage.find('input[data-type="people"]');
            els.removeBtn = els.stage.find('.removeBtn');
            els.addStageBtn = els.dayMoneyBottom.find('.addStageWrap .addStageBtn');
            els.num = els.dayMoneyBottom.find('.addStageWrap .num');
            els.addStageBtn.on('click', function(event) {
              var el, str;
              if (_this.stage === 20) {
                return;
              }
              _this.stage++;
              els.num.text(_this.stage);
              el = $(event.currentTarget);
              str = $("<div class=\"stage clear\" style=\"display: none\">\n	<div class=\"stageLeft\">\n		<input class=\"adjustBtn arrow salary\" value=\"0.00\" />\n		<span class=\"wrapAdjust\">\n			<span class=\"adjust\">\n				<span class=\"wrapBg\">\n					<span class=\"bg\"></span>\n				</span>\n				<i class=\"roundBtn salary\"></i>\n			</span>\n		</span>\n	</div>\n	<div class=\"stageRight " + (+_this.type === 1 ? 'type' : '') + "\">\n		<label>\n		<input type=\"number\" data-type=\"amount\" placeholder=\"购彩量\" />\n			万\n		</label>\n		<label>\n		<input type=\"number\" data-type=\"people\" placeholder=\"活跃用户\" />\n			人\n		</label>\n	</div>\n	<button class=\"removeBtn\">删除</button>\n</div>");
              els.stageWrap.append(str);
              str.slideDown();
              return getDate();
            });
            els.dayMoneyBottom.on('click', '.removeBtn', function(event) {
              var el, parent;
              _this.stage--;
              getDate();
              els.num.text(_this.stage);
              el = $(event.currentTarget);
              parent = el.closest('.stage');
              return parent.slideUp(function() {
                return parent.remove();
              });
            });
            els.dayMoneyTopRadio.on('click', function(event) {
              var el;
              el = $(event.currentTarget);
              if (+el.attr('data-off')) {
                return els.dayMoneyBottom.show();
              } else {
                return els.dayMoneyBottom.hide();
              }
            });
            return getDate = function() {
              _this.els.adjustBtn = _this.$el.find('input.adjustBtn');
              _this.els.salary = _this.els.stageWrap.find('.adjustBtn.salary');
              _this.els.amount = _this.els.stageWrap.find('input[data-type="amount"]');
              return _this.els.people = _this.els.stageWrap.find('input[data-type="people"]');
            };
          };
        })(this), 0);
      };

      View.prototype.eventOpenAgreement = function(event) {
        var el, title, type;
        el = $(event.currentTarget);
        type = el.attr('data-type');
        title = null;
        switch (type) {
          case 'salary':
            title = '日工资协议';
            break;
          case 'rebate':
            title = '返点说明';
        }
        return CSH.alert({
          title: title,
          content: this.tpls.alert({
            name: type
          }),
          className: "agreement"
        });
      };

      View.prototype.getDate = function() {
        this.els.tabTitleUlLi = this.$el.find('.tabTitle ul li');
        this.els.subject = this.els.tabContent.find('.subject');
        this.els.adjustBtn = this.els.subject.find('.adjustBtn');
        this.els.adjustBtnRebate = this.els.subject.find('input.rebate');
        this.els.adjustBtnSalary = this.els.subject.find('input.salary');
        this.els.targetAmount = this.els.subject.find('.targetAmount');
        this.els.stageWrap = this.els.subject.find('.stageWrap');
        this.els.salary = this.els.stageWrap.find('.adjustBtn.salary');
        this.els.amount = this.els.stageWrap.find('input[data-type="amount"]');
        this.els.people = this.els.stageWrap.find('input[data-type="people"]');
        this.els.wrapAdjust = this.els.tabContent.find('.wrapAdjust');
        this.els.roundBtn = this.els.wrapAdjust.find('.roundBtn');
        this.els.username = this.els.subject.find('.name');
        this.els.memo = this.els.subject.find('.memo');
        this.els.resultsName = this.els.subject.find('.resultsUser');
        this.els.resultsAmount = this.els.subject.find('.resultsAmount');
        this.els.dayMoney = this.els.subject.find('.dayMoney');
        return this.type = 1;
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
