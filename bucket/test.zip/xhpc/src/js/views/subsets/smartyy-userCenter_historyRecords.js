(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/history', 'collections/history', 'text!../../../templates/subsets/_smartyy-userCenter_tab.tpl', 'text!../../../templates/subsets/smartyy-userCenter_historyRecords_table.tpl', 'text!../../../templates/_smartyy-paginate.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-noResult.tpl'], function($, _, Backbone, doT, ModelHistoryRecords, CollectionHistoryRecords, TplContent, TplTable, TplPaginate, TplLoading, TplNoResult) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          text: '近期开奖记录'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        table: doT.template(TplTable),
        paginate: doT.template(TplPaginate),
        noResult: doT.template(TplNoResult)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'keyup .paginate input': 'eventKeyupPaginate',
        'change .lottery ': 'eventsLottery'
      };

      View.prototype.initialize = function(data) {
        this.data = {};
        this.data.gID = +CSH.routePath[1] || 100;
        this.$el.html(this.tpls.content(tabOption));
        this.m = new ModelHistoryRecords();
        this.c = new CollectionHistoryRecords();
        this.els = {};
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.render = function(pageInfo) {
        this.els.tabContent.html(this.tpls.table({
          data: this.c.toJSON(),
          gID: this.data.gID,
          total: pageInfo.totalAmount,
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: '* 将为您保留最近 1 个月数据'
          }),
          noResult: this.tpls.noResult()
        }));
        return this.$el.find('select').select2();
      };

      View.prototype.eventsTabSwithc = function(event) {
        var el;
        el = $(event.currentTarget);
        this.view = name;
        this.els = {};
        this.els.tabContent = this.$el.find(' .tabContent');
        return this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m.setUrl(this.data.gID, 12, curPage).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return '{}';
              }
              _this.c.reset(data.data);
              _this.m.clear();
              _this.render(data.pageInfo);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.eventsLottery = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            _this.data.gID = +el.val();
            return _this.fetchData();
          };
        })(this));
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
