(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/bankaccounts', 'models/info', 'models/getMemberInfoByNameNew', 'models/setCredentialsInfo', 'models/banks', 'models/truename', 'models/getLoginRecordByPage', 'models/changepwd', 'models/withdrawalpasswordnew', 'models/changewithpwd', 'models/setquestions', 'models/bankaccountstate', 'models/bindwxmember', 'models/unbindwxmember', 'models/checkbindweixin', 'text!../../../templates/subsets/smartyy-userCenter_security_accountInfo.tpl', 'text!../../../templates/subsets/smartyy-userCenter_security_alert.tpl', 'text!../../../templates/subsets/smartyy-userCenter_security_myBankcard.tpl', 'text!../../../templates/subsets/smartyy-userCenter_security_logRecord.tpl', 'text!../../../templates/subsets/smartyy-userCenter_security_setting.tpl', 'text!../../../templates/subsets/_smartyy-userCenter_tab.tpl', 'text!../../../templates/_smartyy-paginate.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../js/province-city.json'], function($, _, Backbone, doT, ModelBankAccounts, ModelInfo, ModelgetMemberInfoByName, ModelSetCredentialsInfo, ModelsBanks, ModelTruename, ModelGetLoginRecordByPage, ModelChangepwd, ModelWithdrawalPasswordNew, ModelChangeWithpwd, Modelsetquestions, Modelbankaccountstate, ModelBindwxmember, ModelUnBindwxmember, ModelCheckbindweixin, TplAccountInfo, TplAlert, TplMyBankcard, TplLogRecord, TplSetUp, TplTable, TplPaginate, TplLoding, jsonProvinceCity) {
    "use struct";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'accountInfo',
          text: '账户资料'
        }, {
          dataName: 'myBankcard',
          text: '我的银行卡'
        }, {
          dataName: 'logRecord',
          text: '登录记录'
        }
      ];

      View.prototype.tpls = {
        setUp: doT.template(TplSetUp),
        content: doT.template(TplTable),
        alert: doT.template(TplAlert),
        accountInfo: doT.template(TplAccountInfo),
        myBankcard: doT.template(TplMyBankcard),
        paginate: doT.template(TplPaginate),
        logRecord: doT.template(TplLogRecord)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'click button.truenameBtn': 'isCredentials',
        'click button.addID': 'isCredentials',
        'click button.addBankCard': 'eventAddCard',
        'click button.addCrad': 'eventAddCard',
        'click button.addProblem': 'eventAddQuestion',
        'click button[data-type="add"]': 'isWithPwdAdd',
        'click button[data-type="rm"]': 'isWithPwdRm',
        'click .bankWrap li.bankCard': 'eventsBankCardDefault',
        'click .setLoginPassword button.mvLogPass': 'eventMvLogPass',
        'click button.addWeixin': 'eventAddWeixin',
        'click button.rmWeixin': 'eventRmWeixin'
      };

      View.prototype.initialize = function(data) {
        var getBank, initialData;
        this.magnitude = {
          weak: {
            color: '#f15a59',
            text: '低'
          },
          "in": {
            color: '#FDA027',
            text: '中'
          },
          strong: {
            color: '#57BA60',
            text: '高'
          }
        };
        initialData = {};
        initialData.magnitude = this.magnitude;
        this.xhr = false;
        this.isNormalUser = +localStorage.getItem('isNormalUser');
        this.viewName = null;
        new ModelTruename().setUrl().fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              return setTimeout((function() {
                return getBank(data.data);
              }), 0);
            };
          })(this)
        });
        return getBank = (function(_this) {
          return function(name) {
            return new ModelBankAccounts().setUrl().fetch({
              beforeSend: function(xhr) {
                return _this.xhr = xhr;
              },
              dataFilter: function(data) {
                data = data.toJSON();
                if (data.code !== 0) {
                  return '{}';
                }
                initialData.bank = data.data;
                initialData.name = name;
                return setTimeout(function() {
                  _this.$el.html(_this.tpls.setUp(initialData));
                  _this.getInfo();
                  return _this.$el.find('.option').html(_this.tpls.content(tabOption)).find('.tabTitle ul li').eq(0).trigger('click');
                }, 0);
              }
            });
          };
        })(this);
      };

      View.prototype.destroy = function() {
        if (this.xhr) {
          return this.xhr.abort();
        }
      };

      View.prototype.getInfo = function() {
        var info, type;
        info = {};
        info.settingEntrance = this.$el.find('.settingEntrance');
        info.status = info.settingEntrance.find('.settingWrap .status');
        info.safeLine = info.status.find('.safeLine');
        info.prompt = info.status.find('.prompt span');
        this.userType = +localStorage.getItem('userType');
        if (this.userType === 1) {
          type = '会员';
        } else {
          type = '代理';
        }
        return (function(_this) {
          return function() {
            var color, number, prompt;
            number = localStorage.getItem('safetyValue');
            color = _this.magnitude.weak.color;
            prompt = "% " + _this.magnitude.weak.text + " ";
            if (number >= 50 && number <= 70) {
              prompt = "% " + _this.magnitude["in"].text + " ";
              color = _this.magnitude["in"].color;
            } else if (number > 70) {
              prompt = "% " + _this.magnitude.strong.text + " ";
              color = _this.magnitude.strong.color;
            }
            info.prompt.text(number + prompt).css('color', color);
            return info.safeLine.width(number + '%').css('backgroundColor', color);
          };
        })(this)();
      };

      View.prototype.fetchData = function(curPage) {
        var name;
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.viewName === 'accountInfo') {
          name = localStorage.getItem('username');
          new ModelgetMemberInfoByName().setUrl(name).fetch({
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                return _this.els.tabContent.html(_this.tpls[_this.viewName](data.data));
              };
            })(this)
          });
        }
        if (this.viewName === 'myBankcard') {
          new ModelBankAccounts().setUrl().fetch({
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                return _this.els.tabContent.html(_this.tpls[_this.viewName](data.data));
              };
            })(this)
          });
        }
        if (this.viewName === 'logRecord') {
          return new ModelGetLoginRecordByPage().setUrl(curPage).fetch({
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                if (data.code) {
                  return '{}';
                }
                return _this.els.tabContent.html(_this.tpls[_this.viewName]({
                  data: data.data,
                  paginate: _this.tpls.paginate({
                    info: data.pageInfo,
                    notice: '* 将为您保留最近 1 个月数据'
                  })
                }));
              };
            })(this)
          });
        }
      };

      View.prototype.eventsTabSwithc = function(event) {
        var el;
        el = $(event.currentTarget);
        this.viewName = el.attr('data-name');
        el.addClass('active').siblings('li').removeClass('active');
        this.els = {};
        this.els.tabContent = this.$el.find(' .tabContent');
        return this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoding);
      };

      View.prototype.isCredentials = function(event) {
        var el, modalBox;
        if (this.isNormalUser === 2 && this.userType === 1) {
          return this.weakPrompt();
        }
        el = $(event.currentTarget);
        el.attr('disabled', true);
        modalBox = CSH.alert({
          title: '身份认证',
          content: this.tpls.alert({
            name: 'isCredentials'
          }),
          className: 'isCredentials',
          ok: {
            text: '下一步',
            autohide: false,
            callback: (function(_this) {
              return function(event) {
                var data, email, emailEl, fade, idEl, name, nameEl, reg, valName;
                el = $(event.currentTarget);
                nameEl = modalBox.find('input[data-type="name"]');
                idEl = modalBox.find('input[data-type="id"]');
                emailEl = modalBox.find('input[data-type="email"]');
                valName = nameEl.val().trim();
                email = emailEl.val().trim();
                fade = $('.fade');
                data = {};
                reg = /^[1-9]{1}[0-9]{14}$|^[1-9]{1}[0-9]{16}([0-9]|[xX])$/;
                name = /^[\u4E00-\u9FA5]{2,5}(\.[\u4E00-\u9FA5]{2,5})*$/;
                if (!name.test(valName)) {
                  _this.adderrorClass(nameEl);
                  CSH.hint({
                    msg: '请输入正确的姓名',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                  return;
                }
                if (false && !reg.test(idName)) {
                  _this.adderrorClass(idEl);
                  CSH.hint({
                    msg: '请输入正确的身份证',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                  return;
                }
                if (!/^\w+@[a-zA-Z0-9\-]+(\.[a-zA-Z]+){1,2}$/.test(email)) {
                  _this.adderrorClass(emailEl);
                  CSH.hint({
                    msg: '请输入格式正确的邮箱地址',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                  return;
                }
                data.trueName = valName.encodeHTML();
                data.email = email;
                return new ModelSetCredentialsInfo().setUrl().save(data, {
                  dataFilter: function(data) {
                    data = data.toJSON();
                    if (+data.code === 0) {
                      return CSH.hint({
                        msg: data.message,
                        type: 'success',
                        icon: 'icon icon-ok',
                        callback: function() {
                          _this.successSet(modalBox);
                          return modalBox.modal('hide');
                        }
                      });
                    } else {
                      return CSH.hint({
                        msg: data.message,
                        type: 'error',
                        icon: 'icon icon-close'
                      }, el.attr('disabled', false));
                    }
                  }
                });
              };
            })(this)
          }
        });
        this.goUserCenter(modalBox, el);
        return this.removeClass(modalBox);
      };

      View.prototype.eventAddCard = function(event) {
        var Getbank, el;
        if (this.isNormalUser === 2) {
          return this.weakPrompt();
        }
        el = $(event.currentTarget);
        el.attr('disabled', true);
        new ModelTruename().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var modalBox;
              data = data.toJSON();
              if (data.code) {
                return '{}';
              }
              if (!data.data) {
                modalBox = CSH.alert({
                  content: '请绑定身份信息！',
                  ok: {
                    callback: function(event) {
                      return modalBox.find('.close').trigger('click');
                    }
                  }
                });
                _this.goUserCenter(modalBox, el);
                return;
              }
              Getbank(data.data, el);
              return '{}';
            };
          })(this)
        });
        return Getbank = (function(_this) {
          return function(truename, el) {
            return new ModelsBanks().setUrl().fetch({
              dataFilter: function(data) {
                var key, modalBox, province, provinceCity, pwd, val;
                data = data.toJSON();
                if (data.code) {
                  return '{}';
                }
                modalBox = CSH.alert({
                  title: '添加银行卡',
                  content: _this.tpls.alert({
                    name: 'addCard',
                    bank: data.data,
                    truename: truename
                  }),
                  className: 'isCredentials',
                  ok: {
                    text: '添加银行卡',
                    autohide: false,
                    callback: function(event) {
                      var saveData;
                      el = $(event.currentTarget);
                      el.attr('disabled', true);
                      saveData = {};
                      saveData.bankAccount = truename;
                      saveData.bankNumber = modalBox.find('input[data-type="bankNumber"]').val().replace(/\s/g, "");
                      saveData.bankID = modalBox.find('select option:selected').attr('data-id');
                      saveData.isDefault = +(!modalBox.find('input[type="checkbox"]').prop('checked'));
                      saveData.province = pwd.province.val().encodeHTML();
                      saveData.city = pwd.city.val().encodeHTML();
                      saveData.bankAddress = pwd.bankAddress.val().encodeHTML();
                      if (!saveData.bankID) {
                        _this.errorHint('请选择银行', el);
                        return;
                      }
                      if (!(saveData.bankNumber && saveData.bankNumber.checkLuhn())) {
                        _this.errorHint('请输入正确的银行卡号', el);
                        return;
                      }
                      if (saveData.province === '省份') {
                        _this.errorHint('请选择省份', el);
                        return;
                      }
                      if (saveData.city === '城市') {
                        _this.errorHint('请选择省份', el);
                        return;
                      }
                      if (!saveData.bankAddress) {
                        _this.errorHint('请输入开户网点', el);
                        return;
                      }
                      return new ModelBankAccounts().setUrl().save(saveData, {
                        dataFilter: function(data) {
                          var code;
                          data = data.toJSON();
                          code = data.code;
                          if (code === 3) {
                            return _this.errorHint(data.message, el);
                          } else if (code === 0) {
                            return CSH.hint({
                              msg: data.message,
                              type: 'success',
                              icon: 'icon icon-ok',
                              callback: function() {
                                return _this.successSet(modalBox);
                              }
                            });
                          }
                        }
                      });
                    }
                  }
                });
                modalBox.find('input[type="checkbox"]').trigger('click');
                provinceCity = jsonProvinceCity.toJSON();
                pwd = {};
                pwd.bankId = modalBox.find('select.bankId');
                pwd.bankNumber = modalBox.find('input[data-type="bankNumber"]');
                pwd.province = modalBox.find('select.province');
                pwd.city = modalBox.find('select.city');
                pwd.bankAddress = modalBox.find('input[data-type="bankAddress"]');
                province = '';
                for (key in provinceCity) {
                  val = provinceCity[key];
                  province += "<option> " + key + " </option> ";
                }
                pwd.province.append(province).on('change', function(event) {
                  var city, results;
                  el = $(event.currentTarget);
                  city = '';
                  results = [];
                  for (key in provinceCity) {
                    val = provinceCity[key];
                    if (key === el.val()) {
                      if (val.length !== 0) {
                        val.map(function(val, i) {
                          return city += "<option> " + val + " </option> ";
                        });
                      } else {
                        city = "<option> " + key + " </option> ";
                      }
                      results.push(pwd.city.html(city).select2());
                    } else {
                      results.push(void 0);
                    }
                  }
                  return results;
                });
                pwd.bankNumber.on('keyup', function(event) {
                  el = $(event.currentTarget);
                  val = el.val();
                  val = val.replace(/\s/g, '');
                  val = val.replace(/\D$/, '');
                  return el.val(val.replace(/\d{4}/g, '$& ').trim());
                });
                modalBox.find('select').select2().on('click', function() {
                  return $('.select2-container--open').css('zIndex', 1600);
                });
                _this.goUserCenter(modalBox, el);
                return _this.removeClass(modalBox);
              }
            });
          };
        })(this);
      };

      View.prototype.eventMvLogPass = function(event) {
        if (this.isNormalUser === 2 && this.userType === 1) {
          return this.weakPrompt();
        }
        CSH.views.body.modifyInitPwd($(event.currentTarget));
      };

      View.prototype.isWithPwdAdd = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.isNormalUser === 2 && this.userType === 1) {
          return this.weakPrompt();
        }
        return CSH.views.body.isWithPwd(el);
      };

      View.prototype.isWithPwdRm = function(event) {
        var el, inputs, intensity, intensityShow, modalBox;
        if (this.isNormalUser === 2 && this.userType === 1) {
          return this.weakPrompt();
        }
        modalBox = CSH.alert({
          title: '修改资金密码',
          content: this.tpls.alert({
            name: 'isWithPwdRm'
          }),
          className: 'isCredentials',
          ok: {
            autohide: false,
            callback: (function(_this) {
              return function(event) {
                var confirm, confirmVal, data, el, pwd, pwdVal, temp, tempVal;
                el = $(event.currentTarget);
                temp = inputs.filter('[data-type="origin"]');
                pwd = inputs.filter('[data-type="pwd"]');
                confirm = inputs.filter('[data-type="confirm"]');
                tempVal = temp.val();
                pwdVal = pwd.val();
                confirmVal = confirm.val();
                data = {};
                el.attr('disabled', true);
                if (tempVal.length < 6) {
                  _this.adderrorClass(temp);
                  return _this.errorHint('请输入完整的登录密码', el);
                }
                if (pwdVal.length < 6) {
                  _this.adderrorClass(pwd);
                  return _this.errorHint('请设置完整的交易密码', el);
                }
                if (confirmVal.length < 6) {
                  _this.adderrorClass(confirm);
                  return _this.errorHint('再次输入完整的密码', el);
                }
                if (tempVal === pwdVal) {
                  _this.adderrorClass(pwd);
                  return _this.errorHint('新密码不能和原密码相同', el);
                } else if (pwdVal !== confirmVal) {
                  _this.adderrorClass(pwd);
                  return _this.errorHint('两次输入密码不一致', el);
                }
                data.oldPwd = tempVal.md5();
                data.newPwd = pwdVal.md5();
                data.safeLevel = intensity;
                return new ModelChangeWithpwd().setUrl().save(data, {
                  dataFilter: function(data) {
                    data = data.toJSON();
                    if (data.code === 0) {
                      return CSH.hint({
                        msg: '密码设置成功',
                        type: 'success',
                        icon: 'icon icon-ok',
                        callback: function() {
                          return _this.successSet(modalBox);
                        }
                      });
                    } else {
                      return CSH.hint({
                        msg: data.message,
                        type: 'error',
                        icon: 'icon icon-close',
                        callback: function() {
                          return el.prop('disabled', false);
                        }
                      });
                    }
                  }
                });
              };
            })(this)
          }
        });
        el = $(event.currentTarget);
        intensity = 1;
        inputs = modalBox.find('input');
        intensityShow = modalBox.find('.content .intensity');
        inputs.filter('[data-type="pwd"]').on('keyup', (function(_this) {
          return function(event) {
            return intensity = _this.eventIntensity(event, intensityShow);
          };
        })(this));
        this.goUserCenter(modalBox, el);
        return this.removeClass(modalBox);
      };

      View.prototype.eventAddWeixin = function(event) {
        var QRCodeAlert, el, modalBox;
        el = $(event.currentTarget);
        modalBox = CSH.alert({
          title: '登录密码',
          content: this.tpls.alert({
            name: 'addWeixin'
          }),
          className: 'isCredentials',
          ok: {
            autohide: false,
            text: '下一步',
            callback: (function(_this) {
              return function(event) {
                var input, password;
                el = $(event.currentTarget);
                input = modalBox.find('.loginPas input');
                password = input.val();
                el.attr('disabled', true);
                if (!password) {
                  return CSH.hint({
                    msg: '登录密码不能为空',
                    callback: function() {
                      return el.attr('disabled', false);
                    }
                  });
                } else {
                  return new ModelBindwxmember().setUrl(password).fetch({
                    dataFilter: function(data) {
                      data = data.toJSON();
                      if (data.code) {
                        return CSH.hint({
                          msg: data.message,
                          callback: function() {
                            el.attr('disabled', false);
                            return input.val('').focus();
                          }
                        });
                      } else {
                        return CSH.hint({
                          msg: '输入密码成功',
                          callback: function() {
                            input.val('').focus();
                            el.attr('disabled', false);
                            modalBox.modal('hide');
                            QRCodeAlert(data);
                            return _this.$el.find('button.addWeixin').attr('disabled', false);
                          }
                        });
                      }
                    }
                  });
                }
              };
            })(this)
          }
        });
        return QRCodeAlert = (function(_this) {
          return function(data) {
            var testing;
            modalBox = CSH.alert({
              title: '绑定微信',
              content: _this.tpls.alert({
                name: 'weixinQRCode'
              }),
              className: 'weixinQRCodeAlert'
            });
            modalBox.find('.qrcode').attr('src', data.data);
            return testing = setInterval(function() {
              return new ModelCheckbindweixin().setUrl().fetch({
                dataFilter: function(data) {
                  data = data.toJSON();
                  if (data.code === 0) {
                    clearInterval(testing);
                    return CSH.hint({
                      msg: data.message,
                      callback: function() {
                        _this.successSet(modalBox);
                        return modalBox.modal('hide');
                      }
                    });
                  }
                }
              });
            }, 5000);
          };
        })(this);
      };

      View.prototype.eventRmWeixin = function(event) {
        var el;
        el = $(event.currentTarget);
        return new ModelUnBindwxmember().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              return CSH.hint({
                msg: data.message,
                callback: function() {
                  return history.go(0);
                }
              });
            };
          })(this)
        });
      };

      View.prototype.eventAddQuestion = function(event) {
        var el, modalBox;
        if (this.isNormalUser === 2 && this.userType === 1) {
          return this.weakPrompt();
        }
        el = $(event.currentTarget);
        el.attr('disabled', true);
        modalBox = CSH.alert({
          title: '安全问题',
          content: this.tpls.alert({
            name: 'addQuestion'
          }),
          className: 'isCredentials',
          ok: {
            autohide: false,
            callback: (function(_this) {
              return function(event) {
                var data, input1, input2, input3, inputs, select1, select2, select3, selects, val1, val2, val3;
                el = $(event.currentTarget);
                el.attr('disabled', true);
                inputs = modalBox.find('input');
                selects = modalBox.find('select');
                input1 = inputs.filter('[data-val="1"]');
                input2 = inputs.filter('[data-val="2"]');
                input3 = inputs.filter('[data-val="3"]');
                val1 = input1.val();
                val2 = input2.val();
                val3 = input3.val();
                select1 = selects.filter('[data-key="1"]').find('option:selected').attr('data-number');
                select2 = selects.filter('[data-key="2"]').find('option:selected').attr('data-number');
                select3 = selects.filter('[data-key="3"]').find('option:selected').attr('data-number');
                if (!select1) {
                  return _this.errorHint('请选择问题一', el);
                }
                if (!select2) {
                  return _this.errorHint('请选择问题二', el);
                }
                if (!select3) {
                  return _this.errorHint('请选择问题三', el);
                }
                if (!val1) {
                  _this.adderrorClass(input1);
                  return _this.errorHint('请输入答案一', el);
                }
                if (!val2) {
                  _this.adderrorClass(input2);
                  return _this.errorHint('请输入答案二', el);
                }
                if (!val3) {
                  return _this.errorHint('请输入答案三', el);
                }
                data = {};
                data.Questions = [
                  {
                    key: select1,
                    value: val1.trim().encodeHTML()
                  }, {
                    key: select2,
                    value: val2.trim().encodeHTML()
                  }, {
                    key: select3,
                    value: val3.trim().encodeHTML()
                  }
                ];
                return new Modelsetquestions().setUrl().save(data, {
                  dataFilter: function(data) {
                    data = data.toJSON();
                    if (data.code === 0) {
                      return CSH.hint({
                        msg: '设置成功',
                        type: 'success',
                        icon: 'icon icon-ok',
                        callback: function() {
                          return _this.successSet(modalBox);
                        }
                      });
                    } else {
                      return CSH.hint({
                        msg: data.message,
                        type: 'error',
                        icon: 'icon icon-close',
                        callback: function() {
                          return el.attr('disabled', false);
                        }
                      });
                    }
                  }
                });
              };
            })(this)
          }
        });
        modalBox.find('select').select2().on('click', function() {
          return $('.select2-container--open').css('zIndex', 1600);
        });
        return this.goUserCenter(modalBox, el);
      };

      View.prototype.removeClass = function(modalBox) {
        return modalBox.find('input').blur(function(el) {
          el = $(event.currentTarget);
          if (!!el.val()) {
            return el.removeClass('borderError');
          }
        });
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.errorHint = function(msg, el) {
        CSH.hint({
          msg: msg,
          type: 'error',
          icon: 'icon icon-close'
        });
        if (el) {
          return el.attr('disabled', false);
        }
      };

      View.prototype.eventsBankCardDefault = function(event) {
        var data, el;
        el = $(event.currentTarget);
        if (el.closest('.checked')[0]) {
          CSH.hint('已经是默认银行卡了！');
          return;
        }
        data = {};
        data.bankID = el.attr('data-cardID');
        data.isDefault = 0;
        return new Modelbankaccountstate().setUrl().save(data, {
          dataFilter: function(data) {
            data = data.toJSON();
            if (+data.code === 0) {
              CSH.hint({
                msg: data.message,
                type: 'success',
                icon: 'icon icon-ok'
              });
              return el.addClass('checked').siblings('.bankCard').removeClass('checked');
            } else {
              return CSH.hint({
                msg: data.message,
                type: 'error',
                icon: 'icon icon-close'
              });
            }
          }
        });
      };

      View.prototype.adderrorClass = function(el) {
        return el.addClass('borderError').focus();
      };

      View.prototype.weakPrompt = function() {
        return CSH.hint('亲，试玩账户不享有该权限哦！');
      };

      View.prototype.eventIntensity = function(event, intensityShow) {
        var el, enoughRegex, intensity, mediumRegex, strongRegex;
        el = $(event.currentTarget);
        strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
        mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
        enoughRegex = new RegExp("(?=.{6,}).*", "g");
        intensityShow.css('opacity', 1);
        if (false === enoughRegex.test(el.val())) {
          intensity = 1;
          intensityShow.text('弱').css({
            'background': '#d74241',
            'color': 'rgba( 255, 255, 255, 1)'
          });
        } else if (strongRegex.test(el.val())) {
          intensity = 3;
          intensityShow.text('强').css({
            'background': '#8fc31f',
            'color': 'rgba( 255, 255, 255, 1)'
          });
        } else if (mediumRegex.test(el.val())) {
          intensity = 2;
          intensityShow.text('中').css({
            'background': '#f19a38',
            'color': 'rgba( 255, 255, 255, 1)'
          });
        } else {
          intensity = 1;
          intensityShow.text('弱').css({
            'background': '#d74241',
            'color': 'rgba( 255, 255, 255, 1)'
          });
        }
        return intensity;
      };

      View.prototype.goUserCenter = function(modalBox, el) {
        modalBox.on('keyup', function(event) {
          if (+event.keyCode === 27) {
            modalBox.modal('hide');
            return el.attr('disabled', false);
          }
        });
        return modalBox.find('.close').on('click', function() {
          modalBox.modal('hide');
          return el.attr('disabled', false);
        });
      };

      View.prototype.successSet = function(modalBox) {
        modalBox.modal('hide');
        return setTimeout((function() {
          return CSH.router.refresh();
        }), 1000);
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
