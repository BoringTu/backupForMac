(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/getdetaillist', 'collections/getdetaillist', 'text!../../../templates/subsets/_userCenter_tab.tpl', 'text!../../../templates/subsets/userCenter_personalReport.tpl', 'text!../../../templates/_paginate.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelGetdetaillist, CollectionGetdetaillist, TplContent, TplPersonalReport, TplPaginate, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'team',
          text: '个人报表'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        team: doT.template(TplPersonalReport),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'click .toolbar .day': 'eventsGetDay',
        'click .toolbar .search': 'eventDateSearch',
        'click .dataContent .sort i.icon': 'eventsSort',
        'keyup .paginate input': 'eventKeyupPaginate'
      };

      View.prototype.initialize = function(data) {
        var toDay;
        this.$el.html(this.tpls.content(tabOption));
        this.m = new ModelGetdetaillist();
        this.c = new CollectionGetdetaillist();
        this.viewName = null;
        this.day = 0;
        this.viewData = {
          crumb: void 0,
          curUser: void 0,
          total: void 0,
          msg: '暂无记录'
        };
        toDay = new Date().getFormatDate();
        this.toolbar = {
          userName: void 0,
          beginTime: void 0,
          endTime: void 0
        };
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.render = function(pageInfo) {
        var endDate, sort, startDate;
        sort = this.toolbar.sort;
        if (sort !== 0 && sort !== 1) {
          sort = void 0;
        } else {
          if (+sort === 1) {
            sort = 'asc';
          } else {
            sort = 'desc';
          }
        }
        this.els.tabContent.html(this.tpls[this.viewName]({
          data: this.c.toJSON(),
          sort: sort,
          viewData: this.viewData,
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: '* 将为您保留最近 2 个月数据'
          })
        }));
        this.els.search = this.$el.find('.toolbar .search');
        this.els.pageInput = this.$el.find('.pageinate input');
        this.$el.find('select').select2();
        this.getDate();
        if (this.toolbar.beginTime) {
          startDate = this.toolbar.beginTime.split(':');
          endDate = this.toolbar.endTime.split(':');
          this.els.dateStart.val(startDate[2] ? startDate[0] + ":" + startDate[1] : this.toolbar.beginTime);
          this.els.dateEnd.val(endDate[2] ? endDate[0] + ":" + endDate[1] : this.toolbar.endTime);
        }
        if (!this.day) {
          return;
        }
        return this.els.day.eq(this.day).addClass('active');
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m.setUrl(curPage, 12).save(this.toolbar, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                _this.c.reset(data.data);
                _this.render(data.pageInfo);
              }
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el, name, toDay, type;
        el = $(event.currentTarget);
        arr = el.attr('data-name');
        arr = arr.split('/');
        name = arr[0];
        type = arr[1];
        toDay = new Date().getFormatDate();
        this.viewName = name;
        this.els = {};
        this.els.tabContent = this.$el.find('.tabContent');
        this.toolbar = {
          userName: localStorage.getItem('username'),
          beginTime: toDay + " 00:00:00",
          endTime: toDay + " 23:59:59"
        };
        return this.fetchData();
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.getDate = function() {
        var aWeek, minDate, myDate, toDay, yesterDay;
        this.els.toolbar = this.$el.find('.toolbar');
        this.els.dateStart = this.els.toolbar.find('#dateStart');
        this.els.dateEnd = this.els.toolbar.find('#dateEnd');
        this.els.day = this.els.toolbar.find('.day');
        this.els.toDay = this.els.toolbar.find('.toDay');
        this.els.yesterDay = this.els.toolbar.find('.yesterDay');
        this.els.aWeek = this.els.toolbar.find('.aWeek');
        this.els.all = this.els.toolbar.find('.all');
        toDay = new Date().getFormatDate();
        myDate = new Date();
        yesterDay = new Date().beforeDays(1).getFormatDate();
        aWeek = new Date().beforeDays(7).getFormatDate();
        minDate = new Date(myDate.setMonth(myDate.getMonth() - 2)).getFormatDate();
        this.els.toDay.attr('data-startDate', toDay).attr('data-endDate', toDay);
        this.els.yesterDay.attr('data-startDate', yesterDay).attr('data-endDate', yesterDay);
        this.els.aWeek.attr('data-startDate', aWeek).attr('data-endDate', toDay);
        this.els.all.attr('data-startDate', minDate).attr('data-endDate', toDay);
        this.els.dateStart.datetimepicker({
          useCurrent: false,
          defaultDate: toDay
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59");
        this.els.dateEnd.datetimepicker({
          useCurrent: false,
          defaultDate: toDay + " 23:59"
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59");
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el, time;
            el = $(event.currentTarget);
            time = el.val().split(' ')[0];
            _this.toolbar.beginTime = time + " 00:00";
            if (!_this.els.dateEnd.val()) {
              _this.els.dateEnd.val(time + " 23:59");
              _this.toolbar.endTime = time + " 23:59";
            }
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        return this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el, time;
            el = $(event.currentTarget);
            time = el.val().split(' ')[0];
            _this.toolbar.endTime = time + " 23:59";
            if (!_this.els.dateStart.val()) {
              _this.els.dateStart.val(time + " 00:00");
              _this.toolbar.beginTime = time + " 00:00";
            }
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventsGetDay = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.beginTime = (el.attr('data-startDate')) + " 00:00:00";
        this.toolbar.endTime = (el.attr('data-endDate')) + " 23:59:59";
        this.fetchData();
        return this.day = el.attr('data-number');
      };

      View.prototype.eventDateSearch = function(el) {
        var endVal, startVal;
        el = $(el.currentTarget);
        startVal = this.els.dateStart.val();
        endVal = this.els.dateEnd.val();
        if (startVal && endVal) {
          this.day = 1000000;
          this.toolbar.beginTime = startVal.split(':')[2] ? startVal : startVal + ":00";
          this.toolbar.endTime = endVal.split(':')[2] ? endVal : endVal + ":59";
        } else if (!endVal && !startVal) {
          CSH.hint("请输入开始或结束时间");
          return;
        }
        this.fetchData();
        return el.prop('disabled', true);
      };

      View.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.toolbar.sort === +el.attr('data-sort')) {
          return;
        }
        this.toolbar.sort = +el.attr('data-sort');
        return this.fetchData();
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
