(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/balance'], function($, _, Backbone, doT, ModelBalance) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.events = {
        'click .refreshBalance': 'eventRefreshBalance',
        'click .balanceVisibility': 'eventToggleBalanceVisibility'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        this.data = {};
        this.time = false;
        this.render();
        if (!JSON.parse(localStorage.getItem('visibility-capital'))) {
          return this.els.btnBV.addClass('icon-visible').removeClass('icon-invisible');
        }
      };

      View.prototype.render = function() {
        this.els = {};
        this.els.balanceBox = this.$el.find('.balanceBox');
        this.els.balance = this.$el.find('.balance');
        this.els.btnRefresh = this.$el.find('.refreshBalance');
        this.els.btnBV = this.$el.find('.balanceVisibility');
        this.els.realTimeBalance = $('.realTimeBalance');
        this.els.capitalVisibility = $('.capitalVisibility');
        CSH.$els.balance.lottery = this.els.balance;
        return this.els.btnRefresh.click();
      };

      View.prototype.destroy = function() {};

      View.prototype.eventRefreshBalance = function(event) {
        return CSH.views.body.refreshBalance(event);
      };

      View.prototype.refreshBalance = function() {
        this.els.balance.text(!this.data.invisible ? CSH.utils.formatMoney(CSH.balance) : '***');
      };

      View.prototype.eventToggleBalanceVisibility = function(event) {
        var el, isInvisible;
        if (this.time) {
          return;
        }
        this.time = true;
        setTimeout((function(_this) {
          return function() {
            return _this.time = false;
          };
        })(this), 500);
        el = $(event.currentTarget);
        el.toggleClass('icon-visible icon-invisible');
        isInvisible = !+JSON.parse(localStorage.getItem('visibility-capital'));
        localStorage.setItem('visibility-capital', isInvisible);
        this.data.invisible = isInvisible;
        this.refreshBalance();
        return this.els.capitalVisibility.trigger('click');
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
