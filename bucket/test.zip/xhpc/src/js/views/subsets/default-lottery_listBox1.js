(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/history', 'models/announceByPage', 'models/activitys', 'text!../../../templates/subsets/default-lottery_listBox1.tpl', 'text!../../../templates/subsets/default-lottery_listBox1_lotteryRecords.tpl', 'text!../../../templates/subsets/default-lottery_listBox1_notices.tpl', 'text!../../../templates/subsets/default-lottery_listBox1_activitys.tpl', 'text!../../../templates/_default-contentLoading.tpl'], function($, _, Backbone, doT, ModelHistory, ModelAnnounceByPage, ModelActivitys, TplContent, TplHistory, TplAnnounce, TplActivitys, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        history: doT.template(TplHistory),
        announce: doT.template(TplAnnounce),
        activity: doT.template(TplActivitys)
      };

      View.prototype.events = {
        'click .tabTitle a': 'eventSwitchData',
        'click tfoot button[data-value]': 'eventPaginate'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        this.data = {};
        this.data.gameId = +CSH.routePath[0];
        this.xhr = null;
        this.m_history = new ModelHistory();
        this.m_announce = new ModelAnnounceByPage();
        this.m_activity = new ModelActivitys();
        return this.render();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.tabTitle = this.$el.find('.tabTitle');
        this.els.tabContent = this.$el.find('.tabContent');
        return this.els.tabTitle.find('a:first-child').click();
      };

      View.prototype.destroy = function() {};

      View.prototype.fetch_lotteryRecords = function(page) {
        if (page == null) {
          page = 1;
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m_history.setUrl(this.data.gameId, 5, page).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              _this.els.tabContent.html(_this.tpls.history({
                data: data.data,
                pageInfo: data.pageInfo
              }));
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.fetch_notices = function(page) {
        if (page == null) {
          page = 1;
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m_announce.setUrl(page, 5).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              _this.els.tabContent.html(_this.tpls.announce({
                data: data.data,
                pageInfo: data.pageInfo
              }));
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.fetch_activities = function(page) {
        if (page == null) {
          page = 1;
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m_activity.setUrl().save({
          pageIndex: page,
          pageSize: 5,
          type: 0
        }, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              _this.els.tabContent.html(_this.tpls.activity({
                data: data.data,
                pageInfo: data.pageInfo
              }));
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventSwitchData = function(event) {
        var el, type;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        type = this.data.type = el.attr('data-type');
        el.addClass('active').siblings('.active').removeClass('active');
        this.els.tabContent.html(TplLoading);
        return this["fetch_" + type]();
      };

      View.prototype.eventPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        el.prop('disabled', true);
        p = el.attr('data-value');
        return this["fetch_" + this.data.type](p);
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
