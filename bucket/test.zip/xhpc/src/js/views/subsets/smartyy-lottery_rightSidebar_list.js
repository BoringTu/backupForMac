(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/history', 'models/bettingrecodesList', 'models/appendbettings', 'models/announceByPage', 'models/activitys', 'models/cancelbetting', 'collections/history', 'collections/bettingrecodesList', 'collections/appendbettings', 'collections/announceByPage', 'collections/activitys', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar_list.tpl', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar_list_historyRecords.tpl', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar_list_gameRecords.tpl', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar_list_trackRecords.tpl', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar_list_notices.tpl', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar_list_activities.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-noResult.tpl', 'text!../../../templates/_smartyy-modal.tpl'], function($, _, Backbone, doT, ModelHistoryRecords, ModelGameRecordsList, ModelTrackRecords, ModelNotices, ModelActivities, ModelCancelOrder, CollectionHistoryRecords, CollectionGameRecordsList, CollectionTrackRecords, CollectionNotices, CollectionActivities, TplContent, TplListHistoryRecords, TplListGameRecords, TplListTrackRecords, TplListNotices, TplListActivities, TplLoading, TplNoResult, TplModal) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        noResult: doT.template(TplNoResult),
        modal: doT.template(TplModal),
        list: {
          historyRecords: doT.template(TplListHistoryRecords),
          gameRecords: doT.template(TplListGameRecords),
          trackRecords: doT.template(TplListTrackRecords),
          notices: doT.template(TplListNotices),
          activities: doT.template(TplListActivities)
        }
      };

      View.prototype.events = {
        'click .tabTitle a': 'eventSwitchTab',
        'click button.refresh': 'eventRefresh',
        'change .adjustBox input[type="checkbox"]': 'eventChangeChosen',
        'click .showInfo': 'eventShowInfo',
        'click .revoke': 'eventRevoke'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        this.data = {};
        this.data.tabDict = {
          'historyRecords': '近期开奖',
          'gameRecords': '游戏记录',
          'trackRecords': '追号记录',
          'notices': '平台公告',
          'activities': '平台活动'
        };
        this.data.optionList = ['historyRecords', 'gameRecords', 'trackRecords', 'notices', 'activities'];
        if (+CSH.gType === 6) {
          this.data.optionList.remove('trackRecords');
        }
        this.m_historyRecords = new ModelHistoryRecords();
        this.c_historyRecords = new CollectionHistoryRecords();
        this.m_gameRecords = new ModelGameRecordsList();
        this.c_gameRecords = new CollectionGameRecordsList();
        this.m_trackRecords = new ModelTrackRecords();
        this.c_trackRecords = new CollectionTrackRecords();
        this.m_notices = new ModelNotices();
        this.c_notices = new CollectionNotices();
        this.m_activities = new ModelActivities();
        this.c_activities = new CollectionActivities();
        return this.render();
      };

      View.prototype.destroy = function() {
        this.$el.off();
        return null;
      };

      View.prototype.render = function() {
        var allList, i, initList, item, j, k, l, len, len1, len2, len3, len4, list, map, n, name, ref, ref1, tabList, temp;
        list = localStorage.getItem("rs_tabList_6_" + (+(+CSH.gType === 6)));
        initList = function() {
          return list = ['historyRecords', 'gameRecords', 'trackRecords'];
        };
        if (list) {
          list = list.split(',');
        } else {
          initList();
        }
        if (+CSH.gType === 6) {
          list.remove('trackRecords');
        }
        if (!list.length) {
          initList();
        }
        tabList = [];
        allList = [];
        map = this.data.tabDict;
        for (i = 0, len = list.length; i < len; i++) {
          item = list[i];
          tabList.push({
            name: item,
            text: map[item]
          });
        }
        ref = this.data.optionList;
        for (j = 0, len1 = ref.length; j < len1; j++) {
          item = ref[j];
          allList.push({
            name: item,
            text: map[item]
          });
        }
        for (k = 0, len2 = allList.length; k < len2; k++) {
          item = allList[k];
          if (list.has(item.name)) {
            item.selected = 1;
          }
        }
        switch (tabList.length) {
          case 1:
            name = tabList[0].name;
            for (l = 0, len3 = allList.length; l < len3; l++) {
              item = allList[l];
              if (item.name === name) {
                item.disabled = 1;
              }
            }
            break;
          case 3:
            temp = [];
            for (n = 0, len4 = allList.length; n < len4; n++) {
              item = allList[n];
              if (!(ref1 = item.name, indexOf.call(list, ref1) >= 0)) {
                item.disabled = 1;
              }
            }
        }
        this.$el.html(this.tpls.content({
          tabList: tabList,
          allList: allList
        }));
        this.els = {};
        this.els.tabTitle = this.$el.find('.tabTitle');
        this.els.refresh = this.$el.find('.refresh');
        this.els.tabPos = this.$el.find('.tabPos');
        this.els.tabWindow = this.$el.find('.tabWindow');
        this.els.tabWrap = this.$el.find('.tabWrap');
        this.els.tabContent = this.$el.find('.tabContent');
        return this.els.tabTitle.children('a:first').trigger('click');
      };

      View.prototype.rsExpanded = function() {
        var fun, qeView, tabPos, target;
        target = this.els.tabWindow;
        tabPos = this.els.tabPos;
        qeView = this.parent.views.qe;
        fun = function() {
          return setTimeout(function() {
            target.hide().css({
              top: tabPos.offset().top
            });
            return target.fadeIn(200);
          }, 250);
        };
        if (qeView.data.isLoaded) {
          return fun();
        } else {
          return qeView.dataLoaded = fun;
        }
      };

      View.prototype.rsCollapsing = function() {
        return this.els.tabWindow.hide();
      };

      View.prototype.eventSwitchTab = function(event) {
        var el, type;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        el.addClass('active').siblings('.active').removeClass('active');
        this.data.type = type = el.attr('data-type');
        return this.fetchData(type);
      };

      View.prototype.fetchData = function(type) {
        var param, ref;
        this.els.refresh.prop('disabled', true).addClass('icon-spin icon-fast');
        this.els.tabContent.html(TplLoading);
        if ((ref = this.xhr) != null) {
          ref.abort();
        }
        param = {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var content, url;
              data = data.toJSON().data;
              _this["c_" + type].reset(data);
              if (data.length) {
                content = _this.tpls.list[type]({
                  data: data
                });
              } else {
                content = _this.tpls.noResult();
              }
              url = "userCenter.html#" + (type.encodeHTML());
              if (type === 'historyRecords') {
                url = "trends.html#" + CSH.gID;
              }
              content += "<a class=\"gateway\" href=\"" + url + "\">\n	<span class=\"text\">全部</span>\n	<span class=\"icon icon-prev\"></span>\n</a>";
              _this.els.tabContent.attr({
                'data-type': type
              }).html(content);
              _this.els.refresh.prop('disabled', false).removeClass('icon-spin icon-fast');
              return '{}';
            };
          })(this)
        };
        switch (type) {
          case 'historyRecords':
            return this["m_" + type].setUrl(CSH.gID, 12, 1).fetch(param);
          case 'gameRecords':
            return this["m_" + type].setUrl(12, 1).save({
              gameID: +CSH.gID
            }, param);
          case 'trackRecords':
            return this["m_" + type].setUrl(12, 1).save({
              gameID: +CSH.gID,
              state: 0
            }, param);
          case 'notices':
            return this["m_" + type].setUrl(12, 1).fetch(param);
          case 'activities':
            return this["m_" + type].setUrl().save({
              pageIndex: 1,
              pageSize: 12,
              type: 0
            }, param);
        }
      };

      View.prototype.eventRefresh = function(event) {
        return this.fetchData(this.data.type);
      };

      View.prototype.eventChangeChosen = function(event) {
        var b, box, ckbs, ckeds, el, target, text, type, unckeds;
        el = $(event.currentTarget);
        type = el.attr('data-type');
        b = el.prop('checked');
        box = this.els.tabTitle;
        ckbs = el.closest('ul').find('input[type="checkbox"]');
        ckeds = ckbs.filter(':checked');
        unckeds = ckbs.not(ckeds);
        ckbs.prop({
          disabled: false
        }).parent().prop({
          disabled: false
        });
        if (b) {
          text = el.parent().siblings('.text').text();
          box.append("<a href=\"javascript:;\" data-type=\"" + (type.encodeHTML()) + "\">" + (text.encodeHTML()) + "</a>");
          if (!(ckbs.filter(':checked').length < 3)) {
            unckeds.prop({
              disabled: true
            }).parent().prop({
              disabled: true
            });
          }
        } else {
          target = box.children("a[data-type=\"" + type + "\"]");
          if (target.hasClass('active')) {
            target.siblings('a[data-type]').first().trigger('click');
          }
          target.remove();
          if (!(ckbs.filter(':checked').length > 1)) {
            ckeds.prop({
              disabled: true
            }).parent().prop({
              disabled: true
            });
          }
        }
        return this.saveData();
      };

      View.prototype.eventShowInfo = function(event) {
        var el, id, m, tr, type;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        type = this.data.type;
        id = el.closest('tr').attr('data-id');
        switch (type) {
          case 'gameRecords':
            m = this["c_" + type].findWhere({
              projectid: id
            });
            return CSH.views.body.showGameInfo({
              pageData: m.toJSON()
            });
          case 'trackRecords':
            m = this["c_" + type].get(id);
            return CSH.views.body.showTrackInfo({
              trackInfo: m.toJSON()
            });
        }
      };

      View.prototype.eventRevoke = function(event) {
        var el, id, tr, type;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        type = tr.closest('.tabContent').attr('data-type');
        id = el.closest('tr').attr('data-id');
        switch (type) {
          case 'gameRecords':
            return new ModelCancelOrder().setUrl().save({
              orders: id
            }, {
              dataFilter: (function(_this) {
                return function(data) {
                  switch (data.toJSON().code) {
                    case 0:
                      return CSH.hint({
                        msg: '撤单成功',
                        duration: 500,
                        type: 'success',
                        callback: function() {
                          _this.fetchData(type);
                          return CSH.refreshBalance();
                        }
                      });
                    case 5:
                    case 1:
                      return CSH.hint({
                        msg: '操作失败，请重试',
                        duration: 1500,
                        type: 'error'
                      });
                    case 4:
                      return CSH.hint({
                        msg: '本期已经封盘,不能撤单',
                        duration: 2000
                      });
                    case 2:
                      return CSH.hint({
                        msg: '合买不能撤单',
                        duration: 1500
                      });
                    case 3:
                      return CSH.hint({
                        msg: '已经撤单',
                        duration: 1500
                      });
                    default:
                      return CSH.hint({
                        msg: data.toJSON().message,
                        duration: 1500
                      });
                  }
                };
              })(this)
            });
          case 'trackRecords':
            return console.warn('追号撤单？');
        }
      };

      View.prototype.saveData = function() {
        var aEls, data;
        aEls = this.els.tabTitle.children('a[data-type]');
        data = [];
        aEls.each(function() {
          return data.push($(this).attr('data-type'));
        });
        return localStorage.setItem("rs_tabList_6_" + (+(+CSH.gType === 6)), data.join(','));
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
