(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/getteamreport', 'collections/getteamreport', 'text!../../../templates/subsets/userCenter_teamReports_tab.tpl', 'text!../../../templates/subsets/userCenter_teamReports_team.tpl', 'text!../../../templates/_paginate.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelGetTeamReport, CollectionGetTeamReport, TplContent, TplTeam, TplPaginate, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        team: doT.template(TplTeam),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'keyup .paginate input': 'eventKeyupPaginate',
        'change .toolbar .status': 'eventStatus',
        'click .toolbar .day': 'eventsGetDay',
        'click .toolbar .search': 'eventDateSearch',
        'click .dataContent .sort i.icon': 'eventsSort',
        'click .tabContent .searchTeam': 'eventsSearchTeam',
        'keyup .toolbar .serialNumber': 'eventKeyupInputSearch'
      };

      View.prototype.initialize = function(data) {
        this.$el.html(this.tpls.content());
        this.m_team = new ModelGetTeamReport;
        this.c_team = new CollectionGetTeamReport;
        this.view = null;
        this.day = 0;
        this.viewData = {
          crumb: void 0,
          curUser: void 0,
          total: void 0
        };
        this.toolbar = {
          UserId: void 0,
          likename: '',
          userType: 0,
          sort: 0,
          beginTime: new Date().getFormatDate(),
          endTime: new Date().getFormatDate()
        };
        return $('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.clearPageInfo = function(retainArr) {
        if (!!retainArr && retainArr.has("time")) {

        } else {
          this.day = 0;
          this.toolbar.beginTime = new Date().getFormatDate();
          this.toolbar.endTime = new Date().getFormatDate();
        }
        if (!!retainArr && retainArr.has("userType")) {

        } else {
          this.toolbar.userType = 0;
        }
        if (!!retainArr && retainArr.has("likename")) {

        } else {
          this.toolbar.likename = '';
        }
        if (!!retainArr && retainArr.has("sort")) {

        } else {
          this.toolbar.sort = void 0;
        }
        this.toolbar.userId = void 0;
        this.viewData = {
          crumb: void 0,
          curUser: void 0,
          total: void 0
        };
      };

      View.prototype.render = function(pageInfo) {
        var sort;
        sort = this.toolbar.sort;
        if (!sort) {
          sort = void 0;
        } else {
          if (+sort === 1) {
            sort = 'asc';
          } else {
            sort = 'desc';
          }
        }
        this.els.tabContent.html(this.tpls[this.view]({
          data: this.c.toJSON(),
          sort: sort,
          toolbar: this.toolbar,
          crumb: this.viewData.crumb,
          curUser: this.viewData.curUser,
          total: this.viewData.total,
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: '* 将为您保留最近 2 个月数据'
          })
        }));
        this.$el.find('select').select2();
        this.getDate();
        if (this.els.day.eq(this.day).length === 0) {
          this.els.dateStart.val(this.toolbar.beginTime);
          this.els.dateEnd.val(this.toolbar.endTime);
        }
        return this.els.day.removeClass('active').eq(this.day).addClass('active');
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        return this.m.setUrl(curPage).save(this.toolbar, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              _this.c.reset(data.data.list);
              _this.viewData.crumb = data.data.sub.crumb;
              _this.viewData.curUser = data.data.sub.current[0];
              _this.viewData.total = data.data.sub.total[0];
              _this.render(data.pageInfo);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el, name, type;
        el = $(event.currentTarget);
        arr = el.attr('data-name');
        arr = arr.split('/');
        name = arr[0];
        type = arr[1];
        el.addClass('active').siblings('li').removeClass('active');
        if (name === 'team') {
          this.c = this.c_team;
          this.m = this.m_team;
        } else {
          this.c = this.c_teamhj;
          this.m = this.m_teamhj;
          this.toolbar.userType = type;
        }
        this.view = name;
        this.els = {};
        this.els.tabContent = this.$el.find(' .tabContent');
        this.clearPageInfo();
        return this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventsGetDay = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.startDate = el.attr('data-startDate');
        this.toolbar.endDate = el.attr('data-endDate');
        this.fetchData();
        this.day = el.attr('data-number');
      };

      View.prototype.eventDateSearch = function(el) {
        var endVal, number, startVal;
        el = $(el.currentTarget);
        startVal = this.els.dateStart.val();
        endVal = this.els.dateEnd.val();
        number = this.els.serialNumber.val().trim();
        if (!!startVal && !!endVal) {
          this.day = 1000000;
        }
        if (!!number) {
          this.clearPageInfo(['time']);
          this.toolbar.likename = number.encodeHTML();
        } else if (!endVal && !startVal) {
          CSH.hint("请输入开始或结束时间");
          return;
        }
        this.fetchData();
        el.prop('disabled', true);
        return setTimeout((function(_this) {
          return function() {
            return el.prop('disabled', false);
          };
        })(this), 1000);
      };

      View.prototype.eventStatus = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.userType = +el.val();
        return this.fetchData();
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.getDate = function() {
        var aWeek, minDate, myDate, toDay, yesterDay;
        this.els.toolbar = this.$el.find(' .toolbar');
        this.els.serialNumber = this.els.toolbar.find(' .serialNumber');
        this.els.dateStart = this.els.toolbar.find(' #dateStart');
        this.els.dateEnd = this.els.toolbar.find(' #dateEnd');
        this.els.day = this.els.toolbar.find(' .day');
        this.els.toDay = this.els.toolbar.find(' .toDay');
        this.els.yesterDay = this.els.toolbar.find(' .yesterDay');
        this.els.aWeek = this.els.toolbar.find(' .aWeek');
        this.els.all = this.els.toolbar.find(' .all');
        toDay = new Date().getFormatDate();
        yesterDay = new Date().beforeDays(1).getFormatDate();
        aWeek = new Date().beforeDays(7).getFormatDate();
        myDate = new Date();
        minDate = new Date(myDate.setMonth(myDate.getMonth() - 2)).getFormatDate();
        this.els.toDay.attr('data-startDate', toDay).attr('data-endDate', toDay);
        this.els.yesterDay.attr('data-startDate', yesterDay).attr('data-endDate', yesterDay);
        this.els.aWeek.attr('data-startDate', aWeek).attr('data-endDate', toDay);
        this.els.all.attr('data-startDate', minDate).attr('data-endDate', toDay);
        this.els.dateStart.datetimepicker({
          useCurrent: false
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay);
        this.els.dateEnd.datetimepicker({
          useCurrent: false
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay);
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.startDate = el.val();
            if (!_this.els.dateEnd.val()) {
              _this.els.dateEnd.val(el.val());
            }
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        return this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.endDate = el.val();
            if (!_this.els.dateStart.val()) {
              _this.els.dateStart.val(el.val());
            }
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
      };

      View.prototype.eventsSearchTeam = function(event) {
        this.clearPageInfo(['time']);
        this.toolbar.userId = $(event.currentTarget).attr('data-uid');
        return this.fetchData();
      };

      View.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.toolbar.sort === el.attr('data-sort')) {
          return;
        }
        this.toolbar.sort = +el.attr('data-sort');
        return this.fetchData();
      };

      View.prototype.eventKeyupInputSearch = function(event) {
        if (event.keyCode === 13) {
          return $(".toolbar .search").click();
        }
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
