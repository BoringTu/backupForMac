(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/getUserMemberlstNew', 'collections/getUserMemberlstNew', 'models/memberInfo', 'models/membersnew', 'models/getMemberInfoByNameNew', 'text!../../../templates/subsets/_default-userCenter_tab.tpl', 'text!../../../templates/subsets/default-userCenter_memberManagement_agent.tpl', 'text!../../../templates/subsets/default-userCenter_memberManagement_membersip.tpl', 'text!../../../templates/subsets/default-userCenter_dayMoney_alert.tpl', 'text!../../../templates/_default-paginate.tpl', 'text!../../../templates/_default-contentLoading.tpl'], function($, _, Backbone, doT, ModelGetUserMemberlstNew, CollectionGetUserMemberlstNew, ModelMemberInfo, ModelMembersnew, ModelGetMemberiInfoByNameNew, TplContent, TplAgent, TplMembersip, TplAlert, TplPaginate, TplLoding) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'agent/2',
          text: '代理'
        }, {
          dataName: 'membersip/1',
          text: '玩家'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        agent: doT.template(TplAgent),
        alert: doT.template(TplAlert),
        membersip: doT.template(TplMembersip),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .tabTitle li': 'eventsTabSwithc',
        'click .paginate button': 'eventClickPaginate',
        'keyup .paginate input': 'eventKeyupPaginate',
        'click .toolbar .search': 'eventDateSearch',
        'click .table .sort i.icon': 'eventsSortUpDrop',
        'keyup .toolbar .user': 'eventUser',
        'click .table .accountsBtn': 'eventsAccountsBtn',
        'click .table tbody a.adjust': 'eventOpenAdjust',
        'click .table tbody a.open': 'eventOpenSalaty'
      };

      View.prototype.initialize = function(data) {
        this.$el.html(this.tpls.content(tabOption));
        this.m = new ModelGetUserMemberlstNew();
        this.c = new CollectionGetUserMemberlstNew();
        this.MMemberInfn = new ModelMemberInfo();
        this.MMembers = new ModelMembersnew();
        this.viewName = null;
        this.toolbar = {};
        this.btn = false;
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.render = function(pageInfo) {
        var sort, str;
        this.els.tabContent.html(this.tpls[this.viewName]({
          data: this.c.toJSON(),
          total: pageInfo.totalAmount,
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: ' '
          })
        }));
        this.getDate();
        sort = this.toolbar.sort;
        if (sort !== 0 && sort !== 1) {
          return sort = void 0;
        } else {
          if (+sort === 1) {
            sort = 'asc';
          } else {
            sort = 'desc';
          }
          str = this.els.sort.filter("[data-str=\"" + this.toolbar.sortBy + "\"]");
          return str.addClass(sort);
        }
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m.setUrl(curPage).save(this.toolbar, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var j, len, ref, salary;
              data = data.toJSON();
              if (data.code !== 0) {
                return '{}';
              }
              ref = data.data;
              for (j = 0, len = ref.length; j < len; j++) {
                salary = ref[j];
                salary.listSalarySet.sort(CSH.views.body.salaryStepSort);
              }
              _this.c.reset(data.data);
              return _this.render(data.pageInfo);
            };
          })(this)
        });
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el;
        el = $(event.currentTarget);
        this.els = {};
        arr = el.attr('data-name').split('/');
        this.viewName = arr[0];
        this.els.tabContent = this.$el.find(' .tabContent');
        el.addClass('active').siblings('li').removeClass('active');
        this.toolbar = {};
        this.toolbar.userType = arr[1];
        this.toolbar.userName = void 0;
        return this.fetchData();
      };

      View.prototype.eventsAccountsBtn = function(event) {
        var el, name;
        el = $(event.currentTarget);
        name = el.closest('tr').attr('data-name');
        localStorage.setItem('transferAccounts', name);
        return $('.meAccount .oneBlock span a[href="/userCenter.html#transferAccounts"]').trigger('click');
      };

      View.prototype.nowViewName = function() {
        return this.$el.find('.tabTitle ul li').filter('.active').trigger('click');
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.eventUser = function(event) {
        if (event.keyCode === 13) {
          return this.eventDateSearch();
        }
      };

      View.prototype.eventDateSearch = function(el) {
        var val;
        val = this.els.user.val().trim();
        this.toolbar = {};
        if (!val) {
          this.toolbar.userName = void 0;
        } else {
          this.toolbar.userName = val;
        }
        return this.fetchData();
      };

      View.prototype.eventsSortUpDrop = function(event) {
        var el, str;
        el = $(event.currentTarget);
        str = el.closest('.sort').attr('data-str');
        this.toolbar.sortBy = str;
        this.toolbar.sort = +el.attr('data-sort');
        return this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoding);
      };

      View.prototype.getDate = function() {
        this.els.user = this.$el.find(' .toolbar .user');
        this.els.table = this.$el.find(' .table');
        return this.els.sort = this.els.table.find(' .sort');
      };

      View.prototype.eventOpenSalaty = function(event) {
        if (this.eventRepeatClick()) {
          return;
        }
        this.btn = true;
        return this.changeSalary(event, 'Open');
      };

      View.prototype.eventOpenAdjust = function(event) {
        if (this.eventRepeatClick()) {
          return;
        }
        this.btn = true;
        return this.changeSalary(event, 'Adjust');
      };

      View.prototype.eventRepeatClick = function() {
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 1000);
        return this.btn;
      };

      View.prototype.changeSalary = function(event, change) {
        var el, els, init, item, minRatio, mySalaryState, name, text, tr, type;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        name = tr.attr('data-name');
        type = +tr.attr('data-type');
        minRatio = null;
        els = {};
        item = {};
        text = '调整';
        mySalaryState = +localStorage.getItem('salaryState');
        new ModelGetMemberiInfoByNameNew().setUrl(name).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var modelsBox;
              data = data.toJSON();
              if (+data.code === 0) {
                data = data.data;
                _this.stage = change === 'Adjust' ? data.salarylist.length : 2;
                minRatio = data.minRatio;
                modelsBox = CSH.alert({
                  title: text,
                  content: _this.tpls.alert({
                    name: "userCenter" + change,
                    data: data,
                    type: type
                  }),
                  className: "userCenter" + change,
                  ok: {
                    text: '调整',
                    autohide: false,
                    callback: function(event) {
                      var element, i, j, k, l, m, ref, ref1, ref2, ref3, val;
                      el = $(event.currentTarget);
                      val = [];
                      element = function(i) {
                        var amount, people, ratio;
                        ratio = parseFloat(els.salary.eq(i).val());
                        people = +els.people.eq(i).val();
                        amount = +els.amount.eq(i).val();
                        if (people < 0) {
                          return CSH.hint({
                            msg: '人数不能为负数'
                          });
                        }
                        if (amount < 0) {
                          return CSH.hint({
                            msg: '购彩量不能为负'
                          });
                        }
                        if (!ratio) {
                          return CSH.hint({
                            msg: '日工资比例不能设置为0.00%'
                          });
                        }
                        val.push({
                          step: i + 1,
                          ratio: +(ratio * 0.01).accurate(4),
                          memberCount: people != null ? people : 0,
                          targetAmount: amount * 10000
                        });
                        return false;
                      };
                      if (mySalaryState !== 0) {
                        if (+type === 2) {
                          if (!(_this.viewName === 'agent' && change === 'Adjust')) {
                            if (!els.dayMoneyBottom.is(':hidden')) {
                              if (!(els.people.eq(0).val() || els.amount.eq(0).val())) {
                                el.prop('disabled', false);
                                return CSH.hint('请输入正确购彩量或者活跃用户');
                              }
                              for (i = j = 0, ref = _this.stage - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                                if (element(i) !== false) {
                                  return;
                                }
                              }
                              if (_this.stage !== 1) {
                                for (i = k = 0, ref1 = _this.stage - 2; 0 <= ref1 ? k <= ref1 : k >= ref1; i = 0 <= ref1 ? ++k : --k) {
                                  if (val[i].ratio >= val[i + 1].ratio) {
                                    el.prop('disabled', false);
                                    return CSH.hint('上一阶段日工资比例不能比下一阶段低');
                                  }
                                  if (val[i].memberCount === val[i + 1].memberCount && val[i].targetAmount === val[i + 1].targetAmount) {
                                    el.prop('disabled', false);
                                    return CSH.hint('上一阶段不能跟下一阶相同');
                                  } else if (val[i].memberCount > val[i + 1].memberCount || val[i].targetAmount > val[i + 1].targetAmount) {
                                    el.prop('disabled', false);
                                    return CSH.hint('上一阶不能低于下一阶');
                                  }
                                }
                              }
                              if (minRatio !== 0) {
                                if (minRatio < val[_this.stage - 1].ratio) {
                                  el.prop('disabled', false);
                                  return CSH.hint('调整不能低于当前代理最大的比例');
                                }
                              }
                            }
                          }
                        } else {
                          if (!els.dayMoneyBottom.is(':hidden')) {
                            if (change !== 'Adjust') {
                              if (!els.amount.eq(0).val()) {
                                el.prop('disabled', false);
                                return CSH.hint('请输入正确购彩量');
                              }
                              for (i = l = 0, ref2 = _this.stage - 1; 0 <= ref2 ? l <= ref2 : l >= ref2; i = 0 <= ref2 ? ++l : --l) {
                                if (element(i) !== false) {
                                  return;
                                }
                              }
                              if (_this.stage !== 1) {
                                for (i = m = 0, ref3 = _this.stage - 2; 0 <= ref3 ? m <= ref3 : m >= ref3; i = 0 <= ref3 ? ++m : --m) {
                                  if (val[i].ratio >= val[i + 1].ratio) {
                                    el.prop('disabled', false);
                                    return CSH.hint('上一阶段日工资比例不能比下一阶段低');
                                  }
                                  if (val[i].targetAmount >= val[i + 1].targetAmount) {
                                    el.prop('disabled', false);
                                    return CSH.hint('上一阶不能低于或等于下一阶');
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      el.prop('disabled', true);
                      item = {
                        userName: data.userName,
                        userType: data.userType === 2 ? data.userType : +modelsBox.find('select.type').val()
                      };
                      item.salarylist = els.dayMoneyBottom.is(':hidden') ? [] : val;
                      item.rebateRate = +els.rebate.val();
                      return new ModelMembersnew().setUrl().save(item, {
                        dataFilter: function(data) {
                          data = data.toJSON();
                          if (+data.code === 0) {
                            els.modelsBox.trigger('hidden');
                            $('.fade').hide();
                            CSH.hint({
                              msg: data.message,
                              type: 'success',
                              icon: 'icon icon-ok'
                            });
                            _this.nowViewName();
                          } else {
                            el.prop('disabled', false);
                            CSH.hint(data.message);
                          }
                          return '{}';
                        }
                      });
                    }
                  }
                });
                init(modelsBox);
              }
              return '{}';
            };
          })(this)
        });
        return init = (function(_this) {
          return function(modelsBox) {
            var addStage, convertAgent, disableds, eventInput, eventToggle, eventsSlide, getDate, i, j, minRebate, myRebate, mySalary, openSalary, rebateD, ref, removeStage, results, salaryD, slidesWidth, xMax, xMin;
            els.modelsBox = modelsBox;
            els.dayMoneyTopRadio = els.modelsBox.find('.dayMoneyTop .btns button');
            els.type = els.modelsBox.find('select.type');
            els.dayMoneyBottom = els.modelsBox.find('.dayMoneyBottom');
            els.stageWrap = els.dayMoneyBottom.find('.stageWrap');
            els.stage = els.stageWrap.find('.stage');
            els.salary = els.stage.find('.salary');
            els.amount = els.stage.find('input[data-type="amount"]');
            els.people = els.stage.find('input[data-type="people"]');
            els.removeBtn = els.stage.find('.removeBtn');
            els.addStageWrap = els.dayMoneyBottom.find('.addStageWrap');
            els.addStageBtn = els.addStageWrap.find('.addStageBtn');
            els.num = els.addStageWrap.find('.num');
            els.rebate = els.modelsBox.find('.rebate');
            disableds = false;
            if (change === 'Open' && mySalaryState === 2) {
              disableds = true;
            }
            els.modelsBox.find('select').select2().on('click', function() {
              return $('.select2-container--open').css('zIndex', 1600);
            });
            convertAgent = function(event) {
              el = $(event.currentTarget);
              type = el.val();
              if (+el.val() === 1) {
                els.stageWrap.hide();
                els.addStageWrap.hide();
                return els.brief.show();
              } else {
                els.stageWrap.show();
                els.addStageWrap.show();
                return els.brief.hide();
              }
            };
            addStage = function(event) {
              var str;
              if (_this.stage === 20) {
                return;
              }
              if (event) {
                _this.stage++;
              }
              els.num.text(_this.stage);
              str = $("<div class=\"stage clear\" style=\"display: none\">\n	<div class=\"stageLeft\">\n		<input class=\"adjustBtn arrow salary\" value=\"0.00\">\n		<span class=\"wrapAdjust\">\n			<span class=\"adjust\">\n				<span class=\"wrapBg\">\n					<span class=\"bg\"></span>\n				</span>\n				<i class=\"roundBtn salary\"></i>\n			</span>\n		</span>\n	</div>\n	<div class=\"stageRight " + (+type === 1 ? 'type' : '') + "\">\n		<label>\n		<input type=\"number\" data-type=\"amount\" placeholder=\"购彩量\" />\n			万\n		</label>\n		<label>\n		<input type=\"number\" data-type=\"people\" placeholder=\"活跃用户\" />\n			人\n		</label>\n	</div>\n	<button class=\"removeBtn\">删除</button>\n</div>");
              els.stageWrap.append(str);
              str.slideDown();
              return getDate();
            };
            removeStage = function(event) {
              var parent;
              _this.stage--;
              getDate();
              els.num.text(_this.stage);
              el = $(event.currentTarget);
              parent = el.closest('.stage');
              return parent.slideUp(function() {
                return parent.remove();
              });
            };
            myRebate = localStorage.getItem('rebate');
            mySalary = localStorage.getItem('salary');
            minRebate = +els.rebate.val();
            salaryD = mySalary * 1000 * 1000;
            slidesWidth = 260;
            if (CSH.fix === 'xh') {
              salaryD = salaryD >= 15000 ? 15000 : salaryD;
            }
            rebateD = myRebate - minRebate;
            xMin = 0;
            xMax = 260;
            eventsSlide = function(event) {
              var bg, xInte;
              event.stopPropagation();
              el = $(event.currentTarget);
              xInte = event.clientX - el.position().left;
              bg = el.prev('.wrapBg').find('.bg');
              els.modelsBox.on('mousemove.slide', (function(_this) {
                return function(event) {
                  var dValue, elWrapAdjust, nowRebate, rebate, salary, xNow;
                  xNow = event.clientX - xInte;
                  if (xNow < xMin) {
                    xNow = xMin;
                  }
                  if (xNow > xMax) {
                    xNow = xMax;
                  }
                  dValue = xNow / xMax;
                  elWrapAdjust = el.closest('.wrapAdjust');
                  rebate = elWrapAdjust.prev('.rebate');
                  if (rebate[0]) {
                    nowRebate = Math.round(dValue * rebateD);
                    nowRebate = nowRebate % 2 ? nowRebate + 1 : nowRebate;
                    rebate.val(nowRebate + minRebate > myRebate ? myRebate : nowRebate + minRebate);
                  }
                  salary = elWrapAdjust.prev('.salary');
                  if (salary[0]) {
                    text = dValue * salaryD;
                    text = Math.round(text * 0.01);
                    text = text * 0.01;
                    salary.val(text.accurate(2));
                  }
                  el.css('left', xNow);
                  return bg.css('width', xNow);
                };
              })(this));
              return els.modelsBox.on('mouseup.slide', (function(_this) {
                return function(event) {
                  return els.modelsBox.off('.slide');
                };
              })(this));
            };
            eventToggle = function(event) {
              var adjustBtn, speed, wrapAdjust;
              speed = 200;
              el = $(event.target);
              wrapAdjust = $(el.closest('.wrapAdjust')[0]);
              adjustBtn = $(el.closest('.adjustBtn')[0]);
              els.adjustBtn.addClass('arrow').removeClass('arrowTopple');
              if (adjustBtn.hasClass('arrow')) {
                adjustBtn.addClass('arrowTopple').removeClass('arrow');
                if (el.hasClass('salary')) {
                  return els.stageWrap.animate({
                    'scrollTop': el.closest('.stage').position().top + els.stageWrap.scrollTop()
                  });
                }
              } else {
                return adjustBtn.removeClass('arrowTopple').addClass('arrow');
              }
            };
            eventInput = function(event) {
              var aLLrebate, bg, btn, rebate, salary, val, wi;
              el = $(event.currentTarget);
              val = el.val();
              if (!/\d/g.test(val)) {
                el.val('');
              }
              if (val.length >= 4) {
                if (el.closest('.rebate')[0]) {
                  if (minRebate > val) {
                    el.val(minRebate);
                  }
                  if (myRebate < val) {
                    el.val(myRebate);
                  }
                  val = el.val();
                  rebate = val - minRebate;
                  aLLrebate = myRebate - minRebate;
                  wi = rebate / aLLrebate;
                  wi = wi * slidesWidth;
                } else {
                  val = parseFloat(el.val());
                  el.val(Number.isNaN(val) ? 0 : val);
                  if (String(val).length >= 5) {
                    el.val(0);
                  }
                  salary = salaryD / 100 / 100;
                  if (+salary < val) {
                    el.val(salary);
                  }
                  val = +el.val();
                  wi = val / salary;
                  wi = wi * slidesWidth;
                }
                bg = el.next('.wrapAdjust').find('.bg');
                btn = el.next('.wrapAdjust').find('.roundBtn');
                bg.css('width', wi);
                return btn.css('left', wi);
              }
            };
            openSalary = function(event) {
              el = $(event.currentTarget);
              if (+el.attr('data-off')) {
                return els.dayMoneyBottom.show();
              } else {
                return els.dayMoneyBottom.hide();
              }
            };
            els.dayMoneyTopRadio.on('click', openSalary);
            els.addStageBtn.on('click', addStage);
            els.dayMoneyBottom.on('click', '.removeBtn', removeStage);
            els.modelsBox.on('click', eventToggle);
            els.modelsBox.on('mousedown', '.roundBtn', eventsSlide);
            els.modelsBox.on('keyup', '.adjustBtn', eventInput);
            if (change === 'Adjust' && type === 1) {
              els.brief = els.dayMoneyBottom.find('.brief');
              els.type.on('change', convertAgent);
            }
            getDate = function() {
              els.adjustBtn = els.stageWrap.find('.adjustBtn');
              els.salary = els.stageWrap.find('.adjustBtn.salary');
              els.amount = els.stageWrap.find('input[data-type="amount"]');
              return els.people = els.stageWrap.find('input[data-type="people"]');
            };
            getDate();
            if (change === 'Open') {
              results = [];
              for (i = j = 0, ref = _this.stage - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                results.push(addStage());
              }
              return results;
            }
          };
        })(this);
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
