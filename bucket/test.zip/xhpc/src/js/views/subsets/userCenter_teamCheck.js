(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/teamCheckChange', 'models/teamCheckCashTrades', 'collections/teamCheckChange', 'collections/teamCheckCashTrades', 'text!../../../templates/subsets/_userCenter_tab.tpl', 'text!../../../templates/subsets/userCenter_teamCheck.tpl', 'text!../../../templates/_paginate.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelTeamCheckChange, ModelTeamCheckCashTrades, CollectionTeamCheckChange, CollectionTeamCheckCashTrades, TplContent, TplTeamCheck, TplPaginate, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'teamCheckChange',
          text: '成员账变'
        }, {
          dataName: 'teamTopup/1',
          text: '成员充值'
        }, {
          dataName: 'teamWithdrawal/2',
          text: '成员提现'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        teamCheckChange: doT.template(TplTeamCheck),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'keyup .paginate input': 'eventKeyupPaginate',
        'change .toolbar .status': 'eventStatus',
        'click .toolbar .day': 'eventsGetDay',
        'click .toolbar .search': 'eventDateSearch',
        'keyup .serialNumber': 'eventSerialNumber',
        'click .tabContent .searchTeam': 'eventsSearchTeam',
        'click .dataContent .sort i.icon': 'eventsSort'
      };

      View.prototype.initialize = function(data) {
        this.$el.html(this.tpls.content(tabOption));
        this.viewData = {
          viewName: 'teamCheckChange',
          day: 0,
          pathUserName: localStorage.getItem('username'),
          msg: '暂无记录！'
        };
        this.toolbar = {
          startDate: new Date().beforeDays(7).getFormatDate(),
          endDate: new Date().getFormatDate(),
          tradeType: void 0
        };
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.clearPageInfo = function(retainArr) {
        if (!(retainArr && retainArr.has("time"))) {
          this.viewData.day = 0;
          this.toolbar.startDate = new Date().getFormatDate();
          this.toolbar.endDate = new Date().getFormatDate();
        }
        if (retainArr && retainArr.has("type")) {
          if (this.viewData.viewName === 'teamCheckChange') {
            this.toolbar.state = void 0;
          }
        } else {
          if (this.viewData.viewName === 'teamCheckChange') {
            this.toolbar.tradeType = void 0;
          }
          this.toolbar.state = void 0;
        }
        this.toolbar.userName = void 0;
        this.toolbar.orderBy = void 0;
        this.toolbar.orderControl = void 0;
        this.viewData.pathUserName = localStorage.getItem('username');
        this.viewData.msg = '暂无记录！';
      };

      View.prototype.render = function(pageInfo) {
        var endDate, startDate;
        this.els.tabContent.html(this.tpls.teamCheckChange({
          data: this.c.toJSON(),
          toolbar: this.toolbar,
          viewData: this.viewData,
          total: pageInfo.totalAmount,
          layerRelation: pageInfo.layerRelation || [],
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: '* 将为您保留最近 2 个月数据'
          })
        }));
        this.$el.find('select').select2();
        this.getDate();
        if (this.viewData.day === void 0) {
          startDate = this.toolbar.startDate.split(':');
          endDate = this.toolbar.endDate.split(':');
          this.els.dateStart.val(startDate[2] ? startDate[0] + ":" + startDate[1] : this.toolbar.startDate);
          return this.els.dateEnd.val(endDate[2] ? endDate[0] + ":" + endDate[1] : this.toolbar.endDate);
        }
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m.setUrl(this.viewData.pathUserName, curPage).save(this.toolbar, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                _this.viewData.msg = data.message;
              }
              _this.c.reset(data.data || []);
              _this.render(data.pageInfo || {});
              _this.els.totalTd = _this.$el.find('.total td:eq(0)');
              switch (_this.viewData.viewName) {
                case 'teamCheckChange':
                  _this.els.totalTd.text('账变合计');
                  break;
                case 'teamTopup':
                  _this.els.totalTd.text('充值合计');
                  break;
                case 'teamWithdrawal':
                  _this.els.totalTd.text('提现合计');
              }
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el, type;
        el = $(event.currentTarget);
        arr = el.attr('data-name');
        arr = arr.split('/');
        this.viewData.viewName = arr[0];
        type = arr[1];
        el.addClass('active').siblings('li').removeClass('active');
        this.clearPageInfo();
        this.els = {};
        if (this.viewData.viewName === 'teamCheckChange') {
          this.c = new CollectionTeamCheckChange();
          this.m = new ModelTeamCheckChange();
        } else {
          this.c = new CollectionTeamCheckCashTrades();
          this.m = new ModelTeamCheckCashTrades();
          this.toolbar.tradeType = type;
        }
        this.els.tabContent = this.$el.find(' .tabContent');
        return this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventsGetDay = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.startDate = el.attr('data-startDate');
        this.toolbar.endDate = el.attr('data-endDate');
        this.fetchData();
        this.viewData.day = el.attr('data-number');
      };

      View.prototype.eventSerialNumber = function(event) {
        if (event.keyCode === 13) {
          this.$el.find('.toolbar .search').click();
        }
      };

      View.prototype.eventDateSearch = function(el) {
        var endVal, number, startVal, str;
        el = $(el.currentTarget);
        number = this.els.serialNumber.val().trim();
        startVal = this.els.dateStart.val();
        endVal = this.els.dateEnd.val();
        str = null;
        if (startVal && endVal) {
          this.viewData.day = void 0;
          this.toolbar.startDate = startVal.split(':')[2] ? startVal : startVal + ":00";
          this.toolbar.endDate = endVal.split(':')[2] ? endVal : endVal + ":59";
        }
        if (number) {
          this.clearPageInfo(['time']);
          this.toolbar.userName = number.encodeHTML();
        } else if (!endVal && !startVal) {
          CSH.hint("请输入开始或结束时间");
          return;
        }
        this.fetchData();
        return el.prop('disabled', true);
      };

      View.prototype.eventStatus = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.viewData.viewName === 'teamCheckChange') {
          this.toolbar.tradeType = +el.val();
        } else {
          this.toolbar.state = +el.val();
        }
        return this.fetchData();
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.getDate = function() {
        var aWeek, minDate, myDate, toDay, yesterDay;
        this.els.toolbar = this.$el.find(' .toolbar');
        this.els.serialNumber = this.els.toolbar.find('.serialNumber');
        this.els.dateStart = this.els.toolbar.find('#dateStart');
        this.els.dateEnd = this.els.toolbar.find('#dateEnd');
        this.els.day = this.els.toolbar.find('.day');
        this.els.toDay = this.els.toolbar.find('.toDay');
        this.els.yesterDay = this.els.toolbar.find('.yesterDay');
        this.els.aWeek = this.els.toolbar.find('.aWeek');
        this.els.all = this.els.toolbar.find('.all');
        toDay = new Date().getFormatDate();
        yesterDay = new Date().beforeDays(1).getFormatDate();
        aWeek = new Date().beforeDays(7).getFormatDate();
        myDate = new Date();
        minDate = new Date(myDate.setMonth(myDate.getMonth() - 2)).getFormatDate();
        this.els.toDay.attr('data-startDate', toDay).attr('data-endDate', toDay);
        this.els.yesterDay.attr('data-startDate', yesterDay).attr('data-endDate', yesterDay);
        this.els.aWeek.attr('data-startDate', aWeek).attr('data-endDate', toDay);
        this.els.all.attr('data-startDate', minDate).attr('data-endDate', toDay);
        this.els.dateStart.datetimepicker({
          useCurrent: false,
          defaultDate: toDay
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59:59");
        this.els.dateEnd.datetimepicker({
          useCurrent: false,
          defaultDate: toDay + " 23:59"
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59:59");
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.startDate = el.val();
            if (!_this.els.dateEnd.val()) {
              _this.els.dateEnd.val(el.val());
              _this.toolbar.endDate = el.val();
            }
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        return this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.endDate = el.val();
            if (!_this.els.dateStart.val()) {
              _this.els.dateStart.val(el.val());
              _this.toolbar.startDate = el.val();
            }
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
      };

      View.prototype.eventsSearchTeam = function(event) {
        this.clearPageInfo(['time', 'type']);
        this.viewData.pathUserName = $(event.currentTarget).attr('data-uid');
        this.fetchData();
      };

      View.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.toolbar.orderControl === +el.attr('data-sort')) {
          return;
        }
        this.toolbar.orderControl = +el.attr('data-sort');
        this.toolbar.orderBy = 1;
        return this.fetchData();
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
