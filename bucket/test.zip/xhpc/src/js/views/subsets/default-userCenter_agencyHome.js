(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'highcharts', 'models/agencyHomeBasic', 'models/agencyHomeGetpandect', 'text!../../../templates/subsets/default-userCenter_agencyHome.tpl', 'text!../../../templates/subsets/default-userCenter_agencyHome_team.tpl', 'text!../../../templates/_default-contentLoading.tpl'], function($, _, Backbone, doT, H, ModelBasic, ModelGetpandect, TplContent, TplTeam, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var showTooltipStart;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        team: doT.template(TplTeam)
      };

      View.prototype.events = {
        'click .toolbar .day': 'eventsGetDay',
        'click .toolbar .search': 'eventDateSearch',
        'click .tabTitle li': 'eventsSwitchChart',
        'mouseleave #chart': 'eventsShowTooltip'
      };

      View.prototype.initialize = function(data) {
        this.$el.html(this.tpls.content());
        this.mBasic = new ModelBasic();
        this.mTeam = new ModelGetpandect();
        this.els = {};
        this.chartData = {
          depositAmount: {
            color: '#27cdeb',
            marker: {
              states: {
                hover: {
                  radiusPlus: 6,
                  fillColor: {
                    radialGradient: {
                      r: 0.5
                    },
                    stops: [[0, '#27cdeb'], [0.5, '#27cdeb'], [0.5, '#fff'], [0.7, '#fff'], [0.75, '#27cdeb'], [1, '#27cdeb']]
                  }
                }
              }
            },
            id: 'depositSeries',
            visible: true,
            data: []
          },
          widthdrawAmount: {
            color: '#ff8a54',
            marker: {
              states: {
                hover: {
                  radiusPlus: 6,
                  fillColor: {
                    radialGradient: {
                      r: 0.5
                    },
                    stops: [[0, '#ff8a54'], [0.5, '#ff8a54'], [0.5, '#fff'], [0.7, '#fff'], [0.75, '#ff8a54'], [1, '#ff8a54']]
                  }
                }
              }
            },
            id: 'widthdrawSeries',
            visible: false,
            data: []
          },
          betAmount: {
            color: '#d062b6',
            marker: {
              states: {
                hover: {
                  radiusPlus: 6,
                  fillColor: {
                    radialGradient: {
                      r: 0.5
                    },
                    stops: [[0, '#d062b6'], [0.5, '#d062b6'], [0.5, '#fff'], [0.7, '#fff'], [0.75, '#d062b6'], [1, '#d062b6']]
                  }
                }
              }
            },
            id: 'betSeries',
            visible: false,
            data: []
          },
          prizeAmount: {
            color: '#3292fd',
            marker: {
              states: {
                hover: {
                  radiusPlus: 6,
                  fillColor: {
                    radialGradient: {
                      r: 0.5
                    },
                    stops: [[0, '#3292fd'], [0.5, '#3292fd'], [0.5, '#fff'], [0.7, '#fff'], [0.75, '#3292fd'], [1, '#3292fd']]
                  }
                }
              }
            },
            id: 'prizeSeries',
            visible: false,
            data: []
          },
          concessionsAmount: {
            color: '#91dd34',
            marker: {
              states: {
                hover: {
                  radiusPlus: 6,
                  fillColor: {
                    radialGradient: {
                      r: 0.5
                    },
                    stops: [[0, '#91dd34'], [0.5, '#91dd34'], [0.5, '#fff'], [0.7, '#fff'], [0.75, '#91dd34'], [1, '#91dd34']]
                  }
                }
              }
            },
            id: 'concessionsSeries',
            visible: false,
            data: []
          },
          rebateAmount: {
            color: '#fd587b',
            marker: {
              states: {
                hover: {
                  radiusPlus: 6,
                  fillColor: {
                    radialGradient: {
                      r: 0.5
                    },
                    stops: [[0, '#fd587b'], [0.5, '#fd587b'], [0.5, '#fff'], [0.7, '#fff'], [0.75, '#fd587b'], [1, '#fd587b']]
                  }
                }
              }
            },
            id: 'rebateSeries',
            visible: false,
            data: []
          }
        };
        this.chartObj = void 0;
        this.curId = 'deposit';
        this.isBtnDay = true;
        this.basicInfo = void 0;
        this.toSrvParam = {
          startDate: (new Date().getFormatDate()) + " 00:00:00",
          endDate: (new Date().getFormatDate()) + " 23:59:59"
        };
        return this.fetchData();
      };

      View.prototype.fetchData = function() {
        this.fetchBasicData();
        this.fetchTeamData(1);
      };

      View.prototype.fetchBasicData = function() {
        this.mBasic.setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var key, ref, value;
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              _this.basicInfo = data.data[0];
              ref = _this.basicInfo;
              for (key in ref) {
                value = ref[key];
                _this.$el.find('#' + key).html(value || '0');
              }
            };
          })(this)
        });
      };

      View.prototype.fetchTeamData = function(isInitObj) {
        this.mTeam.setUrl(isInitObj).save(this.toSrvParam, {
          dataFilter: (function(_this) {
            return function(data) {
              var convertToChart, creatChart, key, s, totlalObj, value, view;
              data = data.toJSON();
              view = _this;
              if (data.code !== 0) {
                return;
              }
              _this.els.teamEle = _this.$el.find('.team');
              totlalObj = data.data.totlal;
              _this.mTeam.clear();
              if (isInitObj) {
                s = data.data.data;
                _this.els.teamEle.html(_this.tpls.team({
                  total: totlalObj
                }));
                _this.getDate();
                convertToChart = function(data) {
                  var k, key, results, v, value;
                  results = [];
                  for (key in data) {
                    value = data[key];
                    results.push((function() {
                      var results1;
                      results1 = [];
                      for (k in value) {
                        v = value[k];
                        results1.push(this.chartData[k].data.unshift(+v));
                      }
                      return results1;
                    }).call(_this));
                  }
                  return results;
                };
                convertToChart(s);
                console.log('@chartData----', _this.chartData);
                creatChart = function() {
                  _this.chartObj = new Highcharts.Chart('chart', {
                    chart: {
                      marginLeft: 68.5,
                      marginRight: 30,
                      marginBottom: 48,
                      animation: false
                    },
                    title: {
                      text: null
                    },
                    credits: {
                      enabled: false
                    },
                    legend: {
                      enabled: false
                    },
                    yAxis: {
                      title: {
                        enabled: false
                      },
                      lineColor: '#d5d5d5',
                      lineWidth: 1,
                      gridLineColor: '#dfe5f0',
                      gridLineDashStyle: 'Dash'
                    },
                    xAxis: {
                      type: 'datetime',
                      tickLength: 5,
                      tickPosition: 'inside',
                      tickInterval: 24 * 3600 * 1000,
                      pointInterval: 24 * 3600 * 1000,
                      minPadding: 0.05,
                      dateTimeLabelFormats: {
                        day: '%m.%e'
                      },
                      endOnTick: true,
                      showLastLabel: false,
                      crosshair: {
                        color: '#e9eef6'
                      }
                    },
                    tooltip: {
                      hideDelay: 24 * 3600 * 1000 * 365,
                      useHTML: true,
                      formatter: function(obj) {
                        var d, date, m, setArrowDirection, y;
                        date = new Date(this.x);
                        y = date.getFullYear();
                        m = date.getMonth() + 1;
                        d = date.getDate();
                        setArrowDirection = function(obj) {
                          var target;
                          target = view.els.chart.find('#chart-tooltip-arrow');
                          if (obj.now.anchorY < obj.now.y) {
                            target.addClass('arrowUp');
                          }
                        };
                        setTimeout((function() {
                          return setArrowDirection(obj);
                        }), 600);
                        return "<div id=\"chart-tooltip-arrow\"><small>" + y + "." + m + "." + d + "</small><br><big>￥" + this.y + "</big><em></em></div>";
                      }
                    },
                    plotOptions: {
                      series: {
                        pointStart: Date.UTC(new Date().beforeDays(6).getFullYear(), new Date().beforeDays(6).getMonth(), new Date().beforeDays(6).getDate()),
                        pointInterval: 24 * 3600 * 1000,
                        marker: {
                          symbol: 'circle',
                          radius: 6,
                          states: {
                            hover: {
                              radiusPlus: 6
                            }
                          }
                        }
                      }
                    },
                    series: [_this.chartData.depositAmount, _this.chartData.widthdrawAmount, _this.chartData.betAmount, _this.chartData.prizeAmount, _this.chartData.concessionsAmount, _this.chartData.rebateAmount]
                  });
                };
                creatChart();
                showTooltipStart(_this.chartObj, _this.curId + 'Series');
              } else {
                for (key in totlalObj) {
                  value = totlalObj[key];
                  _this.els.teamEle.find('#' + key).html(Math.floor(value) || '0');
                }
                if (!_this.isBtnDay) {
                  _this.els.searchEle.prop('disabled', false);
                }
              }
            };
          })(this)
        });
      };

      View.prototype.eventsGetDay = function(event) {
        var el, temp;
        this.isBtnDay = true;
        this.els.dateStart.val('');
        this.els.dateEnd.val('');
        el = $(event.currentTarget);
        el.addClass('active').siblings('button.day').removeClass('active');
        if (event.currentTarget.id !== 'all') {
          temp = this.toSrvDate[event.currentTarget.id];
          this.toSrvParam = JSON.parse(JSON.stringify(temp));
        } else {
          delete this.toSrvParam.endDate;
          delete this.toSrvParam.startDate;
        }
        this.fetchTeamData(0);
        this.els.depositEle.click();
      };

      View.prototype.eventDateSearch = function(event) {
        var el, endVal, startVal;
        el = $(event.currentTarget);
        startVal = this.els.dateStart.val();
        endVal = this.els.dateEnd.val();
        if (startVal && endVal) {
          this.toSrvParam.startDate = startVal.split(':')[2] ? startVal : startVal + " 00:00:00";
          this.toSrvParam.endDate = endVal.split(':')[2] ? endVal : endVal + " 23:59:59";
          this.isBtnDay = false;
          this.els.dayEles.removeClass('active');
        } else if (!endVal && !startVal) {
          CSH.hint("请输入开始或结束时间");
          return;
        }
        this.fetchTeamData(0);
        el.prop('disabled', true);
      };

      showTooltipStart = function(chart, seriesId) {
        var len, series;
        series = chart.get(seriesId);
        len = series.data.length;
        return chart.tooltip.refresh(series.data[len - 1]);
      };

      View.prototype.eventsShowTooltip = function(event) {
        showTooltipStart(this.chartObj, this.curId + 'Series');
      };

      View.prototype.eventsSwitchChart = function(event) {
        var el, id;
        el = $(event.currentTarget);
        el.addClass('active').siblings('li').removeClass('active');
        id = el.attr('data-id');
        if (id !== this.curId) {
          this.els.chart.removeClass(this.curId + 'Tooltip').addClass(id + 'Tooltip');
          this.chartObj.get(this.curId + 'Series').hide();
          this.chartObj.get(id + 'Series').show();
          showTooltipStart(this.chartObj, id + 'Series');
          this.curId = id;
        }
      };

      View.prototype.getDate = function() {
        var minDate, today;
        today = new Date();
        minDate = new Date(new Date().setMonth(new Date().getMonth() - 1));
        this.toSrvDate = {
          today: {
            startDate: (today.getFormatDate()) + " 00:00:00",
            endDate: (today.getFormatDate()) + " 23:59:59"
          },
          yesterday: {
            startDate: (today.beforeDays(1).getFormatDate()) + " 00:00:00",
            endDate: (today.beforeDays(1).getFormatDate()) + " 23:59:59"
          },
          aWeek: {
            startDate: (today.beforeDays(7).getFormatDate()) + " 00:00:00",
            endDate: (today.getFormatDate()) + " 23:59:59"
          }
        };
        this.els.dateStart = this.els.teamEle.find('#dateStart');
        this.els.dateEnd = this.els.teamEle.find('#dateEnd');
        this.els.searchEle = this.els.teamEle.find('.search');
        this.els.dayEles = this.els.teamEle.find('.day');
        this.els.depositEle = this.els.teamEle.find('.t1');
        this.els.chart = this.els.teamEle.find('#chart');
        this.els.dateStart.datetimepicker({
          useCurrent: false,
          showClear: false,
          defaultDate: this.toSrvDate.today.startDate,
          format: 'YYYY-MM-DD'
        }).data('DateTimePicker').minDate(minDate.getFormatDate()).maxDate(this.toSrvDate.today.endDate);
        this.els.dateEnd.datetimepicker({
          useCurrent: false,
          showClear: false,
          defaultDate: this.toSrvDate.today.endDate,
          format: 'YYYY-MM-DD'
        }).data('DateTimePicker').minDate(minDate.getFormatDate()).maxDate(this.toSrvDate.today.endDate);
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            if (!_this.els.dateEnd.val()) {
              _this.els.dateEnd.val(el.val());
            }
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        return this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            if (!_this.els.dateStart.val()) {
              _this.els.dateStart.val(el.val());
            }
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
