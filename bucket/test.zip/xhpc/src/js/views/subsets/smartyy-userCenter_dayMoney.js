(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/giveout', 'models/getCurrentDaySalary', 'models/detail', 'models/getMemberInfoByNameNew', 'models/membersnew', 'models/getMyDaySalarylist', 'models/getSubDaySalarylist', 'models/salarymanage', 'collections/getMyDaySalarylist', 'collections/getSubDaySalarylist', 'collections/salarymanage', 'text!../../../templates/subsets/smartyy-userCenter_dayMoney.tpl', 'text!../../../templates/subsets/_smartyy-userCenter_tab.tpl', 'text!../../../templates/subsets/smartyy-userCenter_dayMoney_myDayMoney.tpl', 'text!../../../templates/subsets/smartyy-userCenter_dayMoney_subordinateDayMoney.tpl', 'text!../../../templates/subsets/smartyy-userCenter_dayMoney_manageDayMoney.tpl', 'text!../../../templates/subsets/smartyy-userCenter_dayMoney_alert.tpl', 'text!../../../templates/_smartyy-paginate.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-noResult.tpl'], function($, _, Backbone, doT, ModelGiveout, ModelGetCurrentDaySalary, ModelDetail, ModelGetMemberiInfoByNameNew, ModelMembersnew, ModelGetMyDaySalarylist, ModelgetSubDaySalarylist, ModelSalarymanage, CollectionGetMyDaySalarylist, CollectionGetSubDaySalarylist, CollectionSalarymanage, TplInfo, TplContent, TplMyDayMoney, TplSubordinateDayMoney, TplManageDayMoney, TplAlert, TplPaginate, TplLoading, TplNoResult) {
    "use struct";
    var view;
    return view = (function(superClass) {
      var tabOption, tabOption2;

      extend(view, superClass);

      function view() {
        return view.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'myDayMoney',
          text: '我的日工资'
        }
      ];

      if (+localStorage.getItem('userType') === 2) {
        tabOption2 = [
          {
            dataName: 'subordinateDayMoney',
            text: '下级日工资'
          }, {
            dataName: 'manageDayMoney',
            text: '日工资管理'
          }
        ];
        tabOption = tabOption.concat(tabOption2);
      }

      view.prototype.tpls = {
        info: doT.template(TplInfo),
        content: doT.template(TplContent),
        paginate: doT.template(TplPaginate),
        myDayMoney: doT.template(TplMyDayMoney),
        subordinateDayMoney: doT.template(TplSubordinateDayMoney),
        manageDayMoney: doT.template(TplManageDayMoney),
        alert: doT.template(TplAlert),
        noResult: doT.template(TplNoResult)
      };

      view.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .banner .bannerBtn': 'eventSlideBanner',
        'click .tabTitle li': 'eventsTabSwithc',
        'click .table tbody a.details': 'eventOpenDetails',
        'change .toolbar .state': 'eventsChangeStage',
        'click .toolbar button.search': 'eventDateSearch',
        'change .toolbar .stage': 'eventsChangeStep',
        'keyup .serialNumber': 'eventSerialNumber',
        'click .sort i.icon': 'eventsSort',
        'click button.issued': 'eventsIssued'
      };

      view.prototype.initialize = function(data) {
        this.m = null;
        this.c = null;
        new ModelGetCurrentDaySalary().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var liWidth, num, parent;
              data = data.toJSON();
              if (data.code === 0) {
                parent = _this.$el.width() - 114 - 16;
                liWidth = 260;
                num = Math.floor(parent / liWidth);
                _this.current = Math.ceil(data.data.step / num);
                _this.current = +_this.current ? _this.current - 1 : 0;
                data.data.setlist.sort(CSH.views.body.salaryStepSort);
                _this.$el.html(_this.tpls.info({
                  data: data.data,
                  liLength: num
                })).find('.option').html(_this.tpls.content(tabOption));
                _this.li = _this.$el.find('.option .tabTitle li');
                _this.li.eq(0).trigger('click');
                _this.banner = _this.$el.find('.banner');
                _this.bannerInit();
                _this.togglebannerCurrent();
              }
            };
          })(this)
        });
        return this.btn = false;
      };

      view.prototype.render = function(pageInfo) {
        var sort;
        this.showLoading();
        sort = this.toolbar.sort;
        if (sort !== 0 && sort !== 1) {
          sort = void 0;
        } else {
          if (+sort === 1) {
            sort = 'asc';
          } else {
            sort = 'desc';
          }
        }
        this.els.tabContent.html(this.tpls[this.viewName]({
          data: this.c.toJSON(),
          toolbar: this.toolbar,
          sort: sort,
          total: pageInfo.totalAmount,
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: '* 将为您保留最近 6 个月数据'
          }),
          noResult: this.tpls.noResult()
        }));
        setTimeout(((function(_this) {
          return function() {
            return _this.$el.find('select').select2();
          };
        })(this)), 0);
        return this.getDate();
      };

      view.prototype.nowViewName = function() {
        return this.li.filter("[data-name=\"" + this.viewName + "\"]").trigger('click');
      };

      view.prototype.bannerInit = function() {
        var api, target;
        target = this.banner.Swipe();
        api = target.data('Swipe');
        this.bannerApi = api;
        return this.time = null;
      };

      view.prototype.eventSlideBanner = function(event) {
        var el;
        clearTimeout(this.time);
        el = $(event.currentTarget);
        switch (el.attr('data-btn')) {
          case 'prev':
            this.bannerApi.prev();
            break;
          case 'next':
            this.bannerApi.next();
        }
        return this.togglebannerCurrent();
      };

      view.prototype.togglebannerCurrent = function() {
        var index;
        index = this.bannerApi.getPos();
        if (index === this.current) {
          return;
        }
        return this.time = setTimeout((function(_this) {
          return function() {
            return _this.bannerApi.slide(_this.current, 2000);
          };
        })(this), 3000);
      };

      view.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      view.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      view.prototype.eventsTabSwithc = function(event) {
        var el, today;
        el = $(event.currentTarget);
        this.viewName = el.attr('data-name');
        el.addClass('active').siblings('li').removeClass('active');
        this.els = {};
        this.els.tabContent = this.$el.find('.tabContent');
        this.toolbar = {};
        if (this.viewName === 'myDayMoney') {
          this.m = new ModelGetMyDaySalarylist();
          this.c = new CollectionGetMyDaySalarylist();
        } else if (this.viewName === 'subordinateDayMoney') {
          this.m = new ModelgetSubDaySalarylist();
          this.c = new CollectionGetSubDaySalarylist();
          today = new Date().getFormatDate();
          this.toolbar.beginTime = today;
          this.toolbar.endTime = today;
        } else if (this.viewName === 'manageDayMoney') {
          this.m = new ModelSalarymanage();
          this.c = new CollectionSalarymanage();
        }
        return this.fetchData();
      };

      view.prototype.fetchData = function(curPage) {
        var pageSize;
        if (curPage == null) {
          curPage = 1;
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        pageSize = 12;
        if (this.viewName === 'myDayMoney') {
          return this.m.setUrl(curPage + "/" + pageSize).save(this.toolbar, {
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                if (data.code === 0) {
                  _this.c.reset(data.data);
                  _this.render(data.pageInfo);
                }
                return '{}';
              };
            })(this)
          });
        } else if (this.viewName === 'subordinateDayMoney') {
          return this.m.setUrl(curPage + "/" + pageSize).save(this.toolbar, {
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                if (data.code === 0) {
                  _this.c.reset(data.data);
                  _this.render(data.pageInfo);
                }
                return '{}';
              };
            })(this)
          });
        } else if (this.viewName === 'manageDayMoney') {
          this.toolbar.pageIndex = curPage;
          this.toolbar.pageSize = pageSize;
          return this.m.setUrl().save(this.toolbar, {
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                var j, len, ref, salary;
                data = data.toJSON();
                if (data.code === 0) {
                  ref = data.data;
                  for (j = 0, len = ref.length; j < len; j++) {
                    salary = ref[j];
                    salary.listSalarySet.sort(CSH.views.body.salaryStepSort);
                  }
                  _this.c.reset(data.data);
                  _this.render(data.pageInfo);
                }
                return '{}';
              };
            })(this)
          });
        }
      };

      view.prototype.eventOpenDetails = function(event) {
        var el, id;
        if (this.eventRepeatClick()) {
          return;
        }
        this.btn = true;
        el = $(event.currentTarget);
        id = el.closest('tr').attr('data-id');
        return new ModelDetail().setUrl(id).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var els, maxH, modalBox, scrollHeight, surplus;
              data = data.toJSON();
              if (+data.code === 0) {
                modalBox = CSH.alert({
                  title: '日工资详情',
                  content: _this.tpls.alert({
                    name: 'details',
                    data: data.data
                  }),
                  className: 'details dayMoney'
                });
                els = {};
                els.$window = $(window);
                els.modalBody = modalBox.find('.modal-body');
                surplus = 100;
                maxH = els.modalBody.height();
                scrollHeight = function() {
                  var modalBodyH, windowH;
                  windowH = els.$window.height() * 0.9;
                  modalBodyH = els.modalBody.outerHeight();
                  if (modalBodyH + surplus > windowH || modalBodyH < maxH) {
                    return els.modalBody.css({
                      height: windowH - surplus
                    });
                  }
                };
                scrollHeight();
                els.$window.on('resize', scrollHeight);
              }
              return '{}';
            };
          })(this)
        });
      };

      view.prototype.eventsChangeStage = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.state = +el.val();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventsChangeStep = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            _this.toolbar.step = +el.val();
            return _this.fetchData();
          };
        })(this));
      };

      view.prototype.eventSerialNumber = function(event) {
        if (event.keyCode === 13) {
          return this.eventDateSearch(event);
        }
      };

      view.prototype.eventDateSearch = function(el) {
        var val;
        if (this.viewName === 'manageDayMoney') {
          val = this.els.serialNumber.val().trim();
          if (!val) {
            this.toolbar.username = void 0;
          } else {
            this.toolbar.username = val;
          }
        }
        return this.fetchData();
      };

      view.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (+this.toolbar.sort === +el.attr('data-sort')) {
          return;
        }
        this.toolbar.sort = +el.attr('data-sort');
        return this.fetchData();
      };

      view.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };


      /*
      			成员管理：
      			memberManagement
      			有一模一样的代码 如果修改下面代码需要那边也一起修改
       */

      view.prototype.eventOpenSalaty = function(event) {
        if (this.eventRepeatClick()) {
          return;
        }
        this.btn = true;
        return this.changeSalary(event, 'Open');
      };

      view.prototype.eventOpenAdjust = function(event) {
        if (this.eventRepeatClick()) {
          return;
        }
        this.btn = true;
        return this.changeSalary(event, 'Adjust');
      };

      view.prototype.changeSalary = function(event, change) {
        var el, els, init, item, minRatio, mySalaryState, name, text, tr, type;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        name = tr.attr('data-name');
        type = tr.attr('data-type');
        minRatio = null;
        els = {};
        item = {};
        text = '调整';
        mySalaryState = +localStorage.getItem('salaryState');
        if (mySalaryState !== 0) {
          text += '日工资';
        }
        new ModelGetMemberiInfoByNameNew().setUrl(name).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var modelsBox;
              data = data.toJSON();
              if (+data.code === 0) {
                data = data.data;
                _this.stage = change === 'Adjust' ? data.salarylist.length : 2;
                minRatio = data.minRatio;
                modelsBox = CSH.alert({
                  title: text,
                  content: _this.tpls.alert({
                    name: "userCenter" + change,
                    data: data,
                    type: type
                  }),
                  className: "userCenter" + change,
                  ok: {
                    text: '调整',
                    autohide: false,
                    callback: function(event) {
                      var i, j, k, l, m, ratio, ref, ref1, ref2, ref3, val;
                      el = $(event.currentTarget);
                      el.prop('disabled', true);
                      val = [];
                      if (+type === 2) {
                        if (!els.dayMoneyBottom.is(':hidden')) {
                          if (!(els.people.eq(0).val() || els.amount.eq(0).val())) {
                            el.prop('disabled', false);
                            return CSH.hint('请输入正确购彩量或者活跃用户');
                          }
                          for (i = j = 0, ref = _this.stage - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                            ratio = parseFloat(els.salary.eq(i).text());
                            if (!ratio) {
                              el.prop('disabled', false);
                              return CSH.hint({
                                msg: '日工资比例不能设置为0.00%'
                              });
                            }
                            val.push({
                              step: i + 1,
                              ratio: +(ratio * 0.01).accurate(4),
                              memberCount: els.people.eq(i).val() ? +els.people.eq(i).val() : 0,
                              targetAmount: els.amount.eq(i).val() * 10000
                            });
                          }
                          if (_this.stage !== 1) {
                            for (i = k = 0, ref1 = _this.stage - 2; 0 <= ref1 ? k <= ref1 : k >= ref1; i = 0 <= ref1 ? ++k : --k) {
                              if (val[i].ratio >= val[i + 1].ratio) {
                                el.prop('disabled', false);
                                return CSH.hint('上一阶段日工资比例不能比下一阶段低');
                              }
                              if (val[i].memberCount === val[i + 1].memberCount && val[i].targetAmount === val[i + 1].targetAmount) {
                                el.prop('disabled', false);
                                return CSH.hint('上一阶段不能跟下一阶相同');
                              } else if (val[i].memberCount > val[i + 1].memberCount || val[i].targetAmount > val[i + 1].targetAmount) {
                                el.prop('disabled', false);
                                return CSH.hint('上一阶不能低于下一阶');
                              }
                            }
                          }
                          if (minRatio !== 0) {
                            if (minRatio < val[_this.stage - 1].ratio) {
                              el.prop('disabled', false);
                              return CSH.hint('调整不能低于当前代理最大的比例');
                            }
                          }
                        }
                      } else {
                        if (!els.dayMoneyBottom.is(':hidden')) {
                          if (!els.amount.eq(0).val()) {
                            el.prop('disabled', false);
                            return CSH.hint('请输入正确购彩量');
                          }
                          for (i = l = 0, ref2 = _this.stage - 1; 0 <= ref2 ? l <= ref2 : l >= ref2; i = 0 <= ref2 ? ++l : --l) {
                            ratio = parseFloat(els.salary.eq(i).text());
                            if (!ratio) {
                              el.prop('disabled', false);
                              return CSH.hint({
                                msg: '日工资比例不能设置为0.00%'
                              });
                            }
                            val.push({
                              step: i + 1,
                              ratio: +(ratio * 0.01).accurate(4),
                              memberCount: 0,
                              targetAmount: els.amount.eq(i).val() * 10000
                            });
                          }
                          if (_this.stage !== 1) {
                            for (i = m = 0, ref3 = _this.stage - 2; 0 <= ref3 ? m <= ref3 : m >= ref3; i = 0 <= ref3 ? ++m : --m) {
                              if (val[i].ratio >= val[i + 1].ratio) {
                                el.prop('disabled', false);
                                return CSH.hint('上一阶段日工资比例不能比下一阶段低');
                              }
                              if (val[i].targetAmount >= val[i + 1].targetAmount) {
                                el.prop('disabled', false);
                                return CSH.hint('上一阶不能低于或等于下一阶');
                              }
                            }
                          }
                        }
                      }
                      item = {
                        userName: data.userName,
                        userType: data.userType
                      };
                      item.salarylist = els.dayMoneyBottom.is(':hidden') ? [] : val;
                      item.rebateRate = change === 'Open' ? +els.rebate.text() : data.rebateRate;
                      return new ModelMembersnew().setUrl().save(item, {
                        dataFilter: function(data) {
                          data = data.toJSON();
                          if (+data.code === 0) {
                            els.modelsBox.trigger('hidden');
                            $('.fade').hide();
                            CSH.hint({
                              msg: data.message,
                              type: 'success',
                              icon: 'icon icon-ok'
                            });
                            _this.nowViewName();
                          } else {
                            el.prop('disabled', false);
                            CSH.hint(data.message);
                          }
                          return '{}';
                        }
                      });
                    }
                  }
                });
                init(modelsBox);
              }
              return '{}';
            };
          })(this)
        });
        return init = (function(_this) {
          return function(modelsBox) {
            var addStage, disableds, eventToggle, eventsSlide, getDate, i, j, minRebate, myRebate, mySalary, openSalary, rebateD, ref, removeStage, results, salaryD, xMax, xMin;
            els.modelsBox = modelsBox;
            els.dayMoneyTopRadio = els.modelsBox.find('.dayMoneyTop .btns button');
            els.dayMoneyBottom = els.modelsBox.find('.dayMoneyBottom');
            els.stageWrap = els.dayMoneyBottom.find('.stageWrap');
            els.stage = els.stageWrap.find('.stage');
            els.salary = els.stage.find('.salary');
            els.amount = els.stage.find('input[data-type="amount"]');
            els.people = els.stage.find('input[data-type="people"]');
            els.removeBtn = els.stage.find('.removeBtn');
            els.addStageBtn = els.dayMoneyBottom.find('.addStageWrap .addStageBtn');
            els.num = els.dayMoneyBottom.find('.addStageWrap .num');
            els.rebate = els.modelsBox.find('.rebate');
            disableds = false;
            if (change === 'Open' && mySalaryState === 2) {
              disableds = true;
            }
            addStage = function(event) {
              var str;
              if (_this.stage === 20) {
                return;
              }
              if (event) {
                _this.stage++;
              }
              els.num.text(_this.stage);
              str = $("<div class=\"stage clear\" style=\"display: none\">\n	<div class=\"stageLeft\">\n		<button class=\"adjustBtn arrow salary\">0.00%</button>\n		<span class=\"wrapAdjust\">\n			<span class=\"adjust\">\n				<span class=\"wrapBg\">\n					<span class=\"bg\"></span>\n				</span>\n				<i class=\"roundBtn salary\"></i>\n			</span>\n		</span>\n	</div>\n	<div class=\"stageRight " + (+type === 1 ? 'type' : '') + "\">\n		<label>\n		<input type=\"number\" data-type=\"amount\" placeholder=\"购彩量\" />\n			万\n		</label>\n		<label>\n		<input type=\"number\" data-type=\"people\" placeholder=\"活跃用户\" />\n			人\n		</label>\n	</div>\n	<button class=\"removeBtn\">删除</button>\n</div>");
              els.stageWrap.append(str);
              str.slideDown();
              return getDate();
            };
            removeStage = function(event) {
              var parent;
              _this.stage--;
              getDate();
              els.num.text(_this.stage);
              el = $(event.currentTarget);
              parent = el.closest('.stage');
              return parent.slideUp(function() {
                return parent.remove();
              });
            };
            myRebate = localStorage.getItem('rebate');
            mySalary = localStorage.getItem('salary');
            minRebate = +els.rebate.text();
            salaryD = mySalary * 1000 * 1000;
            rebateD = myRebate - minRebate;
            xMin = 0;
            xMax = 260;
            eventsSlide = function(event) {
              var bg, xInte;
              event.stopPropagation();
              el = $(event.currentTarget);
              xInte = event.clientX - el.position().left;
              bg = el.prev('.wrapBg').find('.bg');
              els.modelsBox.on('mousemove.slide', (function(_this) {
                return function(event) {
                  var dValue, elWrapAdjust, nowRebate, rebate, salary, xNow;
                  xNow = event.clientX - xInte;
                  if (xNow < xMin) {
                    xNow = xMin;
                  }
                  if (xNow > xMax) {
                    xNow = xMax;
                  }
                  dValue = xNow / xMax;
                  elWrapAdjust = el.closest('.wrapAdjust');
                  rebate = elWrapAdjust.prev('.rebate');
                  if (rebate[0]) {
                    nowRebate = Math.round(dValue * rebateD);
                    nowRebate = nowRebate % 2 ? nowRebate + 1 : nowRebate;
                    rebate.text(nowRebate + minRebate > myRebate ? myRebate : nowRebate + minRebate);
                  }
                  salary = elWrapAdjust.prev('.salary');
                  if (salary[0]) {
                    text = dValue * salaryD;
                    text = Math.round(text * 0.01);
                    text = text * 0.01;
                    salary.text((text.accurate(2)) + "%");
                  }
                  el.css('left', xNow);
                  return bg.css('width', xNow);
                };
              })(this));
              return els.modelsBox.on('mouseup.slide', (function(_this) {
                return function(event) {
                  return els.modelsBox.off('.slide');
                };
              })(this));
            };
            eventToggle = function(event) {
              var adjustBtn, speed, wrapAdjust;
              speed = 200;
              el = $(event.target);
              wrapAdjust = $(el.closest('.wrapAdjust')[0]);
              adjustBtn = $(el.closest('.adjustBtn')[0]);
              els.adjustBtn.addClass('arrow').removeClass('arrowTopple');
              if (adjustBtn.hasClass('arrow')) {
                adjustBtn.addClass('arrowTopple').removeClass('arrow');
                if (el.hasClass('salary')) {
                  return els.stageWrap.animate({
                    'scrollTop': el.closest('.stage').position().top + els.stageWrap.scrollTop()
                  });
                }
              } else {
                return adjustBtn.removeClass('arrowTopple').addClass('arrow');
              }
            };
            openSalary = function(event) {
              el = $(event.currentTarget);
              if (+el.attr('data-off')) {
                return els.dayMoneyBottom.show();
              } else {
                return els.dayMoneyBottom.hide();
              }
            };
            els.dayMoneyTopRadio.on('click', openSalary);
            els.addStageBtn.on('click', addStage);
            els.dayMoneyBottom.on('click', '.removeBtn', removeStage);
            els.modelsBox.on('click', eventToggle);
            els.modelsBox.on('mousedown', '.roundBtn', eventsSlide);
            getDate = function() {
              els.adjustBtn = els.stageWrap.find('.adjustBtn');
              els.salary = els.stageWrap.find('.adjustBtn.salary');
              els.amount = els.stageWrap.find('input[data-type="amount"]');
              return els.people = els.stageWrap.find('input[data-type="people"]');
            };
            getDate();
            if (change === 'Open') {
              results = [];
              for (i = j = 0, ref = _this.stage - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                results.push(addStage());
              }
              return results;
            }
          };
        })(this);
      };

      view.prototype.eventRepeatClick = function() {
        setTimeout(((function(_this) {
          return function() {
            return _this.btn = false;
          };
        })(this)), 1000);
        return this.btn;
      };

      view.prototype.eventsIssued = function(event) {
        var el, id;
        el = $(event.currentTarget);
        id = el.closest('tr').attr('data-id');
        return new ModelGiveout().setUrl(id).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (+data.code === 0) {
                _this.nowViewName();
              }
              CSH.hint(data.message);
              return '{}';
            };
          })(this)
        });
      };

      view.prototype.getDate = function() {
        var minDate, myDate, toDay;
        this.els.toolbar = this.$el.find(' .toolbar');
        this.els.serialNumber = this.els.toolbar.find(' .serialNumber');
        this.els.dateStart = this.els.toolbar.find(' #dateStart');
        this.els.dateEnd = this.els.toolbar.find(' #dateEnd');
        toDay = new Date().getFormatDate();
        myDate = new Date();
        minDate = new Date(myDate.setMonth(myDate.getMonth() - 6)).getFormatDate();
        this.els.dateStart.datetimepicker({
          useCurrent: false,
          format: 'YYYY-MM-DD',
          defaultDate: toDay
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay);
        this.els.dateEnd.datetimepicker({
          useCurrent: false,
          format: 'YYYY-MM-DD',
          defaultDate: toDay
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay);
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            _this.els.dateEnd.val(_this.els.dateEnd.val());
            _this.toolbar.beginTime = el.val();
            _this.toolbar.endTime = _this.els.dateEnd.val().trim();
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            _this.els.dateStart.val(_this.els.dateStart.val());
            _this.toolbar.endTime = el.val();
            _this.toolbar.beginTime = _this.els.dateStart.val();
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
        if (this.toolbar.beginTime) {
          this.els.dateStart.val(this.toolbar.beginTime);
          return this.els.dateEnd.val(this.toolbar.endTime);
        } else {
          this.els.dateStart.val('');
          return this.els.dateEnd.val('');
        }
      };

      return view;

    })(Backbone.View);
  });

}).call(this);
