(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'sortable', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-modal.tpl', 'text!../../../templates/smartyy-modal_adjustQuickEntry.tpl'], function($, _, Backbone, doT, Sortable, TplLoading, TplModal, TplModalAdjustQE) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        modal: doT.template(TplModal),
        mAdjustQE: doT.template(TplModalAdjustQE)
      };

      View.prototype.events = {
        'click button.adjustQE': 'eventAdjustQE'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        this.data = {};
        this.xhr = {};
        return this.render();
      };

      View.prototype.render = function() {
        return this.fetchQuickEntry((function(_this) {
          return function(data) {
            var arr, dict, i, k, len, list, v;
            dict = data;
            list = localStorage.getItem('rs_qeList');
            _this.data.qeDict = dict;
            for (k in dict) {
              v = dict[k];
              v.name = k;
            }
            if (list) {
              arr = list.split(',');
              list = [];
              for (i = 0, len = arr.length; i < len; i++) {
                k = arr[i];
                list.push(dict[k]);
              }
            } else {
              list = [];
              for (k in dict) {
                v = dict[k];
                list.push(v);
              }
              list.sort(function(a, b) {
                return a.i - b.i;
              });
              list = list.slice(0, 8);
            }
            _this.data.qeList = list;
            return _this.refreshQE();
          };
        })(this));
      };

      View.prototype.destroy = function() {
        this.$el.off();
        return null;
      };

      View.prototype.refreshQE = function() {
        var box, i, item, len, list, str, target, url;
        box = this.$el.children('.box');
        list = this.data.qeList;
        str = '';
        for (i = 0, len = list.length; i < len; i++) {
          item = list[i];
          target = item.tartet || '_self';
          url = item.url;
          if (!url) {
            switch (item.name) {
              case 'xljc':
                url = _speedLink;
                break;
              case 'lxkf':
                url = _serviceUrl;
            }
          }
          str += "<div class=\"items\">\n	<a href=\"" + url + "\" target=\"" + target + "\">\n		<span class=\"icon icon-" + item.icon + "\"></span>\n		<span class=\"text\">" + item.text + "</span>\n	</a>\n</div>";
        }
        box.html(str.encodeHTML(true));
        if (typeof this.dataLoaded === "function") {
          this.dataLoaded();
        }
        return delete this.dataLoaded;
      };

      View.prototype.fetchQuickEntry = function(callback) {
        this.data.isLoaded = 0;
        return $.ajax({
          url: CSH.path.fapi + "/quickEntryDict",
          success: (function(_this) {
            return function(data) {
              _this.data.isLoaded = 1;
              if (data.code) {
                return;
              }
              if (0 === +localStorage.getItem('contractState')) {
                delete data.data.qyfh;
              }
              if (0 === +localStorage.getItem('salaryState')) {
                delete data.data.rgz;
              }
              if (1 === +localStorage.getItem('userType')) {
                delete data.data.gcbb;
                delete data.data.iygl;
                delete data.data.iyvb;
                delete data.data.tdgl;
                delete data.data.tdyk;
                delete data.data.tgkh;
              }
              return callback(data.data);
            };
          })(this)
        });
      };

      View.prototype.eventAdjustQE = function(event) {
        var chosenBox, elCount, i, item, j, k, l, len, len1, len2, modalBox, o, qeWrap, ref, ref1, sortable, tag, temp, tempArr, text, totalCount, totalList, totalMap, v;
        totalList = [];
        totalMap = {};
        tempArr = [];
        ref = this.data.qeDict;
        for (k in ref) {
          v = ref[k];
          temp = _.clone(v);
          temp.name = k;
          ref1 = this.data.qeList;
          for (i = 0, len = ref1.length; i < len; i++) {
            o = ref1[i];
            if (o.name !== k) {
              continue;
            }
            temp.checked = 1;
            break;
          }
          tempArr.push(temp);
        }
        tempArr = tempArr.sort(function(a, b) {
          return a.i - b.i;
        });
        totalCount = tempArr.length;
        for (j = 0, len1 = tempArr.length; j < len1; j++) {
          item = tempArr[j];
          tag = item.tag;
          if (totalMap[tag] == null) {
            totalMap[tag] = [];
          }
          totalMap[tag].push(item);
        }
        tempArr = ['我的账户', '报表管理', '平台福利', '代理中心', '其　　他'];
        for (l = 0, len2 = tempArr.length; l < len2; l++) {
          text = tempArr[l];
          totalList.push({
            text: text,
            data: totalMap[text]
          });
        }
        modalBox = $(this.tpls.modal({
          title: '快捷入口',
          className: 'modal-adjustQE modal-large',
          content: this.tpls.mAdjustQE({
            totalCount: totalCount,
            chosenList: this.data.qeList,
            totalList: totalList
          })
        }));
        chosenBox = modalBox.find('.chosenBox');
        qeWrap = modalBox.find('.qeWrap');
        elCount = modalBox.find('.chosenMsg strong');
        sortable = Sortable.create(chosenBox[0], {
          animation: 150,
          filter: 'i',
          onEnd: function(event) {
            var target;
            target = $(event.item);
            target.addClass('shaking');
            return setTimeout(function() {
              return target.removeClass('shaking');
            }, 400);
          },
          onFilter: function(event) {
            var target;
            target = $(event.item);
            return modalBox.trigger('unselectItem', [target.attr('data-name')]);
          }
        });
        modalBox.data({
          sortable: sortable,
          els: {
            chosenBox: chosenBox,
            qeWrap: qeWrap
          }
        }).on('hidden', function() {
          sortable.destroy();
          return modalBox.off().remove();
        }).on('mouseenter', '.modal-body .chosenBox li', function(event) {
          return $(event.currentTarget).addClass('hover');
        }).on('mouseleave', '.modal-body .chosenBox li', function(event) {
          return $(event.currentTarget).removeClass('hover');
        }).on('updateCount', function(event, b) {
          return elCount.text(b ? +elCount.text() + 1 : elCount.text() - 1);
        }).on('unselectItem', (function(_this) {
          return function(event, name) {
            return _this.unselectQEItem(modalBox, name);
          };
        })(this)).on('selectItem', (function(_this) {
          return function(event, name) {
            return _this.selectQEItem(modalBox, name);
          };
        })(this)).on('change', '.modal-body input[type="checkbox"]', (function(_this) {
          return function(event) {
            return _this.eventChangeQESelectState(event, modalBox);
          };
        })(this)).on('disableCheckboxes', (function(_this) {
          return function(event, b) {
            return _this.disableCheckboxes(modalBox, !!b);
          };
        })(this)).on('click', '.btn[btn-type="ok"]', (function(_this) {
          return function() {
            return _this.saveData(modalBox);
          };
        })(this));
        modalBox.appendTo(CSH.$els.body);
        return modalBox.modal('show');
      };

      View.prototype.unselectQEItem = function(modalBox, name) {
        var chosenBox, qeWrap, target1, target2;
        chosenBox = modalBox.find('ul.chosenBox');
        target1 = chosenBox.find("[data-name=\"" + name + "\"]");
        if (target1[0]) {
          target1.animate({
            opacity: 0
          }, 200, function() {
            return target1.remove();
          });
        }
        modalBox.trigger('updateCount', [0]);
        qeWrap = modalBox.find('.qeWrap');
        target2 = qeWrap.find("[type=\"checkbox\"][data-name=\"" + name + "\"]");
        if (target2.prop('checked')) {
          target2.prop({
            checked: false
          }).parent().removeClass('checked');
        }
        return modalBox.trigger('disableCheckboxes', [0]);
      };

      View.prototype.selectQEItem = function(modalBox, name) {
        var item, target, text;
        text = this.data.qeDict[name].text;
        target = modalBox.data('els').chosenBox;
        item = $("<li data-name=\"" + name + "\" style=\"opacity: 0;\">\n	<span class=\"text\">" + text + "</span>\n	<i class=\"icon icon-wrong\"></i>\n</li>");
        item.appendTo(target).animate({
          opacity: 1
        }, 200);
        modalBox.trigger('updateCount', [1]);
        if (!(target.children('li').length < 12)) {
          return modalBox.trigger('disableCheckboxes', [1]);
        }
      };

      View.prototype.eventChangeQESelectState = function(event, modalBox) {
        var b, el;
        el = $(event.currentTarget);
        b = el.prop('checked');
        return modalBox.trigger((b ? '' : 'un') + "selectItem", el.attr('data-name'));
      };

      View.prototype.disableCheckboxes = function(modalBox, b) {
        var qeWrap, targets;
        qeWrap = modalBox.data('els').qeWrap;
        if (b && qeWrap.hasClass('disabled')) {
          return;
        }
        if (!(b || qeWrap.hasClass('disabled'))) {
          return;
        }
        qeWrap.toggleClass('disabled', b);
        targets = qeWrap.find('input[type="checkbox"]:not(:checked)');
        return targets.prop({
          disabled: b
        }).parent().prop({
          disabled: b
        });
      };

      View.prototype.saveData = function(modalBox) {
        var arr, chosenBox, list, qeDict, qeList;
        chosenBox = modalBox.data('els').chosenBox;
        arr = chosenBox.children('li');
        qeDict = this.data.qeDict;
        list = [];
        qeList = [];
        arr.each(function() {
          var el, name, obj;
          el = $(this);
          name = el.attr('data-name');
          obj = _.clone(qeDict[name]);
          obj.name = name;
          list.push(name);
          return qeList.push(obj);
        });
        localStorage.setItem('rs_qeList', list.join(','));
        this.data.qeList = qeList;
        this.refreshQE();
        modalBox.modal('hide');
        return CSH.hint('保存成功');
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
