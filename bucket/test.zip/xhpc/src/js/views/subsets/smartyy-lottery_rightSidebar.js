(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/history', 'models/announceByPage', 'models/activitys', 'views/subsets/smartyy-lottery_rightSidebar_qe', 'views/subsets/smartyy-lottery_rightSidebar_list', 'text!../../../templates/subsets/smartyy-lottery_rightSidebar.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-modal.tpl'], function($, _, Backbone, doT, ModelHistory, ModelAnnounceByPage, ModelActivitys, ViewQE, ViewList, TplContent, TplLoading, TplModal) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.resetState = bind(this.resetState, this);
        this.initIntervalNotices = bind(this.initIntervalNotices, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        modal: doT.template(TplModal)
      };

      View.prototype.events = {
        'click .arrowWrap .handle': 'eventToggleSidebarState',
        'click .arrowWrap .promptRsidebar': 'eventHidePromptRsidebar'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        CSH.views['rSidebar'] = this;
        this.data = {};
        this.views = {};
        this.data.interval = {};
        this.xhr = {};
        this.m_history = new ModelHistory();
        this.m_announce = new ModelAnnounceByPage();
        this.m_activity = new ModelActivitys();
        return this.render();
      };

      View.prototype.destroy = function() {
        var id, k, ref, ref1, ref2, v;
        if (this.$el.is('.expand')) {
          this.els.arrowHandle.trigger('click');
        }
        this.$el.off();
        this.els.sidebarWrap.empty();
        CSH.$els.window.off('resize', this.resetState);
        delete CSH.views.rSidebar;
        ref = this.data.interval;
        for (k in ref) {
          id = ref[k];
          clearInterval(id);
        }
        ref1 = this.views;
        for (k in ref1) {
          if (!hasProp.call(ref1, k)) continue;
          v = ref1[k];
          if (typeof v.destroy === "function") {
            if ((ref2 = v.destroy()) != null) {
              ref2.remove();
            }
          }
        }
        return null;
      };

      View.prototype.render = function() {
        this.els = {};
        this.els.arrowHandle = this.$el.find('.arrowWrap .handle');
        this.els.promptRsidebar = this.$el.find('.arrowWrap .promptRsidebar');
        this.els.sidebarWrap = this.$el.find('.sidebarWrap');
        this.els.sidebarWrap.html(this.tpls.content());
        this.els.noticeContent = this.$el.find('.noticeContent');
        this.els.quickEntryWrap = this.$el.find('.quickEntryWrap');
        this.els.dataListWrap = this.$el.find('.dataListWrap');
        this.els.tabTitle = this.$el.find('.tabTitle');
        this.els.tabContent = this.$el.find('.tabContent');
        this.renderNotices();
        this.views.qe = new ViewQE({
          el: this.els.quickEntryWrap,
          parent: this
        });
        this.views.list = new ViewList({
          el: this.els.dataListWrap,
          parent: this
        });
        CSH.$els.window.on('resize', this.resetState);
        if (!+localStorage.getItem('isCollapsedRS')) {
          return this.els.arrowHandle.trigger('click', true);
        } else {
          if (!+localStorage.getItem('promptRsidebar')) {
            return this.els.promptRsidebar.addClass('show');
          }
        }
      };

      View.prototype.renderNotices = function() {
        return this.fetch_notices((function(_this) {
          return function(data) {
            var arr, box, cls, href, i, info, j, ref, text;
            box = _this.els.noticeContent;
            arr = [];
            for (i = j = 0, ref = data.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
              info = data[i];
              href = "na.html#notice/" + (info.id.toString().encodeHTML());
              cls = info.announceType === 1 ? 'text-red' : '';
              text = info.announceName.encodeHTML();
              arr.push("<li class=\"clear\">\n	<a href=\"" + href + "\" class=\"" + cls + "\">" + text + "</a>\n</li>");
            }
            if (data.length !== 1) {
              arr.push(arr[0]);
            }
            box.html(arr.join(''));
            if (data.length === 1) {
              return;
            }
            return _this.initIntervalNotices();
          };
        })(this));
      };

      View.prototype.initIntervalNotices = function() {
        var box, fun, i, max;
        i = 0;
        box = this.els.noticeContent;
        max = box.children().length - 1;
        fun = function() {
          ++i;
          return box.animate({
            scrollTop: box.scrollTop() + 20
          }, 200, function() {
            if (i !== max) {
              return;
            }
            return box.scrollTop(i = 0);
          });
        };
        this.data.interval.notices = setInterval(fun, 3000);
        return box.on('mouseenter', (function(_this) {
          return function() {
            return clearInterval(_this.data.interval.notices);
          };
        })(this)).on('mouseleave', (function(_this) {
          return function() {
            return _this.data.interval.notices = setInterval(fun, 3000);
          };
        })(this));
      };

      View.prototype.resetState = function() {
        var key, st;
        st = CSH.$els.window.width() > CSH.$els.sidebar.width() + 980 + 30 * 2 + 350;
        key = st ? 'removeClass' : 'addClass';
        return this.$el[key]('fixed');
      };

      View.prototype.eventToggleSidebarState = function(event, isFromSys) {
        var deg, el, icon, toEp;
        el = $(event.currentTarget);
        icon = el.find('.icon');
        deg = icon.attr('data-deg') || 180;
        deg = +deg;
        deg += 180;
        toEp = !this.$el.hasClass('expand');
        if (!+localStorage.getItem('promptRsidebar')) {
          this.els.promptRsidebar[toEp ? 'removeClass' : 'addClass']('show');
        }
        if (!isFromSys) {
          localStorage.setItem('isCollapsedRS', +(!toEp));
        }
        if (!toEp) {
          this.views.list.rsCollapsing();
        }
        this.resetState();
        this.$el.toggleClass('expand');
        icon.attr('data-deg', deg).css({
          transform: "rotate(" + deg + "deg)"
        });
        if (toEp) {
          setTimeout(((function(_this) {
            return function() {
              return _this.views.list.rsExpanded();
            };
          })(this)), 250);
        }
        if (toEp) {
          return this.views.list.rsExpanded();
        }
      };

      View.prototype.eventHidePromptRsidebar = function() {
        var toEp;
        toEp = !this.$el.hasClass('expand');
        localStorage.setItem('promptRsidebar', 1);
        this.els.promptRsidebar.removeClass('show');
        if (toEp) {
          return this.views.list.rsExpanded();
        }
      };

      View.prototype.fetch_notices = function(callback) {
        var ref;
        if ((ref = this.xhr.notice) != null) {
          ref.abort();
        }
        return this.m_announce.setUrl(1, 3).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr.notice = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON().data;
              callback(data);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.refreshHistoryRecords = function() {
        var ref, v;
        v = this.views.list;
        if ((ref = v.data.type) !== 'historyRecords') {
          return;
        }
        return v.els.refresh.trigger('click');
      };

      View.prototype.refreshLotteryAndTrackRecords = function() {
        var ref, v;
        v = this.views.list;
        if ((ref = v.data.type) !== 'gameRecords' && ref !== 'trackRecords') {
          return;
        }
        return v.els.refresh.trigger('click');
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
