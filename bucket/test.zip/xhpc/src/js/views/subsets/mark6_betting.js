(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; },
    slice = [].slice;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/lotterybetting', 'models/future', 'models/codestatistics', 'collections/rebaterate', 'text!../../../templates/subsets/mark6_betting.tpl', 'text!../../../templates/subsets/mark6_menu2nd.tpl', 'text!../../../templates/subsets/lottery_betList.tpl', 'text!../../../templates/_contentLoading.tpl', 'text!../../../templates/_modal.tpl', 'text!../../../templates/modal_mark6_betList.tpl', 'face/6'], function($, _, Backbone, doT, ModelLotterybetting, ModelFuture, ModelCodeStatistics, CollectionRebaterate, TplContent, TplMenu2nd, TplBetList, TplLoading, TplModal, TplModalBetList) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.showResult = bind(this.showResult, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        betList: doT.template(TplBetList),
        modal: doT.template(TplModal),
        m2: doT.template(TplMenu2nd),
        mBetList: doT.template(TplModalBetList)
      };

      View.prototype.events = {
        'click .menu1stBox a': 'eventSwitch1stMenu',
        'click .menu2ndBox a': 'eventSwitch2ndMenu',
        'focus .numberBox input.money': 'eventFocusMoneyInput',
        'blur .numberBox input.money': 'eventBlurMoneyInput',
        'keyup .numberBox input.money': 'eventKeyupMoneyInput',
        'change .numberBox input[type="checkbox"]': 'eventChangeInput',
        'mousedown .rapidBox span': 'eventSelectRapidMoney',
        'click button.switchRebate': 'eventSwitchRebate',
        'focus .infoBox input.money': 'eventFocusCbMoneyInput',
        'blur .infoBox input.money': 'eventBlurCbMoneyInput',
        'keyup .infoBox input.money': 'eventKeyupCbMoneyInput',
        'click .reset': 'eventReset',
        'click .toolBox button[data-filter]': 'eventClickToolBoxBtn',
        'keyup .toolBox input[name="money"]': 'eventKeyupToolBoxSetMoney',
        'focus .toolBox input[name="money"]': 'eventFocusToolBoxSetMoney',
        'blur .toolBox input[name="money"]': 'eventBlurToolBoxSetMoney',
        'keyup .toolBox input[name="filterNumber"]': 'eventKeyupToolBoxFilterNumber',
        'change .toolBox input[name="switchRapidMoney"]': 'eventSwitchRapidMoney',
        'click .toolBox a.resetRapidMoney': 'eventResetRapidMoney',
        'click button.bet': 'eventBet'
      };

      View.prototype.initialize = function(data) {
        var temp;
        window.vb = this;
        this.parent = data.parent;
        this.algorithm = data.algorithm;
        temp = +localStorage.getItem('rebate');
        this.data = {
          rebateRateList: [
            {
              value: 1800,
              percent: 0
            }
          ]
        };
        temp = localStorage.getItem('rapidList');
        this.data.rapidList = temp ? temp.split(',') : [5, 100, 2000];
        this.xhr = null;
        return this.loadMethodFilter();
      };

      View.prototype.loadMethodFilter = function() {
        return $.ajax({
          url: CSH.path.fapi + "/blistMethod",
          headers: {
            maxAge: 60000
          },
          success: (function(_this) {
            return function(data) {
              if (data.code) {
                return;
              }
              return _this.render(data.data);
            };
          })(this)
        });
      };

      View.prototype.render = function(blist) {
        var contentWrap, face, l, len, len1, len2, len3, m, m1, m1s, m2, m2s, mf, o, p, q, ref, ref1, ref2, str, tag, totalEls;
        face = CSH.utils.clone(CSH.face['6']);
        this.face = face;
        mf = (function() {
          var l, len, ref, results;
          ref = blist[CSH.gID] || [];
          results = [];
          for (l = 0, len = ref.length; l < len; l++) {
            str = ref[l];
            results.push(str);
          }
          return results;
        })();
        if (mf) {
          m1s = [];
          for (l = 0, len = face.length; l < len; l++) {
            o = face[l];
            m1s.push(o);
          }
          for (m = 0, len1 = face.length; m < len1; m++) {
            m1 = face[m];
            tag = m1.tag;
            if (tag != null) {
              if (indexOf.call(mf, tag) >= 0) {
                m1s.remove(m1);
              }
            } else {
              m2s = [];
              ref = m1.labels;
              for (p = 0, len2 = ref.length; p < len2; p++) {
                o = ref[p];
                m2s.push(o);
              }
              ref1 = m1.labels;
              for (q = 0, len3 = ref1.length; q < len3; q++) {
                m2 = ref1[q];
                if (ref2 = m2.tag, indexOf.call(mf, ref2) >= 0) {
                  m2s.remove(m2);
                }
              }
              m1.labels = m2s;
              if (!m2s.length) {
                m1s.remove(m1);
              }
            }
          }
          this.face = m1s;
        }
        this.$el.html(this.tpls.content({
          data: this.face,
          rebate: this.data.rebateRateList
        }));
        this.els = {};
        this.els.menu1stBox = this.$el.find('> .menu1stBox');
        contentWrap = this.$el.find('> .contentWrap');
        this.els.bettingBox = contentWrap.find('> .bettingBox');
        this.els.toolBox = contentWrap.find('> .toolBox');
        this.els.menu2ndBox = this.els.bettingBox.find('> .menu2ndBox');
        this.els.description = this.els.bettingBox.find('> .description');
        this.els.numberBox = this.els.bettingBox.find('> .numberBox');
        this.els.infoBox = this.els.bettingBox.find('> .infoBox');
        this.els.switchRebate = this.els.description.find('button.switchRebate');
        this.els.filterBtns = this.els.toolBox.find('button[data-filter]');
        this.els.setMoney = this.els.toolBox.find('input[name="money"]');
        this.els.filterNumber = this.els.toolBox.find('input[name="filterNumber"]');
        this.els.cbMoneyBox = this.els.infoBox.find('.cbMoneyBox');
        this.els.cbMoney = this.els.cbMoneyBox.find('input.money');
        totalEls = this.els.infoBox.find('span.num');
        this.els.totalCount = totalEls.filter('[data-type="count"]');
        this.els.totalMoney = totalEls.filter('[data-type="money"]');
        this.els.totalRebate = totalEls.filter('[data-type="rebate"]');
        this.els.bet = this.$el.find('button.bet');
        this.els.rebateBox = this.els.infoBox.find('.rebateBox');
        this.els.toolBox.find('input:text').formatInsert({
          type: 'int'
        });
        this.els.cbMoneyBox.find('input').formatInsert({
          type: 'int'
        });
        this.els.description.find('button.switchRebate:first').click();
        this.els.toolBox.find('input[name="switchRapidMoney"]').prop('checked', true).trigger('change');
        return this.els.menu1stBox.find('a:first').click();
      };

      View.prototype.destroy = function() {};

      View.prototype.loadTpl = function() {
        var alg, ani, coord, data, faceItem, fileName, hsda, hsdj, hshedj, hsheud, hsud, hsxc, i, ids, item, j, l, len, len1, len2, len3, ljda, ljdj, ljhedj, ljheud, ljud, ljxc, lvda, lvdj, lvhedj, lvheud, lvud, lvxc, m, map, name, o, p, q, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, results, s, t, temp, u, w;
        faceItem = arguments[0], coord = 2 <= arguments.length ? slice.call(arguments, 1) : [];
        this.faceItem = faceItem;
        name = faceItem.name;
        coord = coord[0];
        this.faceIndex = coord != null ? coord : null;
        fileName = name;
        if (name === 'tema' || name === 'vgma') {
          fileName = 'code';
        }
        require(["text!../templates/subsets/mark6_numbers_" + fileName + ".tpl"], (function(_this) {
          return function(TplBetting) {
            var desc, isCB, nBox, temp, tpl;
            nBox = _this.els.numberBox.css({
              opacity: 0
            });
            isCB = name === 'buvs' || name === 'ugxc' && coord === 2;
            nBox[isCB ? 'addClass' : 'removeClass']('commonOdds');
            _this.els.cbMoneyBox[isCB ? 'addClass' : 'removeClass']('enabled');
            tpl = doT.template(TplBetting);
            _this.els.numberBox.attr({
              'data-type': fileName,
              'data-name': name
            }).html(tpl({
              data: data,
              rebate: _this.data.rebateRate.value,
              face: faceItem,
              coord: coord,
              ids: ids
            }));
            _this.els.numItems = temp = _this.els.numberBox.find('.item');
            _this.els.numInputs = temp.find('input');
            _this.els.odds = _this.els.numberBox.find('.odds');
            temp.find('input:text').formatInsert({
              type: 'int'
            });
            if (coord != null) {
              desc = faceItem.labels[coord].desc;
            }
            if (!desc) {
              desc = faceItem.desc;
            }
            _this.els.description.find('p.text').html(desc.encodeHTML(true));
            nBox.animate({
              opacity: 1
            }, 200);
          };
        })(this));
        alg = this.algorithm;
        switch (name) {
          case 'tema':
          case 'vgma':
            data = [];
            for (i = l = 0; l < 5; i = ++l) {
              temp = [];
              for (j = m = ref = i * 10, ref1 = (i + 1) * 10; ref <= ref1 ? m < ref1 : m > ref1; j = ref <= ref1 ? ++m : --m) {
                o = alg.data[j];
                if (o) {
                  temp.push(o);
                }
              }
              data.push(temp);
            }
            if (name === 'tema') {
              return ids = faceItem.methodIDs;
            } else if (name === 'vgma') {
              return ids = [faceItem.methodIDs[coord]];
            }
            break;
          case 'bjbo':
            data = [];
            data.push(hsda = {
              color: 1,
              list: [],
              dx: 1,
              name: '红大'
            });
            data.push(hsxc = {
              color: 1,
              list: [],
              dx: 0,
              name: '红小'
            });
            data.push(hsdj = {
              color: 1,
              list: [],
              du: 1,
              name: '红单'
            });
            data.push(hsud = {
              color: 1,
              list: [],
              du: 0,
              name: '红双'
            });
            data.push(hshedj = {
              color: 1,
              list: [],
              hedu: 1,
              name: '红合单'
            });
            data.push(hsheud = {
              color: 1,
              list: [],
              hedu: 0,
              name: '红合双'
            });
            data.push(ljda = {
              color: 2,
              list: [],
              dx: 1,
              name: '蓝大'
            });
            data.push(ljxc = {
              color: 2,
              list: [],
              dx: 0,
              name: '蓝小'
            });
            data.push(ljdj = {
              color: 2,
              list: [],
              du: 1,
              name: '蓝单'
            });
            data.push(ljud = {
              color: 2,
              list: [],
              du: 0,
              name: '蓝双'
            });
            data.push(ljhedj = {
              color: 2,
              list: [],
              hedu: 1,
              name: '蓝合单'
            });
            data.push(ljheud = {
              color: 2,
              list: [],
              hedu: 0,
              name: '蓝合双'
            });
            data.push(lvda = {
              color: 3,
              list: [],
              dx: 1,
              name: '绿大'
            });
            data.push(lvxc = {
              color: 3,
              list: [],
              dx: 0,
              name: '绿小'
            });
            data.push(lvdj = {
              color: 3,
              list: [],
              du: 1,
              name: '绿单'
            });
            data.push(lvud = {
              color: 3,
              list: [],
              du: 0,
              name: '绿双'
            });
            data.push(lvhedj = {
              color: 3,
              list: [],
              hedu: 1,
              name: '绿合单'
            });
            data.push(lvheud = {
              color: 3,
              list: [],
              hedu: 0,
              name: '绿合双'
            });
            ref2 = alg.data;
            for (i = p = 0, len = ref2.length; p < len; i = ++p) {
              item = ref2[i];
              if (i === 48) {
                continue;
              }
              switch (item.color) {
                case 1:
                  if (item.state.daxc) {
                    hsda.list.push(item);
                  } else {
                    hsxc.list.push(item);
                  }
                  if (item.state.djud) {
                    hsdj.list.push(item);
                  } else {
                    hsud.list.push(item);
                  }
                  if (item.state.hedjud) {
                    hshedj.list.push(item);
                  } else {
                    hsheud.list.push(item);
                  }
                  break;
                case 2:
                  if (item.state.daxc) {
                    ljda.list.push(item);
                  } else {
                    ljxc.list.push(item);
                  }
                  if (item.state.djud) {
                    ljdj.list.push(item);
                  } else {
                    ljud.list.push(item);
                  }
                  if (item.state.hedjud) {
                    ljhedj.list.push(item);
                  } else {
                    ljheud.list.push(item);
                  }
                  break;
                case 3:
                  if (item.state.daxc) {
                    lvda.list.push(item);
                  } else {
                    lvxc.list.push(item);
                  }
                  if (item.state.djud) {
                    lvdj.list.push(item);
                  } else {
                    lvud.list.push(item);
                  }
                  if (item.state.hedjud) {
                    lvhedj.list.push(item);
                  } else {
                    lvheud.list.push(item);
                  }
              }
            }
            return ids = faceItem.methodIDs;
          case 'ugxc':
            data = [];
            map = alg.map;
            ref3 = alg.animals;
            for (q = 0, len1 = ref3.length; q < len1; q++) {
              ani = ref3[q];
              data.push(temp = {
                name: ani,
                text: map[ani],
                list: []
              });
              ref4 = alg.data;
              for (s = 0, len2 = ref4.length; s < len2; s++) {
                item = ref4[s];
                if (item.animal === ani) {
                  temp.list.push(item);
                }
              }
            }
            return ids = faceItem.methodIDs[coord];
          case 'wzuu':
            data = [];
            ref5 = alg.data;
            for (t = 0, len3 = ref5.length; t < len3; t++) {
              item = ref5[t];
              i = +item.n[1];
              temp = data[i] != null ? data[i] : data[i] = [];
              temp.push(item);
            }
            return ids = faceItem.methodIDs;
          case 'zsff':
            data = [];
            ids = [];
            temp = faceItem.items;
            i = 0;
            results = [];
            while (i < 8) {
              console.log(i, faceItem.methodIDs[i], temp[i]);
              data.push(temp[i]);
              ids.push(faceItem.methodIDs[i]);
              if (i === 6) {
                results.push(i = 1);
              } else {
                results.push(i += 2);
              }
            }
            return results;
            break;
          case 'buvs':
            data = [];
            for (i = u = 0; u < 7; i = ++u) {
              temp = [];
              for (j = w = ref6 = i * 7, ref7 = (i + 1) * 7; ref6 <= ref7 ? w < ref7 : w > ref7; j = ref6 <= ref7 ? ++w : --w) {
                o = alg.data[j];
                if (o) {
                  temp.push(o);
                }
              }
              data.push(temp);
            }
            return ids = [faceItem.methodIDs[coord]];
        }
      };

      View.prototype.eventSwitch1stMenu = function(event) {
        var data, el, faceItem, i, index, l, len, m2Box, o, ref;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        el.addClass('active').siblings('.active').removeClass('active');
        index = el.index();
        m2Box = this.els.menu2ndBox;
        faceItem = this.face[el.index()];
        data = faceItem.labels || [];
        if (data.length) {
          m2Box.html(this.tpls.m2({
            data: data,
            index: index
          }));
          m2Box.find('a:first').click();
          m2Box.fadeIn(200);
        } else {
          m2Box.hide().html('');
        }
        ref = this.els.switchRebate.find('.text');
        for (i = l = 0, len = ref.length; l < len; i = ++l) {
          o = ref[i];
          o = $(o);
          if (index) {
            o.text(i ? 'B面' : 'A面');
          } else {
            o.text(i ? '特B' : '特A');
          }
        }
        if (data.length) {
          return;
        }
        this.resetTotalInfo();
        this.refreshToolBox(faceItem.tools);
        return this.loadTpl(faceItem);
      };

      View.prototype.eventSwitch2ndMenu = function(event) {
        var el, face1, face2, i1, i2, tools;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        i1 = +el.attr('data-i');
        i2 = el.index();
        el.addClass('active').siblings('.active').removeClass('active');
        face1 = this.face[i1];
        face2 = face1.labels[i2];
        tools = face1.tools;
        if (face2.tools) {
          tools = face2.tools;
        }
        this.resetTotalInfo();
        this.refreshToolBox(tools);
        return this.loadTpl(face1, i2);
      };

      View.prototype.eventFocusMoneyInput = function(event) {
        var el;
        el = $(event.currentTarget);
        this.generateRapidBox(el);
        return el.setSelection(0);
      };

      View.prototype.eventBlurMoneyInput = function(event) {
        return this.destroyRapidBox();
      };

      View.prototype.eventKeyupMoneyInput = function(event) {
        return this.refreshTotalInfo();
      };

      View.prototype.eventChangeInput = function(event) {
        var el, faceItem, id, isChked, item, odds;
        faceItem = this.faceItem;
        if (faceItem.name === 'ugxc') {
          item = this.els.numItems.filter('.bmn');
          el = item.find('input');
          isChked = el.prop('checked');
          id = faceItem.methodIDs[this.faceIndex][+isChked];
          odds = faceItem.labels[this.faceIndex].getRebate(this.data.rebateRate.value, isChked ? 5 : 4);
          this.els.odds.text('×' + odds).attr({
            'data-id': id,
            'data-value': odds
          });
        }
        return this.refreshTotalInfo();
      };

      View.prototype.eventSelectRapidMoney = function(event) {
        var el, tar, val;
        el = $(event.currentTarget);
        val = el.attr('data-value');
        tar = el.parent().data('target');
        tar.val(val);
        return tar.trigger('keyup');
      };

      View.prototype.eventSwitchRebate = function(event) {
        var el, faceItem, fun, i, l, len, name, r, rebate, ref, symbol, temp;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        i = +el.attr('data-type');
        el.addClass('active').siblings('.active').removeClass('active');
        this.data.rebateRate = temp = this.data.rebateRateList[i];
        rebate = temp.value;
        faceItem = this.faceItem;
        this.els.rebateBox[i ? 'fadeIn' : 'fadeOut'](200);
        if (!faceItem) {
          return;
        }
        name = faceItem.name;
        if (this.faceIndex != null) {
          fun = faceItem.labels[this.faceIndex].getRebate;
        }
        if (!fun) {
          fun = faceItem.getRebate;
        }
        symbol = '×';
        switch (name) {
          case 'tema':
          case 'vgma':
            r = fun(rebate);
            this.els.odds.text(symbol + r).attr({
              'data-value': r
            });
            break;
          default:
            ref = this.els.odds;
            for (l = 0, len = ref.length; l < len; l++) {
              el = ref[l];
              el = $(el);
              r = fun(rebate, +el.attr('data-count'));
              el.text(symbol + r).attr({
                'data-value': r
              });
            }
        }
        return this.refreshTotalInfo();
      };

      View.prototype.eventFocusCbMoneyInput = function(event) {
        var el;
        el = $(event.currentTarget);
        this.generateRapidBox(el);
        return el.setSelection(0);
      };

      View.prototype.eventBlurCbMoneyInput = function(event) {
        return this.destroyRapidBox();
      };

      View.prototype.eventKeyupCbMoneyInput = function(event) {
        return this.refreshTotalInfo();
      };

      View.prototype.refreshToolBox = function(tools) {
        var l, len, name, results, widgets;
        widgets = this.els.toolBox.find('> .widget');
        widgets.hide();
        this.els.setMoney.val('');
        this.els.filterBtns.filter('.active').removeClass('active');
        results = [];
        for (l = 0, len = tools.length; l < len; l++) {
          name = tools[l];
          results.push(widgets.filter("[data-type=\"" + name + "\"]").fadeIn(200));
        }
        return results;
      };

      View.prototype.eventReset = function(event) {
        var el, icon;
        el = $(event.currentTarget);
        if (el.hasClass('resetting')) {
          return;
        }
        icon = el.find('.icon');
        el.addClass('resetting');
        icon.addClass('icon-spin');
        setTimeout(function() {
          el.removeClass('resetting');
          return icon.removeClass('icon-spin');
        }, 400);
        return this.reset();
      };

      View.prototype.reset = function() {
        var items;
        this.els.filterBtns.filter('.active').removeClass('active');
        this.els.setMoney.val('');
        this.els.filterNumber.val('');
        this.els.cbMoney.val('');
        items = this.els.numItems;
        items.removeClass('selected');
        items.find('input:text').val('');
        items.find('button.checkbox.checked').click();
        return this.resetTotalInfo();
      };

      View.prototype.eventClickToolBoxBtn = function(event) {
        var data, el, k, n, numItems, v;
        el = $(event.currentTarget);
        numItems = this.els.numItems;
        numItems.filter('.selected').removeClass('selected');
        if (el.hasClass('active')) {
          return el.removeClass('active');
        }
        this.els.filterBtns.filter('.active').removeClass('active');
        el.addClass('active');
        data = el.attr('data-filter');
        data = ("{" + (data.replace(/'/g, '"')) + "}").toJSON();
        for (k in data) {
          if (!hasProp.call(data, k)) continue;
          v = data[k];
          switch (k) {
            case 'color':
              numItems = numItems.filter("[data-color=\"" + v + "\"]");
              break;
            case 'dx':
              numItems = numItems.filter("[data-dx=\"" + v + "\"]");
              break;
            case 'du':
              numItems = numItems.filter("[data-du=\"" + v + "\"]");
              break;
            case 'hedu':
              numItems = numItems.filter("[data-hedu=\"" + v + "\"]");
              break;
            case 'animals':
              numItems = numItems.filter(((function() {
                var l, len, results;
                results = [];
                for (l = 0, len = v.length; l < len; l++) {
                  n = v[l];
                  results.push("[data-animal=\"" + n + "\"]");
                }
                return results;
              })()).join(','));
          }
        }
        numItems.addClass('selected');
        return this.els.setMoney.setSelection(0);
      };

      View.prototype.eventKeyupToolBoxSetMoney = function(event) {
        var el, numItems, targets, val;
        el = $(event.currentTarget);
        val = +el.val();
        numItems = this.els.numItems.filter('.selected');
        targets = numItems.find('input');
        targets.val(val || '');
        return this.refreshTotalInfo();
      };

      View.prototype.eventFocusToolBoxSetMoney = function(event) {
        var el;
        el = $(event.currentTarget);
        this.generateRapidBox(el);
        return el.setSelection(0);
      };

      View.prototype.eventBlurToolBoxSetMoney = function(event) {
        return this.destroyRapidBox();
      };

      View.prototype.eventKeyupToolBoxFilterNumber = function(event) {
        var el, numItems, target, val;
        el = $(event.currentTarget);
        numItems = this.els.numItems;
        target = numItems.filter('.selected');
        if (event.keyCode === 13) {
          target = target.find('input');
          if (target.length) {
            return target.setSelection(0);
          }
        } else {
          val = el.val();
          if (val.length === 1) {
            val = '0' + val;
          }
          target.removeClass('selected');
          target = numItems.filter("[data-value=\"" + val + "\"]");
          return target.addClass('selected');
        }
      };

      View.prototype.eventSwitchRapidMoney = function(event) {
        var el, ref;
        el = $(event.currentTarget);
        this.data.stateRapid = el.prop('checked');
        return (ref = this.els.rapidBox) != null ? ref.hide() : void 0;
      };

      View.prototype.eventResetRapidMoney = function(event) {
        var aEl, i, l, list, map, modalBox, n, str;
        aEl = $(event.currentTarget);
        map = {
          0: '一',
          1: '二',
          2: '三',
          3: '四'
        };
        str = '<ul>';
        list = this.data.rapidList;
        for (i = l = 0; l < 4; i = ++l) {
          n = list[i];
          str += "<li>\n	<span class=\"text\">金额" + map[i] + "：</span>\n	<input data-type=\"" + i + "\" value=\"" + (n || '') + "\" placeholder=\"快捷金额单位：元\" />\n</li>";
        }
        str += '</ul>';
        modalBox = CSH.confirm({
          title: '温馨提示',
          className: 'mark6 mark6-resetRapidMoney',
          content: str,
          ok: {
            text: '保存',
            callback: (function(_this) {
              return function() {
                var cb, el, els, len, m, val;
                els = modalBox.find('input:text');
                for (i = m = 0, len = els.length; m < len; i = ++m) {
                  el = els[i];
                  val = el.value;
                  list[i] = val ? +val : void 0;
                }
                localStorage.setItem('rapidList', list.join(','));
                modalBox.modal('hide');
                CSH.hint({
                  type: 'success',
                  msg: '快捷金额保存成功'
                });
                cb = aEl.closest('.widget').find('input:checkbox');
                if (!cb.prop('checked')) {
                  cb.prop({
                    checked: true
                  });
                  return cb.trigger('change');
                }
              };
            })(this)
          }
        });
        return modalBox.on('hidden', function() {
          return modalBox.remove();
        }).on('focus', 'input:text', function(event) {
          var el;
          el = $(event.currentTarget);
          return el.setSelection(0);
        });
      };

      View.prototype.generateRapidBox = function(target) {
        var cur, l, len, n, offsetP, offsetT, rBox, ref, str;
        if (!this.data.stateRapid) {
          return;
        }
        cur = +target.val();
        str = '<div class="rapidBox">';
        ref = this.data.rapidList;
        for (l = 0, len = ref.length; l < len; l++) {
          n = ref[l];
          if (n) {
            str += "<span data-value=\"" + n + "\"" + (n === cur ? ' class="active"' : '') + ">" + n + "</span>";
          }
        }
        str += '<span data-value="">清零</span></div>';
        rBox = this.els.rapidBox = $(str);
        offsetT = target.offset();
        offsetP = this.$el.offset();
        rBox.css({
          width: target.outerWidth(),
          left: offsetT.left - offsetP.left,
          top: offsetT.top - offsetP.top + target.outerHeight(true)
        });
        rBox.data({
          target: target
        });
        rBox.appendTo(this.$el);
        return rBox.fadeIn(200);
      };

      View.prototype.destroyRapidBox = function() {
        var target;
        if (!this.data.stateRapid) {
          return;
        }
        target = this.els.rapidBox;
        if (!target) {
          return;
        }
        return target.fadeOut(100, function() {
          return target.remove();
        });
      };

      View.prototype.eventBet = function(event) {
        var el, list, temp, total;
        el = $(event.currentTarget);
        el.prop({
          disabled: true
        });
        temp = this.getBetData();
        list = temp.list;
        total = temp.total;
        this.bet(list, total);
        return el.prop({
          disabled: false
        });
      };

      View.prototype.getBetData = function() {
        var ball, balls, btn, cb, codes, create, data, el, faceItem, isCB, l, len, len1, list, m, mID, minCou, money, name, odds, percent, point, ref, ref1, temp, text, texts, tmp, total;
        list = [];
        total = {};
        isCB = this.els.numberBox.hasClass('commonOdds');
        faceItem = this.faceItem;
        temp = this.data.rebateRate;
        percent = temp.percent;
        point = temp.value;
        name = faceItem.title;
        if (this.faceIndex != null) {
          name += " " + faceItem.labels[this.faceIndex].title;
        }
        create = function() {
          return {
            type: faceItem.name === 'zsff' ? 'dxds' : 'digital',
            multiple: 1,
            mode: 1,
            modeid: 1,
            percent: percent,
            timestamp: new Date().getTime(),
            position: ''
          };
        };
        if (isCB) {
          list.push(data = create());
          temp = this.els.odds;
          mID = temp.attr('data-id');
          odds = temp.attr('data-value');
          if (this.faceIndex != null) {
            minCou = faceItem.labels[this.faceIndex].mincount;
          }
          if (!minCou) {
            minCou = faceItem.mincount;
          }
          codes = [];
          texts = [];
          ref = this.els.numInputs.filter(':checked');
          for (l = 0, len = ref.length; l < len; l++) {
            cb = ref[l];
            cb = $(cb);
            btn = cb.parent();
            tmp = (function() {
              var len1, m, ref1, results;
              ref1 = btn.siblings('.ball');
              results = [];
              for (m = 0, len1 = ref1.length; m < len1; m++) {
                ball = ref1[m];
                results.push($(ball).attr('data-value'));
              }
              return results;
            })();
            if (faceItem.name === 'buvs') {
              codes.push(tmp.join(''));
              texts.push(tmp.join(''));
            } else {
              codes.push(tmp.join('&'));
              texts.push(tmp.join(' '));
            }
          }
          data.count = Math.combination(codes.length, minCou);
          if (faceItem.name === 'buvs') {
            data.codes = [codes.join('&')];
            data.text = texts.join(' ');
          } else {
            data.codes = [codes.join('|')];
            data.text = texts.join('<i></i>');
          }
          data.mID = mID;
          data.single = +this.els.cbMoney.val();
          data.money = data.single * data.count;
          data.odds = odds;
          total.name = name;
          if (data.count && data.money) {
            total.count = data.count;
            total.money = data.money;
            total.rebate = (data.money * percent).accurate(3);
          } else {
            total.count = 0;
            total.money = 0;
            total.rebate = '0.000';
          }
        } else {
          total.count = 0;
          total.money = 0;
          total.rebate = '0.000';
          total.name = name;
          ref1 = this.els.numInputs;
          for (m = 0, len1 = ref1.length; m < len1; m++) {
            el = ref1[m];
            el = $(el);
            money = +el.val();
            if (!money) {
              continue;
            }
            list.push(data = create());
            mID = el.parent().attr('data-id');
            odds = el.siblings('.odds').attr('data-value');
            if (faceItem.name === 'zsff') {
              tmp = el.siblings('.name');
              codes = [tmp.text()];
              text = codes[0];
            } else {
              balls = el.siblings('.ball');
              tmp = (function() {
                var len2, p, results;
                results = [];
                for (p = 0, len2 = balls.length; p < len2; p++) {
                  ball = balls[p];
                  results.push($(ball).attr('data-value'));
                }
                return results;
              })();
              codes = [tmp.join('&')];
              text = tmp.join(' ');
            }
            data.count = 1;
            data.mID = mID;
            data.codes = codes;
            data.text = text;
            data.single = money;
            data.money = money;
            data.odds = odds;
            if (data.count && data.money) {
              total.count += data.count;
              total.money += data.money;
            }
          }
          if (total.count) {
            total.rebate = (total.money * percent).accurate(3);
          }
        }
        console.log(list, total);
        return {
          list: list,
          total: total
        };
      };

      View.prototype.resetTotalInfo = function() {
        this.els.bet.prop({
          disabled: true
        });
        this.els.totalCount.text(0);
        this.els.totalMoney.text(0);
        this.els.totalRebate.text('0.000');
        return this.els.cbMoney.val('');
      };

      View.prototype.refreshTotalInfo = function() {
        var count, item, l, len, list, money, temp, total;
        temp = this.getBetData();
        list = temp.list;
        total = temp.total;
        this.els.totalCount.text(total.count);
        this.els.totalMoney.text(total.money);
        this.els.totalRebate.text(total.rebate);
        this.els.bet.prop({
          disabled: !total.count
        });
        return;
        count = 0;
        money = 0;
        for (l = 0, len = list.length; l < len; l++) {
          item = list[l];
          count += +item.count;
          money += +item.money;
        }
        this.data.total.count = count;
        this.data.total.money = money;
        this.els.params.numCountCard.text(count);
        this.els.params.numTotalCard.text(money);
        return this.els.btns.betWithList.prop('disabled', !count);
      };

      View.prototype.refreshInfos = function() {
        var count, modeid, money, mul, n, percent, points, rate, rebate, total;
        rate = this.data.rate;
        modeid = this.data.modeid;
        mul = this.data.multiple;
        percent = this.data.curPercent;
        points = (function() {
          var l, len, ref, results;
          ref = this.data.curPoints;
          results = [];
          for (l = 0, len = ref.length; l < len; l++) {
            n = ref[l];
            results.push((n * rate).accurate(modeid - 1 + 3));
          }
          return results;
        }).call(this);
        money = this.data.money;
        count = this.data.count;
        total = (money * mul * rate).accurate(modeid - 1);
        rebate = (total * percent).accurate(modeid - 1 + 3);
        this.els.params.numCount.text(count);
        this.els.params.numMultiple.text(mul);
        this.els.params.numTotal.text(total);
        this.els.params.numTotal.data('totalWithoutMultiple', (money * rate).accurate(modeid - 1));
        this.els.params.numPoints.text(points.join('|'));
        return this.els.params.numRebate.text(rebate);
      };

      View.prototype.refreshParam = function(hasRebate) {
        var max, maxPercent, min, minPercent, separator;
        if (hasRebate == null) {
          hasRebate = true;
        }
        this.data.count = 0;
        this.data.money = 0;
        if (!hasRebate) {
          return;
        }
        this.els.rePerWrap.removeClass('disabled');
        min = this.data.rebaterate.array[0];
        max = this.data.rebaterate.array.last();
        minPercent = min.persent * 1000 / 10;
        maxPercent = max.persent * 1000 / 10;
        minPercent = (minPercent.accurate(1)) + "%";
        maxPercent = (maxPercent.accurate(1)) + "%";
        separator = '|';
        this.data.curPoints = min.points.split(separator);
        return this.data.curPercent = min.persent;
      };

      View.prototype.refreshCurrentIssue = function() {
        return CSH.$els.body.find('> .modal').trigger('issueChanged');
      };

      View.prototype.getCurrentIssue = function() {
        var issue;
        issue = this.parent.views.headbar.data.issues.current;
        return [issue, issue.replace(/^\d{8}/, '$&-')];
      };

      View.prototype.bet = function(list, total) {
        var issueEl, modalBox;
        modalBox = $(this.tpls.modal({
          title: '投注单',
          className: 'mark6 modal-medium modal-mark6-betList',
          content: this.tpls.mBetList({
            data: list,
            total: total,
            issue: this.getCurrentIssue()[1],
            balance: CSH.utils.formatMoney(CSH.balance)
          })
        }));
        issueEl = modalBox.find('span[data-type="issue"]');
        modalBox.on('hidden', function() {
          return modalBox.remove();
        }).on('click', 'button[btn-type="ok"]', this.payBet).on('issueChanged', (function(_this) {
          return function() {
            return issueEl.text(_this.getCurrentIssue()[1]);
          };
        })(this)).data({
          data: list,
          view: this
        });
        modalBox.appendTo(CSH.$els.body);
        return modalBox.modal('show');
      };

      View.prototype.payBet = function() {
        var btnOk, data, i, item, l, len, len1, list, m, modalBox, place, ref, ref1, str, temp, tempObj, total, view;
        btnOk = $(this);
        modalBox = btnOk.closest('.modal');
        view = modalBox.data('view');
        total = 0;
        list = [];
        data = {
          'lt_issue_start': view.getCurrentIssue()[0],
          'OrderDataList': list
        };
        ref = modalBox.data('data');
        for (l = 0, len = ref.length; l < len; l++) {
          item = ref[l];
          temp = '';
          ref1 = item.codes;
          for (i = m = 0, len1 = ref1.length; m < len1; i = ++m) {
            place = ref1[i];
            str = '';
            if (place instanceof Array) {
              str = place.join('&');
            } else {
              str = place;
            }
            temp += "" + (i ? '|' : '') + str;
          }
          tempObj = {
            type: item.type,
            methodid: +item.mID,
            codes: temp,
            nums: item.count,
            times: item.multiple,
            money: item.money,
            mode: +item.modeid,
            point: item.percent,
            desc: '',
            position: item.position
          };
          list.push(tempObj);
          total += item.money;
        }
        if (CSH.balance - total < 0) {
          return CSH.hint({
            msg: '余额不足'
          });
        }
        btnOk.prop({
          disabled: true
        });
        view.showPayLoading();
        return new ModelLotterybetting().setUrl(CSH.gID).save(data, {
          dataFilter: function(data) {
            var code;
            temp = data.toJSON();
            code = Math.abs(temp.code);
            if (code !== 609) {
              view.hidePayLoading();
            }
            if (code === 0) {
              view.reset();
              modalBox.modal('hide');
              setTimeout(function() {
                return view.showResult(0);
              }, 300);
              CSH.views.body.refreshBalance();
            } else if (code === 609) {
              view.payFailed(btnOk);
            } else {
              CSH.alert(temp.message.encodeHTML());
              btnOk.prop({
                disabled: false
              });
            }
            return '{}';
          }
        });
      };

      View.prototype.fetchFuture = function(modalBox) {
        return new ModelFuture().setUrl(CSH.gID, 120).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              return modalBox.trigger('gotIssues', [data.toJSON().data]);
            };
          })(this)
        });
      };

      View.prototype.showPayLoading = function() {
        return this.els.hint = CSH.hint({
          icon: 'loading',
          msg: '购买中，请稍后...',
          duration: Infinity
        });
      };

      View.prototype.hidePayLoading = function() {
        var fun;
        fun = this.els.hint.data('hide');
        return fun();
      };

      View.prototype.payFailed = function(btn) {
        return setTimeout((function(_this) {
          return function() {
            var fun;
            fun = _this.els.hint.data('hide');
            fun();
            CSH.hint('购买失败');
            return btn.prop('disabled', false);
          };
        })(this), 8000);
      };

      View.prototype.showResult = function(isTrack, callback) {
        var btn, handle, modalBox, refreshText, temp, time;
        temp = {
          type: '投注',
          text: '游戏记录',
          link: location.origin + "/userCenter.html#gameRecords"
        };
        modalBox = CSH.alert({
          title: '温馨提示',
          className: 'mark6 modal-lottery-result',
          content: "<h4>\n	<i class=\"icon icon-ok\"></i>\n	<span>恭喜您" + temp.type + "成功</span>\n</h4>\n<p>您可以通过“ <a href=\"" + temp.link + "\">" + temp.text + "</a> ”查询您的" + temp.type + "记录！</p>"
        });
        btn = modalBox.find('.modal-footer button[btn-type="ok"]');
        btn.removeClass('btn-primary');
        time = 3;
        refreshText = function(time) {
          return btn.text("关闭（" + time + "）");
        };
        handle = setInterval(function() {
          refreshText(--time);
          if (time === 0) {
            clearInterval(handle);
            return modalBox.modal('hide');
          }
        }, 1000);
        refreshText(time);
        if (typeof callback === "function") {
          callback();
        }
      };

      View.prototype.showProcessingHint = function() {
        if (this.els.processing) {
          this.hideProcessingHint();
        }
        return this.els.processing = CSH.hint({
          icon: 'loading',
          msg: '处理中',
          duration: Infinity
        });
      };

      View.prototype.hideProcessingHint = function(callback) {
        var target;
        if (!this.els.processing) {
          return;
        }
        target = this.els.processing;
        return target.animate({
          marginTop: '-32px',
          opacity: 0
        }, 200, (function(_this) {
          return function() {
            target.remove();
            if (typeof callback === "function") {
              callback();
            }
            return _this.els.processing = null;
          };
        })(this));
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
