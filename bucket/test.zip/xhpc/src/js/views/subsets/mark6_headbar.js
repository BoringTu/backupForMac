(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/history', 'models/lotteryperiod', 'text!../../../templates/subsets/mark6_headbar.tpl', 'text!../../../templates/subsets/mark6_history.tpl', 'text!../../../templates/subsets/mark6_lotteryNumbers.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelHistory, ModelLotteryperiod, TplContent, TplHistory, TplLotteryNumbers, TplLoading) {
    "use strict";
    var TransitionMark6, View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.showLotteryNumbers = bind(this.showLotteryNumbers, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        history: doT.template(TplHistory),
        lotteryNumbers: doT.template(TplLotteryNumbers)
      };

      View.prototype.events = {
        'click .toggleHistory': 'eventToggleHistory',
        'click .scrollBar button': 'eventScrollHistory'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        this.algorithm = data.algorithm;
        this.data = {};
        this.data.oldTime = {};
        this.data.issues = {
          before: '',
          current: ''
        };
        this.data.placeCount = 7;
        CSH.audios.issueOver = new CSH.utils.Audio('/audios/issueOver.mp3');
        CSH.audios.ticktack = new CSH.utils.Audio('/audios/ticktack.mp3');
        this.xhr = {};
        return this.render();
      };

      View.prototype.render = function() {
        var issues;
        this.$el.html(this.tpls.content({
          gID: +CSH.gID
        }));
        this.els = {};
        this.els.sbBox = this.$el.find('.scoreboardBox');
        this.els.sbs = {};
        this.els.sbs.h = this.els.sbBox.find('.scoreboard[data-type="h"]');
        this.els.sbs.m = this.els.sbBox.find('.scoreboard[data-type="m"]');
        this.els.sbs.s = this.els.sbBox.find('.scoreboard[data-type="s"]');
        this.els.historyBox = this.$el.find('li.history .wrap ul');
        issues = this.$el.find('.issueNumber');
        this.els.issues = {
          before: issues.eq(1),
          current: issues.eq(0)
        };
        this.els.numBox = this.$el.find('.numBox');
        this.sbs = {};
        this.fetchGameInfo(true);
        return this.fetchLotteryRecords();
      };

      View.prototype.destroy = function() {
        var j, k, len, o, ref, ref1;
        ref = this.sbs;
        for (k in ref) {
          if (!hasProp.call(ref, k)) continue;
          o = ref[k];
          if (typeof o.destroy === "function") {
            o.destroy();
          }
        }
        ref1 = this.tms || [];
        for (j = 0, len = ref1.length; j < len; j++) {
          o = ref1[j];
          o.destroy();
        }
        clearInterval(this.data.czHandle);
        CSH.audios.issueOver.remove();
        CSH.audios.ticktack.remove();
        clearInterval(this.handleGI);
        return this;
      };

      View.prototype.fetchLotteryRecords = function(page, callback) {
        var ref;
        if (page == null) {
          page = 1;
        }
        if ((ref = this.xhr.lr) != null) {
          ref.abort();
        }
        return new ModelHistory().setUrl(CSH.gID, 3, page).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr.lr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var list;
              data = data.toJSON();
              list = data.data;
              _this.els.historyBox.data({
                total: data.pageInfo.totalRecords
              });
              _this.pushHistory(list, callback);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.fetchGameInfo = function(isInit) {
        var ref;
        if ((ref = this.xhr.gi) != null) {
          ref.abort();
        }
        return new ModelLotteryperiod().setUrl(CSH.gID).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              if (!isInit) {
                return _this.xhr.gi = xhr;
              }
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var code, k, o, ref1;
              data = data.toJSON().data;
              if (!isInit) {
                _this.data.issues.current = data[0].issue;
                _this.refreshIssues('cur');
                _this.resetCountDownTime(new Date(data[0].saleend.replace(/-/g, '/')).getTime());
                return;
              }
              ref1 = _this.sbs;
              for (k in ref1) {
                if (!hasProp.call(ref1, k)) continue;
                o = ref1[k];
                if (typeof o.destroy === "function") {
                  o.destroy();
                }
              }
              _this.initScoreboard(data[0]);
              code = data[1].code;
              _this.data.lotteryNumbers = code ? code.split(',') : [];
              _this.data.issues.before = data[1].issue;
              _this.data.issues.current = data[0].issue;
              _this.refreshIssues('init');
              _this.els.numBox.html(_this.tpls.lotteryNumbers({
                count: _this.data.placeCount
              }));
              _this.els.places = _this.els.numBox.find('.nums');
              _this.els.sum = _this.els.numBox.find('.sum');
              if (!_this.data.isStarting) {
                _this.startRandom();
              }
              if (_this.data.lotteryNumbers.length) {
                _this.showLotteryNumbers(_this.data.issues.before);
              }
              return _this.handleGI = setInterval((function() {
                return _this.fetchGameInfo();
              }), 10000);
            };
          })(this)
        });
      };

      View.prototype.refreshIssues = function(data) {
        var format, issues;
        format = function(issue) {
          return issue.replace(/^\d{8}/, '$&-');
        };
        issues = this.data.issues;
        if (data === 'init' || data === 'cur') {
          this.els.issues.current.html(format(issues.current));
          this.parent.views.betting.refreshCurrentIssue();
        }
        if (data === 'init' || data === 'bef') {
          return this.els.issues.before.html(format(issues.before));
        }
      };

      View.prototype.startRandom = function() {
        var i, j, l, len, len1, nums, ref, tb, tms;
        this.data.isStarting = 1;
        this.tms = tms = [];
        window.tms = tms;
        ref = this.els.places;
        for (j = 0, len = ref.length; j < len; j++) {
          nums = ref[j];
          tms.push(new TransitionMark6({
            el: $(nums),
            algorithm: this.algorithm,
            fI: this.algorithm.firstIndex
          }));
        }
        for (i = l = 0, len1 = tms.length; l < len1; i = ++l) {
          tb = tms[i];
          tb.shake({
            index: i
          });
        }
        return this.els.sum.text('???');
      };

      View.prototype.showLotteryNumbers = function(issue, codes) {
        this.data.issues.before = issue;
        this.refreshIssues('bef');
        if (!this.data.isStarting) {
          this.startRandom();
        }
        this.data.isStarting = 0;
        delete this.showLotteryNumbersDelay;
        if (codes) {
          this.data.lotteryNumbers = codes;
        }
        codes = this.data.lotteryNumbers;
        return setTimeout((function(_this) {
          return function() {
            var i, j, len, ref, results, tb;
            ref = _this.tms;
            results = [];
            for (i = j = 0, len = ref.length; j < len; i = ++j) {
              tb = ref[i];
              results.push(tb.result(+codes[i]));
            }
            return results;
          };
        })(this), 1000);
      };

      View.prototype.resetCountDownTime = function(data) {
        var time;
        time = data - CSH.serverTime.getTime();
        time = Math.round(time / 1000);
        return this.data.time = time;
      };

      View.prototype.initScoreboard = function(data) {
        var modalBox;
        this.sbs.h = new Scoreboard(this.els.sbs.h);
        this.sbs.m = new Scoreboard(this.els.sbs.m);
        this.sbs.s = new Scoreboard(this.els.sbs.s);
        this.resetCountDownTime(new Date(data.saleend.replace(/-/g, '/')).getTime());
        modalBox = null;
        return this.data.czHandle = setInterval((function(_this) {
          return function() {
            var gID, i, isNextDay, iss, issues, max, now, nowDate, s, temp, time;
            time = --_this.data.time;
            if (time < 0) {
              nowDate = CSH.serverTime;
              now = nowDate.getTime();
              isNextDay = false;
              switch (+CSH.gID) {
                case 601:
                  clearInterval(_this.data.czHandle);
                  _this.fetchGameInfo();
                  if (modalBox != null) {
                    modalBox.modal('hide');
                  }
                  modalBox = null;
                  return;
                case 602:
                  s = 60 * 2;
              }
              if (isNextDay) {
                temp = new Date(beginTime);
                temp = temp.setDate(temp.getDate() + 1);
                s = temp - now;
              }
              gID = +CSH.gID;
              issues = _this.data.issues;
              issues.before = '';
              max = "" + CSH.gameMap[gID].count;
              if (issues.current.match(new RegExp("\\d{" + max.length + "}$"))[0] === max) {
                iss = issues.current;
                iss = iss.slice(0, iss.length - max.length);
                iss += (((function() {
                  var j, ref, results;
                  results = [];
                  for (i = j = 0, ref = max.length - 1; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
                    results.push('0');
                  }
                  return results;
                })()).join('')) + "1";
                issues.current = iss;
              } else {
                issues.current = "" + (++issues.current);
              }
              _this.refreshIssues('cur');
              _this.data.lotteryNumbers = [];
              time = s + time;
              _this.data.time = time;
              if (modalBox != null) {
                modalBox.modal('hide');
              }
              modalBox = null;
            } else if ((1 < time && time < 11)) {
              if (!CSH.audios.ticktack.state) {
                CSH.audios.ticktack.play();
                CSH.audios.ticktack.state = 1;
              }
              if (modalBox != null) {
                modalBox.modal('hide');
              }
              modalBox = null;
            } else if (time < 2) {
              if (CSH.audios.ticktack.state) {
                CSH.audios.ticktack.stop();
                CSH.audios.ticktack.state = 0;
              }
              if (!modalBox) {
                modalBox = $("<div class=\"modal fade modal-lottery-bet-loading2\" tabindex=\"-1\">\n	<div class=\"modal-dialog\">\n		<div class=\"head openEye\"></div>\n		<div class=\"main mark6\">\n			<p>" + (_this.data.issues.current.replace(/^\d{8}/, '$&-')) + " 期已结束</p>\n			<p>请等待开奖</p>\n			<p class=\"con2\">即将进入下一期 <i></i><i class=\"one\"></i><i class=\"two\"></i></p>\n		</div>\n	</div>\n</div>");
                modalBox.appendTo(CSH.$els.body);
                modalBox.on('hidden', function() {
                  return $(this).remove();
                });
                modalBox.modal('show');
                CSH.audios.issueOver.play();
              }

              /*
              					else
              						modalBox.find '.circle'
              							.html time
              						modalBox.find('.modal-dialog').addClass 'openEye' if time is 1
               */
            } else {
              if (modalBox != null) {
                modalBox.modal('hide');
              }
              modalBox = null;
            }
            return _this.flipScoreboard(time);
          };
        })(this), 1000);
      };

      View.prototype.flipScoreboard = function(time) {
        var h, m, s;
        h = "" + (Math.floor(time / 60 / 60));
        m = "" + (Math.floor(time / 60 % 60));
        s = "" + (Math.floor(time % 60));
        if (this.data.oldTime.h !== h) {
          this.sbs.h.flip("" + (h.length === 1 ? '0' + h : h));
        }
        if (this.data.oldTime.m !== m) {
          this.sbs.m.flip("" + (m.length === 1 ? '0' + m : m));
        }
        this.sbs.s.flip("" + (s.length === 1 ? '0' + s : s));
        this.data.oldTime.h = h;
        return this.data.oldTime.m = m;
      };

      View.prototype.eventToggleHistory = function(event) {
        var el, liEls, targetA, targetB, text;
        el = $(event.currentTarget);
        text = el.find('.text');
        liEls = el.parent().siblings('ul').find('> li');
        targetA = liEls.filter(':hidden');
        targetB = liEls.not(targetA);
        targetB.fadeOut(200, function() {
          return targetA.fadeIn(200);
        });
        return text.animate({
          opacity: 0
        }, 200, function() {
          return text.text(targetA.hasClass('history') ? '最新开奖' : '往期开奖').animate({
            opacity: 1
          }, 200);
        });
      };

      View.prototype.eventScrollHistory = function(event) {
        var box, btns, count, el, fun, h, items, p, total, type;
        el = $(event.currentTarget);
        type = el.attr('data-type');
        box = this.els.historyBox;
        btns = box.parent().siblings('.scrollBar').find('button');
        items = box.children();
        h = items.outerHeight(true);
        count = items.length;
        total = box.data('total');
        p = box.data('p');
        if (p == null) {
          p = 1;
        }
        if (type === 'top') {
          p = 1;
        } else {
          if (+type) {
            p++;
          } else {
            p--;
          }
        }
        fun = function(b) {
          if (!b) {
            items = box.children();
            count = items.length;
          }
          btns.filter('[data-type="top"], [data-type="0"]').prop('disabled', p === 1);
          btns.filter('[data-type="1"]').prop('disabled', count === total && p === Math.ceil(count / 3));
          box.data('p', p);
          return box.animate({
            top: -h * 3 * (p - 1)
          }, 200);
        };
        if (+type === 1 && count !== total && p > Math.floor(count / 3)) {
          return this.fetchLotteryRecords(p, fun);
        } else {
          return fun(true);
        }
      };

      View.prototype.pushHistory = function(list, callback, isNew) {
        var alg, arr, box, j, l, len, len1, n, obj, sum, temp, total;
        alg = this.algorithm;
        box = this.els.historyBox;
        total = box.data('total');
        for (j = 0, len = list.length; j < len; j++) {
          obj = list[j];
          arr = obj.openNumber.split(',');
          sum = 0;
          temp = [];
          for (l = 0, len1 = arr.length; l < len1; l++) {
            n = arr[l];
            sum += +n;
            temp.push({
              n: n,
              color: alg.getColor(n)
            });
          }
          obj.codes = temp;
          obj.sum = sum;
        }
        box[isNew ? 'prepend' : 'append'](this.tpls.history(list));
        if (isNew) {
          box.data({
            total: ++total
          });
        }
        return typeof callback === "function" ? callback() : void 0;
      };

      View.prototype.pushNewHistory = function(list) {
        var data, fun;
        data = {
          openNumber: list.join(','),
          periodName: this.data.issues[this.data.time < 10 ? 'before' : 'current']
        };
        fun = (function(_this) {
          return function() {
            var box, btn;
            box = _this.els.historyBox;
            btn = box.parent().siblings('.scrollBar').find('button[data-type="top"]');
            return btn.click();
          };
        })(this);
        return this.pushHistory([data], fun, true);
      };

      return View;

    })(Backbone.View);
    TransitionMark6 = (function() {
      function TransitionMark6(data1) {
        this.data = data1;
        this._showResult = bind(this._showResult, this);
        this.box = this.data.el;
        this.ani = this.box.parent().next();
        this.data.speed = 200;
        return;
      }

      TransitionMark6.prototype.destroy = function() {
        this._destroy = 1;
        delete this.data;
        return delete this.box;
      };

      TransitionMark6.prototype.shake = function(param) {
        var _result, alg, ani, ball, box, data, fI, fun, k, map, self, speed, v;
        data = this.data;
        for (k in param) {
          if (!hasProp.call(param, k)) continue;
          v = param[k];
          data[k] = v;
        }
        box = this.box;
        ani = this.ani;
        ball = box.parent();
        alg = data.algorithm;
        map = alg.map;
        fI = data.fI;
        speed = data.speed;
        _result = this._showResult;
        self = this;
        fun = function() {
          var n;
          if (self._destroy) {
            return;
          }
          if (data.r) {
            return _result();
          }
          n = Math.round(Math.random() * 48 + 1);
          box.text(n < 10 ? "0" + n : "" + n);
          ball.attr({
            'data-color': alg.getColor(n)
          });
          ani.text(map[alg.getAnimal(n)]);
          setTimeout(fun, 200);
        };
        this._reset();
        return fun();
      };

      TransitionMark6.prototype.result = function(num) {
        var data;
        data = this.data;
        return setTimeout(function() {
          data.r = true;
          return data.n = num;
        }, 1000);
      };

      TransitionMark6.prototype._reset = function() {
        var data;
        data = this.data;
        data.r = false;
        return data.n = null;
      };

      TransitionMark6.prototype._showResult = function() {
        var alg, ani, ball, box, data, fI, map, numEls, sumEl, wrap;
        data = this.data;
        box = this.box;
        ani = this.ani;
        ball = box.parent();
        alg = data.algorithm;
        map = alg.map;
        fI = data.fI;
        wrap = ball.parent();
        wrap.animate({
          opacity: 0
        }, 200);
        if (data.index === 6) {
          sumEl = wrap.siblings('.sum');
          numEls = sumEl.siblings('.ballWrap').find('.nums');
          sumEl.animate({
            opacity: 0
          }, 200);
        }
        return setTimeout(function() {
          var n;
          n = data.n;
          box.text(n < 10 ? "0" + n : "" + n);
          ball.attr({
            'data-color': alg.getColor(n)
          });
          ani.text(map[alg.getAnimal(n)]);
          wrap.animate({
            opacity: 1
          }, 200);
          if (data.index !== 6) {
            return;
          }
          return setTimeout(function() {
            var j, len, nEl, sum;
            sum = 0;
            for (j = 0, len = numEls.length; j < len; j++) {
              nEl = numEls[j];
              sum += +$(nEl).text();
            }
            return sumEl.text(sum).animate({
              opacity: 1
            }, 200);
          }, 200);
        }, (data.index + 1) * 200);
      };

      return TransitionMark6;

    })();
    return View;
  });

}).call(this);
