(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/lotterybetting', 'models/future', 'models/codestatistics', 'models/lotterybettingsets', 'collections/rebaterate', 'text!../../../templates/subsets/default-lottery_betting.tpl', 'text!../../../templates/subsets/default-lottery_methods.tpl', 'text!../../../templates/subsets/default-lottery_betList.tpl', 'text!../../../templates/_default-contentLoading.tpl', 'text!../../../templates/_default-modal.tpl', 'text!../../../templates/default-modal_lottery_betList.tpl', 'text!../../../templates/default-modal_lottery_trackList.tpl', 'text!../../../templates/subsets/default-lottery_trackItems.tpl'], function($, _, Backbone, doT, ModelLotterybetting, ModelFuture, ModelCodeStatistics, ModelLotterybettingSets, CollectionRebaterate, TplContent, TplMethods, TplBetList, TplLoading, TplModal, TplModalBetList, TplModalTrackList, TplTrackItems) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.showResult = bind(this.showResult, this);
        this.pay = bind(this.pay, this);
        this.eventMouseupRangeBarHandle = bind(this.eventMouseupRangeBarHandle, this);
        this.eventMousemoveRangeBarHandle = bind(this.eventMousemoveRangeBarHandle, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        methods: doT.template(TplMethods),
        betList: doT.template(TplBetList),
        modal: doT.template(TplModal),
        mBetList: doT.template(TplModalBetList),
        mTrackList: doT.template(TplModalTrackList),
        mTrackItems: doT.template(TplTrackItems)
      };

      View.prototype.events = {
        'click .method1stBox a': 'eventSwitch1stMethod',
        'click .methodOthersBox a': 'eventSwitch3rdMethod',
        'click .switchRx': 'eventSwitchRx',
        'click .position button': 'eventClickPositionBtn',
        'click .ballContainer .ball': 'eventToggleBallState',
        'click .numberBox .toolbar button': 'eventClickToolbarBtn',
        'click .unitWrap button': 'eventChooseRate',
        'fi.change .multipleWrap input': 'eventChangedMultiple',
        'click .multipleWrap .selection button': 'eventChangedMultipleByStep',
        'click .rePerWrap button': 'eventChoosePercent',
        'click		.textareaBox .description': 'eventClickDesc',
        'keydown	.textareaBox textarea': 'eventLimitInput',
        'keyup		.textareaBox textarea': 'eventCheckInput',
        'change		.textareaBox textarea': 'eventFormatInput',
        'focus		.textareaBox textarea': 'eventFocusInput',
        'blur		.textareaBox textarea': 'eventBlurInput',
        'click		.textareaBox [data-type="unique"]': 'eventClickUnique',
        'click		.textareaBox [data-type="clear"]': 'eventClickClearText',
        'click .infoBox button.addToList': 'eventAddToList',
        'click .infoBox button.bet': 'eventBet',
        'click .shoppingCard .listBox .remove': 'eventRemoveItem',
        'click .shoppingCard .empty': 'eventEmptyList',
        'click .cardInfoBox button.betWithList': 'eventBetWithList',
        'change .numberBox .descriptionLine input[type="checkbox"]': 'eventToggleLostCH',
        'click .numberBox .importList': 'eventClickImportList',
        'change .numberBox .importList input[type="file"]': 'eventImportList'
      };

      View.prototype.initialize = function(data) {
        window.vb = this;
        this.parent = data.parent;
        this.algorithm = data.algorithm;
        this.data = {
          count: 0,
          money: 0,
          modeid: 1,
          rate: 1,
          multiple: 1,
          total: {
            count: 0,
            money: 0
          },
          history: {
            pageIndex: 1,
            length: 0
          },
          isrx: 0
        };
        this.data.mi = null;
        this.c_rebaterate = new CollectionRebaterate();
        this.xhr = {};
        this.listenTo(this.c_rebaterate, 'reset', function() {
          var array, len, map, obj, q, rePer, textarea;
          this.data.rebaterate = {};
          this.data.rebaterate.array = array = this.c_rebaterate.toJSON();
          map = {};
          for (q = 0, len = array.length; q < len; q++) {
            obj = array[q];
            map[obj.persent] = obj.points;
          }
          this.data.rebaterate.map = map;
          this.refreshParam();
          rePer = +localStorage.getItem('lotteryRePer');
          this.els.rePerWrap.addClass('disabled').find('button').removeClass('selected');
          this.els.rePerWrap.find("button[data-type=\"" + (rePer || 0) + "\"]").click();
          textarea = this.els.textarea;
          if (textarea) {
            return this.checkText(textarea);
          } else {
            return this.checkBalls();
          }
        });
        return this.loadMethodFilter();
      };

      View.prototype.render = function() {
        var btnRx, unit;
        this.$el.html(this.tpls.content({
          data: this.face
        }));
        this.els = {};
        this.els.m1stBox = this.$el.children('.method1stBox');
        this.els.mOthersBox = this.$el.children('.methodOthersBox');
        this.els.numberBox = this.$el.children('.numberBox');
        this.els.infoBox = this.$el.children('.infoBox');
        this.els.listBox = this.$el.find('> .shoppingCard .listBox');
        this.els.cardInfo = this.$el.children('.cardInfoBox');
        this.els.switchRx = this.els.m1stBox.find('.switchRx');
        this.els.unitWrap = this.els.infoBox.find('.unitWrap');
        this.els.rePerWrap = this.els.infoBox.find('.rePerWrap');
        this.els.rHandle = this.els.rePerWrap.find('.rangeBar .handle');
        this.els.betLoading = this.els.infoBox.find('.betLoading');
        this.els.params = {
          numCount: this.els.infoBox.find('strong.count'),
          numMultiple: this.els.infoBox.find('strong.multiple'),
          numTotal: this.els.infoBox.find('strong.total'),
          numPoints: this.els.infoBox.find('strong.points'),
          numRebate: this.els.infoBox.find('strong.rebate'),
          numPercent: this.els.infoBox.find('.percent'),
          numCountCard: this.els.cardInfo.find('span[data-type="count"]'),
          numTotalCard: this.els.cardInfo.find('span[data-type="total"]'),
          ckTrackState: this.els.cardInfo.find('input[type="checkbox"][name="trackState"]')
        };
        this.els.btns = {
          addToList: this.els.infoBox.find('button.addToList'),
          bet: this.els.infoBox.find('button.bet'),
          betWithList: this.els.cardInfo.find('button.betWithList')
        };
        btnRx = this.els.switchRx;
        btnRx[+CSH.gType === 1 && btnRx.siblings('.rx').length ? 'show' : 'hide']();
        this.els.m1stBox.find('a.isdefault').click().removeClass('isdefault');
        unit = +localStorage.getItem('lotteryUnit');
        this.els.unitWrap.find("button[data-modeid=\"" + (unit || 1) + "\"]").click();
        return this.renderBetList();
      };

      View.prototype.renderBetList = function() {
        var list;
        list = CSH.betList[CSH.gID];
        return this.els.listBox.html(this.tpls.betList(list));
      };

      View.prototype.destroy = function() {};

      View.prototype.loadMethodFilter = function() {
        return $.ajax({
          url: CSH.path.fapi + "/blistMethod",
          success: (function(_this) {
            return function(data) {
              if (data.code) {
                return;
              }
              return _this.loadFace(data.data);
            };
          })(this)
        });
      };

      View.prototype.loadFace = function(blist) {
        var name;
        name = CSH.gType;
        require(["face/" + name], (function(_this) {
          return function() {
            var face, len, len1, len2, len3, len4, len5, m1, m1s, m2, m2s, m3, m3s, mf, o, q, r, ref, ref1, ref2, ref3, ref4, s, str, u, w, y;
            face = CSH.utils.clone(CSH.face[name]);
            _this.face = face;
            mf = (function() {
              var len, q, ref, results;
              ref = blist[CSH.gID] || [];
              results = [];
              for (q = 0, len = ref.length; q < len; q++) {
                str = ref[q];
                results.push(str);
              }
              return results;
            })();
            if (mf) {
              m1s = [];
              for (q = 0, len = face.length; q < len; q++) {
                o = face[q];
                m1s.push(o);
              }
              for (r = 0, len1 = face.length; r < len1; r++) {
                m1 = face[r];
                m2s = [];
                ref = m1.label;
                for (s = 0, len2 = ref.length; s < len2; s++) {
                  o = ref[s];
                  m2s.push(o);
                }
                ref1 = m1.label;
                for (u = 0, len3 = ref1.length; u < len3; u++) {
                  m2 = ref1[u];
                  m3s = [];
                  ref2 = m2.label;
                  for (w = 0, len4 = ref2.length; w < len4; w++) {
                    o = ref2[w];
                    m3s.push(o);
                  }
                  ref3 = m2.label;
                  for (y = 0, len5 = ref3.length; y < len5; y++) {
                    m3 = ref3[y];
                    if (ref4 = m3.methodid, indexOf.call(mf, ref4) >= 0) {
                      m3s.remove(m3);
                    }
                  }
                  m2.label = m3s;
                  if (!m3s.length) {
                    m2s.remove(m2);
                  }
                }
                m1.label = m2s;
                if (!m2s.length) {
                  m1s.remove(m1);
                }
              }
              _this.face = m1s;
            }
            _this.render();
          };
        })(this));
      };

      View.prototype.loadTpl = function(data, callback) {
        var name;
        name = data.selectarea.type;
        require(["text!../templates/subsets/default-lottery_numbers_" + name + ".tpl"], (function(_this) {
          return function(TplBetting) {
            var tpl;
            tpl = doT.template(TplBetting);
            _this.els.numberBox.attr({
              'data-type': name
            }).html(tpl(data));
            if (name === 'input') {
              _this.els.desc = _this.els.numberBox.find('.description');
              _this.els.textarea = _this.els.numberBox.find('textarea');
              _this.els.btns.unique = _this.els.numberBox.find('button[data-type="unique"]');
              _this.els.btns.clear = _this.els.numberBox.find('button[data-type="clear"]');
            } else {
              delete _this.els.desc;
              delete _this.els.textarea;
              delete _this.els.btns.unique;
              delete _this.els.btns.clear;
            }
            _this.algorithm.type = name;
            _this.algorithm.isrx = data.isrx;
            _this.els.auxiliary = _this.els.numberBox.find('.auxiliary');
            _this.els.auxiliary.hide();
            _this.resetParam();
            _this.refreshYllr();
            if (typeof callback === "function") {
              callback();
            }
          };
        })(this));
      };

      View.prototype.refreshYllr = function() {
        var ref, typeData;
        typeData = this.data.yllrType;
        if (!typeData) {
          return;
        }
        if ((ref = this.xhr.yllr) != null) {
          ref.abort();
        }
        return new ModelCodeStatistics().setUrl(typeData[0], CSH.gID).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr.yllr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var box, dH, dL, dxdsI, el, h, i, j, l, len, maxH, maxL, maxLs, minH, mmHs, n, p, pEl, q, ref1, results, type;
              data = data.toJSON().data;
              dH = data.hot;
              dL = data.lost;
              mmHs = (function() {
                var len, q, results;
                results = [];
                for (q = 0, len = dH.length; q < len; q++) {
                  h = dH[q];
                  results.push([Math.max.apply(null, h), Math.min.apply(null, h)]);
                }
                return results;
              })();
              maxLs = (function() {
                var len, q, results;
                results = [];
                for (q = 0, len = dL.length; q < len; q++) {
                  l = dL[q];
                  results.push(Math.max.apply(null, l));
                }
                return results;
              })();
              dxdsI = [0, 3, 1, 2];
              ref1 = _this.els.numberBox.find('> .positionLine > .ballContainer');
              results = [];
              for (i = q = 0, len = ref1.length; q < len; i = ++q) {
                box = ref1[i];
                box = $(box);
                p = typeData[0] === 3 ? typeData[1] : typeData[1][i];
                maxH = mmHs[p][0];
                minH = mmHs[p][1];
                maxL = maxLs[p];
                results.push((function() {
                  var len1, r, ref2, results1;
                  ref2 = box.find('.ballWrap');
                  results1 = [];
                  for (j = r = 0, len1 = ref2.length; r < len1; j = ++r) {
                    pEl = ref2[j];
                    pEl = $(pEl);
                    results1.push((function() {
                      var len2, ref3, results2, s;
                      ref3 = pEl.find('.auxiliary');
                      results2 = [];
                      for (s = 0, len2 = ref3.length; s < len2; s++) {
                        el = ref3[s];
                        el = $(el);
                        type = el.attr('data-type');
                        if (typeData[0] === 2) {
                          n = +data[type][p][dxdsI[j]];
                        } else {
                          n = +data[type][p][j];
                        }
                        el.text(n);
                        if (type === 'hot') {
                          if (maxH === n) {
                            results2.push(el.addClass('text-red'));
                          } else if (minH === n) {
                            results2.push(el.addClass('text-blue'));
                          } else {
                            results2.push(void 0);
                          }
                        } else if (type === 'lost' && maxL === n) {
                          results2.push(el.addClass('text-black'));
                        } else {
                          results2.push(void 0);
                        }
                      }
                      return results2;
                    })());
                  }
                  return results1;
                })());
              }
              return results;
            };
          })(this)
        });
      };

      View.prototype.checkChallenge = function(count, callback, isFromList) {
        var ref, toggle;
        if (!count) {
          this.data.challenge = null;
          return;
        }
        toggle = (function(_this) {
          return function(b) {
            var btns;
            btns = _this.els.btns.addToList.add(_this.els.btns.bet);
            return btns.prop('disabled', b);
          };
        })(this);
        toggle(true);
        this.els.betLoading.addClass('icon-spin');
        if ((ref = this.xhr.lbs) != null) {
          ref.abort();
        }
        return new ModelLotterybettingSets().setUrl(2).fetch({
          data: {
            gid: CSH.gID,
            mid: this.mID,
            bcount: count
          },
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr.lbs = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var b;
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              data = data.data;
              b = data.isSingle;
              _this.data.challenge = b ? {
                b: b,
                max: +data.maxAmount,
                count: data.singleBetCount
              } : null;
              if (isFromList) {
                toggle(false);
              }
              _this.els.betLoading.removeClass('icon-spin');
              return typeof callback === "function" ? callback() : void 0;
            };
          })(this)
        });
      };

      View.prototype.checkText = function(el, reset) {
        var arr, data, separator, text, val;
        val = el.val().trim();
        text = this.algorithm.getText(val);
        if (reset) {
          el.val(text);
        }
        separator = '|';
        arr = text.split(separator);
        data = this.algorithm.getCount({
          codes: arr
        });
        this.data.count = data.count;
        this.data.money = data.money;
        this.refreshInfos();
        this.codes = arr;
      };

      View.prototype.checkBalls = function() {
        var ball, codes, data, len, len1, minchosen, pData, param, place, q, r, ref, ref1;
        param = {};
        codes = [];
        minchosen = [];
        ref = this.els.numberBox.children('.positionLine');
        for (q = 0, len = ref.length; q < len; q++) {
          place = ref[q];
          place = $(place);
          minchosen.push(+place.attr('data-minchosen'));
          pData = [];
          ref1 = place.find('button.ball.selected');
          for (r = 0, len1 = ref1.length; r < len1; r++) {
            ball = ref1[r];
            ball = $(ball);
            pData.push(ball.attr('data-value'));
          }
          codes.push(pData);
        }
        param.codes = codes;
        param.minchosen = minchosen;
        data = this.algorithm.getCount(param);
        this.data.count = data.count;
        this.data.money = data.money;
        this.refreshInfos();
        this.codes = codes;
      };

      View.prototype.eventSwitch1stMethod = function(event) {
        var el, m1;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        m1 = el.attr('data-index');
        el.addClass('active').siblings('.active').removeClass('active');
        this.mName = {
          '1': el.text()
        };
        this.els.mOthersBox.html(this.tpls.methods({
          data: this.face[m1]
        }));
        this.data.mi = [m1];
        return this.els.mOthersBox.find('> .box:eq(0) > a:eq(0)').click();
      };

      View.prototype.eventSwitch3rdMethod = function(event) {
        var data, defCount, defPos, el, i2, i3, id, layouts, len, m2, q, x;
        el = $(event.currentTarget);
        m2 = el.parent().find('span');
        i2 = m2.attr('data-index');
        i3 = el.attr('data-index');
        id = el.attr('data-id');
        data = this.face[this.data.mi[0]].label[i2].label[i3];
        layouts = data.selectarea.layout;
        this.mName['2'] = m2.text();
        this.mName['3'] = el.text();
        this.mID = id;
        this.pCount = layouts ? layouts.length : 0;
        defCount = 0;
        defPos = data.defaultposition.split('');
        for (q = 0, len = defPos.length; q < len; q++) {
          x = defPos[q];
          if (+x === 1) {
            defCount++;
          }
        }
        this.defCount = defCount;
        el.addClass('active');
        this.els.mOthersBox.find('a.active').not(el).removeClass('active');
        this.data.mi[1] = i2;
        this.data.mi[2] = i3;
        this.data.yllrType = data.yllrType;
        this.c_rebaterate.setUrl(CSH.gType, id).fetch({
          reset: true
        });
        return this.loadTpl(data);
      };

      View.prototype.eventSwitchRx = function(event) {
        var el, ns, rs;
        el = $(event.currentTarget);
        rs = el.siblings('.rx');
        ns = el.siblings(':not(.rx)');
        if (this.data.isrx) {
          this.data.isrx = 0;
          el.text('任选玩法');
          rs.hide();
          return ns.show().first().click();
        } else {
          this.data.isrx = 1;
          el.text('普通玩法');
          ns.hide();
          return rs.show().first().click();
        }
      };

      View.prototype.eventClickPositionBtn = function(event) {
        var defCount, defEls, el, p;
        el = $(event.currentTarget);
        el.toggleClass('selected');
        defEls = $('> .selected', el.parent());
        this.defCount = defCount = defEls.size();
        this.defPos = (function() {
          var len, q, results;
          results = [];
          for (q = 0, len = defEls.length; q < len; q++) {
            p = defEls[q];
            results.push($(p).attr('data-type'));
          }
          return results;
        })();
        this.algorithm.defCount = defCount;
        if (this.els.numberBox.is('[data-type="input"]')) {
          this.checkText(this.els.textarea);
        } else {
          this.checkBalls();
        }
      };

      View.prototype.eventToggleBallState = function(event) {
        var el, temp, val;
        el = $(event.currentTarget);
        el.addClass('selecting');
        setTimeout((function() {
          return el.removeClass('selecting');
        }), 200);
        temp = el.closest('[isdt]');
        if (temp[0]) {
          if (!el.hasClass('selected')) {
            val = el.attr('data-value');
            temp.siblings().find("button.ball[data-value=\"" + val + "\"]").removeClass('selected');
          }
          if (temp.is(':not(:last-child)')) {
            el.closest('.ballContainer').find('button.selected').removeClass('selected');
          }
        }
        temp = el.closest('[data-maxchosen]');
        if (temp[0] && 1 === +temp.attr('data-maxchosen')) {
          if (!el.hasClass('data-value')) {
            el.closest('.ballContainer').find('button.selected').removeClass('selected');
          }
        }
        el.toggleClass('selected');
        this.checkBalls();
      };

      View.prototype.eventClickToolbarBtn = function(event) {
        var ball, balls, el, len, max, min, nums, q, ref, size, temp, type, value;
        el = $(event.currentTarget);
        type = el.attr('data-type');
        if (type !== 'clear') {
          el.addClass('selected');
        }
        el.siblings('.selected').removeClass('selected');
        balls = el.closest('.toolbar').siblings('.ballContainer').find('button');
        balls.filter('.selected').removeClass('selected');
        size = balls.size();
        min = +balls.first().attr('data-value');
        max = size + min - 1;
        switch (type) {
          case 'all':
            balls.addClass('selected');
            break;
          case 'large':
            balls.slice(Math.floor(size / 2)).addClass('selected');
            break;
          case 'small':
            balls.slice(0, Math.round(size / 2)).addClass('selected');
            break;
          case 'odd':
            balls.filter("" + (min === 0 ? ':odd' : ':even')).addClass('selected');
            break;
          case 'even':
            balls.filter("" + (min === 0 ? ':even' : ':odd')).addClass('selected');
        }
        temp = el.closest('[isdt]');
        if (temp[0]) {
          nums = (function() {
            var len, q, ref, results;
            ref = temp.find('.ball.selected');
            results = [];
            for (q = 0, len = ref.length; q < len; q++) {
              ball = ref[q];
              results.push($(ball).attr('data-value'));
            }
            return results;
          })();
          ref = temp.siblings().find('.ball.selected');
          for (q = 0, len = ref.length; q < len; q++) {
            ball = ref[q];
            ball = $(ball);
            value = ball.attr('data-value');
            if (indexOf.call(nums, value) >= 0) {
              ball.removeClass('selected');
            }
          }
        }
        this.checkBalls();
      };

      View.prototype.eventChooseRate = function(event) {
        var el, id, oldRate, rate;
        el = $(event.currentTarget);
        if (el.hasClass('selected')) {
          return;
        }
        el.addClass('selected').siblings('.selected').removeClass('selected');
        rate = +el.attr('data-rate');
        id = el.attr('data-modeid');
        oldRate = this.data.rate || 1;
        this.data.modeid = id;
        this.data.rate = rate;
        localStorage.setItem('lotteryUnit', id);
        if (!this.data.rebaterate) {
          return;
        }
        this.refreshInfos();
      };

      View.prototype.eventChangedMultiple = function(event) {
        var el, mul;
        el = $(event.currentTarget);
        mul = +el.attr('data-value');
        this.data.multiple = mul;
        return this.refreshInfos();
      };

      View.prototype.eventChangedMultipleByStep = function(event) {
        var el, target, val;
        el = $(event.currentTarget);
        target = el.siblings('input');
        val = +target.val();
        if ('+' === el.attr('data-value')) {
          if (("" + (++val)).length > +target.attr('maxlength')) {
            --val;
          }
        } else {
          if (--val < 1) {
            val = 1;
          }
        }
        return target.val(val).trigger('keyup');
      };

      View.prototype.resetParam = function() {
        var el, list;
        list = CSH.betList[CSH.gID];
        list = CSH.betList[CSH.gID] = list || [];
        this.els.params.numCount.text(0);
        this.els.params.numTotal.text(0);
        this.els.params.numPoints.text(0);
        this.els.params.numRebate.text(0);
        this.els.params.numPercent.text('0.0%');
        this.els.infoBox.removeClass('hasRebate');
        this.algorithm.methodId = this.mID;
        this.algorithm.placeCount = this.pCount;
        this.algorithm.defCount = this.defCount;
        this.algorithm.data = {
          count: 0,
          money: 0
        };
        this.defPos = (function() {
          var len, q, ref, results;
          ref = this.els.numberBox.find('> .position button[data-type].selected');
          results = [];
          for (q = 0, len = ref.length; q < len; q++) {
            el = ref[q];
            results.push($(el).attr('data-type'));
          }
          return results;
        }).call(this);
      };

      View.prototype.eventChoosePercent = function(event) {
        var curRate, el, is0, rePer;
        el = $(event.currentTarget);
        if (el.hasClass('selected')) {
          return;
        }
        rePer = +el.attr('data-type');
        is0 = 0 === rePer;
        el.addClass('selected').siblings('.selected').removeClass('selected');
        this.data.curPercent = curRate = is0 ? 0 : this.data.rebaterate.array.last().persent;
        this.data.curPoints = this.data.rebaterate.map[curRate].split('|');
        this.els.infoBox[!is0 ? 'addClass' : 'removeClass']('hasRebate');
        localStorage.setItem('lotteryRePer', rePer);
        return this.refreshInfos();
      };

      View.prototype.eventMousedownRangeBarHandle = function(event) {
        var bar, el, nums;
        el = $(event.currentTarget);
        bar = el.parent();
        nums = bar.prev().find('span.num');
        el.addClass('active');
        el.data('startX', event.clientX);
        el.data('startLeft', parseInt(el.css('left')));
        el.data('maxX', bar.width());
        el.data('maxPercent', this.data.rebaterate.array.last().persent);
        el.data('covered', bar.find('.covered'));
        CSH.$els.body.on('mousemove', this.eventMousemoveRangeBarHandle).on('mouseup', this.eventMouseupRangeBarHandle);
      };

      View.prototype.eventMousemoveRangeBarHandle = function(event) {
        var covered, curPer, curRate, curX, el, left, maxPercent, maxX, separator, startL, startX;
        el = this.els.rHandle;
        startX = el.data('startX');
        startL = el.data('startLeft');
        curX = event.clientX;
        left = curX - startX + startL;
        maxX = el.data('maxX');
        maxPercent = el.data('maxPercent');
        covered = el.data('covered');
        separator = '|';
        if (left < 0) {
          left = 0;
        } else if (left > maxX) {
          left = maxX;
        }
        el.css({
          left: left
        });
        covered.width(left);
        curPer = left / maxX;
        curRate = (Math.round(curPer * maxPercent * 1000)) / 1000;
        this.data.curPercent = curRate;
        this.data.curPoints = this.data.rebaterate.map[curRate].split(separator);
        this.els.params.numPercent.text(((curRate * 1000 / 10).accurate(1)) + "%").data('value', curRate);
        this.els.infoBox[left ? 'addClass' : 'removeClass']('hasRebate');
        this.refreshInfos();
        return false;
      };

      View.prototype.eventMouseupRangeBarHandle = function(event) {
        var el;
        el = this.els.rHandle;
        el.removeClass('active');
        CSH.$els.body.off('mousemove', this.eventMousemoveRangeBarHandle);
      };

      View.prototype.eventClickDesc = function(event) {
        return this.els.textarea.focus();
      };

      View.prototype.eventFocusInput = function(event) {
        return this.els.desc.hide();
      };

      View.prototype.eventBlurInput = function(event) {
        var el, val;
        el = $(event.currentTarget);
        val = el.val();
        if (val !== el.data('oldVal')) {
          el.trigger('keyup');
        }
        if (!val) {
          return this.els.desc.show();
        }
      };

      View.prototype.eventLimitInput = function(event) {
        var ref, ref1;
        if ((ref = event.keyCode) === 91 || ref === 93 || ref === 17) {
          return CSH.cmdKey = 1;
        }
        if (CSH.cmdKey) {
          return;
        }
        if (ref1 = event.keyCode, indexOf.call([0, 8, 13, 32, 186, 188, 220].concat([48, 49, 50, 51, 52, 53, 54, 55, 56, 57].concat([96, 97, 98, 99, 100, 101, 102, 103, 104, 105])), ref1) < 0) {
          return event.preventDefault();
        }
      };

      View.prototype.checkInput = function(reset) {
        var desc, el, val;
        el = this.els.textarea;
        val = el.val();
        el.data({
          oldVal: val
        });
        desc = this.els.desc;
        if (val.trim()) {
          if (!desc.is(':hidden')) {
            desc.hide();
          }
          this.els.btns.unique.prop('disabled', false);
          this.els.btns.clear.prop('disabled', false);
        } else {
          this.els.btns.unique.prop('disabled', true);
          this.els.btns.clear.prop('disabled', true);
        }
        return this.checkText(el, reset);
      };

      View.prototype.eventCheckInput = function(event) {
        var ref;
        if ((ref = event.keyCode) === 91 || ref === 93 || ref === 17) {
          CSH.cmdKey = 0;
        }
        return this.checkInput();
      };

      View.prototype.eventFormatInput = function(event) {
        var el;
        el = $(event.currentTarget);
        return this.checkText(el, true);
      };

      View.prototype.eventClickUnique = function(event) {
        var arr, codes, dN, e, el, errors, i, is1Digit, iseth, iszxdu, len, len1, len2, n, q, r, ref, ref1, ref2, repetitive, s, sN, separator1, separator2, tA, tN, temp, tempCodes, textarea, txt, u, w;
        el = $(event.currentTarget);
        el.prop('disabled', true);
        textarea = this.els.textarea.prop('disabled', true);
        this.showProcessingHint();
        is1Digit = (ref = +CSH.gType) === 1 || ref === 2 || ref === 5;
        separator1 = '|';
        separator2 = is1Digit ? '' : ' ';
        codes = textarea.val().split(separator1);
        errors = this.algorithm.error;
        tempCodes = new Stack();
        for (i = q = ref1 = codes.length - 1; ref1 <= 0 ? q <= 0 : q >= 0; i = ref1 <= 0 ? ++q : --q) {
          tempCodes.push(codes[i]);
        }
        repetitive = [];
        iszxdu = textarea.hasClass('iszxdu');
        iseth = textarea.hasClass('iseth');
        if (errors.length) {
          codes = [];
          for (r = 0, len = errors.length; r < len; r++) {
            e = errors[r];
            while (true) {
              if (!tempCodes.length) {
                break;
              }
              n = tempCodes.pop();
              if (e === n) {
                break;
              }
              if (iszxdu) {
                n = n.split(separator2).sort().join(separator2);
              }
              codes.push(n);
            }
          }
          while (tempCodes.length > 0) {
            codes.push(tempCodes.pop());
          }
        }
        tempCodes = new Stack();
        if (codes.length) {
          for (i = s = ref2 = codes.length - 1; ref2 <= 0 ? s <= 0 : s >= 0; i = ref2 <= 0 ? ++s : --s) {
            tempCodes.push(codes[i]);
          }
        }
        if (tempCodes.length) {
          codes = [];
          while (tempCodes.length) {
            n = tempCodes.pop();
            arr = n.split(separator2);
            if (iszxdu) {
              n = arr.sort().join(separator2);
            }
            if (iseth) {
              tA = [];
              for (u = 0, len1 = arr.length; u < len1; u++) {
                tN = arr[u];
                if (indexOf.call(tA, tN) >= 0) {
                  dN = tN;
                  break;
                }
                tA.push(tN);
              }
              for (w = 0, len2 = arr.length; w < len2; w++) {
                tN = arr[w];
                if (tN !== dN) {
                  sN = tN;
                  break;
                }
              }
              n = dN + dN + sN;
            }
            codes.push(n);
          }
        }
        temp = codes.unique(true);
        codes = temp[0];
        repetitive = temp[1];
        if (errors.length || repetitive.length) {
          txt = '';
          if (errors.length) {
            txt += "<p>过滤掉的错号：<span>" + (errors.join(separator1)) + "</span></p>";
          }
          if (repetitive.length) {
            txt += "<p>过滤掉的重号：<span>" + (repetitive.join(separator1)) + "</span></p>";
          }
          setTimeout(function() {
            return CSH.alert({
              className: 'modal-lottery-unique-result',
              content: txt
            }, 0);
          });
        }
        textarea.val(codes.join(separator1)).trigger('keyup').prop('disabled', false);
        this.hideProcessingHint();
        return el.prop('disabled', true);
      };

      View.prototype.eventClickClearText = function(event) {
        var el;
        el = $(event.currentTarget);
        el.prop('disabled', true);
        return this.els.textarea.val('').trigger('keyup').trigger('change').focus();
      };

      View.prototype.eventAddToList = function(event) {
        var callback, count, ref;
        if ((ref = this.els.btns.unique) != null) {
          ref.click();
        }
        count = this.data.count;
        if (!count) {
          return CSH.hint('请选择至少一组有效号码');
        }
        callback = (function(_this) {
          return function() {
            var el, fun;
            el = $(event.currentTarget);
            fun = function() {
              _this.addToList();
              _this.refreshCardInfo();
              _this.els.mOthersBox.find('a.active').click();
              return _this.data.challenge = null;
            };
            el.prop('disabled', true);
            if (_this.data.challenge) {
              CSH.confirm({
                title: '温馨提示',
                className: 'modal-lottery-challenge',
                content: "<span class=\"icon icon-attention\"></span>\n<p class=\"msg\">该笔属单挑玩法，最高奖金为 <strong>" + (CSH.utils.formatMoney(_this.data.challenge.max, 0)) + "</strong> 元！</p>\n<a href=\"javascript:;\">\n	<span class=\"text\">什么是单挑玩法？</span>\n	<span class=\"desc\">单笔投注数小于等于 " + _this.data.challenge.count + " 注，即为单挑玩法！<br>（不同玩法单挑注数不同）<i></i></span>\n</a>",
                cancel: {
                  text: '取消'
                },
                ok: {
                  text: '添加',
                  callback: fun
                }
              });
            } else {
              fun();
            }
            return el.prop('disabled', false);
          };
        })(this);
        return this.checkChallenge(count, callback);
      };

      View.prototype.eventBet = function(event) {
        var callback, count, ref;
        if ((ref = this.els.btns.unique) != null) {
          ref.click();
        }
        count = this.data.count;
        if (!count) {
          return CSH.hint('请选择至少一组有效号码');
        }
        callback = (function(_this) {
          return function() {
            return _this.bet([_this.getBetData()], _this.data.money * _this.data.multiple * _this.data.rate);
          };
        })(this);
        return this.checkChallenge(count, callback, 0);
      };

      View.prototype.getBetData = function() {
        var len, n, place, q, ref, ref1, ref2, temp, text;
        if (this.algorithm.type === 'input') {
          text = this.codes.join('|');
        } else {
          temp = [];
          ref = this.codes;
          for (q = 0, len = ref.length; q < len; q++) {
            n = ref[q];
            if ((ref1 = +CSH.gType) === 3 || ref1 === 4) {
              place = n.join(' ');
            } else if (+CSH.gType === 5) {
              if (n[0] === '123&234&345&456') {
                place = '三连号通选';
              } else if (n[0] === '111&222&333&444&555&666') {
                place = '三同号通选';
              } else {
                place = n.join(' ');
              }
            } else {
              place = n.join('');
            }
            temp.push(place);
          }
          text = temp.join('<i></i>');
        }
        return {
          type: (ref2 = this.algorithm.type) === 'zhdxdu' || ref2 === 'dice' ? 'digital' : this.algorithm.type,
          codes: this.codes,
          text: text,
          mID: this.mID,
          mName: this.mName['2'] + " " + this.mName['3'],
          count: this.data.count,
          money: this.els.params.numTotal.text(),
          multiple: this.data.multiple,
          moneyWithoutMultiple: this.els.params.numTotal.data('totalWithoutMultiple'),
          mode: CSH.modeMap[this.data.modeid],
          modeid: this.data.modeid,
          percent: this.data.curPercent,
          timestamp: new Date().getTime(),
          position: this.defPos,
          challenge: this.data.challenge
        };
      };

      View.prototype.addToList = function() {
        var list;
        list = CSH.betList[CSH.gID];
        list = CSH.betList[CSH.gID] = list || [];
        list.push(this.getBetData());
        this.renderBetList();
        return this.data.count = 0;
      };

      View.prototype.eventRemoveItem = function(event) {
        var el, id, item, len, li, list, q;
        el = $(event.currentTarget);
        li = el.closest('li');
        id = +li.attr('data-hash');
        li.fadeOut(400, function() {
          return li.remove();
        });
        CSH.hint({
          msg: '已移除所选号码',
          duration: 600
        });
        list = CSH.betList[CSH.gID];
        for (q = 0, len = list.length; q < len; q++) {
          item = list[q];
          if (item.timestamp === id) {
            list.remove(item);
            break;
          }
        }
        return this.refreshCardInfo();
      };

      View.prototype.eventEmptyList = function(event) {
        return CSH.confirm({
          content: '确定清空投注单',
          ok: {
            callback: (function(_this) {
              return function() {
                CSH.betList[CSH.gID] = [];
                _this.els.listBox.find('li').fadeOut(400, function() {
                  return $(this).remove();
                });
                _this.refreshCardInfo();
                return setTimeout((function() {
                  return CSH.hint('已移除投注单内所有号码');
                }), 400);
              };
            })(this)
          }
        });
      };

      View.prototype.refreshCardInfo = function() {
        var count, item, len, list, money, moneyWM, q;
        list = CSH.betList[CSH.gID];
        count = 0;
        money = 0;
        moneyWM = 0;
        for (q = 0, len = list.length; q < len; q++) {
          item = list[q];
          count += +item.count;
          money += +item.money;
          moneyWM += +item.moneyWithoutMultiple;
        }
        money = +money.accurate(4);
        moneyWM = +moneyWM.accurate(4);
        this.data.total.count = count;
        this.data.total.money = money;
        this.data.total.moneyWM = moneyWM;
        this.els.params.numCountCard.text(count);
        this.els.params.numTotalCard.text(money);
        return this.els.btns.betWithList.prop('disabled', !count);
      };

      View.prototype.refreshInfos = function() {
        var count, modeid, money, mul, n, percent, points, rate, rebate, total;
        rate = this.data.rate;
        modeid = this.data.modeid;
        mul = this.data.multiple;
        percent = this.data.curPercent;
        points = (function() {
          var len, q, ref, results;
          ref = this.data.curPoints;
          results = [];
          for (q = 0, len = ref.length; q < len; q++) {
            n = ref[q];
            results.push((n * rate).accurate(modeid - 1 + 3));
          }
          return results;
        }).call(this);
        money = this.data.money;
        count = this.data.count;
        total = (money * mul * rate).accurate(modeid - 1);
        rebate = (total * percent).accurate(modeid - 1 + 3);
        this.els.params.numCount.text(count);
        this.els.params.numMultiple.text(mul);
        this.els.params.numTotal.text(total);
        this.els.params.numTotal.data('totalWithoutMultiple', (money * rate).accurate(modeid - 1));
        this.els.params.numPoints.text(points.join('|'));
        return this.els.params.numRebate.text(rebate);
      };

      View.prototype.refreshParam = function(hasRebate) {
        var btnDesc, max, maxPercent, min, minPercent, separator;
        if (hasRebate == null) {
          hasRebate = true;
        }
        this.data.count = 0;
        this.data.money = 0;
        if (!hasRebate) {
          return;
        }
        this.els.rePerWrap.removeClass('disabled');
        min = this.data.rebaterate.array[0];
        max = this.data.rebaterate.array.last();
        minPercent = min.persent * 100;
        maxPercent = max.persent * 100;
        minPercent = (minPercent.accurate(1)) + "%";
        maxPercent = (maxPercent.accurate(1)) + "%";
        separator = '|';
        btnDesc = this.els.rePerWrap.find('.desc label');
        btnDesc.filter(':first').text(min.points + "---" + minPercent);
        btnDesc.filter(':last').text(max.points + "---" + maxPercent);
        this.data.curPoints = min.points.split(separator);
        return this.data.curPercent = min.persent;
      };

      View.prototype.refreshCurrentIssue = function() {
        return CSH.$els.body.find('> .modal').trigger('issueChanged');
      };

      View.prototype.eventBetWithList = function(event) {
        if (this.els.params.ckTrackState[0].checked) {
          if (this.data.total.money < 0.2) {
            return CSH.hint('追号单总投注额不得低于 0.2 元');
          }
          return this.track(CSH.betList[CSH.gID], this.data.total.moneyWM);
        } else {
          return this.bet(CSH.betList[CSH.gID], this.data.total.money, 1);
        }
      };

      View.prototype.getCurrentIssue = function() {
        var issue;
        issue = this.parent.views.headbar.data.issues.current;
        return [issue, issue.replace(/^\d{8}/, '$&-')];
      };

      View.prototype.bet = function(list, money, isFromList) {
        var issueEl, modalBox, tips, view;
        if (isFromList == null) {
          isFromList = 0;
        }
        if (!isFromList) {
          view = this;
          return this.pay(list, function() {
            if (isFromList) {
              return;
            }
            return setTimeout(function() {
              var btns;
              btns = view.els.btns.addToList.add(view.els.btns.bet);
              return btns.prop({
                disabled: false
              });
            }, 500);
          });
        }
        modalBox = $(this.tpls.modal({
          title: '投注单',
          className: 'modal-medium modal-lottery-betList',
          content: this.tpls.mBetList({
            data: list,
            issue: this.getCurrentIssue()[1],
            money: CSH.utils.formatMoney(money),
            balance: CSH.utils.formatMoney(CSH.balance)
          })
        }));
        issueEl = modalBox.find('span[data-type="issue"]');
        tips = modalBox.find('p.tips');
        modalBox.data('isFromList', isFromList).on('hidden', function() {
          return modalBox.remove();
        }).on('click', 'button[btn-type="ok"]', this.payBet).on('issueChanged', (function(_this) {
          return function() {
            return issueEl.text(_this.getCurrentIssue()[1]);
          };
        })(this)).data({
          data: list,
          view: this
        });
        modalBox.appendTo(CSH.$els.body);
        modalBox.modal('show');
        return setTimeout((function() {
          return tips.animate({
            opacity: 1
          }, 200);
        }), 400);
      };

      View.prototype.payBet = function() {
        var btnOk, callback, isFromList, list, modalBox, view;
        btnOk = $(this);
        modalBox = btnOk.closest('.modal');
        isFromList = modalBox.data('isFromList');
        list = modalBox.data('data');
        view = modalBox.data('view');
        callback = function() {
          modalBox.modal('hide');
          if (isFromList) {
            view.betList = CSH.betList[CSH.gID] = [];
            view.els.btns.betWithList.prop('disabled', true);
            view.els.params.numCountCard.text(0);
            return view.els.params.numTotalCard.text(0);
          }
        };
        btnOk.prop('disabled', true);
        return view.pay(list, callback, isFromList);
      };

      View.prototype.pay = function(param, callback, isFromList) {
        var data, i, isInput, item, len, len1, list, m, place, q, r, ref, str, temp, tempObj, total, view;
        view = this;
        total = 0;
        list = [];
        data = {
          'lt_issue_start': view.getCurrentIssue()[0],
          'OrderDataList': list
        };
        for (q = 0, len = param.length; q < len; q++) {
          item = param[q];
          temp = '';
          isInput = item.type === 'input';
          ref = item.codes;
          for (i = r = 0, len1 = ref.length; r < len1; i = ++r) {
            place = ref[i];
            str = '';
            if (place instanceof Array) {
              str = place.join('&');
            } else {
              str = place;
            }
            temp += "" + (i ? (isInput ? '&' : '|') : '') + str;
          }
          tempObj = {
            type: item.type,
            methodid: +item.mID,
            codes: temp,
            nums: item.count,
            times: item.multiple,
            money: item.money,
            mode: +item.modeid,
            point: item.percent,
            desc: ''
          };
          if (item.position) {
            tempObj.position = item.position.join('&');
          }
          list.push(tempObj);
          total += +item.money;
        }
        if (CSH.balance - total < 0) {
          return CSH.hint({
            msg: '余额不足'
          });
        }
        view.showLoading('购买中，请稍后...');
        m = new ModelLotterybetting();
        m.setUrl(CSH.gID);
        return m.save(data, {
          dataFilter: function(data) {
            var code, vr;
            temp = data.toJSON();
            code = Math.abs(temp.code);
            if (code !== 609) {
              view.hideLoading();
            }
            if (code === 0) {
              view.data.challenge = null;
              setTimeout(function() {
                return view.showResult(0, function() {
                  if (isFromList) {
                    return view.renderBetList();
                  } else {
                    return view.els.mOthersBox.find('a.active').click();
                  }
                });
              }, 300);
              if (typeof callback === "function") {
                callback();
              }
              vr = view.parent.views.records;
              if (vr.data.type === 'gameRecords') {
                vr.fetch_gameRecords();
              }
              CSH.balance = "" + (CSH.balance - total);
              localStorage.setItem('balance', CSH.balance);
              CSH.views.body.refreshBalance();
            } else if (code === 609) {
              view.payFailed(btnOk);
            } else {
              CSH.alert(temp.message.encodeHTML());
              btnOk.prop('disabled', false);
            }
            return '{}';
          }
        });
      };

      View.prototype.fetchFuture = function(modalBox) {
        return new ModelFuture().setUrl(CSH.gID, 120).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              return modalBox.trigger('gotIssues', [data.toJSON().data]);
            };
          })(this)
        });
      };

      View.prototype.track = function(list, money) {
        var btnOk, ckAll, ckTrackStop, infos, input, isGen, issues, len, len1, len2, listBox, modalBox, o, param, q, r, ref, ref1, s, tabs, temp, toolItems, toolbars, view;
        view = this;
        modalBox = $(this.tpls.mTrackList({
          data: list,
          issue: this.getCurrentIssue()[1],
          money: CSH.utils.formatMoney(money),
          balance: CSH.utils.formatMoney(CSH.balance)
        }));
        this.fetchFuture(modalBox);
        toolbars = modalBox.find('.toolbar > div[data-type]');
        listBox = modalBox.find('.listBox');
        btnOk = modalBox.find('button[btn-type="ok"]');
        ckAll = modalBox.find('button.checkAll input');
        ckTrackStop = modalBox.find('.modal-footer input[type="checkbox"][name="trackStop"]');
        toolItems = {};
        for (q = 0, len = toolbars.length; q < len; q++) {
          o = toolbars[q];
          o = $(o);
          temp = toolItems[o.attr('data-type')] = {};
          ref = o.find('input');
          for (r = 0, len1 = ref.length; r < len1; r++) {
            input = ref[r];
            temp[input.name] = $(input);
          }
        }
        infos = {};
        ref1 = modalBox.find('.modal-footer .leftBox strong[data-type]');
        for (s = 0, len2 = ref1.length; s < len2; s++) {
          o = ref1[s];
          o = $(o);
          infos[o.attr('data-type')] = o;
        }
        param = {
          trackType: ''
        };
        issues = null;
        isGen = false;
        modalBox.data({
          data: list,
          view: this
        }).on('hidden', function() {
          return modalBox.remove();
        }).on('click', 'button[btn-type="ok"]', (function(_this) {
          return function(event) {
            var data, el, els, len3, u;
            els = listBox.find('> li.selected');
            data = [];
            for (u = 0, len3 = els.length; u < len3; u++) {
              el = els[u];
              el = $(el);
              data.push({
                'lt_trace_issues': el.attr('data-issue'),
                'lt_trace_Times': +el.attr('data-multiple'),
                'money': +el.attr('data-money')
              });
            }
            return _this.payTrack(event, data, ckTrackStop.prop('checked'));
          };
        })(this)).on('click', '.generateTrackList', function(event) {
          isGen = true;
          modalBox.trigger('clearList', [false]);
          if (issues) {
            return modalBox.trigger('generateList');
          }
        }).on('generateList', function() {
          var mulInputs;
          listBox.html(view.tpls.mTrackItems({
            data: issues,
            param: param
          }));
          ckAll.prop('checked', true).parent().addClass('checked');
          mulInputs = listBox.find('input[name="multiple"]');
          mulInputs.formatInsert({
            type: 'int'
          });
          return modalBox.trigger('refreshInfo');
        }).on('clearList', function(event, clearData) {
          if (clearData == null) {
            clearData = true;
          }
          listBox.empty();
          if (clearData) {
            return issues = null;
          }
        }).on('issueChanged', (function(_this) {
          return function() {
            modalBox.trigger('clearList');
            if (isGen) {
              listBox.html(TplLoading);
            }
            return _this.fetchFuture(modalBox);
          };
        })(this)).on('resetParam', function(event, type) {
          var k, tempMap, v;
          tempMap = toolItems[type];
          param.money = money;
          switch (type) {
            case 'normal':
              param.issueCount = 5;
              param.multiple = 1;
              break;
            case 'double':
              param.issueCount = 5;
              param.startMultiple = 1;
              param.cycle = 1;
              param.multiple = 2;
          }
          for (k in param) {
            if (!hasProp.call(param, k)) continue;
            v = param[k];
            temp = tempMap[k];
            if (!temp) {
              continue;
            }
            temp.val(v).attr('data-value', v).trigger('change');
          }
        }).on('refreshInfo', function() {
          var count, item, items, len3, total, u;
          total = 0;
          items = listBox.find('> li.selected');
          count = items.length;
          for (u = 0, len3 = items.length; u < len3; u++) {
            item = items[u];
            total += +$(item).attr('data-money');
          }
          infos.count.text(count);
          infos.money.text(total.accurate(+view.data.modeid - 1));
          return btnOk.prop('disabled', count ? false : true);
        }).on('gotIssues', function(event, data) {
          issues = data;
          if (!isGen) {
            return;
          }
          return modalBox.trigger('generateList');
        }).on('click', '.modal-header li', function(event) {
          var el, type;
          btnOk.prop('disabled', true);
          el = $(event.currentTarget);
          if (el.hasClass('active')) {
            return;
          }
          isGen = false;
          el.addClass('active').siblings('.active').removeClass('active');
          type = el.attr('data-type');
          param = {
            trackType: type
          };
          modalBox.trigger('resetParam', [type]);
          toolbars.filter("[data-type=\"" + param.trackType + "\"]").show().siblings('[data-type]').hide();
          return modalBox.trigger('clearList', [false]);
        }).on('change', 'button.checkAll input', function(event) {
          var b, cks, el;
          el = $(event.currentTarget);
          b = el.prop('checked');
          cks = listBox.find('input[type="checkbox"]');
          if (b) {
            cks.filter(':not(:checked)').prop('checked', true).parent().addClass('checked').closest('li').addClass('selected');
          } else {
            cks.filter(':checked').prop('checked', false).parent().removeClass('checked').closest('li').removeClass('selected');
          }
          return modalBox.trigger('refreshInfo');
        }).on('change', '.listBox button.checkbox input', function(event) {
          var b, el, li;
          el = $(event.currentTarget);
          b = el.prop('checked');
          li = el.closest('li');
          li[b ? 'addClass' : 'removeClass']('selected');
          return modalBox.trigger('refreshInfo');
        }).on('focus', '.listBox input[name="multiple"]', function(event) {
          return $(event.currentTarget).setCursorPosition(0);
        }).on('keyup', '.listBox input[name="multiple"]', function(event) {
          var el, m, val;
          el = $(event.currentTarget);
          val = el.val();
          if (val.trim() === '') {
            val = 1;
            el.val(1).setCursorPosition(0);
          }
          m = money * val;
          el.parent().next().text(m + " 元");
          el.closest('li').attr({
            'data-multiple': val,
            'data-money': m
          });
          return modalBox.trigger('refreshInfo');
        }).on('fi.change', '.toolbar input', function(event) {
          var el, name, val;
          el = $(event.currentTarget);
          name = el.attr('name');
          val = el.attr('data-value');
          return param[name] = val;
        });
        tabs = modalBox.find('.modal-header li');
        modalBox.appendTo(CSH.$els.body);
        modalBox.modal('show');
        return tabs.first().click();
      };

      View.prototype.payTrack = function(event, traceDataList, isStop) {
        var btnOk, data, i, isInput, item, len, len1, len2, list, m, modalBox, o, place, q, r, ref, ref1, s, str, temp, tempObj, total, view;
        btnOk = $(event.currentTarget);
        modalBox = btnOk.closest('.modal');
        view = modalBox.data('view');
        total = 0;
        list = [];
        data = {
          'lt_issue_start': view.getCurrentIssue()[0],
          'lt_trace_if': 'yes',
          'lt_trace_stop': isStop ? 'yes' : 'no',
          'OrderDataList': list,
          'TraceDataList': traceDataList
        };
        ref = modalBox.data('data');
        for (q = 0, len = ref.length; q < len; q++) {
          item = ref[q];
          temp = '';
          isInput = item.type === 'input';
          ref1 = item.codes;
          for (i = r = 0, len1 = ref1.length; r < len1; i = ++r) {
            place = ref1[i];
            str = '';
            if (place instanceof Array) {
              str = place.join('&');
            } else {
              str = place;
            }
            temp += "" + (i ? (isInput ? '&' : '|') : '') + str;
          }
          tempObj = {
            type: item.type,
            methodid: +item.mID,
            codes: temp,
            nums: item.count,
            times: item.multiple,
            money: item.money,
            mode: +item.modeid,
            percent: item.percent,
            point: item.point,
            desc: ''
          };
          if (item.position) {
            tempObj.position = item.position.join('&');
          }
          list.push(tempObj);
        }
        for (s = 0, len2 = traceDataList.length; s < len2; s++) {
          o = traceDataList[s];
          total += o.money;
          delete o.money;
        }
        if (CSH.balance - total < 0) {
          return CSH.hint({
            msg: '余额不足'
          });
        }
        btnOk.prop('disabled', true);
        view.showLoading('购买中，请稍后...');
        m = new ModelLotterybetting();
        m.setUrl(CSH.gID);
        return m.save(data, {
          dataFilter: function(data) {
            var code, ref2, vr;
            temp = data.toJSON();
            code = Math.abs(temp.code);
            if (code !== 609) {
              view.hideLoading();
            }
            if (code === 0) {
              modalBox.modal('hide');
              setTimeout(function() {
                return view.showResult(1, function() {
                  return view.renderBetList();
                });
              }, 300);
              view.betList = CSH.betList[CSH.gID] = [];
              view.els.btns.betWithList.prop('disabled', true);
              view.els.params.numCountCard.text(0);
              view.els.params.numTotalCard.text(0);
              vr = view.parent.views.records;
              if ((ref2 = vr.els.refresh) != null) {
                ref2.click();
              }
              CSH.balance = "" + (CSH.balance - total);
              localStorage.setItem('balance', CSH.balance);
              CSH.views.body.refreshBalance();
            } else if (code === 609) {
              view.payFailed(btnOk);
            } else {
              CSH.alert(temp.message.encodeHTML());
              btnOk.prop('disabled', false);
            }
            return '{}';
          }
        });
      };

      View.prototype.showLoading = function(msg) {
        return this.els.hint = CSH.hint({
          icon: 'loading',
          duration: Infinity,
          msg: msg.encodeHTML(true)
        });
      };

      View.prototype.hideLoading = function() {
        var fun;
        fun = this.els.hint.data('hide');
        return fun();
      };

      View.prototype.payFailed = function(btn) {
        return setTimeout((function(_this) {
          return function() {
            var fun;
            fun = _this.els.hint.data('hide');
            fun();
            CSH.hint('购买失败');
            return btn.prop('disabled', false);
          };
        })(this), 8000);
      };

      View.prototype.showResult = function(isTrack, callback) {
        var btn, handle, modalBox, refreshText, temp, time;
        temp = {
          type: isTrack ? '追号' : '投注',
          text: isTrack ? '追号记录' : '游戏记录',
          link: location.origin + "/userCenter.html#" + (isTrack ? 'trackRecords' : 'gameRecords')
        };
        modalBox = CSH.alert({
          title: '温馨提示',
          className: 'modal-lottery-result',
          content: "<h4>\n	<i class=\"icon icon-ok\"></i>\n	<span>恭喜您" + temp.type + "成功</span>\n</h4>\n<p>您可以通过“ <a href=\"" + temp.link + "\">" + temp.text + "</a> ”查询您的" + temp.type + "记录！</p>"
        });
        btn = modalBox.find('.modal-footer button[btn-type="ok"]');
        btn.removeClass('btn-primary');
        time = 3;
        refreshText = function(time) {
          return btn.text("关闭（" + time + "）");
        };
        handle = setInterval(function() {
          refreshText(--time);
          if (time === 0) {
            clearInterval(handle);
            return modalBox.modal('hide');
          }
        }, 1000);
        refreshText(time);
        if (typeof callback === "function") {
          callback();
        }
      };

      View.prototype.eventToggleLostCH = function(event) {
        var b, el, name, targets;
        el = $(event.currentTarget);
        b = el.prop('checked');
        name = el.attr('name');
        targets = this.els.auxiliary.filter("[data-type=\"" + name + "\"]");
        return targets[b ? 'fadeIn' : 'fadeOut'](200);
      };

      View.prototype.eventClickImportList = function(event) {
        var el, t;
        el = $(event.currentTarget);
        t = el.find('input[type="file"]');
        if (event.target === t[0]) {
          return;
        }
        return t.click();
      };

      View.prototype.eventImportList = function(event) {
        var el, o, reader;
        if (!FileReader) {
          return CSH.alert('您的浏览器版本过低，请使用推荐的浏览器');
        }
        o = event.currentTarget;
        el = $(o);
        reader = new FileReader();
        reader.readAsBinaryString(o.files[0]);
        return reader.onload = (function(_this) {
          return function() {
            var txt;
            txt = reader.result;
            _this.els.textarea.val(txt);
            _this.checkInput(true);
            return o.value = '';
          };
        })(this);
      };

      View.prototype.showProcessingHint = function() {
        if (this.els.processing) {
          this.hideProcessingHint();
        }
        return this.els.processing = CSH.hint({
          icon: 'loading',
          msg: '处理中',
          duration: Infinity
        });
      };

      View.prototype.hideProcessingHint = function(callback) {
        var target;
        if (!this.els.processing) {
          return;
        }
        target = this.els.processing;
        return target.animate({
          marginTop: '-32px',
          opacity: 0
        }, 200, (function(_this) {
          return function() {
            target.remove();
            if (typeof callback === "function") {
              callback();
            }
            return _this.els.processing = null;
          };
        })(this));
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
