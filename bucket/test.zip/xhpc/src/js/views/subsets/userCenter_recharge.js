(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  define(['jquery', 'underscore', 'backbone', 'doT', 'clipboard', 'models/payonline', 'models/payalipay', 'models/cancelOrder', 'models/getUnPayOrder', 'collections/payPlatform', 'collections/banks', 'text!../../../templates/subsets/_userCenter_tab.tpl', 'text!../../../templates/subsets/userCenter_recharge_quick.tpl', 'text!../../../templates/subsets/userCenter_recharge_caifutong.tpl', 'text!../../../templates/subsets/userCenter_recharge_weixin.tpl', 'text!../../../templates/subsets/userCenter_recharge_zhifubao.tpl', 'text!../../../templates/subsets/userCenter_recharge_bank.tpl', 'text!../../../templates/subsets/userCenter_recharge_caifutong_next.tpl', 'text!../../../templates/subsets/userCenter_recharge_weixin_next.tpl', 'text!../../../templates/subsets/userCenter_recharge_zhifubao_next.tpl', 'text!../../../templates/subsets/userCenter_recharge_bank_next.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, Clipboard, ModelPayOnline, ModelPayAlipay, ModelsCancel, ModelsUnPayOrder, CollectionPayPlatform, CollectionBanks, TplContent, TplQuick, TplCaifutong, TplWeixin, TplZhifubao, TplBank, TplCaifutongN, TplWeixinN, TplZhifubaoN, TplBankN, TplLoding) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'quick/1',
          text: '网银充值'
        }, {
          dataName: 'weixin/2',
          text: '微信'
        }, {
          dataName: 'zhifubao/3',
          text: '支付宝'
        }, {
          dataName: 'caifutong/4',
          text: '财付通'
        }, {
          dataName: 'bank/5',
          text: '网银汇款'
        }, {
          dataName: 'weixin/6',
          text: 'QQ钱包'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        quick: doT.template(TplQuick),
        caifutong: doT.template(TplCaifutong),
        weixin: doT.template(TplWeixin),
        zhifubao: doT.template(TplZhifubao),
        bank: doT.template(TplBank),
        caifutong2: doT.template(TplCaifutongN),
        weixin2: doT.template(TplWeixinN),
        zhifubao2: doT.template(TplZhifubaoN),
        bank2: doT.template(TplBankN)
      };

      View.prototype.events = {
        'click .tabTitle li': 'eventsTabSwithc',
        'click .tabContent .quickBox li button': 'eventsQuickSwicth',
        'click .tabContent .goPay': 'eventsGoPay',
        'click .tabContent .nextStep': 'eventsShowOrder',
        'click .tabContent .backOrder': 'eventsCancelOrder',
        'click .tabContent .payModeGroup button': 'eventsChoosePayMode',
        'focus .moneyInputGroup input': 'eventsMoneyInputFocus',
        'blur .moneyInputGroup input': 'eventsMoneyInputBlur',
        'mousedown .moneyInputGroup ul.dropdown li': 'eventsMoneySelect',
        'keyup input.large': 'eventDelectSpot'
      };

      View.prototype.initialize = function(data) {
        this.cPayPlatform = new CollectionPayPlatform();
        this.cBanks = new CollectionBanks();
        this.getBanksAsync(true);
        this.getPayPlatForms();
        this.getUnPayOrder();
        if (this.hasUnPayOrder) {
          return;
        }
        this.$el.find('.tabTitle ul li').eq(0).trigger('click');
        return this.initCopyBtns();
      };

      View.prototype.destroy = function() {
        var ref;
        return clearInterval(((ref = this.data) != null ? ref.tickHandle : void 0) != null);
      };

      View.prototype.eventDelectSpot = function(event) {
        var el, val;
        el = $(event.currentTarget);
        val = el.val();
        return el.val(val.replace(/\D$/g, ''));
      };

      View.prototype.getBanksAsync = function(isAsync) {
        return new CollectionBanks().setUrl().fetch({
          async: isAsync,
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              return _this.cBanks.reset(data.data);
            };
          })(this)
        });
      };

      View.prototype.getUnPayOrder = function() {
        return new ModelsUnPayOrder().setUrl().fetch({
          async: false,
          dataFilter: (function(_this) {
            return function(data) {
              var orderType, tar;
              data = data.toJSON();
              if (data.code !== 0) {
                return _this.hasUnPayOrder = false;
              }
              orderType = data.data[0].orderType;
              tar = _this.$el.find(".tabTitle ul li[data-name$=" + orderType + "]");
              if (tar.length === 0) {
                return _this.hasUnPayOrder = false;
              }
              CSH.data.recharge_isPaying = true;
              tar.addClass('active').siblings('li').removeClass('active');
              _this.viewName = tar.attr('data-name').split('/')[0];
              _this.els = {};
              _this.data = {};
              _this.curOrder = data.data[0];
              _this.els.tabContent = _this.$el.find(' .tabContent');
              _this.showOrder();
              return _this.hasUnPayOrder = true;
            };
          })(this)
        });
      };

      View.prototype.getPayPlatForms = function() {
        return new CollectionPayPlatform().setUrl().fetch({
          async: false,
          dataFilter: (function(_this) {
            return function(data) {
              var i, id, idxArr, index, item, j, k, key, len, tabOpts;
              data = data.toJSON();
              k = 0;
              for (i in data.data) {
                k++;
              }
              if (k === 0) {
                return _this.$el.html("<div class=\"widget noPlatForm\">您暂未开放充值功能<div>");
              }
              _this.payPlatForms = data.data;
              idxArr = [];
              tabOpts = [];
              for (key in _this.payPlatForms) {
                idxArr.push(+key);
              }
              for (index = j = 0, len = tabOption.length; j < len; index = ++j) {
                item = tabOption[index];
                id = +item.dataName.replace(/^\w*\//, '');
                if (indexOf.call(idxArr, id) >= 0) {
                  tabOpts.push(item);
                }
              }
              tabOpts[0].addBtn = {
                href: '/userCenter.html#property',
                dataTab: 'topUp',
                cls: 'record icon icon-form',
                text: '充值记录'
              };
              return _this.$el.html(_this.tpls.content(tabOpts));
            };
          })(this)
        });
      };

      View.prototype.initCopyBtns = function() {
        var clipboard;
        clipboard = new Clipboard('.copyBtns');
        clipboard.on('success', function() {
          return CSH.hint('复制成功');
        });
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoding);
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el, payType, ref;
        el = $(event.currentTarget);
        if (CSH.data.recharge_isPaying) {
          this.showAdvice(el.index());
          return;
        }
        arr = el.attr('data-name').split('/');
        this.viewName = arr[0];
        payType = +arr[1];
        if ((ref = this.data) != null ? ref.tickHandle : void 0) {
          clearInterval(this.data.tickHandle);
        }
        el.addClass('active').siblings('li').removeClass('active');
        this.els = {};
        this.data = {};
        this.curPlatform = {};
        this.curOrder = {};
        CSH.data.recharge_isPaying = false;
        this.els.tabContent = this.$el.find(' .tabContent');
        return this.fetchPayPlatForm(payType);
      };

      View.prototype.fetchPayPlatForm = function(payType) {
        var data;
        data = this.payPlatForms[payType];
        this.cPayPlatform.reset(data);
        if (this.viewName !== 'bank') {
          this.els.tabContent.html(this.tpls[this.viewName](data));
        }
        switch (+payType) {
          case 1:
            this.els.quickBox = this.els.tabContent.find('.quickBox');
            this.els.inputMoneyGroup = this.els.tabContent.find('.moneyInputGroup');
            this.els.agencyFeeGroup = this.els.tabContent.find('.agencyFee');
            this.els.goPay = this.els.tabContent.find('.goPay');
            return this.els.quickBox.find('li:first-child button').click();
          case 2:
          case 6:
            this.els.fyBtn = this.els.tabContent.find('.payModeGroup button.fy');
            this.els.kcBtn = this.els.tabContent.find('.payModeGroup button.kc');
            this.els.inputMoneyGroup = this.els.tabContent.find('.moneyInputGroup');
            this.els.goPay = this.els.tabContent.find('.nextStep');
            return this.els.tabContent.find('.payModeGroup button:eq(0)').click();
          case 3:
            this.els.payName = this.els.tabContent.find('#payName');
            this.els.fyBtn = this.els.tabContent.find('.payModeGroup button.fy');
            this.els.kcBtn = this.els.tabContent.find('.payModeGroup button.kc');
            this.els.inputMoneyGroup = this.els.tabContent.find('.moneyInputGroup');
            this.els.goPay = this.els.tabContent.find('.nextStep');
            return this.els.tabContent.find('.payModeGroup button:eq(0)').click();
          case 4:
            this.els.inputMoneyGroup = this.els.tabContent.find('.moneyInputGroup');
            this.curPlatform = this.cPayPlatform.at(0).toJSON();
            return this.initInputMoneyGroup();
          case 5:
            if (this.cBanks.length > 0) {
              return this.renderBank();
            }
            this.getBanksAsync(false);
            return this.renderBank();
        }
      };

      View.prototype.renderBank = function() {
        this.els.tabContent.html(this.tpls[this.viewName](this.cBanks.toJSON()));
        this.els.banks = this.els.tabContent.find('#banks');
        this.els.banks.select2({
          width: 320,
          height: 46
        });
        this.els.inputMoneyGroup = this.els.tabContent.find('.moneyInputGroup');
        this.curPlatform = this.cPayPlatform.at(0).toJSON();
        return this.initInputMoneyGroup();
      };

      View.prototype.freshAgencyFeeGroup = function(val) {
        var fee, ref, ref1, ref2;
        if (!val) {
          return (ref = this.els.agencyFeeGroup) != null ? ref.find('#tradeFeeRate').html(this.curPlatform.tradeFeeRate * 100).end().find('#maxTradeFee').html(this.curPlatform.maxTradeFee).end().find('.defTip').show().end().find('#tradeFee').html('').end().find('.lastTip').hide() : void 0;
        } else {
          fee = val * this.curPlatform.tradeFeeRate;
          if ((ref1 = this.els.agencyFeeGroup) != null) {
            ref1.find('.defTip').hide();
          }
          return (ref2 = this.els.agencyFeeGroup) != null ? ref2.find('.lastTip').find('#tradeFee').html("" + (fee > this.curPlatform.maxTradeFee ? this.curPlatform.maxTradeFee : +fee.toFixed(4))).end().show() : void 0;
        }
      };

      View.prototype.initInputMoneyGroup = function() {
        var inputMoney;
        inputMoney = this.els.inputMoneyGroup.find('input');
        inputMoney.attr('placeholder', this.curPlatform.mixAmount + "~" + this.curPlatform.maxAmount + "整数").val('');
        return this.freshAgencyFeeGroup('');
      };

      View.prototype.eventsMoneyInputFocus = function(event) {
        var el;
        el = $(event.currentTarget);
        return el.siblings('.dropdown').slideDown();
      };

      View.prototype.eventsMoneyInputBlur = function(event) {
        var el;
        el = $(event.currentTarget);
        el.siblings('.dropdown').slideUp();
        return this.freshAgencyFeeGroup(+el.val());
      };

      View.prototype.eventsMoneySelect = function(event) {
        var el, val;
        el = $(event.currentTarget);
        val = +el.attr('data-value');
        el.parent().siblings('input').val(val);
        return this.freshAgencyFeeGroup(val);
      };

      View.prototype.eventsQuickSwicth = function(event) {
        var el, id;
        el = $(event.currentTarget);
        id = +el.parents('li').attr('data-id');
        this.curPlatform = this.cPayPlatform.findWhere({
          platformId: id
        }).toJSON();
        return this.initInputMoneyGroup();
      };

      View.prototype.eventsGoPay = function(event) {
        event.preventDefault();
        return this.generateOrder();
      };

      View.prototype.eventsShowOrder = function(event) {
        if (this.curPlatform.isAutoDeposit === 1) {
          this.generateOrder();
          return;
        }
        event.preventDefault();
        return this.payAlipay();
      };

      View.prototype.eventsChoosePayMode = function(event) {
        var el, id;
        el = $(event.currentTarget);
        id = +el.attr('data-id');
        if (el.hasClass('fy')) {
          this.els.tabContent.find('.agencyFee').hide();
          this.els.agencyFeeGroup = void 0;
          if (this.viewName === 'zhifubao') {
            this.els.realNameGroup = this.els.tabContent.find('.realName');
            this.els.realNameGroup.show();
          }
        } else if (el.hasClass('kc')) {
          this.els.agencyFeeGroup = this.els.tabContent.find('.agencyFee');
          this.els.agencyFeeGroup.show();
          if (this.viewName === 'zhifubao') {
            this.els.tabContent.find('.realName').hide();
            this.els.realNameGroup = void 0;
          }
        }
        this.curPlatform = this.cPayPlatform.findWhere({
          platformId: id
        }).toJSON();
        return this.initInputMoneyGroup();
      };

      View.prototype.eventsCancelOrder = function(event) {
        return this.cancelOrder();
      };

      View.prototype.cancelOrder = function(isRefCur) {
        var process;
        CSH.data.recharge_isPaying = false;
        process = CSH.hint({
          icon: 'loading',
          msg: '请稍等...',
          duration: Infinity
        });
        return new ModelsCancel().setUrl(this.curOrder.orderNumber).save({}, {
          async: false,
          dataFilter: (function(_this) {
            return function(data) {
              process.animate({
                marginTop: '-32px',
                opacity: 0
              }, 1, function() {
                return process.remove();
              });
              data = data.toJSON();
              if (data.code !== 0) {
                return CSH.hint(data.message);
              }
              return CSH.hint({
                msg: '撤单成功',
                callback: function() {
                  if (isRefCur) {
                    return;
                  }
                  return _this.$el.find('.tabTitle ul li').eq(0).trigger('click');
                }
              });
            };
          })(this)
        });
      };

      View.prototype.hintError = function(msg) {
        return CSH.hint({
          msg: msg,
          type: 'error',
          icon: 'icon icon-close'
        });
      };

      View.prototype.moneyNotZreo = function() {
        var val;
        val = +this.els.inputMoneyGroup.find('input').val();
        if (/0$/.test(val)) {
          this.hintError('金额尾数不能为0');
          return true;
        }
        return false;
      };

      View.prototype.generateOrder = function(type) {
        var max, min, process, val;
        val = +this.els.inputMoneyGroup.find('input').val();
        min = this.curPlatform.mixAmount;
        max = this.curPlatform.maxAmount;
        if (!((min <= val && val <= max))) {
          return this.hintError("请输入" + min + "~" + max + "的整数");
        }
        if (this.moneyNotZreo()) {
          return;
        }
        process = CSH.hint({
          icon: 'loading',
          msg: '请稍等...',
          duration: Infinity
        });
        return new ModelPayOnline().setUrl().save({
          amount: val,
          platformID: this.curPlatform.platformId
        }, {
          async: false,
          dataFilter: (function(_this) {
            return function(data) {
              process.animate({
                marginTop: '-32px',
                opacity: 0
              }, 1, function() {
                return process.remove();
              });
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              _this.curOrder = data.data;
              _this.goPay();
              return _this.showPayRst();
            };
          })(this)
        });
      };

      View.prototype.payAlipay = function() {
        var max, min, payBankName, payName, process, ref, val;
        val = +this.els.inputMoneyGroup.find('input').val();
        min = this.curPlatform.mixAmount;
        max = this.curPlatform.maxAmount;
        if (!((min <= val && val <= max))) {
          return this.hintError("请输入" + min + "~" + max + "的整数");
        }
        if (this.moneyNotZreo()) {
          return;
        }
        payName = this.els.realNameGroup ? this.els.realNameGroup.find('#payName').val() : '';
        payBankName = this.els.banks ? (ref = this.cBanks.get(this.els.banks.val())) != null ? ref.get('bankName') : void 0 : '';
        if (this.viewName === 'zhifubao' && !payName) {
          return this.hintError('请输入您的支付宝号');
        }
        if (this.viewName === 'bank' && !payBankName) {
          return this.hintError('请选择银行卡');
        }
        process = CSH.hint({
          icon: 'loading',
          msg: '请稍等...',
          duration: Infinity
        });
        return new ModelPayAlipay().setUrl().save({
          amount: val,
          platformID: this.curPlatform.platformId,
          payName: payName,
          payBankName: payBankName
        }, {
          async: false,
          dataFilter: (function(_this) {
            return function(data) {
              process.animate({
                marginTop: '-32px',
                opacity: 0
              }, 1, function() {
                return process.remove();
              });
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              CSH.data.recharge_isPaying = true;
              _this.curOrder = data.data;
              return _this.showOrder();
            };
          })(this)
        });
      };

      View.prototype.goPay = function(data) {
        var el, url;
        url = this.curPlatform.submitLink + "?OrderNumber=" + this.curOrder.orderNumber + "&TradeAmount=" + this.curOrder.amount + "&PlatformNameSign=" + this.curPlatform.platformNameSign + "&Type=" + this.curPlatform.type + "&IsAutoDeposit=" + this.curPlatform.isAutoDeposit;
        el = $("<a href=\"" + url + "\" style=\"opacity: 0; position: absolute;\">前往充值</a>");
        if (this.els.goPay) {
          el.attr({
            target: this.els.goPay.attr('target')
          });
        }
        CSH.$els.body.append(el);
        el[0].click();
        return setTimeout((function() {
          return el.remove();
        }), 100);
      };

      View.prototype.showOrder = function() {
        var mBank, payBankName;
        this.els.tabContent.html(this.tpls[this.viewName + 2](this.curOrder));
        this.els.tTick = this.els.tabContent.find('.tick p.tim');
        this.initTick(this.curOrder.addTime);
        if (this.viewName === 'bank') {
          this.els.bankLinkBtn = this.els.tabContent.find('.goPaySelf');
          payBankName = this.els.tabContent.find('.payBank').html();
          if (!(this.cBanks.length > 0)) {
            this.getBanksAsync(false);
          }
          mBank = this.cBanks.findWhere({
            bankName: payBankName
          });
          return this.els.bankLinkBtn.attr({
            href: mBank.get('bankURL')
          });
        }
      };

      View.prototype.initTick = function(data) {
        var now, time;
        now = CSH.serverTime.getTime();
        time = new Date(data).getTime() + 20 * 60 * 1000 - now;
        time = Math.round(time / 1000);
        return this.data.tickHandle = setInterval((function(_this) {
          return function() {
            var h, m, s;
            --time;
            h = "" + (Math.floor(time / 60 / 60));
            m = "" + (Math.floor(time / 60 % 60));
            s = "" + (Math.floor(time % 60));
            if (time < 0) {
              CSH.data.recharge_isPaying = false;
              clearInterval(_this.data.tickHandle);
              return CSH.hint({
                msg: '倒计时结束，请重新充值',
                callback: function() {
                  return _this.refreshTab();
                }
              });
            } else if ((-1 < time && time < 20 * 60)) {
              return _this.els.tTick.html((h.length === 1 ? '0' + h : h) + "\'" + (m.length === 1 ? '0' + m : m) + "\'" + (s.length === 1 ? '0' + s : s));
            }
          };
        })(this), 1000);
      };

      View.prototype.showPayRst = function() {
        return CSH.confirm({
          className: 'payRstAlert',
          title: '支付结果',
          content: '请在新开页面完成充值！',
          ok: {
            text: '查看充值结果',
            callback: (function(_this) {
              return function() {
                return _this.$el.find('.tabTitle a.record').trigger('click');
              };
            })(this)
          },
          cancel: {
            text: '继续充值',
            callback: (function(_this) {
              return function() {
                return _this.refreshTab();
              };
            })(this)
          }
        });
      };

      View.prototype.showAdvice = function(num) {
        return CSH.confirm({
          className: 'advAlert',
          title: '支付结果',
          content: "<p>您的该笔充值尚未完成，是否撤销付款？</p>\n<p class=\"sub\">若完成支付，请不要撤销付款</p>",
          ok: {
            text: '继续充值',
            callback: (function(_this) {
              return function() {
                return CSH.data.recharge_isPaying = true;
              };
            })(this)
          },
          cancel: {
            text: '撤销付款',
            callback: (function(_this) {
              return function() {
                if ($(arguments[0].currentTarget).hasClass('close')) {
                  return;
                }
                CSH.data.recharge_isPaying = false;
                _this.cancelOrder(true);
                return _this.$el.find('.tabTitle ul li').eq(num).trigger('click');
              };
            })(this)
          }
        });
      };

      View.prototype.refreshTab = function() {
        return this.$el.find(".tabTitle ul li[data-name^=" + this.viewName + "]").trigger('click');
      };

      View.prototype.checkOrderRst = function(orderNo) {
        return 111;
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
