(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/bettingrecodesList', 'models/appendbettings', 'models/cancelbetting', 'collections/bettingrecodesList', 'collections/appendbettings', 'text!../../../templates/subsets/default-lottery_listBox2.tpl', 'text!../../../templates/subsets/default-lottery_listBox2_gameRecords.tpl', 'text!../../../templates/subsets/default-lottery_listBox2_trackRecords.tpl', 'text!../../../templates/_default-contentLoading.tpl'], function($, _, Backbone, doT, ModelGameRecords, ModelTrackRecords, ModelCancelOrder, CollectionGameRecords, CollectionTrackRecords, TplContent, TplGameRecords, TplTrackRecords, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        gr: doT.template(TplGameRecords),
        tr: doT.template(TplTrackRecords)
      };

      View.prototype.events = {
        'click .tabTitle a': 'eventSwitchData',
        'click .tabTitle .refresh': 'eventRefresh',
        'click tfoot button[data-value]': 'eventPaginate',
        'click .showInfo': 'eventShowInfo',
        'click .revoke': 'eventRevoke'
      };

      View.prototype.initialize = function(data) {
        this.parent = data.parent;
        this.data = {};
        this.xhr = null;
        this.m_gr = new ModelGameRecords();
        this.m_tr = new ModelTrackRecords();
        this.c_gr = new CollectionGameRecords();
        this.c_tr = new CollectionTrackRecords();
        return this.render();
      };

      View.prototype.render = function() {
        this.$el.html(TplContent);
        this.els = {};
        this.els.tabTitle = this.$el.find('.tabTitle');
        this.els.tabContent = this.$el.find('.tabContent');
        this.els.refresh = this.$el.find('.refresh');
        return this.els.tabTitle.find('a:first-child').click();
      };

      View.prototype.destroy = function() {};

      View.prototype.fetch_gameRecords = function(page) {
        var param;
        if (page == null) {
          page = 1;
        }
        this.data.page = page;
        if (this.xhr) {
          this.xhr.abort();
        }
        param = {
          gameID: +CSH.gID
        };
        return this.m_gr.setUrl(5, page).save(param, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              _this.els.tabContent.html(_this.tpls.gr({
                data: data.data,
                pageInfo: data.pageInfo
              }));
              _this.resetRefresh();
              _this.c_gr.reset(data.data);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.fetch_trackRecords = function(page) {
        var param;
        if (page == null) {
          page = 1;
        }
        this.data.page = page;
        if (this.xhr) {
          this.xhr.abort();
        }
        param = {
          gameID: +CSH.gID,
          state: 0
        };
        return this.m_tr.setUrl(5, page).save(param, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              _this.els.tabContent.html(_this.tpls.tr({
                data: data.data,
                pageInfo: data.pageInfo
              }));
              _this.resetRefresh();
              _this.c_tr.reset(data.data);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.resetRefresh = function() {
        return this.els.refresh.prop('disabled', false).removeClass('icon-spin icon-fast');
      };

      View.prototype.eventSwitchData = function(event) {
        var el, type;
        el = $(event.currentTarget);
        if (el.hasClass('active')) {
          return;
        }
        type = this.data.type = el.attr('data-type');
        el.addClass('active').siblings('.active').removeClass('active');
        this.els.tabContent.html(TplLoading);
        return this["fetch_" + type]();
      };

      View.prototype.eventPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        el.prop('disabled', true);
        p = el.attr('data-value');
        return this["fetch_" + this.data.type](p);
      };

      View.prototype.eventRefresh = function(event) {
        var el;
        el = $(event.currentTarget);
        el.prop('disabled', true).addClass('icon-spin icon-fast');
        this.els.tabContent.html(TplLoading);
        return this["fetch_" + this.data.type]();
      };

      View.prototype.eventShowInfo = function(event) {
        var el, id, m, tr, type;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        type = tr.closest('table').attr('data-type');
        id = el.closest('tr').attr('data-id');
        switch (type) {
          case 'gameRecords':
            m = this.c_gr.findWhere({
              projectid: id
            });
            return CSH.views.body.showGameInfo({
              pageData: m.toJSON()
            });
          case 'trackRecords':
            m = this.c_tr.get(id);
            console.log(m.toJSON());
            return CSH.views.body.showTrackInfo({
              trackInfo: m.toJSON()
            });
        }
      };

      View.prototype.eventRevoke = function(event) {
        var el, id, tr, type;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        type = tr.closest('table').attr('data-type');
        id = el.closest('tr').attr('data-id');
        switch (type) {
          case 'gameRecords':
            return new ModelCancelOrder().setUrl().save({
              orders: id
            }, {
              dataFilter: (function(_this) {
                return function(data) {
                  switch (data.toJSON().code) {
                    case 0:
                      return CSH.hint({
                        msg: '撤单成功',
                        duration: 500,
                        type: 'success',
                        callback: function() {
                          _this.fetch_gameRecords(_this.data.page);
                          return CSH.views.body.refreshBalance();
                        }
                      });
                    case 5:
                    case 1:
                      return CSH.hint({
                        msg: '操作失败，请重试',
                        duration: 1500,
                        type: 'error'
                      });
                    case 4:
                      return CSH.hint({
                        msg: '本期已经封盘,不能撤单',
                        duration: 2000
                      });
                    case 2:
                      return CSH.hint({
                        msg: '合买不能撤单',
                        duration: 1500
                      });
                    case 3:
                      return CSH.hint({
                        msg: '已经撤单',
                        duration: 1500
                      });
                    default:
                      return CSH.hint({
                        msg: data.toJSON().message,
                        duration: 1500
                      });
                  }
                };
              })(this)
            });
          case 'trackRecords':
            return console.warn('追号撤单？');
        }
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
