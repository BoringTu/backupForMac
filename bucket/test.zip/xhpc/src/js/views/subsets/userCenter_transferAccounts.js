(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/getAgentChildren', 'models/tradetransfer', 'models/safesetschecks', 'models/setCredentialsInfo', 'text!../../../templates/subsets/_userCenter_tab.tpl', 'text!../../../templates/subsets/userCenter_transferAccounts_user.tpl', 'text!../../../templates/subsets/userCenter_security_alert.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelGetAgentChildren, ModelTradetransfer, Modelsefesetschecks, ModelSetCredentialsInfo, TplContent, TplUser, TplAlert, TplLoading) {
    "use struct";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          text: '用户转账',
          addBtn: {
            href: '/userCenter.html#property',
            dataTab: 'virement',
            cls: 'record icon icon-form',
            text: '转账记录'
          }
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        user: doT.template(TplUser),
        alert: doT.template(TplAlert)
      };

      View.prototype.events = {
        'click .tabTitle li': 'eventsTabSwithc',
        'change .selectUser': 'eventSelectPeople',
        'keyup .mony .moneyNumber': 'eventNumber',
        'keyup #tradePassword': 'eventDone',
        'click button[data-type="withdraw"]': 'eventSubmit',
        'click .select2-selection ': 'eventFocus'
      };

      View.prototype.initialize = function(data) {
        this.$el.html(this.tpls.content(tabOption));
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el;
        el = $(event.currentTarget);
        this.els = {};
        arr = el.attr('data-name').split('/');
        this.viewName = arr[0];
        this.els.tabContent = this.$el.find(' .tabContent');
        this.number = {};
        this.number.people = [];
        if (localStorage.getItem('transferAccounts')) {
          this.number.people[0] = localStorage.getItem('transferAccounts');
        }
        return this.fetchData();
      };

      View.prototype.render = function() {
        return new ModelGetAgentChildren().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return '{}';
              }
              _this.els.tabContent.html(_this.tpls.user(data.data));
              return _this.getDate();
            };
          })(this)
        });
      };

      View.prototype.fetchData = function() {
        this.showLoading();
        return this.render();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventSelectPeople = function(event) {
        var el;
        el = $(event.currentTarget);
        this.number.people = el.val();
        return this.settlement();
      };

      View.prototype.eventNumber = function(event) {
        var el, val;
        el = $(event.currentTarget);
        val = el.val().replace(/[^0-9]/g, '').trim();
        el.val(val);
        this.number.money = val;
        return this.settlement();
      };

      View.prototype.settlement = function() {
        var money, number, people;
        number = 0;
        if (this.number.money) {
          money = this.number.money;
        }
        if (this.number.people) {
          people = this.number.people.length;
        }
        if (people && money) {
          number = people * money;
          this.els.calculate.text(" ￥ " + number);
        } else {
          this.els.calculate.text('');
        }
        return this.done();
      };

      View.prototype.eventDone = function(event) {
        var el;
        el = $(event.currentTarget);
        this.number.pass = el.val().length > 5;
        return this.done();
      };

      View.prototype.done = function() {
        if (!(this.number.money && this.number.people && this.number.pass)) {
          return this.els.submit.prop('disabled', true);
        } else {
          return this.els.submit.prop('disabled', false);
        }
      };

      View.prototype.eventSubmit = function(event) {
        var data, el;
        el = $(event.currentTarget);
        data = {};
        data.transAmount = this.number.money;
        data.fundPassword = this.els.tradePassword.val().md5();
        data.tradeItem = 34;
        data.userNames = this.number.people.join(',');
        data.memo = '123';
        el.prop('disabled', true);
        return new ModelTradetransfer().setUrl().save(data, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                CSH.hint({
                  msg: '转账成功',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                _this.$el.find('.tabTitle ul li').eq(0).trigger('click');
              } else {
                CSH.hint({
                  msg: data.message,
                  type: 'error',
                  icon: 'icon icon-close'
                });
              }
              return el.prop('disabled', false);
            };
          })(this)
        });
      };

      View.prototype.getDate = function() {
        var subsets;
        subsets = function(items) {
          var $items;
          return $items = $("<span style=\"color: #393f4f;\">" + items.text + " " + (+items.title ? '代理' : '') + " </span>");
        };
        this.els.selectUser = this.els.tabContent.find('.selectUser');
        this.els.selectUser.select2({
          width: 318,
          templateResult: subsets
        });
        this.els.calculate = this.els.tabContent.find('.calculate span:last-of-type');
        this.els.tradePassword = this.els.tabContent.find('#tradePassword');
        this.els.submit = this.els.tabContent.find('button[data-type="withdraw"]');
        return this.successGet();
      };

      View.prototype.successGet = function(modalBox) {
        if (modalBox) {
          modalBox.modal('hide');
        }
        return new Modelsefesetschecks().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var info;
              data = data.toJSON();
              info = data.data[0];
              if (+info.isWithPwd) {
                _this.isWithPwd();
              }
            };
          })(this)
        });
      };

      View.prototype.isWithPwd = function() {
        return CSH.views.body.isWithPwd();
      };

      View.prototype.eventFocus = function(event) {
        var el;
        el = $(event.currentTarget);
        return setTimeout((function() {
          return el.focus();
        }), 200);
      };

      View.prototype.removeClass = function(modalBox) {
        return modalBox.find('input').blur(function(el) {
          el = $(event.currentTarget);
          if (!!el.val()) {
            return el.removeClass('borderError');
          }
        });
      };

      View.prototype.goUserCenter = function(modalBox) {
        modalBox.on('keyup', function(event) {
          if (+event.keyCode === 27) {
            modalBox.trigger('hidden');
            $('.fade').hide();
            return $('.reportEntry .defaultUserCenter').trigger('click');
          }
        });
        return modalBox.find('.close').on('click', function() {
          $('.reportEntry .defaultUserCenter').trigger('click');
          $('.fade').hide();
          return modalBox.trigger('hidden');
        });
      };

      View.prototype.adderrorClass = function(el) {
        return el.addClass('borderError').focus();
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
