(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/bettingrecodes', 'collections/bettingrecodes', 'text!../../../templates/subsets/_userCenter_tab.tpl', 'text!../../../templates/subsets/userCenter_gameRecords_table.tpl', 'text!../../../templates/_paginate.tpl', 'text!../../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelBettingrecodes, CollectionBettingrecodes, TplContent, TplTable, TplPaginate, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          text: '购彩记录'
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        table: doT.template(TplTable),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'keyup .paginate input': 'eventKeyupPaginate',
        'change .lottery ': 'eventsLottery',
        'change .status': 'eventsStatus',
        'click .toolbar .day': 'eventsGetDay',
        'click .toolbar .search': 'eventDateSearch',
        'click .sort i.icon': 'eventsSort',
        'click .tabContent .gameInfo': 'showGameInfo'
      };

      View.prototype.initialize = function(data) {
        var tempDate;
        this.$el.html(this.tpls.content(tabOption));
        this.m = new ModelBettingrecodes();
        this.c = new CollectionBettingrecodes();
        this.status = '-';
        this.day = 0;
        this.toolbar = {};
        this.els = {};
        tempDate = new Date().getFormatDate();
        this.toolbar = {
          gameID: void 0,
          state: void 0,
          startDate: tempDate,
          endDate: tempDate,
          orderControl: void 0
        };
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.render = function(pageInfo) {
        var ref, sort;
        sort = this.toolbar.orderControl;
        if (!sort) {
          sort = void 0;
        } else {
          if (+sort === 1) {
            sort = 'asc';
          } else {
            sort = 'desc';
          }
        }
        this.els.tabContent.html(this.tpls.table({
          data: this.c.toJSON(),
          sort: sort,
          toolbar: this.toolbar,
          total: pageInfo.totalAmount,
          paginate: this.tpls.paginate({
            info: pageInfo,
            notice: '* 将为您保留最近 2 个月数据'
          })
        }));
        this.getDate();
        this.$el.find('select').select2();
        if ((ref = +this.day) !== 0 && ref !== 1 && ref !== 2 && ref !== 3) {
          return;
        }
        this.els.day.eq(this.day).addClass('active');
        this.els.dateStart.val('');
        return this.els.dateEnd.val('');
      };

      View.prototype.eventsTabSwithc = function(event) {
        var el;
        el = $(event.currentTarget);
        this.view = name;
        this.els = {};
        this.els.tabContent = this.$el.find(' .tabContent');
        return this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.m.setUrl(12, curPage).save(this.toolbar, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return '{}';
              }
              _this.c.reset(data.data);
              _this.render(data.pageInfo);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.eventsLottery = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.gameID = +el.val();
        this.clearSort();
        this.fetchData();
      };

      View.prototype.eventsStatus = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.state = +el.val();
        this.clearSort();
        return this.fetchData();
      };

      View.prototype.eventsGetDay = function(event) {
        var el;
        el = $(event.currentTarget);
        this.toolbar.startDate = el.attr('data-startDate');
        this.toolbar.endDate = el.attr('data-endDate');
        this.clearSort();
        this.fetchData();
        return this.day = el.attr('data-number');
      };

      View.prototype.eventDateSearch = function() {
        var endVal, startVal;
        startVal = this.els.dateStart.val();
        endVal = this.els.dateEnd.val();
        if (!(startVal && endVal)) {
          this.day = 0;
          this.els.toDay.trigger('click');
          return;
        }
        this.clearDayBtnClass();
        return this.fetchData();
      };

      View.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.toolbar.orderControl === el.attr('data-sort')) {
          return;
        }
        this.toolbar.orderControl = el.attr('data-sort');
        this.toolbar.orderBy = 'BettingAmount';
        return this.fetchData();
      };

      View.prototype.clearDayBtnClass = function() {
        return this.day = void 0;
      };

      View.prototype.clearSort = function() {
        this.toolbar.orderControl = void 0;
        return this.toolbar.orderBy = void 0;
      };

      View.prototype.getDate = function() {
        var aWeek, endDate, minDate, myDate, startDate, toDay, yesterDay;
        this.els.sort = this.$el.find(' .sort');
        this.els.toolbar = this.$el.find(' .toolbar');
        this.els.dateStart = this.els.toolbar.find('#dateStart');
        this.els.dateEnd = this.els.toolbar.find('#dateEnd');
        this.els.day = this.els.toolbar.find('.day');
        this.els.toDay = this.els.toolbar.find('.toDay');
        this.els.yesterDay = this.els.toolbar.find('.yesterDay');
        this.els.aWeek = this.els.toolbar.find('.aWeek');
        this.els.all = this.els.toolbar.find('.all');
        toDay = new Date().getFormatDate();
        yesterDay = new Date().beforeDays(1).getFormatDate();
        aWeek = new Date().beforeDays(7).getFormatDate();
        myDate = new Date();
        minDate = new Date(myDate.setMonth(myDate.getMonth() - 2)).getFormatDate();
        this.els.toDay.attr('data-startDate', toDay).attr('data-endDate', toDay);
        this.els.yesterDay.attr('data-startDate', yesterDay).attr('data-endDate', yesterDay);
        this.els.aWeek.attr('data-startDate', aWeek).attr('data-endDate', toDay);
        this.els.all.attr('data-startDate', minDate).attr('data-endDate', toDay);
        this.els.dateStart.datetimepicker({
          useCurrent: false,
          defaultDate: toDay
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59:59");
        this.els.dateEnd.datetimepicker({
          useCurrent: false,
          defaultDate: toDay + " 23:59"
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59:59");
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            if (!_this.els.dateEnd.val()) {
              _this.els.dateEnd.val((el.val().split(' ')[0]) + " 23:59");
            }
            _this.toolbar.startDate = el.val() ? (el.val()) + ":00" : (el.val()) + " 00:00:00";
            _this.toolbar.endDate = (_this.els.dateEnd.val().trim()) + ":59";
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            if (!_this.els.dateStart.val()) {
              _this.els.dateStart.val((el.val().split(' ')[0]) + " 00:00");
            }
            _this.toolbar.endDate = el.val() ? (el.val()) + ":59" : (el.val()) + ":59:59";
            _this.toolbar.startDate = (_this.els.dateStart.val()) + ":00";
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
        if (!this.toolbar.startDate) {
          return;
        }
        startDate = this.toolbar.startDate.split(':');
        endDate = this.toolbar.endDate.split(':');
        this.els.dateStart.val(startDate[2] ? startDate[0] + ":" + startDate[1] : this.toolbar.startDate);
        return this.els.dateEnd.val(endDate[2] ? endDate[0] + ":" + endDate[1] + " " : this.toolbar.endDate);
      };

      View.prototype.showGameInfo = function(event) {
        var el, index, options;
        el = $(event.currentTarget);
        index = +el.attr('data-index');
        options = this.c.models[index].attributes;
        CSH.views.body.showGameInfo({
          pageData: options,
          callback: (function(_this) {
            return function() {
              var p;
              p = +_this.$el.find('.paginate input').val();
              _this.fetchData(p);
            };
          })(this)
        });
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
