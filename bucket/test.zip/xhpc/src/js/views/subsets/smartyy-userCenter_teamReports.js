(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/getTeamReport', 'collections/getTeamReport', 'models/getTeamLotteryReportList', 'collections/getTeamLotteryReportList', 'text!../../../templates/subsets/_smartyy-userCenter_tab.tpl', 'text!../../../templates/subsets/smartyy-userCenter_teamReports_team.tpl', 'text!../../../templates/subsets/smartyy-userCenter_teamReports_lottery.tpl', 'text!../../../templates/_smartyy-paginate.tpl', 'text!../../../templates/_smartyy-contentLoading.tpl', 'text!../../../templates/_smartyy-noResult.tpl'], function($, _, Backbone, doT, ModelGetTeamReport, CollectionGetTeamReport, ModelGetTeamLotteryReportList, CollectionGetTeamLotteryReportList, TplContent, TplTeam, TplLottery, TplPaginate, TplLoading, TplNoResult) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'team',
          text: '团队报表'
        }
      ];


      /* 暂时隐藏掉
      		,
      			dataName: 'withdraw/2'
      			text: '真人报表'
      		,
      			dataName: 'virement/3_4'
      			text: '体育报表'
      		,
      			dataName: 'bouns'
      			text: '电子报表'
       */

      View.prototype.tpls = {
        content: doT.template(TplContent),
        team: doT.template(TplTeam),
        lottery: doT.template(TplLottery),
        paginate: doT.template(TplPaginate),
        noResult: doT.template(TplNoResult)
      };

      View.prototype.events = {
        'click .paginate button': 'eventClickPaginate',
        'click .tabTitle li': 'eventsTabSwithc',
        'keyup .paginate input': 'eventKeyupPaginate',
        'change .toolbar .status': 'eventStatus',
        'click .toolbar .day': 'eventsGetDay',
        'click .toolbar .search': 'eventDateSearch',
        'click .dataContent .sort i.icon': 'eventsSort',
        'click .tabContent .searchTeam': 'eventsSearchTeam',
        'keyup .toolbar .serialNumber': 'eventKeyupInputSearch',
        'change .toolbar .lottery': 'eventLottery',
        'click .tabContent .gameInfo': 'showGameInfo',
        'change .toolbar .platformName': 'eventplatformToggle'
      };

      View.prototype.initialize = function(data) {
        var today;
        this.$el.html(this.tpls.content(tabOption));
        this.m_team = new ModelGetTeamReport();
        this.c_team = new CollectionGetTeamReport();
        this.m_lottery = new ModelGetTeamLotteryReportList();
        this.c_lottery = new CollectionGetTeamLotteryReportList();
        this.msg = '暂无记录！';
        this.viewName = null;
        this.day = 0;
        today = new Date().getFormatDate();
        this.viewData = {
          crumb: void 0,
          curUser: void 0,
          total: void 0,
          msg: '暂无记录！'
        };
        this.toolbar = {
          userId: void 0,
          likename: '',
          userType: 0,
          sort: 0,
          beginTime: today,
          endTime: today,
          platformType: 0
        };
        this.viewDataLottery = {
          pathUserName: localStorage.getItem('username')
        };
        this.toolbarLottery = {
          userName: void 0,
          gameId: 0,
          state: void 0,
          startDate: void 0,
          endDate: void 0,
          platformType: 0
        };
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.clearPageInfo = function(retainArr) {
        if (!(retainArr && retainArr.has("time"))) {
          this.day = 0;
          this.toolbar.beginTime = new Date().getFormatDate();
          this.toolbar.endTime = new Date().getFormatDate();
        }
        if (!(retainArr && retainArr.has("userType"))) {
          this.toolbar.userType = 0;
        }
        if (!(retainArr && retainArr.has("likename"))) {
          this.toolbar.likename = '';
        }
        if (!(retainArr && retainArr.has("sort"))) {
          this.toolbar.sort = void 0;
        }
        this.toolbar.userId = void 0;
        this.viewData = {
          crumb: void 0,
          curUser: void 0,
          total: void 0,
          msg: '暂无记录！'
        };
      };

      View.prototype.clearPageInfoLottery = function(retainArr) {
        if (!(retainArr && retainArr.has("time"))) {
          this.toolbarLottery.startDate = (new Date().getFormatDate()) + " 00:00:00";
          this.toolbarLottery.endDate = (new Date().getFormatDate()) + " 23:59:59";
        }
        if (!(retainArr && retainArr.has("state"))) {
          this.toolbarLottery.state = void 0;
        }
        if (!(retainArr && retainArr.has("gameId"))) {
          this.toolbarLottery.gameId = 0;
        }
        if (!(retainArr && retainArr.has("userName"))) {
          this.toolbarLottery.userName = void 0;
        }
        this.viewDataLottery = {
          pathUserName: localStorage.getItem('username')
        };
        this.msg = '暂无记录！';
      };

      View.prototype.render = function(pageInfo) {
        var endDate, sort, startDate;
        sort = this.toolbar.sort;
        if (sort !== 0 && sort !== 1) {
          sort = void 0;
        } else {
          if (+sort === 1) {
            sort = 'asc';
          } else {
            sort = 'desc';
          }
        }
        if (this.viewName === 'lottery') {
          this.els.tabContent.html(this.tpls[this.viewName]({
            data: this.c.toJSON(),
            toolbar: this.toolbarLottery,
            layerRelation: pageInfo.layerRelation,
            msg: this.msg,
            paginate: this.tpls.paginate({
              info: pageInfo,
              notice: '* 将为您保留最近 1 个月数据'
            }),
            noResult: this.tpls.noResult({
              text: this.msg
            })
          }));
        } else {
          this.els.tabContent.html(this.tpls[this.viewName]({
            data: this.c.toJSON(),
            sort: sort,
            toolbar: this.toolbar,
            viewData: this.viewData,
            paginate: this.tpls.paginate({
              info: pageInfo,
              notice: '* 将为您保留最近 1 个月数据'
            }),
            noResult: this.tpls.noResult({
              text: this.msg
            })
          }));
        }
        this.els.search = this.$el.find('.toolbar .search');
        this.els.pageInput = this.$el.find('.paginate input');
        this.$el.find('select').select2();
        this.getDate();
        if (this.els.day.eq(this.day).length === 0) {
          if (this.viewName === 'lottery') {
            if (this.toolbarLottery.startDate) {
              startDate = this.toolbarLottery.startDate.split(':');
              endDate = this.toolbarLottery.endDate.split(':');
              this.els.dateStart.val(startDate[2] ? startDate[0] + ":" + startDate[1] : this.toolbarLottery.startDate);
              this.els.dateEnd.val(endDate[2] ? endDate[0] + ":" + endDate[1] : this.toolbarLottery.endDate);
            }
          } else {
            startDate = this.toolbar.beginTime.split(':');
            endDate = this.toolbar.endTime.split(':');
            this.els.dateStart.val(startDate[2] ? startDate[0] + ":" + startDate[1] : this.toolbar.beginTime);
            this.els.dateEnd.val(endDate[2] ? endDate[0] + ":" + endDate[1] : this.toolbar.endTime);
          }
        }
        return this.els.day.removeClass('active').eq(this.day).addClass('active');
      };

      View.prototype.fetchData = function(curPage) {
        var ref;
        if (curPage == null) {
          curPage = 1;
        }
        this.showLoading();
        if ((ref = this.toolbar.sort) !== 0 && ref !== 1) {
          this.toolbar.sort = 1;
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        if (this.viewName === 'lottery') {
          this.m.setUrl(this.viewDataLottery.pathUserName, curPage).save(this.toolbarLottery, {
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                if (data.code !== 0) {
                  _this.msg = data.message;
                }
                _this.c.reset(data.data || []);
                _this.render(data.pageInfo || {});
                _this.m.clear();
              };
            })(this)
          });
        } else {
          this.m.setUrl(curPage, 15).save(this.toolbar, {
            beforeSend: (function(_this) {
              return function(xhr) {
                return _this.xhr = xhr;
              };
            })(this),
            dataFilter: (function(_this) {
              return function(data) {
                data = data.toJSON();
                if (data.code !== 0) {
                  _this.viewData.msg = data.message;
                  _this.c.reset([]);
                  _this.viewData.crumb = [];
                  _this.viewData.curUser = {};
                  _this.viewData.total = {};
                  _this.render(data.pageInfo || {});
                  return;
                }
                _this.c.reset(data.data.list || []);
                _this.viewData.crumb = data.data.sub.crumb || [];
                _this.viewData.curUser = data.data.sub.current[0];
                _this.viewData.total = data.data.sub.total[0];
                _this.render(data.pageInfo || {});
                _this.m.clear();
              };
            })(this)
          });
        }
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el, name, type;
        el = $(event.currentTarget);
        arr = el.attr('data-name');
        arr = arr.split('/');
        name = arr[0];
        type = arr[1];
        el.addClass('active').siblings('li').removeClass('active');
        this.viewName = name;
        this.els = {};
        this.els.tabContent = this.$el.find('.tabContent');
        if (name === 'team') {
          this.c = this.c_team;
          this.m = this.m_team;
          this.clearPageInfo();
        } else if (name === 'lottery') {
          this.c = this.c_lottery;
          this.m = this.m_lottery;
          this.clearPageInfoLottery();
        }
        this.toolbarLottery.platformType = 0;
        this.toolbar.platformType = 0;
        this.fetchData();
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoading);
      };

      View.prototype.eventsGetDay = function(event) {
        var el;
        el = $(event.currentTarget);
        if (!el.hasClass('all')) {
          this.toolbar.beginTime = el.attr('data-startDate');
          this.toolbar.endTime = el.attr('data-endDate');
        } else {
          delete this.toolbar.beginTime;
          delete this.toolbar.endTime;
        }
        this.fetchData();
        this.day = el.attr('data-number');
      };

      View.prototype.eventDateSearch = function(el) {
        var endVal, number, startVal;
        el = $(el.currentTarget);
        startVal = this.els.dateStart.val();
        endVal = this.els.dateEnd.val();
        number = this.els.serialNumber.val().trim();
        if (this.viewName === 'lottery') {
          if (startVal && endVal) {
            this.day = 1000000;
            this.toolbarLottery.startDate = startVal.split(':')[2] ? startVal : startVal + ":00";
            this.toolbarLottery.endDate = endVal.split(':')[2] ? endVal : endVal + ":59";
          }
          if (number) {
            this.clearPageInfoLottery(['time']);
            this.toolbarLottery.userName = number.encodeHTML();
          } else if (!endVal && !startVal) {
            CSH.hint("请输入开始或结束时间");
            return;
          }
        } else {
          if (startVal && endVal) {
            this.day = 1000000;
            this.toolbar.beginTime = startVal.split(':')[2] ? startVal : startVal + ":00";
            this.toolbar.endTime = endVal.split(':')[2] ? endVal : endVal + ":59";
          }
          if (number) {
            this.clearPageInfo(['time']);
            this.toolbar.likename = number.encodeHTML();
          } else if (!endVal && !startVal) {
            CSH.hint("请输入开始或结束时间");
            return;
          }
        }
        this.toolbarLottery.userName = this.toolbar.likename = number.encodeHTML();
        this.fetchData();
        return el.prop('disabled', true);
      };

      View.prototype.eventStatus = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            if (_this.viewName === 'lottery') {
              _this.toolbarLottery.state = +el.val();
            } else {
              _this.toolbar.userType = +el.val();
            }
            return _this.fetchData();
          };
        })(this));
      };

      View.prototype.eventLottery = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el;
            el = $(event.currentTarget);
            _this.toolbarLottery.gameId = +el.val();
            return _this.fetchData();
          };
        })(this));
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        return this.fetchData(p);
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          return this.fetchData(p);
        }
      };

      View.prototype.getDate = function() {
        var aWeek, minDate, myDate, toDay, yesterDay;
        this.els.toolbar = this.$el.find('.toolbar');
        this.els.serialNumber = this.els.toolbar.find('.serialNumber');
        this.els.dateStart = this.els.toolbar.find('#dateStart');
        this.els.dateEnd = this.els.toolbar.find('#dateEnd');
        this.els.day = this.els.toolbar.find('.day');
        this.els.toDay = this.els.toolbar.find('.toDay');
        this.els.yesterDay = this.els.toolbar.find('.yesterDay');
        this.els.aWeek = this.els.toolbar.find('.aWeek');
        this.els.all = this.els.toolbar.find('.all');
        toDay = new Date().getFormatDate();
        yesterDay = new Date().beforeDays(1).getFormatDate();
        aWeek = new Date().beforeDays(7).getFormatDate();
        myDate = new Date();
        minDate = new Date(myDate.setMonth(myDate.getMonth() - 2)).getFormatDate();
        this.els.toDay.attr('data-startDate', toDay).attr('data-endDate', toDay);
        this.els.yesterDay.attr('data-startDate', yesterDay).attr('data-endDate', yesterDay);
        this.els.aWeek.attr('data-startDate', aWeek).attr('data-endDate', toDay);
        this.els.dateStart.datetimepicker({
          useCurrent: false,
          defaultDate: toDay
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59:59");
        this.els.dateEnd.datetimepicker({
          useCurrent: false,
          defaultDate: toDay + " 23:59"
        }).data('DateTimePicker').minDate(minDate).maxDate(toDay + " 23:59:59");
        this.els.dateStart.on('dp.change', (function(_this) {
          return function(event) {
            var el, time;
            el = $(event.currentTarget);
            time = el.val().split(' ')[0];
            if (_this.viewName === 'lottery') {
              _this.toolbarLottery.startDate = el.val();
              if (!_this.els.dateEnd.val()) {
                _this.els.dateEnd.val(time + " 23:59:59");
                _this.toolbarLottery.endDate = time + " 23:59:59";
              }
            } else {
              _this.toolbar.beginTime = el.val();
              if (!_this.els.dateEnd.val()) {
                _this.els.dateEnd.val(time + " 23:59:59");
                _this.toolbar.endTime = time + " 23:59:59";
              }
            }
            return _this.els.dateEnd.data('DateTimePicker').minDate(event.date);
          };
        })(this));
        return this.els.dateEnd.on('dp.change', (function(_this) {
          return function(event) {
            var el;
            el = $(event.currentTarget);
            if (_this.viewName === 'lottery') {
              _this.toolbarLottery.endDate = el.val();
              _this.els.dateEnd.val(el.val());
              if (!_this.els.dateStart.val()) {
                _this.els.dateStart.val((el.val().split(' ')[0]) + " 00:00");
                _this.toolbarLottery.startDate = (el.val().split(' ')[0]) + " 00:00";
              }
            } else {
              _this.toolbar.endTime = el.val();
              if (!_this.els.dateStart.val()) {
                _this.els.dateStart.val(el.val());
                _this.toolbar.beginTime = el.val();
              }
            }
            return _this.els.dateStart.data('DateTimePicker').maxDate(event.date);
          };
        })(this));
      };

      View.prototype.eventsSearchTeam = function(event) {
        if (this.viewName === 'lottery') {
          this.clearPageInfoLottery(['time']);
          this.viewDataLottery.pathUserName = $(event.currentTarget).attr('data-uid');
        } else {
          this.clearPageInfo(['time']);
          this.toolbar.userId = $(event.currentTarget).attr('data-uid');
        }
        this.fetchData();
      };

      View.prototype.eventsSort = function(event) {
        var el;
        el = $(event.currentTarget);
        if (this.toolbar.sort === +el.attr('data-sort')) {
          return;
        }
        this.toolbar.sort = +el.attr('data-sort');
        return this.fetchData();
      };

      View.prototype.eventplatformToggle = function(event) {
        return CSH.async((function(_this) {
          return function() {
            var el, today, type;
            el = $(event.currentTarget);
            type = el.val();
            today = new Date().getFormatDate();
            _this.toolbarLottery.platformType = +type;
            _this.toolbar = {
              platformType: +type,
              likename: "",
              userType: 0,
              sort: 1,
              beginTime: today + " 00:00:00",
              endTime: today + " 23:59:59"
            };
            _this.day = 0;
            return _this.fetchData();
          };
        })(this));
      };

      View.prototype.eventKeyupInputSearch = function(event) {
        if (event.keyCode === 13) {
          this.els.search.click();
        }
      };

      View.prototype.showGameInfo = function(event) {
        var el, index, options;
        el = $(event.currentTarget);
        index = +el.attr('data-index');
        options = this.c.models[index].attributes;
        CSH.views.body.showGameInfo({
          pageData: options,
          callback: (function(_this) {
            return function() {
              var p;
              p = +_this.els.pageInput.val();
              _this.fetchData(p);
            };
          })(this)
        });
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
