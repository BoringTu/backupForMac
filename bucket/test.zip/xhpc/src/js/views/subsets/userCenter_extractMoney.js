(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/bankaccounts', 'models/withdrawl', 'models/availableamount', 'models/setCredentialsInfo', 'models/banks', 'models/truename', 'models/safesetschecks', 'text!../../../templates/subsets/_userCenter_tab.tpl', 'text!../../../templates/subsets/userCenter_extractMoney_table.tpl', 'text!../../../templates/subsets/userCenter_security_alert.tpl', 'text!../../../templates/_contentLoading.tpl', 'text!../../../js/province-city.json'], function($, _, Backbone, doT, ModelBankAccounts, ModelWithDrawl, ModelAvailableAmount, ModelSetCredentialsInfo, ModelsBanks, ModelTruename, Modelsefesetschecks, TplContent, TplExtracyMoney, TplAlert, TplLoding, jsonProvinceCity) {
    "use strict";
    var View;
    return View = (function(superClass) {
      var tabOption;

      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      tabOption = [
        {
          dataName: 'extractMoney',
          text: '快速提现',
          addBtn: {
            href: '/userCenter.html#property',
            dataTab: 'withdraw',
            cls: 'record icon icon-form',
            text: '提现记录'
          }
        }
      ];

      View.prototype.tpls = {
        content: doT.template(TplContent),
        alert: doT.template(TplAlert),
        extractMoney: doT.template(TplExtracyMoney)
      };

      View.prototype.events = {
        'click .tabTitle li': 'eventsTabSwithc',
        'click .mony .rightBox .selectMonyBtn': 'eventAllSelectMonyBtn',
        'click .monyWrap button[data-type="withdraw"]': 'eventWithdrawButton',
        'keyup .monyWrap #tradePassword': 'eventKeyUpTradePassword',
        'keyup #mony': 'eventIsNumber',
        'click .monyWrap .add': 'eventAddCard'
      };

      View.prototype.initialize = function(data) {
        this.$el.html(this.tpls.content(tabOption));
        return this.$el.find('.tabTitle ul li').eq(0).trigger('click');
      };

      View.prototype.render = function() {
        this.els.tabContent.html(this.tpls[this.viewName](this.data));
        return this.getDate();
      };

      View.prototype.fetchData = function() {
        var getBankList, getEnabledMoney;
        this.showLoading();
        getEnabledMoney = (function(_this) {
          return function(callback) {
            return new ModelAvailableAmount().setUrl().fetch({
              dataFilter: function(data) {
                data = data.toJSON();
                if (data.code !== 0) {
                  return '{}';
                }
                _this.data.balance = _this.data.enabledMoney = parseInt(data.data.nowBalance);
                return callback();
              }
            });
          };
        })(this);
        getBankList = (function(_this) {
          return function() {
            return new ModelBankAccounts().setUrl().fetch({
              dataFilter: function(data) {
                data = data.toJSON();
                if (data.code !== 0) {
                  return '{}';
                }
                _this.data.bankMap = data.data;
                _this.render();
                _this.els.mony.val('');
                return _this.els.tradePassword.val('');
              }
            });
          };
        })(this);
        return getEnabledMoney(getBankList);
      };

      View.prototype.nowViewName = function(viewName) {
        return this.$el.find('.tabTitle ul li').filter("[data-name=\"" + this.viewName + "\"]").trigger('click');
      };

      View.prototype.showLoading = function() {
        return this.els.tabContent.off().empty().html(TplLoding);
      };

      View.prototype.eventsTabSwithc = function(event) {
        var arr, el;
        el = $(event.currentTarget);
        this.els = {};
        arr = el.attr('data-name').split('/');
        this.viewName = arr[0];
        this.els.tabContent = this.$el.find(' .tabContent');
        this.data = {};
        return this.fetchData();
      };

      View.prototype.eventAllSelectMonyBtn = function() {
        var allTop;
        allTop = 50000;
        if (this.data.balance < allTop) {
          allTop = this.data.balance;
        }
        return this.els.mony.val(allTop);
      };

      View.prototype.eventIsNumber = function(event) {
        var allTop, el;
        el = $(event.currentTarget);
        allTop = el.val();
        if (allTop > 50000) {
          allTop = 50000;
          el.val(allTop);
        }
        if (this.data.balance < allTop) {
          allTop = parseInt(this.data.balance);
        }
        return el.val(parseInt(allTop));
      };

      View.prototype.eventKeyUpTradePassword = function(event) {
        var el, val;
        el = $(event.currentTarget);
        val = el.val().length > 5;
        return this.els.passBtn.attr('disabled', !val);
      };

      View.prototype.eventWithdrawButton = function(event) {
        var btn, cardCount, id, mony, ref, saveData, temp, tradePassword;
        btn = $(event.currentTarget);
        mony = this.els.mony.val();
        tradePassword = this.els.tradePassword.val();
        id = this.els.bankCard.find("option:selected").attr('data-id');
        btn.attr('disabled', true);
        if (mony < 100 || mony > 50000 || !mony) {
          return CSH.hint({
            msg: '请输入100~50,000的整数',
            type: 'error',
            icon: 'icon icon-close',
            callback: function() {
              return btn.attr('disabled', false);
            }
          });
        }
        cardCount = 0;
        ref = this.data.bankMap;
        for (temp in ref) {
          if (!hasProp.call(ref, temp)) continue;
          cardCount++;
        }
        if (!cardCount) {
          return CSH.hint({
            msg: '请绑定银行卡',
            type: 'error',
            icon: 'icon icon-close',
            callback: function() {
              return btn.attr('disabled', false);
            }
          });
        }
        saveData = {
          tradeAmount: +mony,
          withdrawalPassword: tradePassword.md5(),
          bankID: +id
        };
        return new ModelWithDrawl().setUrl().save(saveData, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code === 0) {
                CSH.hint({
                  msg: '提现申请已提交',
                  type: 'success',
                  icon: 'icon icon-ok'
                });
                return _this.$el.find('.tabTitle ul li').eq(0).trigger('click');
              } else {
                _this.errorHint(data.message);
                return btn.attr('disabled', false);
              }
            };
          })(this)
        });
      };

      View.prototype.getDate = function() {
        this.els.tabContent.find('select').select2().find('select2-selection').css('height', '46');
        this.els.mony = this.els.tabContent.find('#mony');
        this.els.bankCard = this.els.tabContent.find('#bankCard');
        this.els.tradePassword = this.els.tabContent.find('#tradePassword');
        this.els.passBtn = this.els.tabContent.find('button[data-type="withdraw"]');
        return this.successGet();
      };

      View.prototype.eventAddCard = function(event) {
        var Getbank, el;
        el = $(event.currentTarget);
        el.attr('disabled', true);
        new ModelTruename().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code) {
                return '{}';
              }
              return Getbank(data.data, el);
            };
          })(this)
        });
        return Getbank = (function(_this) {
          return function(truename, el) {
            return new ModelsBanks().setUrl().fetch({
              dataFilter: function(data) {
                var key, modalBox, province, provinceCity, pwd, val;
                data = data.toJSON();
                if (data.code) {
                  return '{}';
                }
                modalBox = CSH.alert({
                  title: '添加银行卡',
                  content: _this.tpls.alert({
                    name: 'addCard',
                    bank: data.data,
                    truename: truename
                  }),
                  className: 'isCredentials',
                  ok: {
                    text: '添加银行卡',
                    autohide: false,
                    callback: function(event) {
                      var saveData;
                      el = $(event.currentTarget);
                      el.attr('disabled', true);
                      saveData = {};
                      saveData.bankAccount = truename;
                      saveData.bankNumber = modalBox.find('input[data-type="bankNumber"]').val().replace(/\s/g, "");
                      saveData.bankID = modalBox.find('select option:selected').attr('data-id');
                      saveData.isDefault = +(!modalBox.find('input[type="checkbox"]').prop('checked'));
                      saveData.province = pwd.province.val().encodeHTML();
                      saveData.city = pwd.city.val().encodeHTML();
                      saveData.bankAddress = pwd.bankAddress.val().encodeHTML();
                      if (!saveData.bankID) {
                        _this.errorHint('请选择银行', el);
                        return;
                      }
                      if (!(saveData.bankNumber && saveData.bankNumber.checkLuhn())) {
                        _this.errorHint('请输入正确的银行卡号', el);
                        return;
                      }
                      if (saveData.province === '省份') {
                        _this.errorHint('请选择省份', el);
                        return;
                      }
                      if (saveData.city === '城市') {
                        _this.errorHint('请选择省份', el);
                        return;
                      }
                      if (!saveData.bankAddress) {
                        _this.errorHint('请输入开户网点', el);
                        return;
                      }
                      return new ModelBankAccounts().setUrl().save(saveData, {
                        dataFilter: function(data) {
                          var code;
                          data = data.toJSON();
                          code = data.code;
                          if (code === 3) {
                            return _this.errorHint(data.message, el);
                          } else if (code === 0) {
                            return CSH.hint({
                              msg: data.message,
                              type: 'success',
                              icon: 'icon icon-ok',
                              callback: function() {
                                return _this.successSet(modalBox);
                              }
                            });
                          }
                        }
                      });
                    }
                  }
                });
                modalBox.find('input[type="checkbox"]').trigger('click');
                provinceCity = jsonProvinceCity.toJSON();
                pwd = {};
                pwd.bankId = modalBox.find('select.bankId');
                pwd.bankNumber = modalBox.find('input[data-type="bankNumber"]');
                pwd.province = modalBox.find('select.province');
                pwd.city = modalBox.find('select.city');
                pwd.bankAddress = modalBox.find('input[data-type="bankAddress"]');
                province = '';
                for (key in provinceCity) {
                  val = provinceCity[key];
                  province += "<option> " + key + " </option> ";
                }
                pwd.province.append(province).on('change', function(event) {
                  var city, results;
                  el = $(event.currentTarget);
                  city = '';
                  results = [];
                  for (key in provinceCity) {
                    val = provinceCity[key];
                    if (key === el.val()) {
                      if (val.length !== 0) {
                        val.map(function(val, i) {
                          return city += "<option> " + val + " </option> ";
                        });
                      } else {
                        city = "<option> " + key + " </option> ";
                      }
                      results.push(pwd.city.html(city).select2());
                    } else {
                      results.push(void 0);
                    }
                  }
                  return results;
                });
                pwd.bankNumber.on('keyup', function(event) {
                  el = $(event.currentTarget);
                  val = el.val();
                  val = val.replace(/\s/g, '');
                  val = val.replace(/\D$/, '');
                  return el.val(val.replace(/\d{4}/g, '$& ').trim());
                });
                modalBox.find('select').select2().on('click', function() {
                  return $('.select2-container--open').css('zIndex', 1600);
                });
                _this.goUserCenter(modalBox, el);
                return _this.removeClass(modalBox);
              }
            });
          };
        })(this);
      };

      View.prototype.isCredentials = function() {
        var modalBox;
        modalBox = CSH.alert({
          title: '身份认证',
          content: this.tpls.alert({
            name: 'isCredentials'
          }),
          className: 'isCredentials',
          ok: {
            text: '下一步',
            autohide: false,
            callback: (function(_this) {
              return function(event) {
                var data, el, email, emailEl, fade, idEl, name, nameEl, reg, valName;
                el = $(event.currentTarget);
                nameEl = modalBox.find('input[data-type="name"]');
                idEl = modalBox.find('input[data-type="id"]');
                emailEl = modalBox.find('input[data-type="email"]');
                valName = nameEl.val().trim();
                email = emailEl.val().trim();
                fade = $('.fade');
                data = {};
                reg = /^[1-9]{1}[0-9]{14}$|^[1-9]{1}[0-9]{16}([0-9]|[xX])$/;
                name = /[\u4E00-\u9FA5]{2,5}(?:·[\u4E00-\u9FA5]{2,5})*/;
                if (!name.test(valName || valName)) {
                  _this.adderrorClass(nameEl);
                  CSH.hint({
                    msg: '请输入正确的姓名',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                  return;
                }
                if (false && !reg.test(idName)) {
                  _this.adderrorClass(idEl);
                  CSH.hint({
                    msg: '请输入正确的身份证',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                  return;
                }
                if (!/^\w+@[a-zA-Z0-9\-]+(\.[a-zA-Z]+){1,2}$/.test(email)) {
                  _this.adderrorClass(emailEl);
                  CSH.hint({
                    msg: '请输入格式正确的邮箱地址',
                    type: 'error',
                    icon: 'icon icon-close'
                  });
                  return;
                }
                data.trueName = valName;
                data.email = email;
                return new ModelSetCredentialsInfo().setUrl().save(data, {
                  dataFilter: function(data) {
                    data = data.toJSON();
                    if (+data.code === 0) {
                      CSH.hint({
                        msg: data.message,
                        type: 'success',
                        icon: 'icon icon-ok',
                        callback: function() {
                          return _this.successGet(modalBox);
                        }
                      });
                    } else {
                      CSH.hint({
                        msg: data.message,
                        type: 'error',
                        icon: 'icon icon-close'
                      }, el.attr('disabled', false));
                    }
                  }
                });
              };
            })(this)
          }
        });
        this.goUserCenter(modalBox);
        return this.removeClass(modalBox);
      };

      View.prototype.isWithPwd = function() {
        return CSH.views.body.isWithPwd();
      };

      View.prototype.errorHint = function(msg, el) {
        CSH.hint({
          msg: msg,
          type: 'error',
          icon: 'icon icon-close'
        });
        if (el) {
          return el.attr('disabled', false);
        }
      };

      View.prototype.successGet = function(modalBox) {
        if (modalBox) {
          modalBox.modal('hide');
        }
        return new Modelsefesetschecks().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var info;
              data = data.toJSON();
              info = data.data[0];
              if (+info.isWithPwd) {
                _this.isWithPwd();
              }
            };
          })(this)
        });
      };

      View.prototype.successSet = function(modalBox) {
        modalBox.modal('hide');
        return CSH.router.refresh();
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
