(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/info', 'models/balance', 'models/safesetschecks', 'models/safelevel', 'text!../../templates/userCenter.tpl', 'text!../../templates/_contentLoading.tpl'], function($, _, Backbone, doT, ModelInfo, ModelsBalance, ModelSafesetschecks, Modelsafelevel, TplContent, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .reportEntry a': 'eventLoadView',
        'click .refresh': 'eventRefresh'
      };

      View.prototype.initialize = function(data) {
        var name;
        this.data = {};
        this.render();
        name = CSH.routePath[0];
        if (name) {
          this.loadView(name);
        } else {
          name = 'property';
          this.loadView(name, true);
        }
        return CSH.$els.window.on('hashchange', (function(_this) {
          return function(event) {
            console.log(arguments);
            return _this.loadView(name);
          };
        })(this));
      };

      View.prototype.render = function() {
        var it;
        it = {};
        it.username = localStorage.getItem('username');
        it.time = this.time();
        it.rebate = localStorage.getItem('rebate');
        this.$el.html(this.tpls.content(it));
        this.els = {};
        this.els.content = this.$el.find('.content');
        return this.getInfo();
      };

      View.prototype.loadView = function(name, isInit) {
        var r1, ref;
        if ((ref = this.oldView) != null) {
          if (typeof ref.destroy === "function") {
            ref.destroy();
          }
        }
        this.showLoading();
        r1 = CSH.pageName;
        return require(["views/subsets/" + r1 + "_" + name], (function(_this) {
          return function(View) {
            _this.oldView = new View({
              el: _this.els.content,
              pView: _this
            });
            _this.els.content.addClass(name);
            return _this.oldName = name;
          };
        })(this));
      };

      View.prototype.showLoading = function() {
        return this.els.content.off().empty().removeClass(this.oldName).html(TplLoading);
      };

      View.prototype.eventLoadView = function(event) {
        var el, href, name, r1;
        event.preventDefault();
        el = $(event.currentTarget);
        href = el.attr('href');
        if (href === 'javascript:;') {
          return;
        }
        name = href.replace(/^\/userCenter.html\//, '');
        CSH.$els.window.trigger('hashchange');
        r1 = CSH.pageName;
        console.log(r1, name);
        history.pushState(null, null, "#" + r1 + "/" + name);
        return;
        return this.loadView(name);
      };

      View.prototype.getInfo = function() {
        new ModelInfo().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var $type, type;
              data = data.toJSON();
              if (data.data === 1) {
                type = '会员';
              } else {
                type = '代理';
              }
              $type = _this.$el.find('.typeWrap .type');
              return $type.text(type);
            };
          })(this)
        });
        new ModelSafesetschecks().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var $card, $realname, $safeState, $safety, className, complete;
              data = data.toJSON();
              complete = data.data[0];
              className = "complete";
              $safeState = _this.$el.find('.safeState');
              $realname = $safeState.find('.icon-realname');
              $safety = $safeState.find('.icon-safety');
              $card = $safeState.find('.icon-card');
              if (!complete.isWithPwd) {
                $safety.addClass(className);
              }
              if (!complete.isBankAccount) {
                $card.addClass(className);
              }
              if (!complete.isCredentials) {
                $realname.addClass(className);
              }
              localStorage.setItem('isCredentials', complete.isCredentials);
              return localStorage.setItem('isWithPwd', complete.isWithPwd);
            };
          })(this)
        });
        new Modelsafelevel().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var $aBtn, $prompt, $status, color, number, prompt;
              data = data.toJSON();
              number = data.data;
              color = '#f15a59';
              prompt = '% 低';
              $status = _this.$el.find(' .status .safeLine');
              $prompt = _this.$el.find(' .status .prompt span');
              $aBtn = _this.$el.find(' .status a');
              if (number > 50 && number < 70) {
                prompt = '% 中';
                color = '#f3cb69';
              } else if (number > 70) {
                prompt = '% 高';
                color = '#57ba60';
              }
              if (number === 100) {
                $aBtn.remove();
              }
              $prompt.text(number + prompt).css('color', color);
              return $status.width(number + '%').css('backgroundColor', color);
            };
          })(this)
        });
        return this.eventRefresh();
      };

      View.prototype.eventRefresh = function(event) {
        var el;
        if (event) {
          el = $(event.currentTarget);
          el.prop('disabled', true).find('.icon').addClass('icon-spin icon-fast');
        }
        new ModelsBalance().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var $money, i, len, obj, str;
              data = data.toJSON();
              data.data = +data.data;
              str = +data.data.accurate(4);
              $money = $(' .realTimeBalance');
              for (i = 0, len = $money.length; i < len; i++) {
                obj = $money[i];
                obj = $(obj);
                if (+obj.attr('data-type')) {
                  str = CSH.utils.formatMoney(str);
                }
                obj.text(str);
              }
              if (event) {
                return el.prop('disabled', false).find('.icon').removeClass('icon-spin icon-fast');
              }
            };
          })(this)
        });
        if (event) {
          return setTimeout(function() {
            return el.prop('disabled', false).find('.icon').removeClass('icon-spin icon-fast');
          }, 1000);
        }
      };

      View.prototype.time = function() {
        var iHours, iMin, myTime, now, re;
        myTime = new Date();
        iHours = myTime.getHours();
        iMin = myTime.getMinutes();
        now = this.toTow(iHours) + this.toTow(iMin);
        if (now < 600) {
          re = '晚上好';
        } else if (now < 1130) {
          re = '上午好';
        } else if (now < 1400) {
          re = '中午好';
        } else if (now < 1700) {
          re = '下午好';
        } else {
          re = '晚上好';
        }
        return re;
      };

      View.prototype.toTow = function(n) {
        if (n < 10) {
          return '0' + n;
        } else {
          return '' + n;
        }
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
