(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'algorithmMark6', 'models/bettingrecodesList', 'models/cancelbetting', 'collections/bettingrecodesList', 'views/subsets/default-mark6_headbar', 'views/subsets/default-mark6_betting', 'text!../../templates/default-mark6.tpl', 'text!../../templates/_default-modal.tpl', 'text!../../templates/subsets/default-mark6_gameRecords.tpl'], function($, _, Backbone, doT, AlgorithmMark6, ModelGameRecords, ModelCancelOrder, CollectionGameRecords, ViewHeadbar, ViewBetting, TplContent, TplModal, TplGameRecords) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.eventRevoke = bind(this.eventRevoke, this);
        this.eventShowInfo = bind(this.eventShowInfo, this);
        this.eventPaginate = bind(this.eventPaginate, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        modal: doT.template(TplModal),
        gr: doT.template(TplGameRecords)
      };

      View.prototype.events = {
        'click .showHistory': 'eventShowHistory'
      };

      View.prototype.initialize = function() {
        window.v = this;
        CSH.gID = CSH.routePath[0];
        CSH.gType = 6;
        CSH.balance = localStorage.getItem('balance');
        this.data = {};
        this.views = {};
        this.xhr = null;
        this.algorithm = new AlgorithmMark6();
        this.m_gr = new ModelGameRecords();
        this.c_gr = new CollectionGameRecords();
        this.resetWS();
        return this.render();
      };

      View.prototype.destroy = function() {
        var k, ref, ref1, ref2, v;
        ref = this.views;
        for (k in ref) {
          if (!hasProp.call(ref, k)) continue;
          v = ref[k];
          if (typeof v.destroy === "function") {
            if ((ref1 = v.destroy()) != null) {
              ref1.remove();
            }
          }
        }
        if ((ref2 = this.xhr) != null) {
          ref2.abort();
        }
        this.ws.onopen = null;
        this.ws.onerror = null;
        this.ws.onclose = null;
        this.ws.onmessage = null;
        CSH.ws_number = null;
        this._activeToClose = 1;
        return this.ws.close();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.headbar = this.$el.find('.headbar');
        this.els.betting = this.$el.find('.bettingContainer');
        this.views.headbar = new ViewHeadbar({
          el: this.els.headbar,
          parent: this,
          algorithm: this.algorithm
        });
        return this.views.betting = new ViewBetting({
          el: this.els.betting,
          parent: this,
          algorithm: this.algorithm
        });
      };

      View.prototype.fetch_gameRecords = function(page) {
        var param, ref;
        if (page == null) {
          page = 1;
        }
        this.data.page = page;
        if ((ref = this.xhr) != null) {
          ref.abort();
        }
        param = {
          gameID: +CSH.gID
        };
        return this.m_gr.setUrl(5, page).save(param, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var ref1;
              data = data.toJSON();
              if ((ref1 = _this.els.grContent) != null) {
                ref1.html(_this.tpls.gr({
                  data: data.data,
                  pageInfo: data.pageInfo
                }));
              }
              _this.c_gr.reset(data.data);
              return '{}';
            };
          })(this)
        });
      };

      View.prototype.eventShowHistory = function(event) {
        var modalBox, modalWrap, view;
        view = this;
        modalBox = $(this.tpls.modal({
          className: 'mark6 mark6-gameRecords',
          title: '投注记录'
        }));
        modalWrap = modalBox.find('.modal-wrap');
        this.els.grContent = modalWrap;
        this.fetch_gameRecords();
        return modalBox.appendTo(CSH.$els.body).on('hidden', function() {
          var ref;
          modalBox.remove();
          if ((ref = view.xhr) != null) {
            ref.abort();
          }
          return view.els.grContent = null;
        }).on('click', 'tfoot button[data-value]', view.eventPaginate).on('click', '.showInfo', view.eventShowInfo).on('click', '.revoke', view.eventRevoke).modal('show');
      };

      View.prototype.eventPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        el.prop({
          disabled: true
        });
        p = el.attr('data-value');
        return this.fetch_gameRecords(p);
      };

      View.prototype.eventShowInfo = function(event) {
        var el, id, m, tr;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        id = el.closest('tr').attr('data-id');
        m = this.c_gr.findWhere({
          projectid: id
        });
        return CSH.views.body.showGameInfo({
          pageData: m.toJSON()
        });
      };

      View.prototype.eventRevoke = function(event) {
        var el, id, tr;
        el = $(event.currentTarget);
        tr = el.closest('tr');
        id = el.closest('tr').attr('data-id');
        return new ModelCancelOrder().setUrl().save({
          orders: id
        }, {
          dataFilter: (function(_this) {
            return function(data) {
              switch (data.toJSON().code) {
                case 0:
                  return CSH.hint({
                    msg: '撤单成功',
                    duration: 500,
                    type: 'success',
                    callback: function() {
                      _this.fetch_gameRecords(_this.data.page);
                      return CSH.views.body.refreshBalance();
                    }
                  });
                case 5:
                case 1:
                  return CSH.hint({
                    msg: '操作失败，请重试',
                    duration: 1500,
                    type: 'error'
                  });
                case 4:
                  return CSH.hint({
                    msg: '本期已经封盘,不能撤单',
                    duration: 2000
                  });
                case 2:
                  return CSH.hint({
                    msg: '合买不能撤单',
                    duration: 1500
                  });
                case 3:
                  return CSH.hint({
                    msg: '已经撤单',
                    duration: 1500
                  });
                default:
                  return CSH.hint({
                    msg: data.toJSON().message,
                    duration: 1500
                  });
              }
            };
          })(this)
        });
      };

      View.prototype.resetWS = function() {
        var _abortedCount, _close, _createNewWS, _error, _message, switchCZ, view;
        view = this;
        _abortedCount = 0;
        switchCZ = (function(_this) {
          return function() {
            return _this.ws.send(JSON.stringify({
              model: 1,
              msgType: 2,
              target: {
                targetCategory: CSH.gID
              }
            }));
          };
        })(this);
        _message = function(event) {
          var codes, data, issue;
          if (event.data === 'Connect successful!') {
            return;
          }
          data = event.data.toJSON();
          if (data.msgType !== 2) {
            return;
          }
          codes = data.msg.split(',');
          issue = data.fromSource;
          view.views.headbar.showLotteryNumbers(issue, codes);
          return view.views.headbar.pushNewHistory(codes);
        };
        _error = function() {
          console.error('error', arguments);
          return _createNewWS();
        };
        _close = function() {
          console.error('closed', arguments);
          if (!this._activeToClose) {
            return _createNewWS();
          }
        };
        _createNewWS = (function(_this) {
          return function() {
            var ws;
            if (_abortedCount++ > 5) {
              return;
            }
            _this.ws = ws = CSH.ws_number = new WebSocket(CSH.path.ws);
            ws.onmessage = _message;
            ws.onerror = _error;
            ws.onclose = _close;
            if (ws.readyState === 1) {
              return switchCZ();
            } else {
              return ws.onopen = switchCZ;
            }
          };
        })(this);
        return _createNewWS();
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
