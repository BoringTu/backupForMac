(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/membertalkTop', 'models/balance', 'text!../../templates/_default-navbar.tpl'], function($, _, Backbone, doT, ModelMembertalkList, ModelsBalance, TplContent) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click #logoff': 'eventLogOff',
        'click .capitalVisibility': 'eventToggleCapitalVisibility',
        'click .mute': 'eventSwitchMuteState',
        'click .messageBox ul li a': 'eventShowConvesation'
      };

      View.prototype.initialize = function() {
        this.time = false;
        return this.render();
      };

      View.prototype.render = function() {
        var isVisible;
        this.$el.html(this.tpls.content({
          username: localStorage.getItem('username')
        }));
        this.els = {};
        this.els.time = this.$el.find('.time');
        this.els.cVisibility = this.$el.find('.capitalVisibility');
        this.els.msgBox = this.$el.find('.messageBox');
        this.els.capitalBox = this.$el.find('.capitalBox');
        this.els.balance = this.els.capitalBox.find('.balance');
        this.els.capitalVisibility = this.els.capitalBox.find('.capitalVisibility');
        this.els.dropdownBoxLi = this.els.capitalBox.find('.dropdownBox ul li');
        this.initTopMessageBox();
        this.renderServerTime();
        isVisible = +JSON.parse(localStorage.getItem('visibility-capital'));
        this.els.cVisibility.data({
          visibility: isVisible
        });
        if (isVisible) {
          return this.els.cVisibility.toggleClass('icon-visible icon-invisible');
        }
      };

      View.prototype.eventLogOff = function(event) {
        return CSH.confirm({
          content: '确定要退出吗？',
          ok: {
            callback: CSH.views.body.logOff
          }
        });
      };

      View.prototype.eventToggleCapitalVisibility = function(event) {
        var el, elBalance, els, i, isVisible, len, o, ref, userCenterBalance;
        if (this.time) {
          return;
        }
        this.time = true;
        setTimeout((function(_this) {
          return function() {
            return _this.time = false;
          };
        })(this), 500);
        if ((ref = $('.allVisibilityBtn')) != null) {
          ref.click();
        }
        el = $(event.currentTarget);
        isVisible = +el.hasClass('icon-visible');
        el.toggleClass('icon-visible icon-invisible');
        localStorage.setItem('visibility-capital', isVisible);
        el.data('visibility', isVisible);
        elBalance = el.siblings('.balance');
        elBalance.text(isVisible ? '***' : elBalance.attr('data-value'));
        els = el.siblings('.dropdownBox').find('ul span');
        for (i = 0, len = els.length; i < len; i++) {
          o = els[i];
          o = $(o);
          o.text(isVisible ? '***' : o.attr('data-value'));
        }
        if (CSH.pageName === 'userCenter') {
          userCenterBalance = $('.moneyList span.realTimeBalance');
          return userCenterBalance.text(isVisible ? '***' : userCenterBalance.attr('data-value'));
        }
      };

      View.prototype.renderServerTime = function() {
        var render, target;
        target = this.els.time;
        render = function() {
          return target.html(CSH.serverTime.getFormatDateAndTime());
        };
        render();
        return setInterval(render, 1000);
      };

      View.prototype.eventSwitchMuteState = function(event) {
        var el, isMute;
        el = $(event.currentTarget);
        el.toggleClass('icon-ring icon-mute');
        isMute = +el.hasClass('icon-mute');
        CSH.isMute = isMute;
        localStorage.setItem('isMute', isMute);
        return el.find('span').text("声音已" + (isMute ? '关闭' : '开启'));
      };

      View.prototype.renderUnreadMsgLen = function() {
        if (this.unreadMsgLen > 0) {
          return this.els.msgBox.addClass('hasMsg').find('>.point').html(this.unreadMsgLen);
        } else {
          return this.els.msgBox.removeClass('hasMsg').find('>.point').html(this.unreadMsgLen);
        }
      };

      View.prototype.initTopMessageBox = function() {
        return new ModelMembertalkList().setUrl().save({
          total: 5
        }, {
          dataFilter: (function(_this) {
            return function(data) {
              var box, i, item, len, list, msgP, tem, ul;
              box = _this.els.msgBox.find('.box');
              msgP = box.find('>p');
              ul = box.find('ul');
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              data = data.data;
              list = data.results;
              _this.unreadMsgLen = +data.pagingInfo.notReadTotal;
              _this.renderUnreadMsgLen();
              tem = '';
              if (list.length === 0) {
                tem = "<p>暂无消息</p>\n<a href=\"/userCenter.html#message\" class=\"showAll\">查看全部</a>";
              } else {
                tem += '<ul>';
                for (i = 0, len = list.length; i < len; i++) {
                  item = list[i];
                  tem += "<li data-type=\"" + (item.type.toString().encodeHTML()) + "\" data-id=\"" + (item.contactsID.encodeHTML()) + "\">\n	<div>\n		" + (item.sender !== +localStorage.getItem("userID") && !item.isRead ? '<i class="point"></i>' : '') + "\n		<span class=\"icon" + (+item.type === 0 ? ' icon-message' : +item.type === -1 ? ' icon-loudspeaker' : void 0) + "\"></span>\n		<a href=\"javascript:;\">\n			<span class=\"username\">" + (+item.contactsID === +localStorage.getItem('parentId') ? '上级' : item.contacts.encodeHTML()) + "</span>\n			<span class=\"text\">" + (item.message.encodeHTML()) + "</span>\n		</a>\n	</div>\n</li>";
                }
                tem += '</ul>';
                tem += '<a href="/userCenter.html#message" class="showAll">查看全部</a>';
              }
              return _this.els.msgBox.find('.box').html(tem);
            };
          })(this)
        });
      };

      View.prototype.eventShowConvesation = function(event) {
        var el, id, tar, type;
        el = $(event.currentTarget);
        tar = el.parents('li');
        id = +tar.attr('data-id');
        type = +tar.attr('data-type');
        CSH.views.body.showConversation(id, type);
        if (tar.find('i.point').length > 0) {
          tar.find('i.point').remove();
          --this.unreadMsgLen;
        }
        return this.renderUnreadMsgLen();
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
