(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'text!../../templates/default-help.tpl', 'text!../../templates/_default-contentLoading.tpl'], function($, _, Backbone, doT, TplContent, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.eventWindowScroll = bind(this.eventWindowScroll, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .leftBox a': 'eventChooseMenu',
        'click .q_clps_head': 'eventSwitchCollapse',
        'click .collapse .closeBtn': 'eventCloseCollapse'
      };

      View.prototype.initialize = function(data) {
        this.data = {};
        this.data.top = 56;
        this.data.fHeight = CSH.$els.footer.outerHeight(true);
        this.data.compatibleBody = CSH.$els.body;
        this.data.compatibleBody = $('html');
        CSH.$els.window.on('scroll', this.eventWindowScroll);
        return this.render();
      };

      View.prototype.destroy = function() {
        return CSH.$els.window.off('scroll', this.eventWindowScroll);
      };

      View.prototype.render = function() {
        var id;
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.leftBox = this.$el.find('.leftBox');
        this.els.rightBox = this.$el.find('.rightBox');
        this.els.menus = this.els.leftBox.find('a');
        this.data.lbHeight = this.els.leftBox.outerHeight(true);
        id = CSH.routePath[0];
        if (id) {
          this.scrollToTarget($("#" + id));
        }
        if (localStorage.getItem('openDNS')) {
          localStorage.removeItem('openDNS');
          this.$el.find('#openDNS').click();
        }
        return this.getTops();
      };

      View.prototype.setLeftBoxMenuActive = function(target) {
        this.els.menus.filter('.active').removeClass('active');
        return target.addClass('active');
      };

      View.prototype.setClosestHead = function(id) {
        var ref, ref1;
        this.data.prevHead = (ref = $("#" + id).parent('.r_block').prev()) != null ? ref.find('h4') : void 0;
        return this.data.nextHead = (ref1 = $("#" + id).parent('.r_block').next()) != null ? ref1.find('h4') : void 0;
      };

      View.prototype.eventChooseMenu = function(event) {
        var el, id, target;
        event.preventDefault();
        el = $(event.currentTarget);
        id = el.attr('href').replace(/^\.*#/, '');
        target = $("#" + id);
        history.replaceState(null, null, "#" + id);
        this.setLeftBoxMenuActive(el);
        return this.scrollToTarget(target);
      };

      View.prototype.scrollToTarget = function(target) {
        if (target[0]) {
          return this.data.compatibleBody.animate({
            scrollTop: target.offset().top - 50 - 10
          }, 200);
        }
      };

      View.prototype.eventSwitchCollapse = function(event) {
        var el, target;
        el = $(event.currentTarget);
        target = el.next();
        el.toggleClass('active');
        target.fadeToggle();
        return this.getTops();
      };

      View.prototype.eventCloseCollapse = function(event) {
        var el;
        el = $(event.currentTarget);
        return el.closest('.collapse').prev().click();
      };

      View.prototype.getTops = function() {
        var el, j, len, ref, results;
        this.data.tops = [];
        ref = this.els.rightBox.find('h4[id]');
        results = [];
        for (j = 0, len = ref.length; j < len; j++) {
          el = ref[j];
          el = $(el);
          results.push(this.data.tops.push({
            top: el.offset().top - 50 - 10,
            id: el.attr('id')
          }));
        }
        return results;
      };

      View.prototype.eventWindowScroll = function(event) {
        var i, id, item, j, ref, sTop, tHeight, tops;
        sTop = this.data.compatibleBody.scrollTop();
        tHeight = document.documentElement.offsetHeight;
        if (sTop < this.data.top + 75) {
          this.els.leftBox.removeClass('fixed_top').removeClass('fixed_bottom');
        } else if (tHeight - sTop - (this.data.lbHeight + 6) - (this.data.fHeight + 10) < 0) {
          this.els.leftBox.removeClass('fixed_top').addClass('fixed_bottom');
        } else {
          this.els.leftBox.removeClass('fixed_bottom').addClass('fixed_top');
        }
        tops = this.data.tops;
        for (i = j = ref = tops.length - 1; ref <= 0 ? j <= 0 : j >= 0; i = ref <= 0 ? ++j : --j) {
          item = tops[i];
          if (!(sTop < item.top)) {
            id = item.id;
            break;
          }
        }
        if (id == null) {
          return;
        }
        this.setLeftBoxMenuActive(this.els.menus.filter("[href=\"/help.html#" + id + "\"]"));
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
