(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/activitys', 'models/activity', 'models/registerAct', 'models/getActivityMoney', 'collections/announceByPage', 'collections/activitys', 'text!../../templates/default-na.tpl', 'text!../../templates/subsets/default-na_act.tpl', 'text!../../templates/_default-contentLoading.tpl', 'text!../../templates/_default-paginate.tpl'], function($, _, Backbone, doT, ModelsActivitys, ModelsActivity, ModelsRegisterAct, ModelsGetActivityMoney, CollectionAnnounceByPage, CollectionActivitys, TplContent, TplAct, TplLoading, TplPaginate) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent),
        act: doT.template(TplAct),
        paginate: doT.template(TplPaginate)
      };

      View.prototype.events = {
        'click .main .na_title a': 'eventLoadDataList',
        'click .main .notice_content a,.main .activity_content a.actNews': 'eventGoToNoticeDetail',
        'click .main .activity_content a': 'eventGoToActDetail',
        'click .main .activity_content .classify button': 'eventLoadClassifyList',
        'click .n_detail .back_btn': 'eventBackList',
        'click .n_d_con_sign button.sign': 'eventSign',
        'click .n_d_con_sign button.lj': 'eventTakePrize',
        'click .n_d_footer button': 'eventSwitchDetail',
        'click .paginate button': 'eventClickPaginate',
        'keyup .paginate input': 'eventKeyupPaginate'
      };

      View.prototype.initialize = function() {
        this.c = new CollectionAnnounceByPage();
        this.ca = new CollectionActivitys();
        this.maList = new ModelsActivitys();
        this.ma = new ModelsActivity();
        this.pageInfo = void 0;
        this.pageSize = 12;
        this.pageSize2 = 8;
        this.actType = 0;
        this.onlyFreLis = false;
        return this.render();
      };

      View.prototype.render = function() {
        var id;
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.main = this.$el.find('.main');
        this.els.con = this.$el.find('#naContent');
        this.els.nDetail = this.$el.find('.n_detail');
        this.els.aMain = this.$el.find('.a_main');
        this.type = CSH.routePath[0];
        id = CSH.routePath[1];
        if (id) {
          this.clickId = id;
        }
        if (!this.type) {
          this.type = 'notice';
        }
        this.els.con.removeClass().addClass(this.type + "_content");
        return this.$el.find("#" + this.type).click();
      };

      View.prototype.fetchData = function(curPage) {
        if (curPage == null) {
          curPage = 1;
        }
        this.els.con.html(TplLoading);
        if (this.xhr) {
          this.xhr.abort();
        }
        this.c.setUrl(curPage, this.pageSize).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var i, info, j, len, list, temp;
              data = data.toJSON();
              list = data.data;
              _this.pageInfo = data.pageInfo;
              _this.c.reset(list);
              temp = '<ul>';
              for (i = j = 0, len = list.length; j < len; i = ++j) {
                info = list[i];
                if (!(i < _this.pageSize)) {
                  break;
                }
                temp += "<li>\n	<span class=\"n_icon\"><i><i></i></i></span>\n	<a href=\"javascript:;\"" + (info.announceType === 1 ? 'class="text-red"' : '') + "id=\"" + (info.id.toString().encodeHTML()) + "\">" + (info.announceName.encodeHTML()) + "</a>\n	<span class=\"date\">" + (info.addTime.replace(/:\d{2}$/, '')) + "</span>\n</li>";
              }
              temp += '</ul>';
              temp += '<div class="paginate">';
              temp += _this.tpls.paginate({
                info: _this.pageInfo
              });
              temp += '</div>';
              if (list.length === 0) {
                temp = '<div class="no-result">暂无公告</div>';
              }
              _this.els.con.html(temp);
              if (_this.clickId) {
                _this.els.main.find("#" + _this.clickId).click();
                return _this.clickId = void 0;
              }
            };
          })(this)
        });
      };

      View.prototype.fetchData2 = function(curPage) {
        var param;
        if (curPage == null) {
          curPage = 1;
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        param = {
          pageIndex: curPage,
          pageSize: this.pageSize2,
          type: this.actType
        };
        this.maList.setUrl().save(param, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var list, tab;
              data = data.toJSON();
              list = data.data;
              _this.pageInfo = data.pageInfo;
              _this.ca.reset(list);
              if (_this.onlyFreLis) {
                _this.onlyFreLis = false;
                _this.els.aMain.html(_this.tpls.act({
                  data: _this.ca.toJSON(),
                  paginate: _this.tpls.paginate({
                    info: _this.pageInfo
                  })
                }));
              } else {
                tab = "<div class=\"classify\">\n	<button data-type=\"0\" class=\"active\">全部</button>\n	<button data-type=\"1\">彩票</button>\n	<button data-type=\"2\">真人娱乐</button>\n	<button data-type=\"3\">电子游戏</button>\n	<button data-type=\"4\">体育</button>\n</div>";
                _this.els.con.html(tab);
                _this.els.con.append(_this.tpls.act({
                  data: _this.ca.toJSON(),
                  paginate: _this.tpls.paginate({
                    info: _this.pageInfo
                  })
                }));
                _this.els.aMain = _this.$el.find('.a_main');
              }
              if (_this.clickId) {
                _this.els.main.find("#" + _this.clickId).click();
                return _this.clickId = void 0;
              }
            };
          })(this)
        });
      };

      View.prototype.eventLoadDataList = function(event) {
        var controlCssEl, el;
        el = $(event.currentTarget);
        controlCssEl = el.parent('li');
        this.type = el.attr('id');
        this.els.con.removeClass().addClass(this.type + "_content");
        history.replaceState(null, null, "#" + this.type);
        this.els.con.html(TplLoading);
        controlCssEl.addClass('active').siblings('.active').removeClass('active');
        switch (this.type) {
          case 'notice':
            return this.fetchData();
          case 'activity':
            return this.fetchData2();
        }
      };

      View.prototype.eventLoadClassifyList = function(event) {
        var el;
        el = $(event.currentTarget);
        el.addClass('active').siblings('.active').removeClass('active');
        this.actType = +el.attr('data-type');
        this.els.aMain.html(TplLoading);
        this.onlyFreLis = true;
        return this.fetchData2();
      };

      View.prototype.eventSign = function(event) {
        var el, id;
        el = $(event.currentTarget);
        id = +el.parent().attr('data-id');
        if (this.xhr) {
          this.xhr.abort();
        }
        new ModelsRegisterAct().setUrl(id).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var s;
              data = data.toJSON();
              if (data.code !== 0) {
                return CSH.hint(data.message);
              }
              data = data.data;
              CSH.hint({
                msg: '报名成功',
                type: 'success'
              });
              s = _this.getSignPrizeBtn(+data.status);
              if (_this.noPrize && +data.status !== 5) {
                s = _this.getSignPrizeBtn(6);
              }
              return el.replaceWith(s);
            };
          })(this)
        });
      };

      View.prototype.eventTakePrize = function(event) {
        var el, id;
        el = $(event.currentTarget);
        id = +el.parent().attr('data-id');
        if (el.hasClass('s1')) {
          return CSH.hint('您还未达到领取条件');
        }
        if (this.xhr) {
          this.xhr.abort();
        }
        new ModelsGetActivityMoney().setUrl(id).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var s;
              data = data.toJSON();
              if (data.code !== 0) {
                return CSH.hint(data.Message);
              }
              CSH.hint({
                msg: '领奖成功',
                type: 'success'
              });
              s = _this.getSignPrizeBtn(4);
              return el.replaceWith(s);
            };
          })(this)
        });
      };

      View.prototype.addSignSeal = function(type) {
        return this.els.nDetail.find('.n_d_con').append("<div class=\"signSeal" + (type === 1 ? ' dark' : '') + "\"></div>");
      };

      View.prototype.getSignPrizeBtn = function(status) {
        var s;
        switch (status) {
          case 0:
            s = '';
            break;
          case 1:
            s = "<button class=\"sign\">我要报名</button>";
            break;
          case 2:
            s = "<button class=\"lj s1\">领取奖金</button>";
            break;
          case 3:
            s = "<button class=\"lj s2\">领取奖金</button>";
            break;
          case 4:
            s = "<button class=\"grayBtn\">已领取</button>";
            break;
          case 5:
            s = "<button class=\"grayBtn\">活动已结束</button>";
            break;
          case 6:
            s = "<button class=\"grayBtn\">已报名</button>";
        }
        return s;
      };

      View.prototype.getName = function(n, x) {
        if (this.xhr) {
          this.xhr.abort();
        }
        return this.c.setUrl(n, 1).fetch({
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var btnEle, model, p;
              if (x === 0) {
                btnEle = _this.els.nDetail.find('.n_d_footer .prev');
                p = _this.pageInfo.pageIndex - 1;
              } else if (x === 1) {
                btnEle = _this.els.nDetail.find('.n_d_footer .next');
                p = _this.pageInfo.pageIndex + 1;
              }
              data = data.toJSON();
              model = data.data[0];
              btnEle.attr('id', model.id.toString().encodeHTML() + 'detail').attr('data-page', p).find('span').removeClass().html(model.announceName.encodeHTML());
            };
          })(this)
        });
      };

      View.prototype.getActivity = function(id) {
        var param;
        if (this.xhr) {
          this.xhr.abort();
        }
        param = {
          actid: +id
        };
        this.ma.setUrl().save(param, {
          beforeSend: (function(_this) {
            return function(xhr) {
              return _this.xhr = xhr;
            };
          })(this),
          dataFilter: (function(_this) {
            return function(data) {
              var curTime, dCon, dTim, dTit, s, startTime, temp;
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              data = data.data;
              dTit = data.act_Title.encodeHTML();
              dTim = new Date(data.addTime).getFormatDateAndTime();
              dCon = data.act_Content.encodeHTML(true);
              curTime = new Date().getTime();
              startTime = new Date(data.act_BeginTime).getTime();
              _this.noPrize = false;
              if (+data.status === 5) {
                s = _this.getSignPrizeBtn(5);
              } else if (data.act_Sign) {
                if (+data.status === 1) {
                  s = _this.getSignPrizeBtn(1);
                } else {
                  if (data.act_Action === 1) {
                    s = _this.getSignPrizeBtn(+data.status);
                  } else {
                    _this.noPrize = true;
                    s = _this.getSignPrizeBtn(6);
                  }
                }
              } else {
                if (data.act_Action === 1) {
                  s = _this.getSignPrizeBtn(+data.status);
                } else {
                  s = '';
                }
              }
              if (curTime < startTime) {
                s = _this.getSignPrizeBtn(0);
              }
              temp = "<div class=\"pub_title\">\n	<a href=\"##\" class=\"back_btn\"><span class=\"icon icon-arrow-left\"></span>返回列表</a>\n</div>\n<div class=\"n_d_con\">\n	<div class=\"n_d_con_head\">\n		<p class=\"h_title\">" + dTit + "</p>\n		<p class=\"h_date\">" + dTim + "</p>\n	</div>\n	<div class=\"n_d_con_body\">\n		" + dCon + "\n	</div>\n	<div class=\"n_d_con_sign\" data-id=\"" + (data.id.toString().encodeHTML()) + "\">\n		" + s + "\n	</div>\n</div>";
              return _this.els.nDetail.html(temp);
            };
          })(this)
        });
      };

      View.prototype.eventGoToNoticeDetail = function(event) {
        var dCon, dTim, dTit, data, el, id, idxPage, index, isFirstOfAll, isFirstOfPage, isLastOfAll, isLastOfPage, model, n, nextModel, p, prevModel, t, temp;
        el = $(event.currentTarget);
        id = el.attr('id');
        if (this.type === 'notice') {
          model = this.c.get(id);
          data = model.toJSON();
          dTit = data.announceName.encodeHTML();
          dTim = new Date(data.addTime).getFormatDateAndTime();
          dCon = data.announceContent.encodeHTML(true);
        } else {
          this.getActivity(id);
          this.els.nDetail.html(TplLoading);
          this.els.main.hide();
          this.els.nDetail.show();
          return;
        }
        temp = "<div class=\"pub_title\">\n	<a href=\"##\" class=\"back_btn\"><span class=\"icon icon-arrow-left\"></span>返回列表</a>\n</div>\n<div class=\"n_d_con\">\n	<div class=\"n_d_con_head\">\n		<p class=\"h_title\">" + dTit + "</p>\n		<p class=\"h_date\">" + dTim + "</p>\n	</div>\n	<div class=\"n_d_con_body\">\n		" + dCon + "\n	</div>\n</div>";
        if (this.type === 'notice') {
          index = this.c.indexOf(model);
          p = this.pageInfo.pageIndex;
          t = this.pageInfo.totalRecords;
          idxPage = index + this.pageSize * (p - 1);
          if (idxPage === 0) {
            isFirstOfAll = true;
            nextModel = this.c.at(index + 1);
            if (nextModel) {
              temp += "<div class=\"n_d_footer\">\n	<button class=\"prev\" disabled=\"disabled\">上一篇：<span>无</span></button>\n	<button class=\"next\" id=\"" + (nextModel.get('id').toString().encodeHTML()) + "detail\"><span>" + (nextModel.get('announceName').encodeHTML()) + "</span>：下一篇</button>\n</div>";
            }
          } else if (idxPage === t - 1) {
            isLastOfAll = true;
            prevModel = this.c.at(index - 1);
            if (prevModel) {
              temp += "<div class=\"n_d_footer\">\n	<button class=\"prev\" id=\"" + (prevModel.get('id').toString().encodeHTML()) + "detail\">上一篇：<span>" + (prevModel.get('announceName').encodeHTML()) + "</span></button>\n	<button class=\"next\" disabled=\"disabled\"><span>无</span>：下一篇</button>\n</div>";
            }
          } else if (index === 0) {
            isFirstOfPage = true;
            nextModel = this.c.at(index + 1);
            n = this.pageSize * (p - 1);
            if (nextModel) {
              temp += "<div class=\"n_d_footer\">\n	<button class=\"prev\">上一篇：<span class=\"icon icon-loading icon-spin icon-fast\"></span></button>\n	<button class=\"next\" id=\"" + (nextModel.get('id').toString().encodeHTML()) + "detail\"><span>" + (nextModel.get('announceName').encodeHTML()) + "</span>：下一篇</button>\n</div>";
            }
            this.getName(n, 0);
          } else if (index === this.pageSize - 1) {
            isLastOfPage = true;
            prevModel = this.c.at(index - 1);
            n = this.pageSize * p + 1;
            if (prevModel) {
              temp += "<div class=\"n_d_footer\">\n	<button class=\"prev\" id=\"" + (prevModel.get('id').toString().encodeHTML()) + "detail\">上一篇：<span>" + (prevModel.get('announceName').encodeHTML()) + "</span></button>\n	<button class=\"next\"><span class=\"icon icon-loading icon-spin icon-fast\"></span>：下一篇</button>\n</div>";
            }
            this.getName(n, 1);
          } else {
            prevModel = this.c.at(index - 1);
            nextModel = this.c.at(index + 1);
            if (prevModel && nextModel) {
              temp += "<div class=\"n_d_footer\">\n	<button class=\"prev\" id=\"" + (prevModel.get('id').toString().encodeHTML()) + "detail\">上一篇：<span>" + (prevModel.get('announceName').encodeHTML()) + "</span></button>\n	<button class=\"next\" id=\"" + (nextModel.get('id').toString().encodeHTML()) + "detail\"><span>" + (nextModel.get('announceName').encodeHTML()) + "</span>：下一篇</button>\n</div>";
            }
          }
        }
        this.els.nDetail.html(temp);
        this.els.main.hide();
        return this.els.nDetail.show();
      };

      View.prototype.eventSwitchDetail = function(event) {
        var dataPage, el, id;
        el = $(event.currentTarget);
        id = el.attr('id').replace(/detail/, '');
        dataPage = +el.attr('data-page');
        if (dataPage) {
          this.fetchData(dataPage);
          this.clickId = id;
          return;
        }
        return this.els.main.find("#" + id).click();
      };

      View.prototype.eventBackList = function(event) {
        event.preventDefault();
        this.els.nDetail.hide();
        return this.els.main.show();
      };

      View.prototype.eventClickPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = el.attr('data-value');
        if (this.type === 'notice') {
          return this.fetchData(p);
        } else {
          return this.fetchData2(p);
        }
      };

      View.prototype.eventKeyupPaginate = function(event) {
        var el, p;
        el = $(event.currentTarget);
        p = +el.val();
        if (event.keyCode === 13) {
          if (!p) {
            return;
          }
          if (this.type === 'notice') {
            return this.fetchData(p);
          } else {
            return this.fetchData2(p);
          }
        }
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
