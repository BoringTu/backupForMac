(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', '../algorithm', 'views/subsets/smartyy-lottery_headbar', 'views/subsets/smartyy-lottery_betting', 'views/subsets/smartyy-lottery_rightSidebar', 'text!../../templates/smartyy-lottery.tpl'], function($, _, Backbone, doT, Algorithm, ViewHeadbar, ViewBetting, ViewRSidebar, TplContent) {
    "use strict";
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.initialize = function() {
        window.v = this;
        CSH.gID = CSH.routePath[0];
        CSH.gType = CSH.gID.charAt(0);
        this.data = {};
        this.views = {};
        this.algorithm = new Algorithm(this);
        this.resetWS();
        return this.render();
      };

      View.prototype.destroy = function() {
        var k, ref, ref1, v;
        clearInterval(this._interval);
        console.warn('headbar destroy');
        ref = this.views;
        for (k in ref) {
          if (!hasProp.call(ref, k)) continue;
          v = ref[k];
          if (typeof v.destroy === "function") {
            if ((ref1 = v.destroy()) != null) {
              ref1.remove();
            }
          }
        }
        this.ws.onopen = null;
        this.ws.onerror = null;
        this.ws.onclose = null;
        this.ws.onmessage = null;
        CSH.ws_number = null;
        this._activeToClose = 1;
        return this.ws.close();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.headbar = this.$el.find('.headbar');
        this.els.betting = this.$el.find('.bettingContainer');
        this.views.headbar = new ViewHeadbar({
          el: this.els.headbar,
          parent: this
        });
        this.views.betting = new ViewBetting({
          el: this.els.betting,
          parent: this,
          algorithm: this.algorithm
        });
        return this.views.rSidebar = new ViewRSidebar({
          el: CSH.$els.rightSidebar,
          parent: this
        });
      };

      View.prototype.resetWS = function() {
        var _abortedCount, _close, _createNewWS, _error, _message, switchCZ, view;
        view = this;
        _abortedCount = 0;
        switchCZ = (function(_this) {
          return function() {
            _this.ws.send(JSON.stringify({
              model: 1,
              msgType: 2,
              target: {
                targetCategory: CSH.gID
              }
            }));
            return _this._interval = setInterval((function() {
              return _this.ws.send('{}');
            }), 30000);
          };
        })(this);
        _message = function(event) {
          var codes, data, issue;
          if (event.data === 'Connect successful!') {
            return;
          }
          data = event.data.toJSON();
          if (data.msgType !== 2) {
            return;
          }
          codes = data.msg.split(',');
          issue = data.fromSource;
          view.views.headbar.showLotteryNumbers(issue, codes);
          view.views.betting.refreshYllr();
          return view.views.rSidebar.refreshHistoryRecords();
        };
        _error = function() {
          console.error('error', arguments);
          return _createNewWS();
        };
        _close = function() {
          console.error('closed', arguments);
          if (!this._activeToClose) {
            return _createNewWS();
          }
        };
        _createNewWS = (function(_this) {
          return function() {
            var ws;
            if (_abortedCount++ > 5) {
              return;
            }
            _this.ws = ws = CSH.ws_number = new WebSocket(CSH.path.ws);
            ws.onmessage = _message;
            ws.onerror = _error;
            ws.onclose = _close;
            if (ws.readyState === 1) {
              return switchCZ();
            } else {
              return ws.onopen = switchCZ;
            }
          };
        })(this);
        return _createNewWS();
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
