(function() {
  var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'models/adList', 'models/currentperiodallinfo', 'models/gameRanking', 'collections/announceByPage', 'text!../../templates/smartyy-index-bj.tpl'], function($, _, Backbone, doT, ModelAdList, ModelCurrentPeriodAllInfo, ModelGameRanking, CollectionAnnounceByPage, TplContent) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        this.refreshSwitchPositionBanner = bind(this.refreshSwitchPositionBanner, this);
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .swipe.banner .position i': 'eventSwitchoverBanner',
        'click .banner .bannerBtn': 'eventSlideBanner'
      };

      View.prototype.initialize = function() {
        this.data = {};
        this.data.bannerData = null;
        this.data.notice = {};
        this.render();
        return CSH.views.sidebar.els.menuWrapLi.first().children('a').click();
      };

      View.prototype.render = function() {
        var el, id, j, len, li, ref, results;
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.banner = this.$el.find('.banner');
        this.els.bannerBtnPrevImg = this.els.banner.find('.bannerBtn[data-btn="prev"] .imgs');
        this.els.bannerBtnNextImg = this.els.banner.find('.bannerBtn[data-btn="next"] .imgs');
        this.els.notice = this.$el.find('.bulletin .notice');
        this.els.content = this.$el.find('.content');
        this.els.lotteryBoxSmalls = this.els.content.find('.lotteryBox.smalls');
        this.els.timeBox = this.els.content.find('.lotteryBox a');
        this.els.lotteryRanking = this.els.content.find('.lotteryRanking');
        this.bannerTransformationInit();
        this.data.notice.width = false;
        this.lotteryBox = {};
        this.aElWidth = 240;
        $(window).resize((function(_this) {
          return function() {
            return _this.viewWidth();
          };
        })(this));
        this.platformNotice();
        this.viewWidth();
        this.fetchGamesRecentOpen();
        this.getGameRanking();
        this.data.countDownMap = {};
        ref = this.els.timeBox;
        results = [];
        for (j = 0, len = ref.length; j < len; j++) {
          el = ref[j];
          el = $(el);
          id = el.attr('href').split('#')[1];
          li = el.find('li');
          this.data.countDownMap[id] = this.data.countDownMap[id] || [];
          results.push(this.data.countDownMap[id].push({
            hour: li.filter('[data-type="hour"]'),
            minute: li.filter('[data-type="minute"]'),
            second: li.filter('[data-type="second"]')
          }));
        }
        return results;
      };

      View.prototype.destroy = function() {
        clearInterval(this.data.bHandle);
        clearInterval(this.data.notice.timer);
        return this.data.czHandle;
      };

      View.prototype.viewWidth = function() {
        var width;
        width = this.$el.width();
        if (width >= 1420) {
          this.data.notice.width = false;
          this.$el.removeClass('w-1420 w-1180');
        } else if (width < 1200) {
          this.data.notice.width = true;
          this.$el.addClass('w-1180').removeClass('w-1420');
        } else if (width < 1420) {
          this.data.notice.width = false;
          this.$el.addClass('w-1420').removeClass('w-1180');
        }
        return this.initLotteryScroll();
      };

      View.prototype.bannerTransformationInit = function() {
        return new ModelAdList().setUrl().fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var api, fun, i, imgLis, index, item, j, k, len, liEls, liStr, ref, ref1, speed, target;
              data = data.toJSON();
              if (data.code !== 0) {
                return;
              }
              _this.data.bannerData = data.data;
              imgLis = '';
              ref = data.data;
              for (index = j = 0, len = ref.length; j < len; index = ++j) {
                item = ref[index];
                imgLis += '<li>';
                if (item.sourceUrl) {
                  imgLis += "<a href=\"" + item.sourceUrl + "\" target=\"_blank\">";
                }
                imgLis += "<img alt=\"" + (item.sourceText || '') + "\" src=\"" + (item.source.encodeHTML(true)) + "\" />";
                if (item.sourceUrl) {
                  imgLis += "</a>";
                }
                imgLis += "</li>";
              }
              _this.els.banner.find('ul.swipe-wrap').html(imgLis);
              speed = 3000;
              _this.data.bHandle = null;
              target = _this.els.banner.Swipe({
                callback: _this.refreshSwitchPositionBanner
              });
              api = target.data('Swipe');
              liStr = '';
              for (i = k = 1, ref1 = api.getNumSlides(); 1 <= ref1 ? k <= ref1 : k >= ref1; i = 1 <= ref1 ? ++k : --k) {
                liStr += "<li" + (i === 1 ? ' class="active"' : '') + "><i>&nbsp;</i></li>";
              }
              liEls = $(liStr).appendTo(target.find('> .position ul'));
              fun = function() {
                return _this.data.bHandle = setInterval(function() {
                  api.next();
                  return _this.refersSamllImg(api.getPos());
                }, speed);
              };
              target.on('mouseenter', function() {
                return clearInterval(_this.data.bHandle);
              }).on('mouseleave', function() {
                return fun();
              });
              fun();
              _this.data.banner = api;
              _this.data.bannerLis = liEls;
              return _this.refersSamllImg();
            };
          })(this)
        });
      };

      View.prototype.refreshSwitchPositionBanner = function(i) {
        this.data.bannerLis.filter(":eq(" + i + ")").addClass('active').siblings('.active').removeClass('active');
      };

      View.prototype.eventSwitchoverBanner = function(event) {
        var el, i;
        el = $(event.currentTarget);
        i = el.parent().index();
        this.data.banner.slide(i);
        return this.refersSamllImg(i);
      };

      View.prototype.eventSlideBanner = function(event) {
        var el;
        el = $(event.currentTarget);
        switch (el.attr('data-btn')) {
          case 'prev':
            this.data.banner.prev();
            break;
          case 'next':
            this.data.banner.next();
        }
        return this.refersSamllImg(this.data.banner.getPos());
      };

      View.prototype.refersSamllImg = function(i) {
        var h, n, p;
        if (i == null) {
          i = 0;
        }
        h = this.data.bannerData.length - 1;
        if (h <= 1) {
          this.els.bannerBtnPrevImg.hide();
          this.els.bannerBtnNextImg.hide();
          return;
        }
        n = i === h ? 0 : i + 1;
        p = i === 0 ? h : i - 1;
        this.els.bannerBtnPrevImg.css('backgroundImage', "url(" + this.data.bannerData[p].source + ")");
        return this.els.bannerBtnNextImg.css('backgroundImage', "url(" + this.data.bannerData[n].source + ")");
      };

      View.prototype.platformNotice = function() {
        var num, speed;
        num = 6;
        speed = 10000;
        return new CollectionAnnounceByPage().setUrl(1, num).fetch({
          dataFilter: (function(_this) {
            return function(data) {
              var fun, i, info, j, len, liAllHeight, liEl, liElHeight, list, temp;
              list = data.toJSON().data;
              temp = '<ul class="clear">';
              for (i = j = 0, len = list.length; j < len; i = ++j) {
                info = list[i];
                temp += "<li>\n	<div>\n		<a href=\"/na.html#notice/" + (info.id.toString().encodeHTML()) + "\"><span>" + (info.announceName.encodeHTML()) + "</span>" + (info.addTime.match(/^\d{4}\/(\d{2}\/\d{2})/)[0]) + " </a>\n	</div>\n</li>";
              }
              temp += '</ul>';
              temp += temp;
              _this.els.notice.html(temp);
              liEl = _this.els.notice.find('li');
              liElHeight = liEl.height();
              i = 0;
              liAllHeight = Math.ceil(liEl.length / 2);
              _this.els.notice.on('mouseenter', function() {
                return clearInterval(_this.data.notice.timer);
              }).on('mouseleave', function() {
                return fun();
              });
              fun = function() {
                return _this.data.notice.timer = setInterval(function() {
                  i++;
                  return _this.els.notice.animate({
                    top: -liElHeight * i
                  }, function() {
                    var n;
                    n = _this.data.notice.width ? liAllHeight : Math.ceil(liAllHeight / 2);
                    if (i > n) {
                      i = n;
                    }
                    if (i === n) {
                      _this.els.notice.css({
                        top: 0
                      });
                      return i = 0;
                    }
                  });
                }, speed);
              };
              return fun();
            };
          })(this)
        });
      };

      View.prototype.initLotteryScroll = function() {
        this.els.lotteryBoxSmalls.map((function(_this) {
          return function(i, el) {
            var aEl, aQuantity, scroll, type;
            el = $(el);
            type = el.attr('data-type') || 1;
            type = +type;
            scroll = el.children('.scroll');
            aEl = scroll.children('a');
            aQuantity = 0;
            if (type === 1) {
              aQuantity = aEl.length;
            } else {
              aQuantity = Math.ceil(aEl.length / 2);
            }
            scroll.css({
              width: _this.aElWidth * aQuantity
            });
            return _this.lotteryBox[i] = {
              parent: el,
              type: type,
              scroll: scroll,
              title: el.prevAll('.title'),
              aEl: aEl,
              aQuantity: aQuantity
            };
          };
        })(this));
        return this.lotteryBoxslides();
      };

      View.prototype.lotteryBoxslides = function() {
        var item, key, ref, results;
        ref = this.lotteryBox;
        results = [];
        for (key in ref) {
          item = ref[key];
          results.push((function(_this) {
            return function(item) {
              var btnNext, btnPrev, button, change, parentWdith, slideBtn;
              parentWdith = item.parent.width() + 20;
              slideBtn = item.title.find('.slide');
              btnPrev = slideBtn.find('button[data-btn="prev"]').off();
              btnNext = slideBtn.find('button[data-btn="next"]').off();
              button = item.title.find('ul button');
              change = function() {
                btnPrev.on('click', function() {
                  var left, width;
                  left = Math.abs(item.scroll.position().left);
                  if (left > parentWdith) {
                    width = left - parentWdith;
                  } else {
                    width = 0;
                  }
                  item.scroll.animate({
                    left: -width
                  }).end();
                  if (width === 0) {
                    btnPrev.attr('disabled', true);
                  }
                  return btnNext.attr('disabled', false);
                });
                return btnNext.on('click', function() {
                  var left, width;
                  left = Math.abs(item.scroll.position().left);
                  width = item.scroll.width() - left - parentWdith;
                  if (width >= parentWdith) {
                    width = parentWdith + left;
                  } else {
                    width += left;
                  }
                  item.scroll.animate({
                    left: -width
                  }).end();
                  if (width + parentWdith === item.scroll.width()) {
                    btnNext.attr('disabled', true);
                  }
                  return btnPrev.attr('disabled', false);
                });
              };
              if (parentWdith >= item.scroll.width()) {
                slideBtn.hide();
              } else {
                slideBtn.show();
                change();
              }
              return button.on('click', function(event) {
                var el, type;
                el = $(event.currentTarget);
                button.removeClass();
                el.addClass('active');
                console.log(el.attr('data-type'));
                type = el.attr('data-type');
                item.aEl.removeClass('aHidden').attr('style', '');
                if (type === 'all') {
                  return;
                }
                return item.aEl.map(function(i, el) {
                  console.log(i, el);
                  el = $(el);
                  if (type !== el.attr('data-type')) {
                    el.addClass('aHidden');
                    return setTimeout((function() {
                      return el.hide();
                    }), 200);
                  }
                });
              });
            };
          })(this)(item));
        }
        return results;
      };

      View.prototype.fetchGamesRecentOpen = function() {
        var xhr;
        xhr = null;
        return new ModelCurrentPeriodAllInfo().setUrl().fetch({
          beforeSend: function(x) {
            return xhr = x;
          },
          dataFilter: (function(_this) {
            return function(data) {
              var czTime, info, j, len, now, time;
              data = data.toJSON().data;
              now = new Date(xhr.getResponseHeader('Date')).getTime();
              czTime = {};
              for (j = 0, len = data.length; j < len; j++) {
                info = data[j];
                time = new Date(info.saleend).getTime() - now;
                time = Math.round(time / 1000);
                czTime[info.gameId] = time;
              }
              return _this.data.czHandle = setInterval(function() {
                var beginTime, endTime, id, isNextDay, results, s, temp;
                results = [];
                for (id in czTime) {
                  if (!hasProp.call(czTime, id)) continue;
                  time = czTime[id];
                  czTime[id] = --time;
                  if (!(time < 0)) {
                    _this.refreshLotteryCountDown(id, time);
                    continue;
                  }
                  if (!CSH.serverTime) {
                    continue;
                  }
                  now = CSH.serverTime.getTime();
                  isNextDay = false;
                  switch (+id) {
                    case 100:
                      beginTime = new Date(new Date(now).setHours(9)).setMinutes(50);
                      endTime = new Date(new Date(now).setHours(22)).setMinutes(0);
                      s = 5 * 60;
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      }
                      break;
                    case 101:
                    case 300:
                    case 303:
                      beginTime = new Date(new Date(now).setHours(9)).setMinutes(0);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(0);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 103:
                      beginTime = new Date(new Date(now).setHours(0)).setMinutes(0);
                      endTime = new Date(new Date(now).setHours(2)).setMinutes(0);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        beginTime = new Date(new Date(now).setHours(10)).setMinutes(0);
                        endTime = new Date(new Date(now).setHours(24)).setMinutes(0);
                        if ((beginTime < now && now < endTime)) {
                          s = 10 * 60;
                        } else {
                          temp = new Date(beginTime);
                          s = temp - now;
                        }
                      }
                      break;
                    case 109:
                    case 119:
                      s = 45;
                      break;
                    case 104:
                    case 107:
                    case 108:
                    case 203:
                    case 304:
                      s = 60;
                      break;
                    case 106:
                    case 110:
                    case 111:
                    case 112:
                    case 113:
                    case 114:
                    case 120:
                    case 402:
                      s = 60 * 1.5;
                      break;
                    case 115:
                      s = 60 * 2;
                      break;
                    case 105:
                    case 116:
                      s = 60 * 3;
                      break;
                    case 117:
                      beginTime = new Date(new Date(now).setHours(9)).setMinutes(5);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(55);
                      if ((beginTime < now && now < endTime)) {
                        s = 60 * 5;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 118:
                      beginTime = new Date(new Date(now).setHours(7)).setMinutes(5);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(55);
                      if ((beginTime < now && now < endTime)) {
                        s = 60 * 5;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 200:
                    case 202:
                      temp = new Date(now);
                      temp = new Date(temp.setDate(temp.getDate + 1));
                      temp = new Date(temp.setHours(20));
                      temp = new Date(temp.setMinutes(0));
                      s = temp - now;
                      break;
                    case 201:
                      beginTime = new Date(new Date(now).setHours(10)).setMinutes(0);
                      endTime = new Date(new Date(now).setHours(21)).setMinutes(30);
                      if ((beginTime < now && now < endTime)) {
                        s = 30 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 301:
                      beginTime = new Date(new Date(now).setHours(8)).setMinutes(50);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(50);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 302:
                      beginTime = new Date(new Date(now).setHours(8)).setMinutes(50);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(0);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 306:
                      beginTime = new Date(new Date(now).setHours(8)).setMinutes(55);
                      endTime = new Date(new Date(now).setHours(21)).setMinutes(55);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 401:
                      beginTime = new Date(new Date(now).setHours(9)).setMinutes(2);
                      endTime = new Date(new Date(now).setHours(23)).setMinutes(57);
                      if ((beginTime < now && now < endTime)) {
                        s = 5 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 501:
                      beginTime = new Date(new Date(now).setHours(8)).setMinutes(40);
                      endTime = new Date(new Date(now).setHours(22)).setMinutes(10);
                      if ((beginTime < now && now < endTime)) {
                        s = 10 * 60;
                      } else {
                        isNextDay = true;
                      }
                      break;
                    case 601:
                      time = new Date(data[0].saleend.replace(/-/g, '/')).getTime() - CSH.serverTime.getTime();
                      time = Math.round(time / 1000);
                      break;
                    case 602:
                      s = 60 * 2;
                  }
                  if (isNextDay) {
                    temp = new Date(beginTime);
                    temp = temp.setDate(temp.getDate() + 1);
                    s = temp - now;
                  }
                  time = s + time;
                  czTime[id] = time;
                  results.push(_this.refreshLotteryCountDown(id, time));
                }
                return results;
              }, 1000);
            };
          })(this)
        });
      };

      View.prototype.refreshLotteryCountDown = function(id, time) {
        var h, initSpan, j, len, m, map, n, results, s;
        h = "" + (Math.floor(time / 60 / 60));
        m = "" + (Math.floor(time / 60 % 60));
        s = "" + (Math.floor(time % 60));
        map = this.data.countDownMap[id];
        if (!map) {
          return;
        }
        initSpan = function(n) {
          if (n.length === 1) {
            return "<span>0</span><span>" + n + "</span>";
          } else {
            return "<span>" + n[0] + "</span><span>" + n[1] + "</span>";
          }
        };
        results = [];
        for (j = 0, len = map.length; j < len; j++) {
          n = map[j];
          n.hour.html(initSpan(h));
          n.minute.html(initSpan(m));
          results.push(n.second.html(initSpan(s)));
        }
        return results;
      };

      View.prototype.getGameRanking = function() {
        var aWeek, li, toDay;
        toDay = new Date().getFormatDate();
        aWeek = new Date().beforeDays(6).getFormatDate();
        li = this.els.lotteryRanking.find('ul li');
        return new ModelGameRanking().setUrl(5, 1).save({
          startDate: aWeek,
          engDate: toDay
        }, {
          dataFilter: (function(_this) {
            return function(data) {
              data = data.toJSON();
              if (data.code !== 0) {
                return '{}';
              }
              return li.map(function(i, el) {
                var m;
                if (!data.data[i]) {
                  return;
                }
                el = $(el);
                el.find('h5').text(CSH.gameMap[data.data[i].gameNameID].text);
                el.find('a').attr('href', "lottery.html#" + data.data[i].gameNameID);
                m = data.data[i].bettingAmount;
                if (m < 10000) {
                  m = parseInt(m);
                } else {
                  m /= 10000;
                  m = (m.accurate(2)) + "万";
                }
                return el.find('span').text(m);
              });
            };
          })(this)
        });
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
