(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'text!../../templates/_result.tpl'], function($, _, Backbone, doT, TplContent) {
    var View;
    View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.el = '.content';

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .rightBox': 'eventGoBack'
      };

      View.prototype.initialize = function(data) {
        this.ctrlName = data.ctrlName;
        return this.render();
      };

      View.prototype.render = function() {
        this.$el.html(this.tpls.content);
        this.els = {};
        this.els.header = $('> header', this.$el);
        this.els.title = $('> .row1 .text', this.els.header);
        this.els.Container = $('> ._resultContainer', this.$el);
        this.els.content = $('> .contents', this.els.Container);
        this.els.fail_one = $('> .fail_one', this.els.Container);
        this.els.success_one = $('> .success_one', this.els.Container);
        this.els.success_two = $('> .success_two', this.els.Container);
        switch (CSH.routePath[0]) {
          case 'fail_one':
            this.go('.fail_one', 'XX失败1');
            break;
          case 'success_one':
            this.go('.success_one', 'XX成功1');
            break;
          case 'success_two':
            this.go('.success_two', 'XX成功2');
        }
      };

      View.prototype.eventGoBack = function() {
        return history.back();
      };

      View.prototype.go = function(content, title) {
        var el;
        el = $(content);
        el.show();
        this.els.title.text(title);
        $('> h3 p', el).text(title);
      };

      return View;

    })(Backbone.View);
    return View;
  });

}).call(this);
