(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  define(['jquery', 'underscore', 'backbone', 'doT', 'text!../../templates/smartyy-help.tpl', 'text!../../templates/_smartyy-contentLoading.tpl'], function($, _, Backbone, doT, TplContent, TplLoading) {
    "use strict";
    var View;
    return View = (function(superClass) {
      extend(View, superClass);

      function View() {
        return View.__super__.constructor.apply(this, arguments);
      }

      View.prototype.tpls = {
        content: doT.template(TplContent)
      };

      View.prototype.events = {
        'click .q_clps_head': 'eventSwitchCollapse',
        'click .collapse .closeBtn': 'eventCloseCollapse'
      };

      View.prototype.initialize = function(data) {
        this.data = {};
        this.data.headerHeight = CSH.$els.header.outerHeight(true);
        return this.render();
      };

      View.prototype.render = function() {
        var id;
        this.$el.html(this.tpls.content());
        this.els = {};
        this.els.rightBox = this.$el.find('.rightBox');
        id = CSH.routePath[0];
        if (id) {
          this.scrollToTarget("#" + id);
        }
        if (localStorage.getItem('openDNS')) {
          localStorage.removeItem('openDNS');
          this.$el.find('#openDNS').click();
        }
        return this.getTops();
      };

      View.prototype.chooseMenu = function(id) {
        return this.scrollToTarget(id);
      };

      View.prototype.scrollToTarget = function(id) {
        var target;
        target = $(id);
        CSH.scrollTo(target.position().top, 200);
        return history.replaceState(null, null, "help.html" + id);
      };

      View.prototype.eventSwitchCollapse = function(event) {
        var el, target;
        el = $(event.currentTarget);
        target = el.next();
        el.toggleClass('active');
        target.fadeToggle();
        return this.getTops();
      };

      View.prototype.eventCloseCollapse = function(event) {
        var el;
        el = $(event.currentTarget);
        return el.closest('.collapse').prev().click();
      };

      View.prototype.getTops = function() {
        var el, i, len, ref, results;
        this.data.tops = [];
        ref = this.els.rightBox.find('h4[id]');
        results = [];
        for (i = 0, len = ref.length; i < len; i++) {
          el = ref[i];
          el = $(el);
          results.push(this.data.tops.push({
            top: el.offset().top - 50 - 10,
            id: el.attr('id')
          }));
        }
        return results;
      };

      return View;

    })(Backbone.View);
  });

}).call(this);
