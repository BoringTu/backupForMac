(function() {
  var reg,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.md5 = function() {
    return md5.apply(null, [this].concat([].slice.apply(arguments)));
  };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  String.prototype.encodeHTML = String.prototype.encodeHTML || function() {
    var encodeHTMLRules, matchHTML;
    encodeHTMLRules = {
      "&": "&#38;",
      "<": "&#60;",
      ">": "&#62;",
      '"': '&#34;',
      "'": '&#39;',
      "/": '&#47;'
    };
    matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
    if (this) {
      return this.replace(matchHTML, function(m) {
        return encodeHTMLRules[m] || m;
      });
    } else {
      return this;
    }
  };

  reg = (function() {
    function reg() {
      this.showHint = bind(this.showHint, this);
      this.eventCancelCloce = bind(this.eventCancelCloce, this);
      this.eventAgreeLogin = bind(this.eventAgreeLogin, this);
      this.eventSee = bind(this.eventSee, this);
      this.eventHideAgreement = bind(this.eventHideAgreement, this);
      this.eventShowAgreement = bind(this.eventShowAgreement, this);
      this.userName = bind(this.userName, this);
      this.errorText = bind(this.errorText, this);
      this.registerBtn = bind(this.registerBtn, this);
      this.intensity = bind(this.intensity, this);
      this.eventPass2Blur = bind(this.eventPass2Blur, this);
      this.eventpassBlur = bind(this.eventpassBlur, this);
      this.eventUserNameKey = bind(this.eventUserNameKey, this);
      this.demoBtn = bind(this.demoBtn, this);
      this.eventClearText = bind(this.eventClearText, this);
      this.checkValid = bind(this.checkValid, this);
      this.eventInputBlur = bind(this.eventInputBlur, this);
      this.eventInputKeyup = bind(this.eventInputKeyup, this);
      this.eventInputFocus = bind(this.eventInputFocus, this);
      this.loadAgreement = bind(this.loadAgreement, this);
      this.host = (function(_this) {
        return function() {
          var arr, i, k, kv, len, tmp;
          _this.isLocal = 0;
          arr = location.search.slice(1).split('&');
          for (i = 0, len = arr.length; i < len; i++) {
            kv = arr[i];
            tmp = kv.split('=');
            k = tmp[0];
            if (k === 'test') {
              _this.isLocal = 1;
              break;
            }
          }

          /*
          			if @isLocal
          				"#{ location.protocol }//appapi.#{ location.hostname.replace /^\w+\./, '' }"
          			else
          				location.origin + '/api'
           */
          return location.origin + "/api";
        };
      })(this)();
      this.loginAgreementUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/loginAgreement.tpl";
      this.url = '/openlinkaccount	';
      this.urlUser = '/members/username';
      this.hash = window.location.hash.substring(1).split('/');
      this.els = {};
      this.els.userName = $('input[name="username"]');
      this.els.password = $('input[name="password"]');
      this.els.password2 = $('input[name="password2"]');
      this.els.radio = $('.radio');
      this.els.clearText = $('.clearText');
      this.els.errorWrap = $('.errorWrap');
      this.els.prompt = $('.prompt');
      this.els.clause = $('.clause a');
      this.els.intensity = $('.intensity');
      this.els.agreement = $('.agreementContainer');
      this.els.reg = $('.reg');
      this.els.demo = $('.demo');
      this.els.plat = $('.platform');
      this.els.password.on('keyup', this.intensity);
      this.els.password.on('blur', this.eventpassBlur);
      this.els.password2.on('blur', this.eventPass2Blur);
      this.els.clearText.on('click', this.eventClearText);
      this.els.userName.on('keyup', this.eventUserNameKey);
      this.els.radio.on('click', this.eventSee);
      this.els.clause.on('click', this.eventShowAgreement);
      this.els.reg.on('click', this.registerBtn);
      this.els.demo.on('click', this.demoBtn);
      $('input').on('focus', this.eventInputFocus).on('blur', this.eventInputBlur).on('keyup', this.eventInputKeyup);
      this.intensityNumber = 1;
      this._BtnTrue = false;
      this.els.radio.trigger('click');
      this.loadAgreement();
      return;
    }

    reg.prototype.loadAgreement = function() {
      return $.ajax({
        url: this.loginAgreementUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var content, pfs;
            content = $(data);
            pfs = content.find('.platform');
            pfs.text(platform);
            _this.els.agreement.html(content);
            _this.els.agreementCloes = $(' .icon', _this.els.agreement);
            _this.els.agree = $(' .agree', _this.els.agreement);
            _this.els.cancel = $(' .cancel', _this.els.agreement);
            _this.els.agreementCloes.on('click', _this.eventHideAgreement);
            _this.els.agree.on('click', _this.eventAgreeLogin);
            return _this.els.cancel.on('click', _this.eventCancelCloce);
          };
        })(this)
      });
    };

    reg.prototype.eventInputFocus = function(event) {
      var el, x;
      this.els.errorWrap.hide();
      el = $(event.currentTarget);
      x = el.next('.clearText');
      x.next('.prompt').show();
      if (el.val()) {
        return x.show();
      }
    };

    reg.prototype.eventInputKeyup = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      x.toggle(!!el.val());
      return this.checkValid();
    };

    reg.prototype.eventInputBlur = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      x.next('.prompt').hide();
      return setTimeout((function() {
        return x.hide();
      }), 200);
    };

    reg.prototype.checkValid = function() {
      var state;
      state = this.els.userName.val() && this.els.password.val() && this.els.password2.val() && this._BtnTrue;
      return this.els.reg.prop('disabled', !state);
    };

    reg.prototype.eventClearText = function(event) {
      var el, x;
      x = $(event.currentTarget);
      el = x.prev('input');
      return el.val('').focus().trigger('keyup');
    };

    reg.prototype.demoBtn = function(event) {
      event.preventDefault();
      return $.ajax({
        url: this.host + "/members/demo/" + this.hash[0] + "/" + this.hash[1],
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processDate: false,
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var temp;
            temp = data.toJSON();
            if (+temp.code === 0) {
              localStorage.setItem('userType', temp.data.UserType);
              localStorage.setItem('username', temp.data.LoginName);
              localStorage.setItem('balance', temp.data.Balance);
              localStorage.setItem('rebate', temp.data.RebetRate);
              localStorage.setItem('salary', temp.data.DayPercent);
              localStorage.setItem('userID', temp.data.UserID);
              localStorage.setItem('stargetID', temp.data.LoginToken);
              localStorage.setItem('lastLoginAddress', temp.data.LastLoginAddress);
              localStorage.setItem('parentId', temp.data.ParentID);
              localStorage.setItem('parentName', temp.data.ParentName);
              if (temp.data.Notice) {
                localStorage.setItem('notice', temp.data.Notice);
              }
              localStorage.setItem('demo', 1);
              location.href = location.origin + "/index.html";
            }
            return data;
          };
        })(this),
        error: (function(_this) {
          return function() {
            return _this.showHint('服务器暂时无法访问，请检查网络连接');
          };
        })(this)
      });
    };

    reg.prototype.eventUserNameKey = function(event) {
      var data, el, elVal, user2Regex, userRegex;
      el = $(event.currentTarget);
      userRegex = /^[a-zA-Z]/;
      user2Regex = /^[a-zA-Z]\w{5,13}$/;
      elVal = el.val();
      if (!userRegex.test(elVal)) {
        this.errorText(el, '英文字母开头');
        return;
      } else {
        this.els.errorWrap.hide();
      }
      if (user2Regex.test(elVal)) {
        data = {
          userName: el.val().encodeHTML()
        };
        this.userName(data, el);
      }
    };

    reg.prototype.eventpassBlur = function(event) {
      var el;
      el = $(event.currentTarget);
      if (el.val().length < 6) {
        return this.errorText(el, '长度为6~16位');
      }
    };

    reg.prototype.eventPass2Blur = function(event) {
      var el;
      el = $(event.currentTarget);
      if (el.val() !== this.els.password.val()) {
        return this.errorText(el, '两次密码不一致');
      }
    };

    reg.prototype.intensity = function(event) {
      var el, enoughRegex, mediumRegex, strongRegex;
      el = $(event.currentTarget);
      strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
      mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
      enoughRegex = new RegExp("(?=.{6,}).*", "g");
      this.els.intensity.css('opacity', 1);
      if (false === enoughRegex.test(el.val())) {
        this.els.intensity.text('弱').css({
          'background': '#436484',
          'color': 'rgba( 255, 255, 255, 0.3)'
        });
        this.intensityNumber = 1;
      } else if (strongRegex.test(el.val())) {
        this.els.intensity.text('强').css({
          'background': '#8fc31f',
          'color': 'rgba( 255, 255, 255, 1)'
        });
        this.intensityNumber = 3;
      } else if (mediumRegex.test(el.val())) {
        this.els.intensity.text('中').css({
          'background': '#f19a38',
          'color': 'rgba( 255, 255, 255, 1)'
        });
        this.intensityNumber = 2;
      } else {
        this.els.intensity.text('弱').css({
          'background': '#436484',
          'color': 'rgba( 255, 255, 255, 0.3)'
        });
        this.intensityNumber = 1;
      }
    };

    reg.prototype.registerBtn = function(event) {
      var data, el, passwordRegex, userRegex;
      event.preventDefault();
      el = $(event.currentTarget);
      el.attr('disabled', true);
      userRegex = /^[a-zA-Z]\w{5,13}$/;
      passwordRegex = /^\S{6,20}$/;
      data = {
        userName: this.els.userName.val(),
        password: this.els.password.val(),
        safeLevel: this.intensityNumber,
        lid: this.hash[0],
        aid: this.hash[1]
      };
      if (!userRegex.test(this.els.userName.val())) {
        return this.errorText(this.els.userName, '账号开头英文字母,并且账号长度6~14位英文与数字');
      } else if (!passwordRegex.test(this.els.password.val())) {
        return this.errorText(this.els.password, '密码由大小写英文、数字、特殊符号组成');
      } else if (this.els.password.val() !== this.els.password2.val()) {
        return this.errorText(this.els.password, '输入的两次密码不同');
      } else {
        return this.register(data);
      }
    };

    reg.prototype.register = function(data) {
      var passV, userV;
      userV = data.userName;
      passV = data.password;
      return $.ajax({
        url: "" + this.host + this.url,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processData: false,
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        data: JSON.stringify(data),
        dataFilter: (function(_this) {
          return function(data) {
            var temp;
            temp = data.toJSON();
            if (temp.code === 0) {
              _this.showHint('注册成功');
              setTimeout((function() {
                return location.href = location.origin + "/login.html";
              }), 2000);
            } else {
              _this.showHint(temp.message);
            }
            _this.els.reg.attr('disabled', false);
            return '{}';
          };
        })(this),
        error: (function(_this) {
          return function() {
            return _this.showHint('服务器暂时无法访问，请检查网络连接');
          };
        })(this)
      });
    };

    reg.prototype.errorText = function(el, text) {
      var x, y;
      this.els.prompt.hide();
      el = el.closest('li');
      y = el.offset().left + el.width() + 20;
      x = el.offset().top + 5;
      return this.els.errorWrap.css({
        top: x,
        left: y,
        display: 'block'
      }).find('p').text(text);
    };

    reg.prototype.userName = function(data, el) {
      if (this.xhr) {
        this.xhr.abort();
      }
      $.ajax({
        url: "" + this.host + this.urlUser + "/" + data.userName,
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        beforeSend: (function(_this) {
          return function(xhr) {
            return _this.xhr = xhr;
          };
        })(this),
        dataFilter: (function(_this) {
          return function(data) {
            var temp;
            temp = data.toJSON();
            if (temp.code === 0) {
              _this.errorText(el, '该账号已经存在');
            } else {
              _this.els.errorWrap.hide();
            }
            return '{}';
          };
        })(this)
      });
    };

    reg.prototype.eventShowAgreement = function() {
      var speed;
      speed = 200;
      return this.els.agreement.css('display', 'block').animate({
        top: '5%',
        opacity: '1'
      }, speed);
    };

    reg.prototype.eventHideAgreement = function() {
      var speed;
      speed = 200;
      return this.els.agreement.animate({
        top: '0%',
        opacity: '0'
      }, speed, (function(_this) {
        return function() {
          return _this.els.agreement.css('display', 'none');
        };
      })(this));
    };

    reg.prototype.eventSee = function(event) {
      var el;
      el = $(event.currentTarget);
      el.css('backgroundPosition', '-240px 0');
      this._BtnTrue = true;
      return this.checkValid();
    };

    reg.prototype.eventAgreeLogin = function() {
      this.els.radio.trigger('click');
      return this.eventHideAgreement();
    };

    reg.prototype.eventCancelCloce = function() {
      this.els.radio.removeAttr('style');
      this._BtnTrue = false;
      this.checkValid();
      return this.eventHideAgreement();
    };

    reg.prototype.showHint = function(msg) {
      var speed, target;
      speed = 200;
      target = $("<div class=\"hint\">\n	<p>" + (msg.encodeHTML()) + "</p>\n</div>");
      target.appendTo('body').css({
        marginTop: '-30',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, speed, function() {
        return target.removeAttr('style');
      });
      return setTimeout((function(_this) {
        return function() {
          return target.animate({
            marginTop: '-30',
            opacity: 0
          }, speed, function() {
            return target.remove();
          });
        };
      })(this), 2000, function() {});
    };

    return reg;

  })();

  new reg();

}).call(this);
