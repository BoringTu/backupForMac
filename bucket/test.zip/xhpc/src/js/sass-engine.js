
/*
  * sass Engine
 */

(function() {
  var i, len, link, links, loadSassFile, sass, url;

  sass = new Sass();

  loadSassFile = function(url) {
    var xhr;
    console.debug('Fetch Sass File:', url);
    xhr = new XMLHttpRequest();
    xhr.open('GET', url, false);
    xhr.setRequestHeader('Accept', 'text/x-sass, text/css; q=0.9, */*; q=0.5');
    xhr.send(null);
    return xhr.onreadystatechange = function() {
      if (xhr.readyState === 4) {
        if (xhr.status === 0 || (xhr.status >= 200 && xhr.status < 300)) {
          sass.compile(xhr.responseText, function(result) {
            var css, head, style;
            css = result.text;
            head = document.head || document.getElementsByTagName('head')[0];
            style = document.createElement('style');
            style.type = 'text/css';
            style.id = "sass:" + (url.replace(/^\//, '').replace(/\//g, '_').replace(/\.sass$/, ''));
            if (style.styleSheet) {
              style.styleSheet.cssText = css;
            } else {
              style.appendChild(document.createTextNode(css));
            }
            return head.appendChild(style);
          });
          return console.debug('rendering Sass File:', url);
        } else {
          return console.error('Not Found:', url);
        }
      }
    };
  };

  links = document.getElementsByTagName('link');

  for (i = 0, len = links.length; i < len; i++) {
    link = links[i];
    if (link.rel !== 'stylesheet/sass') {
      continue;
    }
    url = link.href.replace(new RegExp(location.origin.replace(/\//g, '\/')), '');
    loadSassFile(url);
  }

}).call(this);
