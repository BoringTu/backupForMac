(function() {
  define(['jquery'], function($) {
    "use strict";
    var Algorithm;
    Algorithm = (function() {
      function Algorithm() {
        var i, n, sn;
        this.data = [];
        for (n = i = 1; i <= 49; n = ++i) {
          sn = n < 10 ? "0" + n : "" + n;
          this.data.push({
            n: sn,
            animal: this.getAnimal(n),
            color: this.getColor(n),
            state: {
              daxc: n > 24,
              djud: n % 2 === 1,
              hedjud: (+sn[0] + +sn[1]) % 2 === 1
            }
          });
        }
        console.log(this.data);
      }

      Algorithm.prototype.firstIndex = (CSH.serverTime.getFullYear() - 2008) % 12;

      Algorithm.prototype.animals = ['uu', 'nq', 'hu', 'tu', 'ls', 'ue', 'ma', 'yh', 'hb', 'ji', 'gb', 'vu'];

      Algorithm.prototype.map = {
        uu: '鼠',
        nq: '牛',
        hu: '虎',
        tu: '兔',
        ls: '龙',
        ue: '蛇',
        ma: '马',
        yh: '羊',
        hb: '猴',
        ji: '鸡',
        gb: '狗',
        vu: '猪'
      };

      Algorithm.prototype.getAnimal = function(n) {
        return this.animals[(12 - (12 + n - this.firstIndex - 1) % 12) % 12];
      };

      Algorithm.prototype.getColor = function(n) {
        if (n > 11 + 0) {
          n++;
        }
        if (n > 20 + 1) {
          n++;
        }
        if (n > 31 + 2) {
          n++;
        }
        if (n > 40 + 3) {
          n++;
        }
        return (Math.ceil(n % 6 / 2)) || 3;
      };

      return Algorithm;

    })();
    return Algorithm;
  });

}).call(this);
