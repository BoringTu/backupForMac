(function() {
  var Login, getCaptchaId,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Base64.extendString();

  String.prototype.md5 = function() {
    return md5.apply(null, [this].concat([].slice.apply(arguments)));
  };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  String.prototype.encodeHTML = String.prototype.encodeHTML || function() {
    var encodeHTMLRules, matchHTML;
    encodeHTMLRules = {
      "&": "&#38;",
      "<": "&#60;",
      ">": "&#62;",
      '"': '&#34;',
      "'": '&#39;',
      "/": '&#47;'
    };
    matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
    if (this) {
      return this.replace(matchHTML, function(m) {
        return encodeHTMLRules[m] || m;
      });
    } else {
      return this;
    }
  };

  getCaptchaId = function() {
    return 'e614300cf3de4d36bfa64407470121c5';
  };

  Login = (function() {
    function Login() {
      this.nec = bind(this.nec, this);
      this.getWeiXinQrCodeState = bind(this.getWeiXinQrCodeState, this);
      this.eventWXQRHide = bind(this.eventWXQRHide, this);
      this.eventWXQRShow = bind(this.eventWXQRShow, this);
      this.showHint = bind(this.showHint, this);
      this.eventCancelCloce = bind(this.eventCancelCloce, this);
      this.eventAgreeLogin = bind(this.eventAgreeLogin, this);
      this.eventHideAgreement = bind(this.eventHideAgreement, this);
      this.eventShowAgreement = bind(this.eventShowAgreement, this);
      this.setStorageData = bind(this.setStorageData, this);
      this.eventLogin = bind(this.eventLogin, this);
      this.getServerTime = bind(this.getServerTime, this);
      this.eventSlideUnlock = bind(this.eventSlideUnlock, this);
      this.textSlide = bind(this.textSlide, this);
      this.checkValid = bind(this.checkValid, this);
      this.eventInputKeyup = bind(this.eventInputKeyup, this);
      this.loadAgreement = bind(this.loadAgreement, this);
      this.getBackPassword = bind(this.getBackPassword, this);
      this.eventToggleLowLogin = bind(this.eventToggleLowLogin, this);
      this.eventPasswordFocus = bind(this.eventPasswordFocus, this);
      this.eventPasswordChanged = bind(this.eventPasswordChanged, this);
      this.processSPW = bind(this.processSPW, this);
      window.v = this;
      this.host = (function(_this) {
        return function() {
          var arr, j, k, kv, len, tmp;
          _this.isLocal = 0;
          arr = location.search.slice(1).split('&');
          for (j = 0, len = arr.length; j < len; j++) {
            kv = arr[j];
            tmp = kv.split('=');
            k = tmp[0];
            if (k === 'test') {
              _this.isLocal = 1;
              break;
            }
          }

          /*
          			if @isLocal
          				"#{ location.protocol }//appapi.#{ location.hostname.replace /^\w+\./, '' }"
          			else
          				location.origin + '/api'
           */
          return location.origin + "/api";
        };
      })(this)();
      this.getServerTime();
      this.loginAlertUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/default-loginAlert.tpl";
      this.loginAgreementUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/default-loginAgreement.tpl";
      this.url = '/members/Login';
      this.els = {};
      this.data = {};
      this.els.userName = $('[name="username"]');
      this.els.password = $('[name="password"]');
      this.els.lowlogin = $('li.lowlogin .checkbox');
      this.els.login = $('button.login');
      this.els.slideWrap = $('.slideWrap');
      this.els.wxLoginBtn = $('.wxLoginBtn');
      this.els.wxQrCode = this.els.wxLoginBtn.find('.qrcode img');
      this.wxQrRandomCode = null;
      this.detectionRequest = null;
      this.els.clearText = $('.clearText');
      this.els.agreement = $(' .agreementContainer');
      this.els.getBackPassword = $('#getBackPassword');
      this.rememberPassword = 11111111111;
      setTimeout((function(_this) {
        return function() {
          _this.els.userName.val(localStorage.getItem('username') || '');
          return _this.processSPW();
        };
      })(this), 100);
      $('input').on('focus', this.eventInputFocus).on('blur', this.eventInputBlur).on('keyup', this.eventInputKeyup);
      this.els.password.on('change', this.eventPasswordChanged);
      this.els.password.on('focus', this.eventPasswordFocus);
      this.els.lowlogin.parent().on('click', this.eventToggleLowLogin);
      this.els.clearText.on('click', this.eventClearText);
      this.els.login.on('click', this.eventLogin);
      this.els.getBackPassword.on('click', this.getBackPassword);
      this.els.wxLoginBtn.on('mouseover', this.eventWXQRShow);
      this.els.wxLoginBtn.on('mouseout', this.eventWXQRHide);
      this._BtnTrue = false;
      this.loadAgreement();

      /*
      		fun	= => if window.NECaptcha then @nec() else setTimeout fun, 100
      		setTimeout fun, 100
       */
      this.generateQRCode();
      this.getWeiXinQrCode();
      setInterval((function(_this) {
        return function() {
          return _this.getWeiXinQrCode();
        };
      })(this), 120000);
      return;
    }

    Login.prototype.processSPW = function() {
      var spw;
      spw = localStorage.getItem('spw');
      if (spw) {
        this.els.lowlogin.addClass('checked');
        this.els.password.val(this.rememberPassword).attr('isSPW', 1);
        return this.els.login.prop('disabled', false);
      } else {
        return this.els.password.val('');
      }
    };

    Login.prototype.eventPasswordChanged = function(event) {
      var el;
      el = $(event.currentTarget);
      return el.removeAttr('isSPW');
    };

    Login.prototype.eventPasswordFocus = function(event) {
      var el;
      el = $(event.currentTarget);
      return el.setSelection(0);
    };

    Login.prototype.eventToggleLowLogin = function(event) {
      event.preventDefault();
      return this.els.lowlogin.toggleClass('checked');
    };

    Login.prototype.getBackPassword = function() {
      var InModalBox, identity, outModalBox, passwordNew, passwordScueess, speed;
      speed = 350;
      $.ajax({
        url: this.loginAlertUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var els, text;
            els = {};
            InModalBox(data, els);
            els.modal.addClass('getBackPassword');
            els.content = els.modal.find('.content');
            text = "<label>\n	<span> 账号 </span>\n	<span>\n		<input type=\"text\" class=\"name\" placeholder=\"请输入账号\" maxlength=\"14\"	>\n	</span>\n</label>\n<label class=\"identifyingCode\">\n	<span> 验证码 </span>\n	<span>\n		<input type=\"text\" class=\"code\" placeholder=\"请输入验证码\">\n		<img class=\"imgCode\" />\n	</span>\n</label>";
            els.content.append(text);
            els.imgCode = els.modal.find('.imgCode');
            els.btn = els.modal.find('button.btn');
            els.name = els.modal.find('input.name');
            els.code = els.modal.find('input.code');
            els.imgCode.on('click', function() {
              var imgUrl;
              imgUrl = _this.host + "/common/verifyImage?" + (Math.random());
              return els.imgCode.attr('src', imgUrl);
            });
            els.imgCode.trigger('click');
            els.name.focus();
            return els.btn.on('click', function(event) {
              var el, name, url;
              el = $(event.currentTarget);
              name = els.name.val();
              data = {};
              url = _this.host + "/members/checkUsername/" + name;
              data.verifyCode = els.code.val();
              if (!name) {
                el.prop('disabled', false);
                _this.showHint({
                  msg: '账号不能为空'
                });
                return;
              }
              if (!data.verifyCode) {
                _this.showHint({
                  msg: '验证码不能为空'
                });
                els.imgCode.trigger('click');
                return;
              } else if (data.verifyCode.length < 5) {
                _this.showHint({
                  msg: '验证码长度不符'
                });
                els.imgCode.trigger('click');
                return;
              }
              data.varifyToken = $.cookie('valicode_token');
              return $.ajax({
                url: url,
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                processDate: false,
                croossDomain: true,
                headers: {
                  'Content-type': 'application/json; charset=utf-8'
                },
                xhrFields: {
                  'withCredentials': true
                },
                data: JSON.stringify(data),
                dataFilter: function(data) {
                  var ref;
                  data = data.toJSON();
                  if (+data.code === 0) {
                    identity(name);
                    return outModalBox(els);
                  } else if ((ref = +data.code) === 1 || ref === 2) {
                    _this.showHint({
                      msg: data.message
                    });
                    return els.imgCode.trigger('click');
                  } else if (+data.code < 0) {
                    _this.showHint({
                      msg: data.message
                    });
                    return els.imgCode.trigger('click');
                  }
                }
              });
            });
          };
        })(this)
      });
      identity = (function(_this) {
        return function(name) {
          return setTimeout(function() {
            return $.ajax({
              url: _this.loginAlertUrl,
              dataType: 'text',
              success: function(data) {
                var addQuestion, els, text;
                els = {};
                InModalBox(data, els);
                els.modal.addClass('identity');
                els.content = els.modal.find('.content');
                text = "<label >\n	<span>问题一</span>\n	<span class=\"problem\">您儿时的绰号叫什么？</span>\n</label>\n<label >\n	<span> 答案 </span>\n	<span>\n		<input type=\"text\" class=\"answer\" placeholder=\"请输入您的答案\"	>\n	</span>\n</label>\n<label>\n	<span>问题二</span>\n	<span class=\"problem\">您儿时的绰号叫什么？</span>\n</label>\n<label>\n	<span> 答案 </span>\n	<span>\n		<input type=\"text\" class=\"answer\" placeholder=\"请输入您的答案\"	>\n	</span>\n</label>\n<label>\n	<span>问题三</span>\n	<span class=\"problem\">您儿时的绰号叫什么？</span>\n</label>\n<label>\n	<span> 答案 </span>\n	<span>\n		<input type=\"text\" class=\"answer\" placeholder=\"请输入您的答案\"	>\n	</span>\n</label>";
                els.content.append(text).addClass('indentity');
                els.title = els.modal.find('.title');
                els.title.css('display', 'block');
                els.process = els.modal.find('.process');
                els.process.find('li:eq(1)').addClass('inExecution');
                els.problem = els.modal.find('.problem');
                els.answer = els.modal.find('.answer');
                els.btn = els.modal.find('button.btn');
                addQuestion = ['你童年时代的绰号是什么？', '你最喜欢的歌手是谁？', '你最喜欢的电影的名字？', '你少年时代最好的朋友叫什么名字？', '你最喜欢哪个球队？', '你最喜欢的活动是什么？', '你的理想工作是什么？', '你的初恋叫什么名字？', '你第一次坐飞机是去哪里？', '你最喜欢的老师叫什么名字？', '你最喜欢吃的菜叫什么？', '你最喜欢哪个国家？', '你的爸爸叫什么？', '你的妈妈叫什么？', '你的爷爷叫什么？', '你的奶奶叫什么？', '喜欢什么动物啊？', '每天怎么上班的？'];
                $.ajax({
                  url: _this.host + "/members/findPassGetQuestions/" + name,
                  type: 'GET',
                  contentType: 'application/json',
                  dataType: 'json',
                  crossDomain: true,
                  headers: {
                    'Content-type': 'application/json; charset=utf-8'
                  },
                  xhrFields: {
                    'withCredentials': true
                  },
                  dataFilter: function(data) {
                    data = data.toJSON();
                    return $.each(data, function(i, k) {
                      return els.problem.eq(i).text(addQuestion[k]).attr('data-number', k);
                    });
                  }
                });
                return els.btn.on('click', function() {
                  data = {};
                  data.q1 = els.problem.eq(0).attr('data-number');
                  data.q2 = els.problem.eq(1).attr('data-number');
                  data.q3 = els.problem.eq(2).attr('data-number');
                  data.answer1 = els.answer.eq(0).val();
                  data.answer2 = els.answer.eq(1).val();
                  data.answer3 = els.answer.eq(2).val();
                  if (!(data.answer1 && data.answer2 && data.answer3)) {
                    _this.showHint({
                      msg: '请输入答案'
                    });
                  }
                  return $.ajax({
                    url: _this.host + "/members/findPassAnswerQuestions/" + name,
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    processDate: false,
                    croossDomain: true,
                    headers: {
                      'Content-type': 'application/json; charset=utf-8'
                    },
                    xhrFields: {
                      'withCredentials': true
                    },
                    data: JSON.stringify(data),
                    dataFilter: function(data) {
                      data = data.toJSON();
                      if (data.code === 0) {
                        outModalBox(els);
                        return passwordNew(name);
                      } else if (data.code < 0) {
                        return _this.showHint({
                          msg: data.message
                        });
                      }
                    }
                  });
                });
              }
            });
          }, speed);
        };
      })(this);
      passwordNew = (function(_this) {
        return function(name) {
          return setTimeout(function() {
            return $.ajax({
              url: _this.loginAlertUrl,
              dataType: 'text',
              success: function(data) {
                var els, intensityNumber, text;
                els = {};
                InModalBox(data, els);
                els.modal.addClass('passwordNew');
                els.content = els.modal.find('.content');
                text = "<label>\n	<span> 新密码 </span>\n	<span>\n		<input type=\"password\" class=\"password1\" placeholder=\"请输入新密码\" maxlength=\"16\">\n		<span class=\"intensity\" style=\"opacity: 0.3; background: #d74241; color: rgba(255, 255, 255, 1);\">弱</span>\n	</span>\n</label>\n<label>\n	<span> 确认密码 </span>\n	<span>\n		<input type=\"password\" class=\"password2\" placeholder=\"再次确认您的密码\" maxlength=\"16\">\n	</span>\n</label>";
                els.content.append(text);
                els.password1 = els.modal.find('.password1');
                els.password2 = els.modal.find('.password2');
                els.btn = els.modal.find('button.btn');
                els.intensity = els.modal.find('.intensity');
                els.process = els.modal.find('.process');
                els.content = els.modal.find('.content');
                els.process.find('li:eq(1)').addClass('inExecution').end().find('li:eq(2)').addClass('inExecution');
                intensityNumber = 0;
                els.password1.on('keyup', function(event) {
                  var el, enoughRegex, mediumRegex, strongRegex;
                  el = $(event.currentTarget);
                  strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
                  mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
                  enoughRegex = new RegExp("(?=.{6,}).*", "g");
                  if (false === enoughRegex.test(el.val())) {
                    els.intensity.text('弱').css({
                      background: '#d74241',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 1;
                  } else if (strongRegex.test(el.val())) {
                    els.intensity.text('强').css({
                      background: '#8fc31f',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 3;
                  } else if (mediumRegex.test(el.val())) {
                    els.intensity.text('中').css({
                      background: '#f19a38',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 2;
                  } else {
                    els.intensity.text('弱').css({
                      background: '#d74241',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 1;
                  }
                });
                return els.btn.on('click', function() {
                  if (els.password1.val().length < 6) {
                    return _this.showHint({
                      msg: '密码长度为6~16位'
                    });
                  }
                  if (els.password1.val() !== els.password2.val()) {
                    return _this.showHint({
                      msg: '两次密码不一致'
                    });
                  }
                  data = {};
                  data.safeLevel = intensityNumber;
                  data.newPwd = els.password1.val().md5();
                  return $.ajax({
                    url: _this.host + "/members/findPassResetPwd/" + name,
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    processDate: false,
                    corrssDomain: true,
                    headers: {
                      'Content-type': 'application/json; charset=utf-8'
                    },
                    xhrFields: {
                      'withCredentials': true
                    },
                    data: JSON.stringify(data),
                    dataFilter: function(data) {
                      data = data.toJSON();
                      if (data.code === 0) {
                        outModalBox(els);
                        return passwordScueess(name);
                      }
                    }
                  });
                });
              }
            });
          }, speed);
        };
      })(this);
      passwordScueess = (function(_this) {
        return function(name) {
          return setTimeout(function() {
            return $.ajax({
              url: _this.loginAlertUrl,
              dataType: 'text',
              success: function(data) {
                var els, iNow, text, time;
                els = {};
                InModalBox(data, els);
                els.modal.addClass('passwordScueess');
                els.modalBody = els.modal.find('.modal-body');
                text = "<div  class=\"success\">\n	<span class=\"icon\"></span>\n	<h4>密码修改成功</h4>\n	<p>恭喜你，可以使用新密码登录了</p>\n</div>";
                els.modalBody.text('').append(text);
                els.btn = els.modal.find('button.btn');
                els.btn.text('完成（3）').css({
                  'width': 190
                }).on('click', function() {
                  outModalBox(els);
                  return clearInterval(time);
                });
                iNow = 3;
                return time = setInterval(function() {
                  iNow--;
                  els.btn.text("完成（" + iNow + "）");
                  if (iNow === 0) {
                    els.btn.trigger('click');
                    return clearInterval(time);
                  }
                }, 1000);
              }
            });
          }, speed);
        };
      })(this);
      InModalBox = (function(_this) {
        return function(data, els) {
          els.modalBox = $(data);
          $('body').append(els.modalBox);
          els.modal = els.modalBox.find('.modal');
          els.modalBackdrop = $('.modal-backdrop');
          els.modalBackdrop.show();
          els.modal.css({
            top: '-150px',
            opacity: 0.5
          }).animate({
            top: 0,
            opacity: 1
          }, speed);
          $('body').on('click', '.close', function() {
            return outModalBox(els);
          }).on('keyup', '.modal', function(event) {
            var el;
            if (+event.keyCode === 27) {
              outModalBox(els);
            }
            if (+event.keyCode === 13) {
              el = $(event.currentTarget);
              return el.find('.btn').trigger('click');
            }
          });
        };
      })(this);
      return outModalBox = (function(_this) {
        return function(els) {
          return els.modal.css({
            top: '0',
            opacity: 1
          }).animate({
            top: '-150px',
            opacity: 0.5
          }, speed, function() {
            return els.modalBox.remove();
          });
        };
      })(this);
    };

    Login.prototype.loadAgreement = function() {
      return $.ajax({
        url: this.loginAgreementUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var content, pfs;
            content = $(data);
            pfs = content.find('.platform');
            pfs.text(platform);
            _this.els.agreement.html(content);
            _this.els.agreementCloes = $(' .icon', _this.els.agreement);
            _this.els.agree = $(' .agree', _this.els.agreement);
            _this.els.cancel = $(' .cancel', _this.els.agreement);
            _this.els.agreementCloes.on('click', _this.eventHideAgreement);
            _this.els.agree.on('click', _this.eventAgreeLogin);
            return _this.els.cancel.on('click', _this.eventCancelCloce);
          };
        })(this)
      });
    };

    Login.prototype.eventInputBlur = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      return setTimeout((function() {
        return x.hide();
      }), 200);
    };

    Login.prototype.eventInputFocus = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      if (el.val()) {
        return x.show();
      }
    };

    Login.prototype.eventInputKeyup = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      x.toggle(!!el.val());
      return this.checkValid();
    };

    Login.prototype.checkValid = function() {
      var state;
      state = this.els.userName.val() && this.els.password.val();
      return this.els.login.prop('disabled', !state);
    };

    Login.prototype.eventClearText = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.prev('input');
      return x.val('').focus();
    };

    Login.prototype.textSlide = function(obj) {
      var text, toMove;
      text = obj;
      toMove = function() {
        return setTimeout(function() {
          return text.css({
            transition: '2s',
            backgroundPosition: '200px 0px'
          });
        }, 1000);
      };
      toMove();
      setInterval(function() {
        toMove();
        return text.css({
          transition: 'none',
          backgroundPosition: '-200px 0px'
        });
      }, 5000);
    };

    Login.prototype.eventSlideUnlock = function() {
      var dMt, mWidth, slideLeftBtn, xInte;
      xInte = 0;
      slideLeftBtn = this.els.slideLeft;
      dMt = $(document);
      mWidth = 0;
      slideLeftBtn.on('mousedown.slide', (function(_this) {
        return function(event) {
          var BtnWidth;
          event.stopPropagation();
          xInte = event.clientX - slideLeftBtn.position().left;
          BtnWidth = slideLeftBtn.width() / 2;
          mWidth = _this.els.slide.width() - slideLeftBtn.width();
          slideLeftBtn.css({
            'transition': 'none'
          });
          _this.els.slideShade.css({
            'transition': 'none'
          });
          dMt.on('mousemove.slide', function(event) {
            var xNow;
            event.stopPropagation();
            xNow = event.clientX - xInte;
            if (xNow < 0) {
              xNow = 0;
            }
            if (xNow >= mWidth) {
              xNow = mWidth;
            }
            slideLeftBtn.css('left', xNow);
            xNow = BtnWidth + xNow;
            return _this.els.slideShade.css('clip', 'rect(0, ' + xNow + 'px, 40px, 0)');
          });
          dMt.on('mouseup.slide', function(event) {
            if (parseInt(slideLeftBtn.css('left')) > (mWidth - 10)) {
              slideLeftBtn.css({
                'left': mWidth,
                'backgroundPosition': '-163px -37px'
              });
              _this._BtnTrue = true;
              _this.checkValid();
              slideLeftBtn.unbind();
            } else {

            }
            dMt.off('.slide');
          });
        };
      })(this));
    };

    Login.prototype.errorLock = function() {
      this._BtnTrue = false;
      return $('.ncpt_slide_fg').find('.icon').css({
        'backgroundPosition': ' -100px -37px'
      });
    };

    Login.prototype.getServerTime = function() {
      return $.ajax({
        url: location.origin + "/fapi/time",
        contentType: 'application/json',
        dataType: 'json',
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        dataFilter: (function(_this) {
          return function(data) {
            var sDate, stdv;
            sDate = new Date(data.toJSON().data);
            _this.serverTimeDV = stdv = sDate.getTime() - new Date().getTime();
            return localStorage.setItem('serverTimeDV', stdv);
          };
        })(this)
      });
    };

    Login.prototype.eventLogin = function(event) {
      var data, el, i, j, n, pw, ref;
      event.preventDefault();
      el = $(event.currentTarget);
      if (this.els.password.attr('isSPW') && +this.rememberPassword === +this.els.password.val()) {
        pw = localStorage.getItem('spw').fromBase64().split('').slice(1);
        for (i = j = 0, ref = pw.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          if (!(i % 2 - 1)) {
            continue;
          }
          n = pw[i];
          if (n === '.') {
            n = 0;
          } else {
            n = 1 + parseInt(n, 36);
            n = n.toString(36);
          }
          pw[i] = n;
        }
        pw = pw.join('');
      } else {
        pw = this.els.password.val().md5();
      }
      data = {
        userName: this.els.userName.val(),
        password: pw
      };
      this.login(data);
      return el.prop('disabled', true);
    };

    Login.prototype.login = function(data) {
      var xhr;
      this.hintEl = this.showHint({
        msg: '登录中...',
        type: 'loading',
        duration: Infinity
      });
      this.data.isInitPwd = data.password === 'x123456'.md5();
      this.data.password = data.password;
      this.data.username = data.userName;
      xhr = null;
      $.ajax({
        url: this.host + this.url,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processData: false,
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          withCredentials: true
        },
        data: JSON.stringify(data),
        beforeSend: function(_xhr) {
          return xhr = _xhr;
        },
        dataFilter: (function(_this) {
          return function(data) {
            var loginMode;
            loginMode = 'password';
            _this.setStorageData(data, loginMode);
            return data;
          };
        })(this),
        error: (function(_this) {
          return function() {
            var fun;
            _this.showHint({
              msg: '服务器暂时无法访问，请检查网络连接'
            });
            _this.errorLock();
            fun = _this.hintEl.data('hide');
            return fun();
          };
        })(this)
      });
    };

    Login.prototype.setStorageData = function(data, loginMode) {
      var fun, next;
      next = (function(_this) {
        return function(data, loginMode) {
          var i, j, n, ref, temp;
          _this.hintEl.data('hide')();
          temp = data.toJSON();
          if (+temp.code !== 0) {
            _this.showHint({
              msg: temp.message
            });
            _this.els.password.val('');
            _this.errorLock();
            return '{}';
          }
          localStorage.setItem('isLocal', _this.isLocal);
          localStorage.setItem('username', temp.data.LoginName);
          if (loginMode === 'password') {
            if (_this.els.lowlogin.hasClass('checked')) {
              _this.data.password = ("." + _this.data.password).split('');
              for (i = j = 0, ref = _this.data.password.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
                if (!(i % 2)) {
                  continue;
                }
                n = parseInt(_this.data.password[i], 36);
                if (n) {
                  --n;
                  n = n.toString(36);
                } else {
                  n = '.';
                }
                _this.data.password[i] = n;
              }
              _this.data.password = _this.data.password.join('').toBase64();
              localStorage.setItem('spw', _this.data.password);
            } else {
              localStorage.removeItem('spw');
            }
          }
          if (temp.data) {
            localStorage.setItem('balance', temp.data.Balance);
            localStorage.setItem('rebate', temp.data.RebetRate);
            localStorage.setItem('userID', temp.data.UserID);
            localStorage.setItem('userType', temp.data.UserType);
            localStorage.setItem('stargetID', temp.data.LoginToken);
            localStorage.setItem('isInitPwd', +_this.data.isInitPwd);
            localStorage.setItem('lastLoginAddress', temp.data.LastLoginAddress);
            localStorage.setItem('parentId', temp.data.ParentID);
            localStorage.setItem('parentName', temp.data.ParentName);
            if (temp.data.Notice) {
              localStorage.setItem('notice', temp.data.Notice);
            }
            localStorage.setItem('dfMonthActivityPop', 1);
            if (_this.data.isInitPwd) {
              return _this.eventShowAgreement();
            } else {
              return _this.eventAgreeLogin();
            }
          }
        };
      })(this);
      fun = (function(_this) {
        return function() {
          if (_this.serverTimeDV) {
            return next(data, loginMode);
          } else {
            return setTimeout(fun, 100);
          }
        };
      })(this);
      return fun();
    };

    Login.prototype.eventShowAgreement = function() {
      var speed;
      speed = 200;
      return this.els.agreement.css('display', 'block').animate({
        top: '5%',
        opacity: '1'
      }, speed);
    };

    Login.prototype.eventHideAgreement = function() {
      var speed;
      speed = 200;
      return this.els.agreement.animate({
        top: '0%',
        opacity: '0'
      }, speed, (function(_this) {
        return function() {
          return _this.els.agreement.css('display', 'none');
        };
      })(this));
    };

    Login.prototype.eventAgreeLogin = function() {
      var isLogin, x;
      isLogin = true;
      x = location.search.slice(1).split('&');
      x.map((function(_this) {
        return function(current, index) {
          var c;
          c = current.split('=');
          if (c[0] === 'backUrl') {
            isLogin = false;
            location.href = "" + location.origin + (decodeURIComponent(c[1])) + (_this.isLocal ? '?test=1' : '');
          }
        };
      })(this));
      if (isLogin) {
        return location.href = location.origin + "/index.html";
      }
    };

    Login.prototype.eventCancelCloce = function() {
      this.eventHideAgreement();
      this.els.password.val('');
      return this.errorLock();
    };

    Login.prototype.showHint = function(param) {
      var target;
      if (param.speed == null) {
        param.speed = 200;
      }
      if (param.duration == null) {
        param.duration = 2000;
      }
      target = $("<div class=\"hint\">\n	<p>\n		" + (param.type === 'loading' ? '<img class="icon icon-spin icon-fast" src="/images/loading.png"/>' : '') + "\n		<label>" + (param.msg.encodeHTML()) + "</label>\n	</p>\n</div>");
      target.appendTo('body').data('hide', function() {
        clearTimeout(target.data('timeout'));
        return target.animate({
          marginTop: '-32px',
          opacity: 0
        }, param.speed, function() {
          target.remove();
          return typeof param.callback === "function" ? param.callback() : void 0;
        });
      }).css({
        marginTop: '-32px',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, param.speed, function() {
        return target.removeAttr('style');
      });
      if (param.duration !== Infinity) {
        target.data('timeout', setTimeout(function() {
          var fun;
          fun = target.data('hide');
          return fun();
        }, param.duration));
      }
      return target;
    };

    Login.prototype.getWeiXinQrCode = function() {
      return $.ajax({
        url: this.host + "/members/loginqr",
        type: 'GET',
        contentType: 'json',
        success: (function(_this) {
          return function(data) {
            if (data.code !== 0) {
              return;
            }
            _this.els.wxQrCode.attr('src', data.data);
            _this.els.wxQrCode.next().removeClass('qrLoading');
            return _this.wxQrRandomCode = data.message;
          };
        })(this)
      });
    };

    Login.prototype.eventWXQRShow = function(event) {
      var el;
      el = $(event.currentTarget);
      el.addClass('toggleqr');
      return this.detectionRequest = setInterval((function(_this) {
        return function() {
          return _this.getWeiXinQrCodeState();
        };
      })(this), 2000);
    };

    Login.prototype.eventWXQRHide = function(event) {
      var el;
      el = $(event.currentTarget);
      el.removeClass('toggleqr');
      return clearInterval(this.detectionRequest);
    };

    Login.prototype.getWeiXinQrCodeState = function() {
      return $.ajax({
        url: this.host + "/qr/login/" + this.wxQrRandomCode,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processData: false,
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          withCredentials: true
        },
        success: (function(_this) {
          return function(data) {
            var loginMode;
            if (data.code !== 0) {
              return;
            }
            data = JSON.stringify(data);
            loginMode = 'weixin';
            clearInterval(_this.detectionRequest);
            _this.hintEl = _this.showHint({
              msg: '登录中...',
              type: 'loading',
              duration: Infinity
            });
            return _this.setStorageData(data, loginMode);
          };
        })(this)
      });
    };

    Login.prototype.generateQRCode = function() {
      var target;
      target = $('.fixedToolbar .qrcode .wrap');
      return setTimeout(function() {
        return target.qrcode({
          text: "" + window.appdownload,
          render: 'div',
          ecLevel: 'H',
          size: 168,
          minVersion: 8,
          background: '#fff'
        });
      }, 250);
    };

    Login.prototype.nec = function() {
      var height, nec, opts;
      height = "46px";
      nec = {};
      opts = {
        'element': 'slide',
        'captchaId': getCaptchaId(),
        'width': '302',
        'verifyCallback': (function(_this) {
          return function(ret) {
            if (ret['value']) {
              _this._BtnTrue = true;
              _this.checkValid();
              nec.btnFg.find('span').css({
                'backgroundPosition': '-168px -37px'
              });
            } else {
              nec.btnFg.find('span').css({
                'backgroundPosition': '-236px -37px'
              });
              setTimeout(function() {
                return nec.btnFg.find('span').css({
                  'backgroundPosition': ' -100px -37px'
                });
              }, 1000);
            }
          };
        })(this),
        'initCallback': (function(_this) {
          return function() {
            var btn;
            btn = '<span class="icon" style="width: 58px;height: 37px; background-position: -100px -37px; display: block;"></span>';
            nec.bgWrap = _this.els.slideWrap.find('.ncpt_widget');
            nec.bg = _this.els.slideWrap.find('.ncpt_slide_bg');
            nec.text = _this.els.slideWrap.find('.ncpt_hint_txt');
            nec.btnFg = _this.els.slideWrap.find('.ncpt_slide_fg');
            nec.btnFgImg = nec.btnFg.find('img');
            nec.imgBg = _this.els.slideWrap.find('.ncpt_puzzle_bg');
            nec.imgfG = _this.els.slideWrap.find('.ncpt_puzzle_fg');
            nec.iframe = _this.els.slideWrap.find('.ncpt_win_iframe');
            nec.bg.css({
              height: height,
              borderRadius: '50px'
            });
            nec.bgWrap.css({
              height: height
            });
            nec.text.addClass('text').css({
              height: height,
              lineHeight: height
            });
            nec.btnFg.css({
              top: '5px',
              padding: '0 4px'
            }).append(btn);
            nec.btnFgImg.css('display', 'none');
            nec.bg.on('mouseover', function() {
              nec.imgBg.css({
                top: '-50px'
              });
              nec.imgfG.css({
                top: '-50px'
              });
              return nec.iframe.css({
                width: 0,
                height: 0
              });
            });
            return _this.textSlide(nec.text);
          };
        })(this)
      };
      return this.ins = new NECaptcha(opts);
    };

    return Login;

  })();

  $.fn.extend({

    /*
    	  * 设置光标选中文本
    	  * @param selectionStart [Number] 开始下标
    	  * @param selectionEnd [Number] 结束下标
     */
    setSelection: function(selectionStart, selectionEnd) {
      var input, range;
      if (this.lengh === 0) {
        return this;
      }
      input = this[0];
      if (!selectionEnd) {
        selectionEnd = this.val().length;
      }
      if (input.createTextRange) {
        range = input.createTextRange();
        range.collapse(true);
        range.moveEnd('character', selectionEnd);
        range.moveStart('character', selectionStart);
        range.select();
      } else if (input.setSelectionRange) {
        input.focus();
        input.setSelectionRange(selectionStart, selectionEnd);
      }
      return this;
    }
  });

  new Login();

  return;

}).call(this);
