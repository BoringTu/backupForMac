(function() {
  define(['jquery', 'backbone', 'utils', 'moment', 'jcookie', 'datetimepicker', 'swipe', 'select2'], function($, Backbone, Utils, moment) {
    "use strict";
    var Common;
    Common = (function() {
      function Common() {}

      Common.initialize = function() {
        var temp;
        window.moment = moment;
        this.datetimepickerInit();
        this.select2Init();
        $.cookie.defaults.expires = 7;
        $.cookie.defaults.domain = CSH.path.domain;
        this.bbInit();
        this.otherInit();
        CSH.utils = new Utils();
        temp = $('body > [name="token"]');
        CSH.token = temp.val();
        temp.remove();
      };

      Common.datetimepickerInit = function() {
        var zh_cn;
        zh_cn = moment.defineLocale('zh-cn', {
          months: '一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月'.split('_'),
          monthsShort: '1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月'.split('_'),
          weekdays: '星期日_星期一_星期二_星期三_星期四_星期五_星期六'.split('_'),
          weekdaysShort: '周日_周一_周二_周三_周四_周五_周六'.split('_'),
          weekdaysMin: '日_一_二_三_四_五_六'.split('_'),
          longDateFormat: {
            LT: 'Ah点mm分',
            LTS: 'Ah点m分s秒',
            L: 'YYYY-MM-DD',
            LL: 'YYYY年MMMD日',
            LLL: 'YYYY年MMMD日Ah点mm分',
            LLLL: 'YYYY年MMMD日ddddAh点mm分',
            l: 'YYYY-MM-DD',
            ll: 'YYYY年MMMD日',
            lll: 'YYYY年MMMD日Ah点mm分',
            llll: 'YYYY年MMMD日ddddAh点mm分'
          },
          meridiemParse: /凌晨|早上|上午|中午|下午|晚上/,
          meridiemHour: function(hour, meridiem) {
            if (hour === 12) {
              hour = 0;
            }
            if (meridiem === '凌晨' || meridiem === '早上' || meridiem === '上午') {
              return hour;
            } else if (meridiem === '下午' || meridiem === '晚上') {
              return hour + 12;
            } else {
              if (hour >= 11) {
                return hour;
              } else {
                return hour + 12;
              }
            }
          },
          meridiem: function(hour, minute, isLower) {
            var hm;
            hm = hour * 100 + minute;
            if (hm < 600) {
              return '凌晨';
            } else if (hm < 900) {
              return '早上';
            } else if (hm < 1130) {
              return '上午';
            } else if (hm < 1230) {
              return '中午';
            } else if (hm < 1800) {
              return '下午';
            } else {
              return '晚上';
            }
          },
          calendar: {
            sameDay: function() {
              if (this.minutes() === 0) {
                return '[今天]Ah[点整]';
              } else {
                return '[今天]LT';
              }
            },
            nextDay: function() {
              if (this.minutes() === 0) {
                return '[明天]Ah[点整]';
              } else {
                return '[明天]LT';
              }
            },
            lastDay: function() {
              if (this.minutes() === 0) {
                return '[昨天]Ah[点整]';
              } else {
                return '[昨天]LT';
              }
            },
            nextWeek: function() {
              var prefix, startOfWeek;
              startOfWeek = moment().startOf('week');
              prefix = this.diff(startOfWeek, 'days') >= 7 ? '[下]' : '[本]';
              if (this.minutes() === 0) {
                return prefix + 'dddAh点整';
              } else {
                return prefix + 'dddAh点mm';
              }
            },
            lastWeek: function() {
              var prefix, startOfWeek;
              startOfWeek = moment().startOf('week');
              prefix = this.unix() < startOfWeek.unix() ? '[上]' : '[本]';
              if (this.minutes() === 0) {
                return prefix + 'dddAh点整';
              } else {
                return prefix + 'dddAh点mm';
              }
            },
            sameElse: 'LL'
          },
          ordinalParse: /\d{1,2}(日|月|周)/,
          ordinal: function(number, period) {
            switch (period) {
              case 'd':
              case 'D':
              case 'DDD':
                return number + '日';
              case 'M':
                return number + '月';
              case 'w':
              case 'W':
                return number + '周';
              default:
                return number;
            }
          },
          relativeTime: {
            future: '%s内',
            past: '%s前',
            s: '几秒',
            m: '1 分钟',
            mm: '%d 分钟',
            h: '1 小时',
            hh: '%d 小时',
            d: '1 天',
            dd: '%d 天',
            M: '1 个月',
            MM: '%d 个月',
            y: '1 年',
            yy: '%d 年'
          },
          week: {
            dow: 1,
            doy: 4
          }
        });
        $.fn.datetimepicker.defaults.format = 'YYYY-MM-DD HH:mm';
        $.fn.datetimepicker.defaults.locale = 'zh-cn';
        $.fn.datetimepicker.defaults.stepping = 1;
        $.fn.datetimepicker.defaults.useCurrent = false;
        $.fn.datetimepicker.defaults.ignoreReadonly = true;
        $.fn.datetimepicker.defaults.showClear = true;
        $.fn.datetimepicker.defaults.sideBySide = false;
        return $.fn.datetimepicker.defaults.dayViewHeaderFormat = 'YYYY MMMM';
      };

      Common.select2Init = function() {
        $.fn.select2.defaults.defaults.minimumResultsForSearch = Infinity;
        $.fn.select2.amd.define("select2/i18n/zh-CN", [], function() {
          return {
            errorLoading: function() {
              return "无法载入结果。";
            },
            inputTooLong: function(e) {
              var n, t;
              t = e.input.length - e.maximum;
              n = "请删除" + t + "个字符";
              return n;
            },
            inputTooShort: function(e) {
              var n, t;
              t = e.minimum - e.input.length;
              n = "请再输入至少" + t + "个字符";
              return n;
            },
            loadingMore: function() {
              return "载入更多结果…";
            },
            maximumSelected: function(e) {
              var t;
              t = "最多只能选择" + e.maximum + "个项目";
              return t;
            },
            noResults: function() {
              return "未找到结果";
            },
            searching: function() {
              return "搜索中…";
            }
          };
        });
      };

      Common.bbInit = function() {
        var _setUrl, goToLoginPage, sync;
        Backbone.ajax = function(request) {
          request.xhrFields = {
            'withCredentials': true
          };
          return Backbone.$.ajax.apply(Backbone.$, arguments);
        };
        _setUrl = function() {
          var i, len, list, param;
          if (!this.originUrl) {
            console.error('针对非规范api的模型，需要注册originUrl');
          }
          this.url = CSH.path.origin + this.originUrl;
          list = [].slice.apply(arguments);
          for (i = 0, len = list.length; i < len; i++) {
            param = list[i];
            this.url += "/" + param;
          }
          return this;
        };
        Backbone.Model.prototype.setUrl = _setUrl;
        Backbone.Collection.prototype.setUrl = _setUrl;
        goToLoginPage = function() {
          return location.href = location.origin + '/login.html';
        };
        sync = Backbone.sync;
        Backbone.sync = function(method, model, options) {
          var beforeSend, dataFilter, error, success;
          options || (options = {});
          beforeSend = options.beforeSend;
          options.beforeSend = function(xhr) {
            CSH.xhrPool.push(xhr);
            beforeSend && beforeSend.apply(this, arguments);
          };
          dataFilter = options.dataFilter;
          options.dataFilter = function(data) {
            var msg, ref, temp;
            temp = JSON.parse(data);
            if (temp && ((ref = +temp.code) === 403 || ref === 405 || ref === (-5)) && !CSH.$els.body.find('> .modal-authority-login')[0]) {
              msg = temp.message;
              CSH.alert({
                content: msg,
                className: 'modal-authority-login',
                ok: {
                  text: '点击前往登录页'
                }
              }).on('hidden', goToLoginPage);
              return '{}';
            }
            if (+(temp != null ? temp.code : void 0) !== 0) {
              console.warn(temp != null ? temp.message : void 0);
            }
            temp = JSON.stringify(temp);
            if (dataFilter) {
              return dataFilter.call(this, data);
            } else {
              return data;
            }
          };
          success = options.success;
          options.success = function() {
            var ref, temp, xhr;
            xhr = arguments[2];
            temp = JSON.parse(xhr.responseText);
            if (temp && ((ref = +temp.code) === 403 || ref === 405 || ref === (-5))) {
              return;
            }
            if (success) {
              return success.apply(this, arguments);
            }
          };
          error = options.error;
          options.error = function() {
            var textStatus;
            textStatus = arguments[1];
            if (error) {
              return error.apply(this, arguments);
            }
          };
          sync.apply(this, arguments);
        };
      };

      Common.otherInit = function() {
        $('body').on('click', 'button.checkbox, button.radio', function(event) {
          var b, el, tar;
          el = $(event.currentTarget);
          b = !el.hasClass('checked');
          if (!b && el.hasClass('radio')) {
            return;
          }
          tar = el.find('input');
          tar.prop({
            checked: b
          });
          tar.trigger('change');
        }).on('change', 'button.checkbox input, button.radio input', function(event) {
          var btn, el, isChecked, isRadio;
          el = $(event.currentTarget);
          btn = el.closest('button');
          isChecked = el[0].checked;
          isRadio = btn.is('.radio');
          btn[isChecked ? 'addClass' : 'removeClass']('checked');
          if (isRadio) {
            $("input[type=\"radio\"][name=\"" + (el.attr('name')) + "\"]").not(el).closest('button.radio').removeClass('checked');
          }
        });
      };

      Common.setCrossDomain = function() {
        var proxiedSync;
        proxiedSync = Backbone.sync;
        Backbone.sync = function(method, model, options) {
          options || (options = {});
          if (!options.crossDomain) {
            options.crossDomain = true;
          }
          if (!options.xhrFields) {
            options.xhrFields = {
              withCredentials: true
            };
          }
          return proxiedSync(method, model, options);
        };
      };

      return Common;

    })();
    return Common;
  });

}).call(this);
