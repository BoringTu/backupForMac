(function() {
  "use strict";
  require.config({
    paths: {
      'jquery': '../../assets/jquery.min',
      'base64': '../../assets/base64.min',
      'md5': '../../assets/md5.min',
      'qrcode': '../../assets/jquery.qrcode.min',
      'underscore': '../../assets/underscore.min',
      'backbone': '../../assets/backbone.min',
      'doT': '../../assets/doT.min',
      'text': '../../assets/text.min',
      'jcookie': '../../assets/jquery.cookie.min',
      'highcharts': '../../assets/highcharts.min',
      'select2': '../../assets/select2/select2.min',
      'moment': '../../assets/moment.min',
      'datetimepicker': '../../assets/datetimepicker/js/bootstrap-datetimepicker.min',
      'swipe': '../../assets/swipe.min',
      'clipboard': '../../assets/clipboard.min'
    },
    shim: {
      'backbone': {
        deps: ['jquery', 'underscore'],
        exports: 'backbone'
      },
      'jcookie': {
        deps: ['jquery'],
        exports: 'jcookie'
      },
      'qrcode': {
        deps: ['jquery'],
        exports: 'qrcode'
      },
      'swipe': {
        deps: ['jquery'],
        exports: 'swipe'
      }
    }
  });

  require(['jquery', 'base64', 'md5', 'qrcode', 'underscore', 'backbone', 'doT', 'text', 'jcookie', 'highcharts', 'select2', 'moment', 'datetimepicker', 'swipe', 'clipboard', 'CSH', 'common', 'router-default']);

}).call(this);
