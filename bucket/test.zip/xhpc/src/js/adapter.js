
/*
  * 适配器
  * 用于每个页面加载自己的Router
 */

(function() {
  var env, frameName, pageName;

  env = (function() {
    var b;
    b = +localStorage.getItem('isLocal');
    if (b) {
      return 'src';
    } else {
      return 'dist';
    }
  })();

  pageName = location.pathname.replace(/(^\/)|(\.html.*$)/g, '');

  frameName = window.frameName || 'default';

  require.config({
    baseUrl: env + "/js",
    urlArgs: "_=" + window.cacheCode,
    waitSeconds: 0
  });

  require([frameName + "-main"], function() {
    var appName;
    appName = "app-" + frameName + "-" + pageName;
    if (frameName !== 'default' && pageName === 'index') {
      appName += "-" + CSH.fix;
    }
    return require([appName]);
  });

}).call(this);
