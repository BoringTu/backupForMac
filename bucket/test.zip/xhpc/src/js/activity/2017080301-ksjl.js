(function() {
  "use strict";
  var Active, domain,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  domain = location.hostname.replace(/^\w+\./, '');

  Active = (function() {
    function Active() {
      this.eventColse = bind(this.eventColse, this);
      this.eventAgentBtn = bind(this.eventAgentBtn, this);
      this.eventLinkparentBtn = bind(this.eventLinkparentBtn, this);
      this.eventdetailedListBtn = bind(this.eventdetailedListBtn, this);
      this.eventGoBack = bind(this.eventGoBack, this);
      this.loginStatus = bind(this.loginStatus, this);
      this.render = bind(this.render, this);
      this.host = (function() {
        var arr, i, isLocal, k, kv, len, tmp;
        isLocal = 0;
        arr = location.search.slice(1).split('&');
        for (i = 0, len = arr.length; i < len; i++) {
          kv = arr[i];
          tmp = kv.split('=');
          k = tmp[0];
          if (k === 'test') {
            isLocal = 1;
            break;
          }
        }
        if (isLocal) {
          return location.protocol + "//appapi." + domain;
        } else {
          return location.origin + '/api';
        }
      })();
      this.loginStatus();
      this.render();
    }

    Active.prototype.render = function() {
      this.els = {};
      this.els.moreActivities = $('.moreActivities');
      this.els.mbDownload = $('.mbDownload');
      this.els.xhlogo = $('.xhlogo');
      this.els.container = $('.container');
      this.els.detailedListBtn = this.els.container.find('.detailedListBtn');
      this.els.agentBtn = this.els.container.find('.agentBtn');
      this.els.mask = this.els.container.find('.mask');
      this.els.dialogBox1 = $('.Box1');
      this.els.dialogBox2 = $('.Box2');
      this.els.colse = $('.dialog').find('.colse');
      this.els.linkParentBtn = this.els.dialogBox1.find('.btn');
      this.els.linkParentBtnTwo = this.els.dialogBox2.find('.btn');
      this.els.detailedListBtn.on('click', (function(_this) {
        return function(event) {
          return _this.eventdetailedListBtn(event);
        };
      })(this));
      this.els.colse.on('click', (function(_this) {
        return function(event) {
          return _this.eventColse(event);
        };
      })(this));
      this.els.linkParentBtn.on('click', (function(_this) {
        return function(event) {
          return _this.eventLinkparentBtn(event);
        };
      })(this));
      this.els.agentBtn.on('click', (function(_this) {
        return function(event) {
          return _this.eventAgentBtn(event);
        };
      })(this));
      return this.els.linkParentBtnTwo.on('click', (function(_this) {
        return function(event) {
          return _this.eventLinkparentBtn(event);
        };
      })(this));
    };

    Active.prototype.loginStatus = function(pageInfo) {
      if (pageInfo == null) {
        pageInfo = 1;
      }
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + pageInfo + "/" + 20.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var pathname, ref;
            data = data.toJSON();
            if ((ref = +data.code) === 2 || ref === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
            }
            return '{}';
          };
        })(this)
      });
    };

    Active.prototype.eventGoBack = function() {
      return history.back();
    };

    Active.prototype.eventdetailedListBtn = function(event) {
      var el, userType;
      el = $(event.currentTarget);
      userType = localStorage.getItem('userType');
      if (+userType === 1) {
        this.els.mask.css({
          'visibility': 'visible',
          'opacity': '0.6'
        });
        this.els.dialogBox1.css({
          'visibility': 'visible',
          'opacity': '1'
        });
        return;
      }
      return el.attr('href', '/index.html#userCenter/property');
    };

    Active.prototype.eventLinkparentBtn = function(event) {
      var el;
      el = $(event.currentTarget);
      return el.attr('href', '/index.html#userCenter/message');
    };

    Active.prototype.eventAgentBtn = function(event) {
      var el;
      el = $(event.currentTarget);
      this.els.mask.css({
        'visibility': 'visible',
        'opacity': '0.6'
      });
      return this.els.dialogBox2.css({
        'visibility': 'visible',
        'opacity': '1'
      });
    };

    Active.prototype.eventColse = function(event) {
      var el;
      el = $(event.currentTarget);
      el.parent('.dialog').css({
        'visibility': 'hidden',
        'opacity': '0'
      });
      return this.els.mask.css({
        'visibility': 'hidden',
        'opacity': '0'
      });
    };

    return Active;

  })();

  new Active();

}).call(this);
