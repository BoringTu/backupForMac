(function() {
  "use strict";
  var Active, domain,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  domain = location.hostname.replace(/^\w+\./, '');

  Active = (function() {
    function Active() {
      this.countDownTimer = bind(this.countDownTimer, this);
      this.timerData = bind(this.timerData, this);
      this.eventRankingBtns = bind(this.eventRankingBtns, this);
      this.eventTab = bind(this.eventTab, this);
      this.rener = bind(this.rener, this);
      this.host = (function() {
        var arr, i, isLocal, k, kv, len, tmp;
        isLocal = 0;
        arr = location.search.slice(1).split('&');
        for (i = 0, len = arr.length; i < len; i++) {
          kv = arr[i];
          tmp = kv.split('=');
          k = tmp[0];
          if (k === 'test') {
            isLocal = 1;
            break;
          }
        }
        if (isLocal) {
          return location.protocol + "//appapi." + domain;
        } else {
          return location.origin + '/api';
        }
      })();
      this.rener();
    }

    Active.prototype.rener = function() {
      this.els = {};
      this.els.logo = $('header img');
      this.els.container = $('.container');
      this.els.tab = this.els.container.find('.tab li');
      this.els.activitys = this.els.container.find('.activitys');
      this.els.ranking = this.els.activitys.find('.ranking');
      this.els.rankingNum = this.els.ranking.find('.rankingNum span');
      this.els.rankingDate = this.els.ranking.find('.rankingDate span');
      this.els.rankingBtn = this.els.ranking.find('.rankingDate button');
      this.els.rankingDataWrap = this.els.ranking.find('.rankingData');
      this.els.tableBody = this.els.ranking.find('.table2 tbody');
      this.els.rankingBtns = this.els.ranking.find('.rankingBtn button');
      this.els.rankingBtns.on('click', (function(_this) {
        return function(event) {
          return _this.eventRankingBtns(event);
        };
      })(this));
      this.els.tab.on('click', (function(_this) {
        return function(event) {
          return _this.eventTab(event);
        };
      })(this));

      /*
      		@timer	= null
      		@els.rankingBtn.on 'click', => @countDownTimer()
      			.trigger 'click'
      		 * 一切的开始
       */
      this.els.tab.eq(0).trigger('click');
      this.myRanking();
      return this.timerData(1);

      /*
      		@els.rankingBtns.map ( index, current) =>
      			el	= $ current
      			if +@data.pageInfo.pageCount < index + 1
      				el.addClass 'disable'
      		 * 配合后台 在获取一次数据。 用搜索的形式拿到当前排名
       */
    };

    Active.prototype.eventTab = function(event) {
      var content, el;
      el = $(event.currentTarget);
      content = el.attr('data-content');
      this.els.tab.removeClass();
      el.addClass('active');
      if ('bwpms' === el.attr('data-content')) {
        this.els.rankingBtns.eq(0).trigger('click');
      }
      return this.els.activitys.hide().filter("[data-content=\"" + content + "\"]").show();
    };

    Active.prototype.eventRankingBtns = function(event) {
      var el;
      el = $(event.currentTarget);
      this.timerData(el.index() + 1);
      this.els.rankingBtns.removeClass('active');
      return el.addClass('active');
    };

    Active.prototype.timerData = function(pageInfo, async) {
      var data, ref, ref1, ref2, trs;
      if (pageInfo == null) {
        pageInfo = 1;
      }
      if (async == null) {
        async = true;
      }
      this.data = data = window.userList[pageInfo - 1];
      if ((ref = this.els) != null) {
        ref.tableBody.text('');
      }
      trs = '';
      data.map((function(_this) {
        return function(current, index) {
          var tr;
          tr = "<tr>\n	<td>" + current.orderNum + "</td>\n	<td>" + current.userName + "</td>\n	<td>" + current.trueName + "</td>\n	<td>" + current.winLoseMoney + "</td>\n</tr>";
          return trs += tr;
        };
      })(this));
      if ((ref1 = this.target) != null) {
        ref1.remove();
      }
      if ((ref2 = this.els) != null) {
        ref2.tableBody.append(trs);
      }
      return;
      if (async) {
        this.showHint();
      }
      this.myRanking();
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + pageInfo + "/" + 20.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        async: async,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var isTrue, pathname, ref3;
            data = data.toJSON();
            if ((ref3 = +data.code) === 403 || ref3 === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
              return '{}';
            }
            isTrue = false;
            _this.data = data;
            if (_this.els) {
              _this.els.tableBody.text('');
            }
            trs = '';
            data.data.map(function(current, index) {
              var tr;
              tr = "<tr>\n	<td>" + current.orderNum + "</td>\n	<td>" + current.userName + "</td>\n	<td>" + current.trueName + "</td>\n	<td>" + current.winLoseMoney + "</td>\n</tr>";
              return trs += tr;
            });
            if (_this.target) {
              _this.target.remove();
            }
            if (_this.els) {
              _this.els.tableBody.append($(trs));
            }
            return '{}';
          };
        })(this)
      });
    };

    Active.prototype.countDownTimer = function(date) {
      if (date == null) {
        date = 121;
      }
      clearInterval(this.timer);
      return this.timer = setInterval((function(_this) {
        return function() {
          date--;
          _this.els.rankingDate.text(date + "秒");
          if (date === 0) {
            date = 121;
          }
          if (date === 120) {
            return _this.els.rankingBtns.filter('.active').trigger('click');
          }
        };
      })(this), 1000);
    };

    Active.prototype.showHint = function(msg) {
      var speed;
      if (this.target) {
        this.target.remove();
      }
      speed = 200;
      this.target = $("<div class=\"hint\">\n	<p class=\"loading\">\n		<span></span>\n		<span></span>\n		<span></span>\n		<span></span>\n		<span></span>\n	</p>\n</div>");
      return this.target.appendTo(this.els.rankingDataWrap).css({
        marginTop: '-30',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      });
    };

    Active.prototype.myRanking = function() {
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + 1. + "/" + 1.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        data: JSON.stringify({
          userName: localStorage.getItem('username')
        }),
        dataFilter: (function(_this) {
          return function(data) {
            var pathname, ref;
            data = data.toJSON();
            if ((ref = +data.code) === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
              return '{}';
            }
            _this.els.rankingNum.text(data.data.length ? data.data[0].orderNum + "名" : '未上榜');
            return '{}';
          };
        })(this)
      });
    };

    return Active;

  })();

  new Active();

}).call(this);
