(function() {
  "use strict";
  var Active, domain,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  domain = location.hostname.replace(/^\w+\./, '');

  Active = (function() {
    function Active() {
      this.loading = bind(this.loading, this);
      this.loginDetection = bind(this.loginDetection, this);
      this.host = (function() {
        var arr, isLocal, j, k, kv, len, tmp;
        isLocal = 0;
        arr = location.search.slice(1).split('&');
        for (j = 0, len = arr.length; j < len; j++) {
          kv = arr[j];
          tmp = kv.split('=');
          k = tmp[0];
          if (k === 'test') {
            isLocal = 1;
            break;
          }
        }
        if (isLocal) {
          return location.protocol + "//appapi." + domain;
        } else {
          return location.origin + '/api';
        }
      })();
      this.loginDetection();
      this.img = $('img');
      this.loading();
    }

    Active.prototype.loginDetection = function(pageInfo) {
      if (pageInfo == null) {
        pageInfo = 1;
      }
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + pageInfo + "/" + 20.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var pathname, ref;
            data = data.toJSON();
            if ((ref = +data.code) === 2 || ref === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
              return '{}';
            }
            return '{}';
          };
        })(this)
      });
    };

    Active.prototype.loading = function() {
      var all, bg1, i, img, spinner;
      bg1 = $('#bg1');
      bg1.attr('src', '/images/activity/2017092901-df10yhd/df1.jpg');
      spinner = $('.spinner');
      img = bg1.nextAll('img');
      i = 0;
      all = img.length - 1;
      return bg1.load(function() {
        spinner.remove();
        return img.map((function(_this) {
          return function(index, ev) {
            return $(ev).load(function() {
              index++;
              console.log(index);
              if (i === all) {
                return console.log(1);
              }
            });
          };
        })(this));
      });
    };

    return Active;

  })();

  new Active;

}).call(this);
