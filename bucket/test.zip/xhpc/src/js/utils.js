(function() {
  var hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; },
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  define(['jquery', 'doT', 'md5', 'text!../templates/_alert.tpl', 'text!../templates/_scoreboard.tpl', 'base64'], function($, doT, md5, TplAlert, TplScoreboard) {
    "use strict";
    var Queue, Scoreboard, Stack, Utils, ieMode, isIE, isIE6, isIE7, isIE8, isIE9;
    ieMode = document.documentMode;
    isIE = !!window.ActiveXObject;
    isIE6 = isIE && !window.XMLHttpRequest;
    isIE7 = isIE && !isIE6 && !ieMode || ieMode === 7;
    isIE8 = isIE && ieMode === 8;
    isIE9 = isIE && ieMode === 9;
    Utils = (function() {
      var _firstDayOfMonth, _formatDate, _lastDayOfMonth;

      function Utils() {}


      /*
      		  * 拷贝对象（针对解析多维数据成一维数据给Backbone.Collection）
      		  * @param obj [Object] 必填。将要拷贝的对象
       */

      Utils.prototype.copy = function(obj) {
        var o, re, val;
        re = {};
        for (o in obj) {
          if (!hasProp.call(obj, o)) continue;
          val = obj[o];
          if (o === 'children') {
            continue;
          }
          re[o] = val;
        }
        return re;
      };


      /*
      		  * 深度 clone 对象
      		  * @param obj [Object] 必填。将要 clone 的对象
       */

      Utils.prototype.clone = function(obj) {
        var o, re, val;
        if (!(typeof obj === 'object' && (obj != null))) {
          return obj;
        }
        if (obj instanceof Date) {
          re = new Date();
          re.setTime(obj.getTime());
          return re;
        }
        re = obj instanceof Array ? [] : {};
        for (o in obj) {
          if (!hasProp.call(obj, o)) continue;
          val = obj[o];
          if (typeof val === 'object') {
            re[o] = this.clone(val);
          } else {
            re[o] = val;
          }
        }
        return re;
      };

      Utils.prototype.getRoutePath = function() {
        return location.hash.replace(/^#/, '');
      };

      Utils.prototype.getRouteName = function() {
        var i, s;
        s = this.getRoutePath();
        i = s.indexOf('\/');
        if (i === -1) {
          return s;
        } else {
          return s.substr(0, i);
        }
      };


      /*
      		  * 格式化金额
      		  * @param money [string/Number] 待精确的金额
      		  * @param precision [int] 小数点后精确位数 默认：4
      		  * e.g.: 1234567.89	=>	1,234,567.8900
       */

      Utils.prototype.formatMoney = function(money, precision) {
        var decimal, formatRound, i, round, temp;
        if (precision == null) {
          precision = 4;
        }
        formatRound = function(money) {
          return ("" + money).replace(/(\d+?)(?=(?:\d{3})+$)/g, '$1,');
        };
        money = money + '';
        temp = money.split('.');
        round = +temp[0];
        round = formatRound(round);
        if (!precision) {
          return round;
        }
        decimal = '' + Math.round(("." + (temp[1] || 0)) * Math.pow(10, precision));
        return (formatRound(round)) + "." + (((function() {
          var j, ref, results;
          results = [];
          for (i = j = 0, ref = precision - decimal.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
            results.push('0');
          }
          return results;
        })()).join('')) + decimal;
      };


      /*
      		  * 获得指定日期规范格式<yyyy-MM-dd>的字符串数组
      		  * @param param [Object] 选填。JSON对象。
      		  * @param param - date [Date/String] 选填。欲格式化的Date/String类型的数据。如为空，则返回当前日期。
      		  * @param param - forward [Number] 选填。提前的天数。支持0和负整数。如果调用时带有此参数，将返回一个包含两个元素的数组，第一个日期早于第二个日期。
       */

      Utils.prototype.getDate = function(param) {
        var af_day, be_day, date;
        if (!param) {
          return;
        }
        date = param['date'] || new Date();
        if (typeof date === 'string') {
          date = new Date(date);
        }
        if (/^-?\d+$/.test(param['forward'])) {
          af_day = date.getTime();
          be_day = af_day - param['forward'] * 24 * 60 * 60 * 1000;
          af_day = date.getFormatDate(new Date(af_day));
          be_day = date.getFormatDate(new Date(be_day));
          return [be_day, af_day];
        }
      };


      /*
      		  * 注释实现多行文本拼接 -- 参考文献：http://www.ghugo.com/function-multiline-text-in-comments/
      		  * @param fn [Function] 必填。一个匿名函数，函数体是一个块注释。(注意：需要带上!@preserve)（用法详见参考文献）
       */

      Utils.prototype.multiline = function(fn) {
        var match, reCommentContents;
        reCommentContents = /\/\*!?(?:\@preserve)?[ \t]*(?:\r\n|\n)([\s\S]*?)(?:\r\n|\n)[ \t]*\*\//;
        match = reCommentContents.exec(fn.toString());
        if (!match) {
          throw new TypeError('Multiline comment missing.');
        }
        return match[1];
      };


      /*
      		  * 包装过的 Audio
       */

      Utils.prototype.Audio = function(filepath) {
        var obj;
        obj = new Audio(filepath);
        this.play = function() {
          if (CSH.isMute) {
            return this;
          }
          CSH.views.body.soundAlert();
          obj.currentTime = 0;
          obj.play();
          return this;
        };
        this.stop = function() {
          obj.pause();
          return this;
        };
        this.remove = function() {
          return obj.remove();
        };
        this.audio = obj;
        return this;
      };


      /*
      		  * 获得指定日期、时间规范格式<yyyy-MM-dd>|<HH:mm:ss>|<yyyy-MM-dd HH:mm:ss>的字符串
      		  * @param param [Object] 选填。JSON对象。
      		  * @param param - date [Date] 选填。欲格式化的Date类型的数据。如为空，则默认当前日期。
      		  * @param param - hasDate [Boolean] 选填。返回的规范化字符串带有“日期”。
      		  * @param param - hasTime [Boolean] 选填。返回的规范化字符串带有“时间”。
      		  * @param param - forward [Number] 选填。提前的天数。支持0和负整数。如果调用时带有此参数，将返回一个包含两个元素的数组，第一个日期早于第二个日期。
      		  * 注：此函数是用来追加到Date prototype的，不能直接调用。
       */

      _formatDate = function(param) {
        var H, M, d, date, hD, hT, m, rD, rT, re, s, y;
        date = param['date'] || this;
        y = date.getFullYear();
        M = date.getMonth() + 1;
        M = (M + '').length > 1 ? M : '0' + M;
        d = date.getDate();
        d = (d + '').length > 1 ? d : '0' + d;
        H = date.getHours();
        H = (H + '').length > 1 ? H : '0' + H;
        m = date.getMinutes();
        m = (m + '').length > 1 ? m : '0' + m;
        s = date.getSeconds();
        s = (s + '').length > 1 ? s : '0' + s;
        hD = param.hasDate;
        hT = param.hasTime;
        rD = hD ? y + '-' + M + '-' + d : '';
        rT = hT ? H + ':' + m + ':' + s : '';
        re = "" + rD + (hD && hT ? ' ' : '') + rT;
        date = void 0;
        return re;
      };


      /*
      		  * 获得指定月份第一天的规范格式<yyyy-MM-dd>的字符串
      		  * @param date [Date/String] 必填。指定月份的Date对象或可以转换成Date对象的字符串
       */

      _firstDayOfMonth = function(date) {
        if (typeof date === 'string') {
          date = new Date(date);
        }
        return new Date(date.setDate(1));
      };


      /*
      		  * 获得指定月份最后一天的规范格式<yyyy-MM-dd>的字符串
      		  * @param date [Date/String] 必填。指定月份的Date对象或可以转换成Date对象的字符串
       */

      _lastDayOfMonth = function(date) {
        var re;
        if (typeof date === 'string') {
          date = new Date(date);
        }
        date = new Date(date.setDate(1));
        re = date.setMonth(date.getMonth() + 1) - 1 * 24 * 60 * 60 * 1000;
        return new Date(re);
      };


      /*
      		  * 获取格式化日期：2000-01-01
       */

      Date.prototype.getFormatDate = function(date) {
        if (date == null) {
          date = this;
        }
        return _formatDate.call(this, {
          date: date,
          hasDate: 1
        });
      };


      /*
      		  * 获取格式化时间：00:00:00
       */

      Date.prototype.getFormatTime = function(date) {
        if (date == null) {
          date = this;
        }
        return _formatDate.call(this, {
          date: date,
          hasTime: 1
        });
      };


      /*
      		  * 获取格式化日期+时间：2000-01-01 00:00:00
       */

      Date.prototype.getFormatDateAndTime = function(date) {
        if (date == null) {
          date = this;
        }
        return _formatDate.call(this, {
          date: date,
          hasDate: 1,
          hasTime: 1
        });
      };


      /*
      		  * 获取指定月份第一天的格式化日期：2000-01-01
      		  * @param date [Date/String]
       */

      Date.prototype.firstDayOfMonth = function(date) {
        if (date == null) {
          date = this;
        }
        return _firstDayOfMonth.call(this, date);
      };


      /*
      		  * 获取指定月份最后一天的格式化日期：2000-01-31
      		  * @param date [Date/String]
       */

      Date.prototype.lastDayOfMonth = function(date) {
        if (date == null) {
          date = this;
        }
        return _lastDayOfMonth.call(this, date);
      };


      /*
      		  * 获取 n 天前的日期（n 可为负）
       */

      Date.prototype.beforeDays = function(n, date) {
        if (date == null) {
          date = this;
        }
        return new Date(date.getTime() - n * 1000 * 60 * 60 * 24);
      };


      /*
      		  * 获取 n 天后的日期（n 可为负）
       */

      Date.prototype.afterDays = function(n, date) {
        if (date == null) {
          date = this;
        }
        return new Date(date.getTime() + n * 1000 * 60 * 60 * 24);
      };


      /*
      		  * 获取 n 个月前的日期（n 可为负）
       */

      Date.prototype.beforeMonths = function(n, date) {
        if (date == null) {
          date = this;
        }
        return new Date(date.setMonth(date.getMonth() - n));
      };


      /*
      		  * 获取 n 天后的日期（n 可为负）
       */

      Date.prototype.afterMonths = function(n, date) {
        if (date == null) {
          date = this;
        }
        return new Date(date.setMonth(date.getMonth() + n));
      };


      /*
      		  * 去空格 - 前后空格都去掉
       */

      String.prototype.trim = function() {
        return this.replace(/(^\s*)|(\s*$)/g, '');
      };


      /*
      		  * 去空格 - 去前面的空格
       */

      String.prototype.trimPre = function() {
        return this.replace(/(^\s*)/g, '');
      };


      /*
      		  * 去空格 - 去后面的空格
       */

      String.prototype.trimSuf = function() {
        return this.replace(/(\s*$)/g, '');
      };


      /*
      		  * 处理JSON库
       */

      String.prototype.toJSON = function() {
        return JSON.parse(this);
      };


      /*
      		  * 将 $、<、>、"、'，与 / 转义成 HTML 字符
       */

      String.prototype.encodeHTML = function(onlyEncodeScript) {
        var encodeHTMLRules, matchHTML, str;
        if (!this) {
          return this;
        }
        encodeHTMLRules = {
          "&": "&#38;",
          "<": "&#60;",
          ">": "&#62;",
          '"': '&#34;',
          "'": '&#39;',
          "/": '&#47;'
        };
        if (onlyEncodeScript) {
          matchHTML = /<\/?\s*(script|iframe)[\s\S]*?>/gi;
          str = this.replace(matchHTML, function(m) {
            var s;
            switch (true) {
              case /script/i.test(m):
                s = 'script';
                break;
              case /iframe/i.test(m):
                s = 'iframe';
                break;
              default:
                s = '';
            }
            return "" + encodeHTMLRules['<'] + (-1 === m.indexOf('/') ? '' : encodeHTMLRules['/']) + s + encodeHTMLRules['>'];
          });
          return str.replace(/on[\w]+\s*=/gi, '');
        } else {
          matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
          return this.replace(matchHTML, function(m) {
            return encodeHTMLRules[m] || m;
          });
        }
      };


      /*
      		  * 将 $、<、>、"、'，与 / 从 HTML 字符 反转义成正常字符
       */

      String.prototype.decodeHTML = String.prototype.decodeHTML || function() {
        var decodeHTMLRules, matchHTML;
        decodeHTMLRules = {
          "&#38;": "&",
          "&#60;": "<",
          "&#62;": ">",
          '&#34;': '"',
          '&#39;': "'",
          '&#47;': "/"
        };
        matchHTML = /&#38;|&#60;|&#62;|&#34;|&#39;|&#47;/g;
        if (this) {
          return this.replace(matchHTML, function(m) {
            return decodeHTMLRules[m] || m;
          });
        } else {
          return this;
        }
      };

      String.prototype.utf16to8 = function() {
        var c, i, j, len, out, ref;
        out = '';
        len = this.length;
        for (i = j = 0, ref = len; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          c = this.charCodeAt(i);
          if (c >= 0x0001 && c <= 0x007F) {
            out += this.charAt(i);
          } else if (c > 0x07FF) {
            out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
            out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
            out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
          } else {
            out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
            out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
          }
        }
        return out;
      };

      String.prototype.checkLuhn = function() {
        var count, i, j, len, n, num, ref, sum;
        num = this.split('');
        len = num.length;
        sum = 0;
        for (i = j = 0, ref = len; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          count = i + 1;
          n = +num[len - 1 - i];
          if (count % 2 === 0) {
            n = n * 2;
            if (!(n < 10)) {
              n = n - 9;
            }
          }
          sum += n;
        }
        return sum % 10 === 0;
      };


      /*
      		  * Array: 判断当前 array 中是否存在指定元素
       */

      Array.prototype.has = function(obj) {
        return this.indexOf(obj) !== -1;
      };


      /*
      		  * Array: 获取最后一个元素
       */

      Array.prototype.last = function() {
        return this[this.length - 1];
      };


      /*
      		  * Array: 去重
      		  * @param bool [Boolean] 是否返回移除的元素array 默认false
       */

      Array.prototype.unique = function(bool) {
        var hash, j, l, len1, len2, obj, re, result;
        if (bool == null) {
          bool = false;
        }
        result = [];
        re = [];
        hash = {};
        if (bool) {
          for (j = 0, len1 = this.length; j < len1; j++) {
            obj = this[j];
            if (hash[obj]) {
              re.push(obj);
            } else {
              result.push(obj);
              hash[obj] = true;
            }
          }
          return [result, re];
        } else {
          for (l = 0, len2 = this.length; l < len2; l++) {
            obj = this[l];
            if (!hash[obj]) {
              result.push(obj);
              hash[obj] = true;
            }
          }
          return result;
        }

        /*
        			 * 大数据量时，splice会比较低效，可以换一种方式
        			 *
        			hash = {}
        			i	 = 0
        			temp = @[0]
        			while temp
        				if hash[temp]
        					@splice i--, 1
        				else
        					hash[temp] = true
        
        				temp = @[++i]
        			@
         */
      };


      /*
      		 * Array: 移除参数中的元素
       */

      Array.prototype.remove = function(obj) {
        var i;
        i = this.indexOf(obj);
        if (i === -1) {
          return null;
        }
        return this.splice(i, 1)[0];
      };


      /*
      		  * 处理Base64库
       */

      if (Object.defineProperty && !isIE8) {
        Base64.extendString();
      } else {
        String.prototype.toBase64 = function(urisafe) {
          return Base64[urisafe ? 'encodeURI' : 'encode'](this);
        };
        String.prototype.toBase64URI = function() {
          return Base64['encodeURI'](this);
        };
        String.prototype.fromBase64 = function() {
          return Base64['decode'](this);
        };
      }


      /*
      		 * 处理md5库
       */

      String.prototype.md5 = function() {
        return md5.apply(null, [this].concat([].slice.apply(arguments)));
      };


      /*
      		 * 精确小数点位数
      		 * @param count [int] 精确小数点后位数
      		 * @param round [Boolean] 是否四舍五入（默认：yes）
       */

      Number.prototype.accurate = function(count, round) {
        var i, j, l, len, num, re, ref, ref1, str, temp, txt, x;
        if (round == null) {
          round = true;
        }
        if (this.valueOf() === 0) {
          if (count === 0) {
            return '0';
          }
          re = '0.';
          for (x = j = 0, ref = count; 0 <= ref ? j < ref : j > ref; x = 0 <= ref ? ++j : --j) {
            re += '0';
          }
          return re;
        }
        temp = Math.pow(10, count);
        num = Math[round ? 'round' : 'floor'](this * temp);
        num = num / temp;
        str = num.toString();
        len = count - str.replace(/^\d+\.*/, '').length;
        txt = str;
        if (len) {
          txt += (num % 1 === 0 ? '.' : '');
        }
        for (i = l = 0, ref1 = len; 0 <= ref1 ? l < ref1 : l > ref1; i = 0 <= ref1 ? ++l : --l) {
          txt += '0';
        }
        return txt;
      };


      /*
      		 * 判断当前数字是否是质数
       */

      Number.prototype.isPrime = function() {
        var i, j, ref;
        if (this === 0 || this === 1) {
          throw "The " + this + " is neither a prime number nor a composite number.";
        }
        if (this % 1) {
          throw 'The Number which to check is a composite number or not must be a natural number.';
        }
        if (this < 4) {
          return true;
        }
        for (i = j = 2, ref = Math.sqrt(this); 2 <= ref ? j <= ref : j >= ref; i = 2 <= ref ? ++j : --j) {
          if (!(this % i)) {
            return false;
          }
        }
        return true;
      };


      /*
      		 * 阶乘 num!
      		 * @param num [int] 操作数
       */

      Math.factorial = function(num) {
        var formula;
        if (num !== Math.abs(num)) {
          throw 'The number to calculate for factorial must be a positive integer.';
        }
        if (num % 1 !== 0) {
          throw 'The number to calculate for factorial must be a int number.';
        }
        if (num === 0) {
          return 1;
        }
        formula = function(num, total) {
          if (num === 1) {
            return total;
          }
          return formula(num - 1, num * total);
        };
        return formula(num, 1);
      };


      /*
      		 * 排列(Arrangement)
      		 * A(n,m)
      		 * @param n [int] 元素的总个数
      		 * @param m [int] 参与选择的元素个数
       */

      Math.arrangement = function(n, m) {
        var a, b;
        if (n < m) {
          return 0;
        }
        a = Math.factorial(n);
        b = Math.factorial(n - m);
        return a / b;
      };


      /*
      		 * 组合(Combination)
      		 * C(n,m)
      		 * @param n [int] 元素的总个数
      		 * @param m [int] 参与选择的元素个数
       */

      Math.combination = function(n, m) {
        var a, b;
        if (n < m) {
          return 0;
        }
        a = Math.arrangement(n, m);
        b = Math.factorial(m);
        return a / b;
      };


      /*
      		 * int 随机数
      		 * @param min [int] 随机范围的最小数字
      		 * @param max [int] 随机范围的最大数字
       */

      Math.intRange = function(min, max) {
        if (min == null) {
          min = 0;
        }
        if (max == null) {
          max = 0;
        }
        return min + Math.round(Math.random() * (max - 1));
      };


      /*
      		 * 交集(Intersection)
       */

      Array.intersection = function(a, b) {
        var j, len1, re, ref, x;
        re = [];
        ref = a.unique();
        for (j = 0, len1 = ref.length; j < len1; j++) {
          x = ref[j];
          if (indexOf.call(b, x) >= 0) {
            re.push(x);
          }
        }
        return re;
      };


      /*
      		 * 并集(Union)
       */

      Array.union = function() {
        var arr, j, len1, re;
        re = [];
        for (j = 0, len1 = arguments.length; j < len1; j++) {
          arr = arguments[j];
          re = re.concat(arr);
        }
        return re.unique();
      };


      /*
      		  * 扩展jQuery
       */

      $.zIndex = 1501;

      $.fn.extend({

        /*
        			  * 移动光标到指定位置
        			  * @param position [Number] 光标位置（下标）
         */
        setCursorPosition: function(position) {
          if (this.lengh === 0) {
            return this;
          }
          return $(this).setSelection(position, position);
        },

        /*
        			  * 设置光标选中文本
        			  * @param selectionStart [Number] 开始下标
        			  * @param selectionEnd [Number] 结束下标
         */
        setSelection: function(selectionStart, selectionEnd) {
          var input, range;
          if (this.lengh === 0) {
            return this;
          }
          input = this[0];
          if (!selectionEnd) {
            selectionEnd = this.val().length;
          }
          if (input.createTextRange) {
            range = input.createTextRange();
            range.collapse(true);
            range.moveEnd('character', selectionEnd);
            range.moveStart('character', selectionStart);
            range.select();
          } else if (input.setSelectionRange) {
            input.focus();
            input.setSelectionRange(selectionStart, selectionEnd);
          }
          return this;
        },

        /*
        			  * focus 之后，将光标放到最后
         */
        focusEnd: function() {
          this.setCursorPosition(this.val().length);
        },

        /*
        			  * 限制文本输入（目前仅支持 INPUT）
        			  * @param data [JSON Object] 传入参数
        			  * - type [string]	类型（"int", "float"）
        			  * ============================================
        			  * 当 type === 'int'：
        			  * - maxLength [int] 最大长度（默认不限制）
        			  * ============================================
        			  * 当 type === 'float'：
        			  * - intMaxLength [int] 整数部分最大长度（默认不限制）
        			  * - decMaxLength [int] 小数部分最大长度（默认不限制）
         */
        formatInsert: function(data) {
          var _change, _fun, _keydown, _keyup, compositePreKey, j, l, len1, len2, len3, len4, len5, len6, p, q, r, ref, ref1, ref2, t;
          if (!this.length) {
            return this;
          }
          if (!/^INPUT$/.test(this[0].tagName)) {
            return this;
          }
          if (!data) {
            return this;
          }
          _keydown = [];
          _keyup = [];
          _change = [];
          compositePreKey = (function(_this) {
            return function(keyCode) {
              if (keyCode === 17 || keyCode === 224) {
                _this.data({
                  compositeKey: true
                });
                return true;
              }
              return false;
            };
          })(this);
          switch (data.type) {
            case 'int':
              data.maxLength = data.maxLength || Infinity;
              _keydown.push((function(_this) {
                return function(event) {
                  var keyCode, val;
                  keyCode = event.keyCode;
                  if (compositePreKey(keyCode)) {
                    return true;
                  }
                  if (_this.data('compositeKey')) {
                    return true;
                  }
                  if (keyCode === 8 || keyCode === 9) {
                    return true;
                  }
                  if (indexOf.call([48, 49, 50, 51, 52, 53, 54, 55, 56, 57].concat([96, 97, 98, 99, 100, 101, 102, 103, 104, 105]), keyCode) < 0) {
                    return false;
                  }
                  val = $(event.currentTarget).val();
                  if (data.maxLength && val.length >= data.maxLength) {
                    return false;
                  }
                };
              })(this));
              break;
            case 'float':
              data.intMaxLength = data.intMaxLength || Infinity;
              data.decMaxLength = data.decMaxLength || Infinity;
              _keydown.push((function(_this) {
                return function(event) {
                  var hasDot, keyCode, val;
                  keyCode = event.keyCode;
                  if (compositePreKey(keyCode)) {
                    return true;
                  }
                  if (_this.data('compositeKey')) {
                    return true;
                  }
                  if (keyCode === 8 || keyCode === 9) {
                    return true;
                  }
                  if (indexOf.call([190, 110].concat([48, 49, 50, 51, 52, 53, 54, 55, 56, 57].concat([96, 97, 98, 99, 100, 101, 102, 103, 104, 105])), keyCode) < 0) {
                    return false;
                  }
                  val = $(event.currentTarget).val();
                  hasDot = val.indexOf('.' !== -1);
                  if (hasDot && (keyCode === 190 || keyCode === 110)) {
                    return false;
                  }
                  if (data.intMaxLength && val.replace(/\.\d*$/, '').length >= data.intMaxLength) {
                    return false;
                  }
                  if (hasDot && data.decMaxLength && val.replace(/^\d*\./, '').length >= data.decMaxLength) {
                    return false;
                  }
                };
              })(this));
              _change.push((function(_this) {
                return function(event) {
                  var el;
                  el = $(event.currentTarget);
                  return el.val(el.val().replace(/\.$/, ''));
                };
              })(this));
          }
          _keyup.push((function(_this) {
            return function(event) {
              var ref;
              if ((ref = event.keyCode) === 17 || ref === 224) {
                return _this.data({
                  compositeKey: false
                });
              }
            };
          })(this));
          if (this.data._keydown) {
            ref = this.data._keydown;
            for (j = 0, len1 = ref.length; j < len1; j++) {
              _fun = ref[j];
              this.off('keydown', _fun);
            }
          }
          if (this.data._keyup) {
            ref1 = this.data._keyup;
            for (l = 0, len2 = ref1.length; l < len2; l++) {
              _fun = ref1[l];
              this.off('keyup', _fun);
            }
          }
          if (this.data._change) {
            ref2 = this.data._change;
            for (p = 0, len3 = ref2.length; p < len3; p++) {
              _fun = ref2[p];
              this.off('change', _fun);
            }
          }
          this.data._keydown = _keydown;
          this.data._keyup = _keyup;
          this.data._change = _change;
          for (q = 0, len4 = _keydown.length; q < len4; q++) {
            _fun = _keydown[q];
            this.on('keydown', _fun);
          }
          for (r = 0, len5 = _keyup.length; r < len5; r++) {
            _fun = _keyup[r];
            this.on('keyup', _fun);
          }
          for (t = 0, len6 = _change.length; t < len6; t++) {
            _fun = _change[t];
            this.on('change', _fun);
          }
          return this;
        },
        modal: function(param) {
          var modal;
          modal = this;
          if (!modal.data('modalInited')) {
            modal.data('param', $.extend({
              'show': true,
              'keyboard': true
            }, param));
            param = modal.data('param');
            modal.on('show', function(event) {
              if (event.target !== this) {
                return;
              }
              modal = $(this);
              modal.after('<div class="modal-backdrop fade in" style="z-index: ' + ($.zIndex += 9) + ';"></div>');
              modal.css('zIndex', $.zIndex += 1);
              setTimeout(function() {
                modal.addClass('in');
              }, 0);
              $('.modal-footer .btn:first', modal).focus();
              return modal.trigger('shown');
            }).on('hide', function(event) {
              if (event.target !== this) {
                return;
              }
              modal = $(this);
              modal.removeClass('in');
              setTimeout(function() {
                modal.next('.modal-backdrop').remove();
                modal.trigger('hidden');
              }, 420);
              return this;
            }).on('click', '[data-dismiss="modal"]', function(event) {
              $(event.currentTarget).parents('.modal').trigger('hide');
            }).on('keyup', function(event) {
              var keyCode;
              keyCode = event.keyCode;
              if (keyCode === 27) {
                modal = $(this);
                if (modal.data('param')['keyboard']) {
                  modal.trigger('hide');
                }
              }
            });
            if (param['show']) {
              modal.trigger('show');
            }
            modal.data('modalInited', 1);
          }
          if (typeof param === 'string') {
            if (param === 'show') {
              modal.trigger('show');
            } else if (param === 'hide') {
              modal.trigger('hide');
            }
          }
          return this;
        }
      });


      /*
      		  * 非修改对象原型、非Utils类的Common部分
       */


      /*
      		  * CSH.alert & CSH.confirm
      		  *
      		  * @param param [JSON Object]
      		  * 	- title [string]	标题
      		  * 	- content [string]	正文内容
      		  * 	- className [string]	样式类名（会被追加到 .modal 的 class attribute 中）
      		  * 	- close [string]	关闭按钮状态 当值为'hide'时隐藏关闭按钮 可选值：'hide' 默认：-
      		  * 	- ok [JSON Object]	“确定”按钮参数
      		  * 	-	-	text [string]	“确定”按钮显示文字（默认："确定"）
      		  * 	-	-	callback [Function]	“确定”按钮回调函数
      		  * 	-	-	autohide [Boolean]	“确定”按钮点击后自动隐藏（默认：true）
      		  * 	- cancel [JSON Object]	“取消”按钮参数（注：此参数存在与否会作为判断 alert 或 confirm 的依据）
      		  * 	-	-	text [string]	“取消”按钮显示文字（默认："取消"）
      		  * 	-	-	callback [Function]	“取消”按钮回调函数
       */

      CSH.confirm = function(param) {
        var _el;
        if (!param) {
          return;
        }
        param = $.extend({
          type: 'confirm'
        }, param);
        if (!/<[\w\s]+>/.test(param.content)) {
          param.content = "<p>" + (param.content.encodeHTML(true)) + "</p>";
        }
        param.ok = param.ok || {};
        param.ok = $.extend({
          autohide: true
        }, param.ok);
        _el = $(doT.template(TplAlert)(param)).appendTo('body');
        if (param.className) {
          _el.addClass(param.className);
        }
        _el.on('hidden', function() {
          _el.off().remove();
        });
        if (param.ok.callback) {
          _el.on('click', '.btn[btn-type="ok"]', function() {
            param.ok.callback.apply(_el, arguments);
          });
        }
        if (param.cancel && param.cancel.callback) {
          _el.on('click', '.btn[btn-type="cancel"], .close', function() {
            param.cancel.callback.apply(_el, arguments);
          });
        }
        _el.modal('show');
        $('.modal-footer .btn:eq(0)', _el).focus();
        return _el;
      };


      /*
      		  * 调用方式（两种）
      		  * 1. CSH.alert('string message');
      		  * 2. CSH.alert({content: 'message', ...});
       */

      CSH.alert = function(param) {
        if (typeof param === 'string') {
          param = {
            content: param.encodeHTML(true)
          };
        } else {
          param.content = param.content.encodeHTML(true);
        }
        return CSH.confirm($.extend({
          type: 'alert'
        }, param));
      };


      /*
      		  * 弱提示
      		  * CSH.hint('string message');
      		  * CSH.hint
      		  * 		msg: 'some message'
      		  * 		delay [Number]		# 延迟时间 默认：0
      		  * 		duration [Number]	# 持续时间 默认：1200
      		  * 		speed [Number]		# 显示/隐藏 动画时间 默认：200
      		  * 		icon [String]		# 图标 默认：-；当 type 为 'success' 时，默认：'ok'；当 type 为 'error' 时，默认：'close'
      		  * 		type [String]		# 类型，可选值：'success', 'error' 默认：'default'
      		  * 		callback [Function]	# 回调函数
      		  * 关闭 Function
      		  * target	= CSH.hint...
      		  * fun		= target.data 'hide'
      		  * fun()	# 执行关闭
       */

      CSH.hint = function(param) {
        var Temp;
        Temp = (function() {
          function Temp(param) {
            var fun, target;
            if (typeof param === 'string') {
              param = {
                msg: param
              };
            }
            param = $.extend({
              msg: '',
              delay: 0,
              duration: 1200,
              speed: 200,
              type: 'default'
            }, param);
            switch (param.type) {
              case 'success':
                param = $.extend({
                  icon: 'ok'
                }, param);
                break;
              case 'error':
                param = $.extend({
                  icon: 'close'
                }, param);
            }
            target = $("<div class=\"hint " + param.type + (param.msg ? '' : ' noMsg') + "\">\n	<p><label>" + (param.msg.encodeHTML()) + "</label></p>\n</div>");
            if (param.icon) {
              target.find('label').before("<span class=\"icon " + (param.icon === 'loading' ? 'icon-spin icon-fast ' : '') + "icon-" + param.icon + "\"></span>");
            }
            target.appendTo('body').data('hide', function() {
              clearTimeout(target.data('timeout'));
              return target.animate({
                marginTop: '-32px',
                opacity: 0
              }, param.speed, function() {
                target.remove();
                return typeof param.callback === "function" ? param.callback() : void 0;
              });
            }).css({
              marginTop: '-32px',
              opacity: 0
            });
            fun = function() {
              target.animate({
                marginTop: 0,
                opacity: 1
              }, param.speed, function() {
                return target.removeAttr('style');
              });
              if (param.duration !== Infinity) {
                return target.data('timeout', setTimeout(function() {
                  fun = target.data('hide');
                  return fun();
                }, param.duration));
              }
            };
            if (param.delay) {
              setTimeout(fun, param.delay);
            } else {
              fun();
            }
            return target;
          }

          return Temp;

        })();
        return new Temp(param);
      };


      /*
      		  * 通知信息
      		  * CSH.notice('string message');
      		  * CSH.notice
      		  * 		content: 'some message'	# 消息内容
      		  * 		className [String]	# 样式类名
      		  * 		duration [Number]	# 持续时间 默认：3000
      		  * 		speed [Number]		# 显示/隐藏 动画时间 默认：200
      		  * 		callback [Function]	# 回调函数
       */

      CSH.notice = function(param) {
        var _close, _destroy, target;
        if (typeof param === 'string') {
          param = {
            content: param
          };
        }
        param = $.extend({
          className: '',
          duration: 3000,
          speed: 200,
          title: '系统消息'
        }, param);
        target = $("<div class=\"notice " + param.className + "\">\n	<div class=\"noticeContent\">\n		<h4>" + param.title + "</h4>\n		<div class=\"content\">" + (param.content.encodeHTML(true)) + "</div>\n		<button class=\"close\"><i class=\"icon icon-wrong\"></i></button>\n	</div>\n</div>");
        _destroy = false;
        _close = function() {
          if (_destroy) {
            return;
          }
          _destroy = true;
          return target.animate({
            top: -50,
            opacity: 0
          }, param.speed, function() {
            target.remove();
            target = null;
            return typeof param.callback === "function" ? param.callback() : void 0;
          });
        };
        target.appendTo('body').css({
          top: -50,
          opacity: 0
        }).animate({
          top: 0,
          opacity: 1
        }, param.speed, function() {
          return target.removeAttr('style');
        }).on('click', '.close', _close);
        setTimeout(_close, param.duration);
        return target;
      };

      return Utils;

    })();

    /*
    	  * 栈
     */
    Stack = (function() {
      function Stack() {
        this.dataStore = [];
      }

      Stack.prototype.top = 0;

      Stack.prototype.push = function(element) {
        return this.dataStore[this.top++] = element;
      };

      Stack.prototype.pop = function() {
        return this.dataStore[--this.top];
      };

      Stack.prototype.peek = function() {
        return this.dataStore[this.top - 1];
      };

      Stack.prototype.clear = function() {
        return this.top = 0;
      };

      Stack.prototype.clone = function() {
        var obj;
        obj = new Stack();
        obj.dataStore = CSH.utils.clone(this.dataStore);
        obj.top = this.top;
        return obj;
      };

      return Stack;

    })();
    Object.defineProperties(Stack.prototype, {
      length: {
        get: function() {
          return this.top;
        }
      }
    });
    window.Stack = Stack;

    /*
    	  * 队列
     */
    Queue = (function() {
      function Queue() {
        this.dataStore = [];
      }

      Queue.prototype.enqueue = function(element) {
        return this.dataStore.push(element);
      };

      Queue.prototype.dequeue = function() {
        return this.dataStore.shift();
      };

      Queue.prototype.first = function() {
        return this.dataStore[0];
      };

      Queue.prototype.end = function() {
        return this.dataStore[this.length - 1];
      };

      Queue.prototype.clear = function() {
        return this.dataStore = [];
      };

      Queue.prototype.toString = function() {
        var el, i, j, len1, ref, str;
        str = '';
        ref = this.dataStore;
        for (i = j = 0, len1 = ref.length; j < len1; i = ++j) {
          el = ref[i];
          str += "" + el + (i + 1 !== this.length ? '\n' : '');
        }
        return str;
      };

      return Queue;

    })();
    Object.defineProperties(Queue.prototype, {
      length: {
        get: function() {
          return this.dataStore.length;
        }
      }
    });
    window.Queue = Queue;

    /*
    	  * 计分板
     */
    Scoreboard = (function() {
      function Scoreboard(el1) {
        this.el = el1;
        this.executeAnimation = bind(this.executeAnimation, this);
        this.data = {
          direction: true
        };
        this.tpl = doT.template(TplScoreboard);
        this.el.html(this.tpl());
      }

      Scoreboard.prototype.destroy = function() {
        return this.el.empty().removeClass('up down changing changed');
      };

      Scoreboard.prototype.resetDirection = function() {
        var ref, ref1, str1, str2;
        ref = ['up', 'down'], str1 = ref[0], str2 = ref[1];
        if (!this.data.direction) {
          ref1 = [str2, str1], str1 = ref1[0], str2 = ref1[1];
        }
        this.el.addClass(str1);
        return this.el.removeClass(str2);
      };


      /*
      		  * 翻牌
      		  * @param data [Object] 必填。JSON对象。
      		  * @param data - current [Int] 选填。当前文本
      		  * @param data - next [Int] 必填。下一个文本
      		  * @param data - direction [Boolean] 选填。翻牌方向 自上而下：true；自下而上：false。默认：true
       */

      Scoreboard.prototype.flip = function(data) {
        var k, v;
        if (typeof data !== 'object') {
          data = {
            next: data
          };
        }
        if (!data.current) {
          data.current = this.data.prev || '';
        }
        for (k in data) {
          if (!hasProp.call(data, k)) continue;
          v = data[k];
          this.data[k] = v;
        }
        this.data.prev = this.data.next;
        this.resetDirection();
        this.resetAnimation();
        this.startAnimation();
        return setTimeout(this.executeAnimation, 20);
      };

      Scoreboard.prototype.resetAnimation = function() {
        this.el.addClass('changed');
        return this.el.removeClass('changing');
      };

      Scoreboard.prototype.startAnimation = function() {
        this.el.html(this.tpl(this.data));
        return this.el.removeClass('changed');
      };

      Scoreboard.prototype.executeAnimation = function() {
        return this.el.addClass('changing');
      };

      return Scoreboard;

    })();
    window.Scoreboard = Scoreboard;
    return Utils;
  });

}).call(this);
