(function() {
  define(['jquery', 'backbone', 'models/getMyDaySalarylist'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      Model: Model,
      originUrl: '/daySalary/getMyDaySalarylist'
    });
  });

}).call(this);
