(function() {
  define(['jquery', 'backbone', 'models/membertalkContacts'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/membertalk/contacts'
    });
  });

}).call(this);
