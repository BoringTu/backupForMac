(function() {
  define(['jquery', 'backbone', 'models/activitys'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/activites'
    });
  });

}).call(this);
