(function() {
  define(['jquery', 'backbone', 'models/teamCheckChange'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/fundchanges'
    });
  });

}).call(this);
