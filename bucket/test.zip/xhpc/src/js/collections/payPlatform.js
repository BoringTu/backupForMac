(function() {
  define(['jquery', 'backbone'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      originUrl: '/members/getPayType'
    });
  });

}).call(this);
