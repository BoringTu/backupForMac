(function() {
  define(['jquery', 'backbone', 'models/announceByPage'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/members/getAnnounceByPage'
    });
  });

}).call(this);
