(function() {
  define(['jquery', 'backbone', 'models/appendbettings'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/lotterys/appendbettings'
    });
  });

}).call(this);
