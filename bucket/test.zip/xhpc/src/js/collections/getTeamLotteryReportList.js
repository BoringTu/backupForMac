(function() {
  define(['jquery', 'backbone', 'models/getTeamLotteryReportList'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: 'models/getTeamLotteryReportList'
    });
  });

}).call(this);
