(function() {
  define(['jquery', 'backbone', 'models/teammoneyhistory'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/teammoneyhistory'
    });
  });

}).call(this);
