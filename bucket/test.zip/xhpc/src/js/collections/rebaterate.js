(function() {
  define(['jquery', 'backbone', 'models/rebaterate'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/systemsets/rebaterate',
      parse: function(data) {
        return data.data;
      }
    });
  });

}).call(this);
