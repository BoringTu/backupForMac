(function() {
  define(['jquery', 'backbone', 'models/links'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/Links'
    });
  });

}).call(this);
