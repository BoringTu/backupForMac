(function() {
  define(['jquery', 'backbone', 'models/currentperiodallinfo'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/lotterys/lotteryperiod/getcurrentperiodallinfo'
    });
  });

}).call(this);
