(function() {
  define(['jquery', 'backbone', 'models/salarymanage'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/salarymanage'
    });
  });

}).call(this);
