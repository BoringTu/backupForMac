(function() {
  define(['jquery', 'backbone', 'models/trades'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/members/trades'
    });
  });

}).call(this);
