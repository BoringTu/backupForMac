(function() {
  define(['jquery', 'backbone', 'models/getSubDaySalarylist'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/daySalary/getSubDaySalarylist'
    });
  });

}).call(this);
