(function() {
  define(['jquery', 'backbone', 'models/getTeamLotteryReport'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/GetTeamLotteryReport'
    });
  });

}).call(this);
