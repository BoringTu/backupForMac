(function() {
  define(['jquery', 'backbone', 'models/teammoneytoday'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/teammoneytoday'
    });
  });

}).call(this);
