(function() {
  define(['jquery', 'backbone', 'models/bettingrecodesList'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/lotterys/bettingrecodesList'
    });
  });

}).call(this);
