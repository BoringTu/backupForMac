(function() {
  define(['jquery', 'backbone', 'models/getTeamReport'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/GetTeamReport'
    });
  });

}).call(this);
