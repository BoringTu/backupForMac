(function() {
  define(['jquery', 'backbone', 'models/getUserMemberlst'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/getUserMemberlst'
    });
  });

}).call(this);
