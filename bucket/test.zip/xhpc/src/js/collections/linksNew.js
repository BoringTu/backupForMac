(function() {
  define(['jquery', 'backbone', 'models/linksNew'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/links'
    });
  });

}).call(this);
