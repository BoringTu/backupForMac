(function() {
  define(['jquery', 'backbone', 'models/fundchanges'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/members/fundchanges'
    });
  });

}).call(this);
