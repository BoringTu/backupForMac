(function() {
  define(['jquery', 'backbone', 'models/getBonusLst'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/bonus/getBonusLst'
    });
  });

}).call(this);
