(function() {
  define(['jquery', 'backbone', 'models/getSublstContract'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/contract/getSublstContract'
    });
  });

}).call(this);
