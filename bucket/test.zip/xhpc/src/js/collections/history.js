(function() {
  define(['jquery', 'backbone', 'models/history'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/lotterys/lotteryperiod/history'
    });
  });

}).call(this);
