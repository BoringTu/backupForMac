(function() {
  define(['jquery', 'backbone', 'models/getSubBondLstByPeriod'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/bonus/getSubBondLstByPeriod'
    });
  });

}).call(this);
