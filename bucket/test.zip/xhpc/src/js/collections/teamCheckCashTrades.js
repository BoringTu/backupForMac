(function() {
  define(['jquery', 'backbone', 'models/teamCheckCashTrades'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/cashtrades'
    });
  });

}).call(this);
