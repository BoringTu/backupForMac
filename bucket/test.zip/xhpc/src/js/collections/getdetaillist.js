(function() {
  define(['jquery', 'backbone', 'models/getdetaillist'], function($, Backbone, Model) {
    return Backbone.Collection.extend({
      model: Model,
      originUrl: '/agentmanage/getdetaillist'
    });
  });

}).call(this);
