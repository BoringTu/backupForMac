(function() {
  define(['jquery', 'backbone'], function($, backbone) {
    return Backbone.Model.extend({
      originUrl: '/contract/infobyid'
    });
  });

}).call(this);
