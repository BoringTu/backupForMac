(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/members/recentstatistics'
    });
  });

}).call(this);
