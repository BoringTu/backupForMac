(function() {
  define(['jquery', 'backbone'], function($, backbone) {
    return Backbone.Model.extend({
      originUrl: '/activites'
    });
  });

}).call(this);
