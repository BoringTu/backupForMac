(function() {
  define(['jquery', 'backbone'], function($, Backbone) {
    return Backbone.Model.extend({
      originUrl: '/daysalary/CloseSalaryWindow'
    });
  });

}).call(this);
