(function() {
  define(['jquery', 'backbone'], function($, backbone) {
    return Backbone.Model.extend({
      originUrl: '/members/cancelOrder'
    });
  });

}).call(this);
