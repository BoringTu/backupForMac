
/*
  * Controller
  * mine_sms: 我的消息
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/mine_sms'], function($, View) {
    var ctrlName;
    ctrlName = 'mine_sms';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
