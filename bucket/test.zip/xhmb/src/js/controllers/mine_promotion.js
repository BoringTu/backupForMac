
/*
  * Controller
  * mine_promotion: 推广开户
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/mine_promotion'], function($, View) {
    var ctrlName;
    ctrlName = 'mine_promotion';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
