
/*
  * Controller
  * lowerParticulars: 下级详情
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/lower'], function($, View) {
    var ctrlName;
    ctrlName = 'lower';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
