
/*
  * Controller
  * promotion_list: 链接管理
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/promotion_list'], function($, View) {
    var ctrlName;
    ctrlName = 'promotion_list';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
