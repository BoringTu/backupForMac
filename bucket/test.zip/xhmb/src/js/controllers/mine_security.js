
/*
  * Controller
  * mine_security: 安全中心
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/mine_security'], function($, View) {
    var ctrlName;
    ctrlName = 'mine_security';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
