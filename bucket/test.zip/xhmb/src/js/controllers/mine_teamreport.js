
/*
  * Controller
  * mine_teamreport: 团队管理
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/mine_teamreport'], function($, View) {
    var ctrlName;
    ctrlName = 'mine_teamreport';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
