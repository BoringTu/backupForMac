
/*
  * Controller
  * lotteryTypes: 彩种大厅
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/lotteryTypes'], function($, View) {
    var ctrlName;
    ctrlName = 'lotteryTypes';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
