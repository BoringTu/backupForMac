
/*
  * Controller
  * past_me: 投注记录
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/past_me'], function($, View) {
    var ctrlName;
    ctrlName = 'past_me';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
