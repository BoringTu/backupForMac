
/*
  * Controller
  * _result: 结果
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/_result'], function($, View) {
    var ctrlName;
    ctrlName = '_result';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
