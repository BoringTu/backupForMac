
/*
  * Controller
  * bettingList: 投注单
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/bettingList'], function($, View) {
    var ctrlName;
    ctrlName = 'bettingList';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
