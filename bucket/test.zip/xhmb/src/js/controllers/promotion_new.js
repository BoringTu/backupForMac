
/*
  * Controller
  * promotion_new: 新建推广
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/promotion_new'], function($, View) {
    var ctrlName;
    ctrlName = 'promotion_new';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
