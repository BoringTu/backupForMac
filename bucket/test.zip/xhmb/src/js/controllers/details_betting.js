
/*
  * Controller
  * details_betting: 投注详情
  * @notice context:router
 */

(function() {
  define(['jquery', 'views/details_betting'], function($, View) {
    var ctrlName;
    ctrlName = 'details_betting';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
