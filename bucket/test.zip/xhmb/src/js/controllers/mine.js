
/*
  * Controller
  * mine: 我的（个人中心）
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/mine'], function($, View) {
    var ctrlName;
    ctrlName = 'mine';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
