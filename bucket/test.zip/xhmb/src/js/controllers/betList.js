
/*
  * Controller
  * betList: 投注单
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/betList'], function($, View) {
    var ctrlName;
    ctrlName = 'betList';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
