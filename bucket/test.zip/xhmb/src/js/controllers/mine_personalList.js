
/*
 * Controller
 * mine_personalList: 个人报表
 * @notice context : router
 */

(function() {
  define(['jquery', 'views/mine_personalList'], function($, View) {
    var ctrlName;
    ctrlName = 'mine_personalList';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
