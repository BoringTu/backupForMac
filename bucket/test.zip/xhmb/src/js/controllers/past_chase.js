
/*
  * Controller
  * past_chase: 追号记录
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/past_chase'], function($, View) {
    var ctrlName;
    ctrlName = 'past_chase';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
