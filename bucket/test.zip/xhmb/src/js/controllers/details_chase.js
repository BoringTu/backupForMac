
/*
  * Controller
  * details_chase: 追号详情
  * @notice context: router
 */

(function() {
  define(['jquery', 'views/details_chase'], function($, View) {
    var ctrlName;
    ctrlName = 'details_chase';
    return CSH.controllers[ctrlName] = function() {
      new View({
        ctrlName: ctrlName
      });
    };
  });

}).call(this);
