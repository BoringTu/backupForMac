(function() {
  var Login, fix, getCaptchaId,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    hasProp = {}.hasOwnProperty;

  Base64.extendString();

  String.prototype.md5 = function() {
    return md5.apply(null, [this].concat([].slice.apply(arguments)));
  };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  String.prototype.encodeHTML = function(onlyEncodeScript) {
    var encodeHTMLRules, matchHTML;
    if (!this) {
      return this;
    }
    encodeHTMLRules = {
      "&": "&#38;",
      "<": "&#60;",
      ">": "&#62;",
      '"': '&#34;',
      "'": '&#39;',
      "/": '&#47;'
    };
    if (onlyEncodeScript) {
      matchHTML = /<\/?\s*script\s*>/g;
      return this.replace(matchHTML, function(m) {
        return "" + encodeHTMLRules['<'] + (-1 === m.indexOf('/') ? '' : encodeHTMLRules['/']) + "script" + encodeHTMLRules['>'];
      });
    } else {
      matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
      return this.replace(matchHTML, function(m) {
        return encodeHTMLRules[m] || m;
      });
    }
  };

  fix = location.hostname.match(/(?:^\w+\.|)(\w+)(?:\.\w+$)/);

  fix = fix[1].toLowerCase();

  fix = /test/.test(fix) ? 'rg' : fix.replace(/\d|dev|pvw/g, '');

  getCaptchaId = function() {
    return 'e614300cf3de4d36bfa64407470121c5';
  };

  Login = (function() {
    function Login() {
      this.cssTransform = bind(this.cssTransform, this);
      this.nec = bind(this.nec, this);
      this.defaults = bind(this.defaults, this);
      this.eventAgreementClose = bind(this.eventAgreementClose, this);
      this.eventToggleLowLogin = bind(this.eventToggleLowLogin, this);
      this.eventPasswordFocus = bind(this.eventPasswordFocus, this);
      this.eventPasswordChanged = bind(this.eventPasswordChanged, this);
      this.getServerTime = bind(this.getServerTime, this);
      this.cssLinearGradient = bind(this.cssLinearGradient, this);
      this.errorLock = bind(this.errorLock, this);
      this.eventslideUnlock = bind(this.eventslideUnlock, this);
      this.showAlert = bind(this.showAlert, this);
      this.showHint = bind(this.showHint, this);
      this.InputEach = bind(this.InputEach, this);
      this.eventAgreeLogin = bind(this.eventAgreeLogin, this);
      this.eventLogin = bind(this.eventLogin, this);
      this.eventClearText = bind(this.eventClearText, this);
      this.eventInputBlur = bind(this.eventInputBlur, this);
      this.eventInputKeyup = bind(this.eventInputKeyup, this);
      this.eventInputFocus = bind(this.eventInputFocus, this);
      this.eventPassGet = bind(this.eventPassGet, this);
      this.loadResources = bind(this.loadResources, this);
      this.processSPW = bind(this.processSPW, this);
      window.v = this;
      this.checkAppVersion();
      $('body').append("<script src=\"" + location.protocol + "//c.dun.163yun.com/js/c.js\"></script>");
      this.host = (function(_this) {
        return function() {
          var arr, j, k, kv, len, tmp;
          _this.isLocal = 0;
          arr = location.search.slice(1).split('&');
          for (j = 0, len = arr.length; j < len; j++) {
            kv = arr[j];
            tmp = kv.split('=');
            k = tmp[0];
            if (k === 'test') {
              _this.isLocal = 1;
              break;
            }
          }

          /*
          			if @isLocal
          				"#{ location.protocol }//appapi.#{ location.hostname.replace /^\w+\./, '' }"
          			else
          				location.origin + '/api'
           */
          return location.origin + "/api";
        };
      })(this)();
      this.getServerTime();
      this.passGetUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/passGet.tpl";
      this.agreementUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/agreement.tpl";
      this.url = '/members/Login';
      this.els = {};
      this.els.body = $('body');
      this.els.loginWrapper = $('.loginWrapper');
      this.els.regWrapper = $('.regWrapper');
      this.els.login = $('button.login');
      this.els.reg = $('button.reg');
      this.els.userName = $('[name="username"]');
      this.els.password = $('[name="password"]');
      this.els.lowlogin = $('.passwordAbout .checkbox');
      this.els.plat = $('.platform');
      this.els.loginWrapper_input = $('input', this.els.loginWrapper);
      this.els.clearText = $('.clearText');
      this.els.agreement = $('.agreement');
      this.els.cancel = $('.cancel', this.els.agreement);
      this.els.agree = $('.agree', this.els.agreement);
      this.els.passGetBtn = $('.passGetBtn');
      this.els.errorWrap = $('.errorWrap');
      this.els.slideWrap = $('.slideWrap');
      setTimeout((function(_this) {
        return function() {
          _this.els.userName.val(localStorage.getItem('username') || '');
          return _this.processSPW();
        };
      })(this), 100);
      $('input').on('focus', this.eventInputFocus).on('blur', this.eventInputBlur).on('keyup', this.eventInputKeyup);
      this.els.password.on('change', this.eventPasswordChanged);
      this.els.password.on('focus', this.eventPasswordFocus);
      this.els.lowlogin.parent().on('click', this.eventToggleLowLogin);
      this.els.cancel.on('click', this.eventAgreementClose);
      this.els.login.on('click', this.eventLogin);
      this.els.clearText.on('click', this.eventClearText);
      this.els.passGetBtn.on('touchstart', this.eventPassGet);
      this._BtnTrue = false;
      this.nonWeixinBrowserOpen();
      this.loadResources();
      this.addDownload();

      /*
      		fun	= => if window.NECaptcha then @nec() else setTimeout fun, 100
      		setTimeout fun, 100
       */
      this.rememberPassword = 11111111111;
    }

    Login.prototype.nonWeixinBrowserOpen = function() {
      var domainName, ua;
      ua = navigator.userAgent.toLowerCase();
      domainName = location.host;
      if (!/MicroMessenger/i.test(ua)) {
        return $.ajax({
          url: location.origin + "/fapi/wxDomain",
          dataType: 'json',
          contentType: 'application/json',
          dataFilter: (function(_this) {
            return function(data) {
              var item, j, len, results, wxDomainList;
              wxDomainList = data.toJSON().data;
              results = [];
              for (j = 0, len = wxDomainList.length; j < len; j++) {
                item = wxDomainList[j];
                if (domainName === item) {
                  results.push(location.href = location.origin + "/wxerror.html");
                } else {
                  results.push(void 0);
                }
              }
              return results;
            };
          })(this)
        });
      }
    };

    Login.prototype.addDownload = function() {
      var box, downAppTime, jump, time;
      downAppTime = localStorage.getItem('downAppTime');
      if (downAppTime) {
        if (downAppTime - Date.now() < 0) {
          localStorage.removeItem('downAppTime');
        } else {
          return;
        }
      }
      box = $("<div class=\"appDownloadBox\">\n	<button class=\"close\"><i class=\"icon\"></i></button>\n	<a href=\"" + window.appdownload + "\" class=\"icon textShow\" >\n		<i class=\"icon\"></i>\n		<span>下载APP</span>\n	</a>\n</div>");
      jump = box.find('a');
      this.els.body.append(box);
      box.on('click', '.close', function() {
        var date, therrTime, time;
        jump.addClass('downAnimation');
        setTimeout((function() {
          return box.remove();
        }), 2000);
        time = new Date();
        date = new Date(time.setDate(time.getDate() + 1)).toLocaleDateString();
        therrTime = new Date(date + " 3:00:00").getTime();
        localStorage.setItem('downAppTime', therrTime);
        return clearInterval(time);
      });
      return time = setInterval(function() {
        jump.addClass('downAnimation');
        return setTimeout(function() {
          return jump.toggleClass('textShow').removeClass('downAnimation');
        }, 2000);
      }, 60000);
    };

    Login.prototype.checkAppVersion = function() {
      var arr, i, j, k, kv, l, len, map, results, str, tmp, v;
      str = location.search;
      if (!str) {
        return;
      }
      if (!window.latestVersion) {
        $.ajax({
          url: location.origin + "/fapi/appLatestVersion",
          dataType: 'json',
          contentType: 'application/json',
          dataFilter: (function(_this) {
            return function(data) {
              window.latestVersion = data.toJSON().data.version.split('.');
              _this.checkAppVersion();
              return '{}';
            };
          })(this)
        });
        return;
      }
      arr = str.slice(1).split('&');
      map = {};
      for (j = 0, len = arr.length; j < len; j++) {
        kv = arr[j];
        tmp = kv.split('=');
        k = tmp[0];
        v = tmp[1];
        map[k] = v;
        if (k === 'ver') {
          map[k] = v.split('.');
        }
      }
      results = [];
      for (i = l = 0; l <= 2; i = ++l) {
        if (+window.latestVersion[i] > +map.ver[i]) {
          this.showHint({
            msg: '<span class="nowrap">您当前的版本过低</span><br><span class="nowrap">即将为您跳转到下载页</span>',
            color: 'white',
            callback: function() {
              return location.href = location.origin + "/download.html?ver=" + (window.latestVersion.join('.')) + "&_=" + (new Date().getTime());
            }
          });
          break;
        } else {
          results.push(void 0);
        }
      }
      return results;
    };

    Login.prototype.processSPW = function() {
      var spw;
      spw = localStorage.getItem('spw');
      if (spw) {
        this.els.lowlogin.addClass('checked');
        this.els.password.val(this.rememberPassword).attr('isSPW', 1);
        return this.els.login.prop('disabled', false);
      } else {
        return this.els.password.val('');
      }
    };

    Login.prototype.loadResources = function() {
      return $.ajax({
        url: this.agreementUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var els, temp;
            temp = $(data);
            els = temp.find('.platform');
            els.text(platform);
            return _this.els.agreement.append(temp);
          };
        })(this)
      });
    };

    Login.prototype.eventPassGet = function(event) {
      var closeModalBox, getBackPassword, identity, inModalBox, outModalBox, passwordNew, sideswayModalBox, speed;
      speed = 200;
      $.ajax({
        url: this.passGetUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var modalBox;
            modalBox = $(data).filter("[data-num='1']");
            _this.els.body.append(modalBox);
            modalBox.find('input.name').val(_this.els.userName.val());
            inModalBox(modalBox);
            getBackPassword(modalBox);
            return closeModalBox(modalBox);
          };
        })(this)
      });
      getBackPassword = (function(_this) {
        return function(modalBox) {
          var els;
          els = {};
          els.modify = modalBox.find('.modify');
          els.imgCode = modalBox.find('.imgCode img');
          els.name = modalBox.find('input.name');
          els.code = modalBox.find('input.code');
          els.imgCode.on('touchstart', function(event) {
            var el;
            el = $(event.currentTarget);
            el.attr('src', _this.host + "/common/verifyImage?" + (Math.random()));
          });
          els.imgCode.trigger('touchstart');
          return els.modify.on('click', function(event) {
            var data, el, name, url;
            event.preventDefault();
            el = $(event.currentTarget);
            el.prop('disabled', true);
            name = els.name.val();
            data = {};
            url = _this.host + "/members/checkUsername/" + name;
            data.verifyCode = els.code.val();
            if (!name) {
              el.prop('disabled', false);
              _this.showHint({
                msg: '账号不能为空',
                color: 'white'
              });
              return;
            }
            if (!data.verifyCode) {
              el.prop('disabled', false);
              _this.showHint({
                msg: '验证码不能为空',
                color: 'white'
              });
              return;
            } else if (data.verifyCode.length < 5) {
              el.prop('disabled', false);
              _this.showHint({
                msg: '验证码长度不符',
                color: 'white'
              });
              return;
            }
            data.varifyToken = $.cookie('valicode_token');
            return $.ajax({
              url: url,
              type: 'POST',
              contentType: 'application/json',
              dataType: 'json',
              processDate: false,
              croossDomain: true,
              headers: {
                'Content-type': 'application/json; charset=utf-8'
              },
              xhrFields: {
                'withCredentials': true
              },
              data: JSON.stringify(data),
              dataFilter: function(data) {
                var message;
                data = data.toJSON();
                if (+data.code === 0) {
                  identity(name, modalBox);
                } else if (+data.code === 1) {
                  _this.showAlert(data.message);
                } else if (+data.code === 2) {
                  message = data.message.split('，');
                  message = message[0] + ",<br />" + message[1] + message[2];
                  _this.showHint({
                    msg: message,
                    color: 'white'
                  });
                } else if (+data.code < 0) {
                  _this.showHint({
                    msg: data.message,
                    color: 'white'
                  });
                }
                if (+data.code !== 0) {
                  el.prop('disabled', false);
                  return els.imgCode.trigger('touchstart');
                }
              }
            });
          });
        };
      })(this);
      identity = (function(_this) {
        return function(name, firstModalBox) {
          return setTimeout(function() {
            return $.ajax({
              url: _this.passGetUrl,
              dataType: 'text',
              success: function(data) {
                var addQuestion, els, modalBox;
                modalBox = $(data).filter("[data-num='2']");
                _this.els.body.append(modalBox);
                sideswayModalBox(firstModalBox, modalBox);
                closeModalBox(modalBox);
                els = {};
                els.problem = modalBox.find('.problem h4');
                els.answer = modalBox.find('.answer input');
                els.modify = modalBox.find('.modify');
                addQuestion = ['你童年时代的绰号是什么？', '你最喜欢的歌手是谁？', '你最喜欢的电影的名字？', '你少年时代最好的朋友叫什么名字？', '你最喜欢哪个球队？', '你最喜欢的活动是什么？', '你的理想工作是什么？', '你的初恋叫什么名字？', '你第一次坐飞机是去哪里？', '你最喜欢的老师叫什么名字？', '你最喜欢吃的菜叫什么？', '你最喜欢哪个国家？', '你的爸爸叫什么？', '你的妈妈叫什么？', '你的爷爷叫什么？', '你的奶奶叫什么？', '喜欢什么动物啊？', '每天怎么上班的？'];
                $.ajax({
                  url: _this.host + "/members/findPassGetQuestions/" + name,
                  type: 'GET',
                  contentType: 'application/json',
                  dataType: 'json',
                  crossDomain: true,
                  headers: {
                    'Content-type': 'application/json; charset=utf-8'
                  },
                  xhrFields: {
                    'withCredentials': true
                  },
                  dataFilter: function(data) {
                    data = data.toJSON();
                    return $.each(data, function(i, k) {
                      return els.problem.eq(i).text("问" + (i + 1) + ": " + addQuestion[k]).attr('data-number', k);
                    });
                  }
                });
                return els.modify.on('click', function(event) {
                  event.preventDefault();
                  data = {};
                  data.q1 = els.problem.eq(0).attr('data-number');
                  data.q2 = els.problem.eq(1).attr('data-number');
                  data.q3 = els.problem.eq(2).attr('data-number');
                  data.answer1 = els.answer.eq(0).val();
                  data.answer2 = els.answer.eq(1).val();
                  data.answer3 = els.answer.eq(2).val();
                  if (!(data.answer1 && data.answer2 && data.answer3)) {
                    _this.showHint({
                      msg: '请输入答案',
                      color: 'white'
                    });
                  }
                  return $.ajax({
                    url: _this.host + "/members/findPassAnswerQuestions/" + name,
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    processDate: false,
                    croossDomain: true,
                    headers: {
                      'Content-type': 'application/json; charset=utf-8'
                    },
                    xhrFields: {
                      'withCredentials': true
                    },
                    data: JSON.stringify(data),
                    dataFilter: function(data) {
                      data = data.toJSON();
                      if (data.code === 0) {
                        return passwordNew(name, modalBox);
                      } else if (data.code < 0) {
                        return _this.showHint({
                          msg: data.message,
                          color: 'white'
                        });
                      }
                    }
                  });
                });
              }
            });
          }, speed);
        };
      })(this);
      passwordNew = (function(_this) {
        return function(name, firstModalBox) {
          return setTimeout(function() {
            return $.ajax({
              url: _this.passGetUrl,
              dataType: 'text',
              success: function(data) {
                var els, intensityNumber, modalBox;
                modalBox = $(data).filter("[data-num='3']");
                _this.els.body.append(modalBox);
                sideswayModalBox(firstModalBox, modalBox);
                closeModalBox(modalBox);
                els = {};
                els.password1 = modalBox.find('.password1');
                els.password2 = modalBox.find('.password2');
                els.modify = modalBox.find('.modify');
                els.intensity = modalBox.find('.intensity');
                intensityNumber = 0;
                els.password1.on('keyup', function(event) {
                  var el, enoughRegex, mediumRegex, strongRegex;
                  el = $(event.currentTarget);
                  strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
                  mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
                  enoughRegex = new RegExp("(?=.{6,}).*", "g");
                  if (false === enoughRegex.test(el.val())) {
                    els.intensity.text('弱').css({
                      background: '#d74241',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 1;
                  } else if (strongRegex.test(el.val())) {
                    els.intensity.text('强').css({
                      background: '#8fc31f',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 3;
                  } else if (mediumRegex.test(el.val())) {
                    els.intensity.text('中').css({
                      background: '#f19a38',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 2;
                  } else {
                    els.intensity.text('弱').css({
                      background: '#d74241',
                      color: 'rgba( 255, 255, 255, 1)',
                      opacity: 1
                    });
                    intensityNumber = 1;
                  }
                });
                return els.modify.on('click', function(event) {
                  event.preventDefault();
                  if (els.password1.val().length < 6) {
                    return _this.showHint({
                      msg: '密码长度为6~16位',
                      color: 'white'
                    });
                  }
                  if (els.password1.val() !== els.password2.val()) {
                    return _this.showHint({
                      msg: '两次密码不一致',
                      color: 'white'
                    });
                  }
                  data = {};
                  data.safeLevel = intensityNumber;
                  data.newPwd = els.password1.val().md5();
                  return $.ajax({
                    url: _this.host + "/members/findPassResetPwd/" + name,
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    processDate: false,
                    corrssDomain: true,
                    headers: {
                      'Content-type': 'application/json; charset=utf-8'
                    },
                    xhrFields: {
                      'withCredentials': true
                    },
                    data: JSON.stringify(data),
                    dataFilter: function(data) {
                      data = data.toJSON();
                      if (data.code === 0) {
                        outModalBox(modalBox);
                        return _this.showHint({
                          msg: data.message,
                          color: 'white'
                        });
                      }
                    }
                  });
                });
              }
            });
          }, speed);
        };
      })(this);
      closeModalBox = (function(_this) {
        return function(modalBox) {
          var close;
          close = modalBox.find('.goBack');
          return close.on('touchstart', function() {
            return outModalBox(modalBox);
          });
        };
      })(this);
      inModalBox = (function(_this) {
        return function(modalBox, num) {
          return modalBox.animate({
            top: '0%',
            opacity: '1'
          }, speed);
        };
      })(this);
      outModalBox = (function(_this) {
        return function(modalBox) {
          return modalBox.animate({
            opacity: 0
          }, speed, function() {
            return modalBox.remove();
          });
        };
      })(this);
      return sideswayModalBox = (function(_this) {
        return function(first, after) {
          first.animate({
            left: '-100%',
            opacity: 0
          }, speed, function() {
            return setTimeout((function() {
              return first.remove();
            }), 200);
          });
          return after.animate({
            left: 0,
            opacity: 1
          }, speed);
        };
      })(this);
    };

    Login.prototype.eventInputFocus = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      if (el.val()) {
        return x.show();
      }
    };

    Login.prototype.eventInputKeyup = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      x.toggle(!!el.val());
      return this.checkValid();
    };

    Login.prototype.eventInputBlur = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      return setTimeout((function() {
        return x.hide();
      }), 20);
    };

    Login.prototype.checkValid = function() {
      var state;
      state = this.els.userName.val() && this.els.password.val();
      return this.els.login.prop('disabled', !state);
    };

    Login.prototype.eventClearText = function(event) {
      var el, x;
      x = $(event.currentTarget);
      el = x.prev('input');
      return el.val('').focus();
    };

    Login.prototype.eventLogin = function(event) {
      var data, el, i, j, n, pw, ref;
      event.preventDefault();
      el = $(event.currentTarget);
      if (this.els.password.attr('isSPW') && +this.rememberPassword === +this.els.password.val()) {
        pw = localStorage.getItem('spw').fromBase64().split('').slice(1);
        for (i = j = 0, ref = pw.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
          if (!(i % 2 - 1)) {
            continue;
          }
          n = pw[i];
          if (n === '.') {
            n = 0;
          } else {
            n = 1 + parseInt(n, 36);
            n = n.toString(36);
          }
          pw[i] = n;
        }
        pw = pw.join('');
      } else {
        pw = this.els.password.val().md5();
      }
      data = {
        userName: this.els.userName.val(),
        password: pw
      };
      el.prop('disabled', true);
      return this.login(data);
    };

    Login.prototype.login = function(data) {
      var hintEl, isInitPwd, password, username;
      hintEl = this.showHint({
        msg: '登录中...',
        color: 'white',
        type: 'loading',
        duration: Infinity
      });
      isInitPwd = data.password === 'x123456'.md5();
      password = data.password;
      username = data.userName;
      return $.ajax({
        url: this.host + this.url,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processData: false,
        crossDomain: true,
        headers: {
          'Content-Type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        data: JSON.stringify(data),
        dataFilter: (function(_this) {
          return function(data) {
            var fun, i, j, n, ref, temp;
            fun = hintEl.data('hide');
            fun();
            temp = data.toJSON();
            if (+temp.code !== 0) {
              _this.showHint({
                msg: temp.message
              });
              _this.defaults();
              return '{}';
            }
            localStorage.setItem('isLocal', _this.isLocal);
            localStorage.setItem('username', username);
            if (_this.els.lowlogin.hasClass('checked')) {
              password = ("." + password).split('');
              for (i = j = 0, ref = password.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
                if (!(i % 2)) {
                  continue;
                }
                n = parseInt(password[i], 36);
                if (n) {
                  --n;
                  n = n.toString(36);
                } else {
                  n = '.';
                }
                password[i] = n;
              }
              password = password.join('').toBase64();
              localStorage.setItem('spw', password);
            } else {
              localStorage.removeItem('spw');
            }
            if (temp.data) {
              localStorage.setItem('balance', temp.data.Balance);
              localStorage.setItem('rebate', temp.data.RebetRate);
              localStorage.setItem('userID', temp.data.UserID);
              localStorage.setItem('userType', temp.data.UserType);
              localStorage.setItem('stargetID', temp.data.LoginToken);
              localStorage.setItem('isInitPwd', +isInitPwd);
              if (temp.data.Notice) {
                localStorage.setItem('notice', temp.data.Notice);
              }
              localStorage.setItem('dfMonthActivityPop', 1);
              if (isInitPwd) {
                _this.els.agreement.css({
                  top: '0%',
                  opacity: 1
                });
                _this.els.agree.on('click', function() {
                  return _this.eventAgreeLogin();
                });
              } else {
                _this.eventAgreeLogin();
              }
            }
            return data;
          };
        })(this),
        error: (function(_this) {
          return function() {
            var fun;
            _this.showHint({
              msg: '服务器暂时无法访问<br>请检查网络连接'
            });
            fun = hintEl.data('hide');
            return fun();
          };
        })(this)
      });
    };

    Login.prototype.eventAgreeLogin = function() {
      var isLogin, x;
      isLogin = true;
      x = location.search.slice(1).split('&');
      x.map((function(_this) {
        return function(current, index) {
          var c;
          c = current.split('=');
          if (c[0] === 'backUrl') {
            isLogin = false;
            location.href = "" + location.origin + (decodeURIComponent(c[1])) + (_this.isLocal ? '?test=1' : '');
          }
        };
      })(this));
      if (isLogin) {
        return location.href = location.origin + "/index.html";
      }
    };

    Login.prototype.InputEach = function(input, button) {
      var _BtnTrue;
      _BtnTrue = this._BtnTrue;
      input.each(function() {
        if ($(this).val() && _BtnTrue) {
          button.css('color', '#fff');
          return true;
        } else {
          button.removeAttr('style');
        }
      });
    };

    Login.prototype.showHint = function(param) {
      var target;
      if (param.speed == null) {
        param.speed = 200;
      }
      if (param.duration == null) {
        param.duration = 2000;
      }
      target = $("<div class=\"hint\">\n	<p style=\"" + (param.color ? 'color: ' + param.color + ';' : '') + "\">\n		" + (param.type === 'loading' ? '<img class="icon icon-spin icon-fast" src="/images/loading.png"/>' : '') + "\n		<label>" + (param.msg.encodeHTML(true)) + "</label>\n	</p>\n</div>");
      target.appendTo('body').data('hide', function() {
        clearTimeout(target.data('timeout'));
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, param.speed, function() {
          target.remove();
          return typeof param.callback === "function" ? param.callback() : void 0;
        });
      }).css({
        marginTop: '-0.32rem',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, param.speed, function() {
        return target.removeAttr('style');
      });
      if (param.duration !== Infinity) {
        target.data('timeout', setTimeout(function() {
          var fun;
          fun = target.data('hide');
          return fun();
        }, param.duration));
      }
      return target;
    };

    Login.prototype.showAlert = function(obj, code) {
      var speed, target;
      speed = 200;
      target = $("<div class=\"modal-backdrop fade in\" style=\"z-index: 1510;\"></div>\n<div class=\"modal modal-alert fade in\" tabindex=\"-1\" style=\"z-index: 1511;\">\n	<div class=\"modal-dialog\">\n		<div class=\"modal-content\">\n			<div class=\"modal-header\">\n				<button type=\"button\" class=\"close icon\" data-dismiss=\"modal\">×</button>\n				<h3>温馨提示</h3>\n			</div>\n			<div class=\"modal-body\">\n				<p>" + obj + "</p>\n			</div>\n			<div class=\"modal-footer\">\n				<button class=\"btn btn-primary\" btn-type=\"ok\" data-dismiss=\"modal\">知道了</button>\n			</div>\n		</div>\n	</div>\n</div>");
      return target.appendTo('body').css({
        marginTop: '-0.32rem',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, speed).on('click', '.close', function() {
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, function() {
          return target.remove();
        });
      }).on('click', '.btn', function() {
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, function() {
          return target.remove();
        });
      });
    };

    Login.prototype.eventslideUnlock = function() {
      var eLwidth, startPoint, startX;
      startPoint = startX = eLwidth = 0;
      this.els.slideLeft.on('touchstart', (function(_this) {
        return function(event) {
          var el;
          el = $(event.currentTarget);
          eLwidth = el.width() / 2;
          el.css('transition', 'none');
          _this.els.slideShade.css('transition', 'none');
          _this.maxW = _this.els.slide.width() - el.width();
          startPoint = event.originalEvent.touches[0].clientX;
          startX = _this.cssTransform(el, 'translateX');
        };
      })(this));
      this.els.slideLeft.on('touchmove', (function(_this) {
        return function(event) {
          var dis, el, left, nowPoint;
          if (_this._BtnTrue) {
            return;
          }
          el = $(event.currentTarget);
          event.preventDefault();
          nowPoint = event.originalEvent.touches[0].clientX;
          dis = nowPoint - startPoint;
          left = startX + dis;
          if (left <= 0) {
            left = 0;
          }
          if (left >= _this.maxW) {
            left = _this.maxW;
          }
          _this.cssTransform(el, 'translateX', left);
          _this.els.slideShade.css('width', left + eLwidth);
        };
      })(this));
      return this.els.slideLeft.on('touchend', (function(_this) {
        return function(event) {
          var el, left;
          el = $(event.currentTarget);
          left = _this.cssTransform(el, 'translateX');
          if (left < _this.maxW - _this.maxW * 0.02) {

          } else {
            _this.cssTransform(el, 'translateX', _this.maxW);
            el.css('backgroundImage', 'url("../../images/login/braceSuccess.png")');
            _this._BtnTrue = true;
            _this.checkValid();
          }
        };
      })(this));
    };

    Login.prototype.errorLock = function(obj) {
      obj.css('transition', '0.5s');
      this.cssTransform(obj, 'translateX', 0);
      return this.els.slideShade.css({
        transition: '0.6s',
        width: 0
      });
    };

    Login.prototype.cssLinearGradient = function(obj) {
      var iLeft, oTimer, text, toMove;
      text = obj;
      oTimer = null;
      iLeft = -3;
      toMove = function() {
        return setTimeout(function() {
          text.css({
            transition: '4.5s',
            backgroundPosition: '4rem 0rem'
          });
        }, 1000);
      };
      toMove();
      setInterval(function() {
        toMove();
        return text.css({
          transition: 'none',
          backgroundPosition: '-3rem 0rem'
        });
      }, 3000);
    };

    Login.prototype.getServerTime = function() {
      return $.ajax({
        url: location.origin + "/fapi/time",
        contentType: 'application/json',
        dataType: 'json',
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        dataFilter: (function(_this) {
          return function(data) {
            var sDate, stdv;
            sDate = new Date(data.toJSON().data);
            _this.serverTimeDV = stdv = sDate.getTime() - new Date().getTime();
            return localStorage.setItem('serverTimeDV', stdv);
          };
        })(this)
      });
    };

    Login.prototype.eventPasswordChanged = function(event) {
      var el;
      el = $(event.currentTarget);
      return el.removeAttr('isSPW');
    };

    Login.prototype.eventPasswordFocus = function(event) {
      var el;
      el = $(event.currentTarget);
      return el.setSelection(0);
    };

    Login.prototype.eventToggleLowLogin = function(event) {
      event.preventDefault();
      return this.els.lowlogin.toggleClass('checked');
    };

    Login.prototype.eventAgreementClose = function() {
      this.els.agreement.css({
        top: '100%',
        opacity: 0
      });
      return this.defaults();
    };

    Login.prototype.defaults = function() {
      this.els.login.prop('disabled', false);
      this._BtnTrue = false;
      this.checkValid();
      this.els.password.val('');
      $('.ncpt_slide_fg span').css({
        'backgroundImage': "url('images/login/brace.png')"
      });
      return this.ins.refresh();
    };

    Login.prototype.nec = function() {
      var height, nec, opts, width;
      height = "0.8rem";
      width = this.els.userName.outerWidth(true);
      nec = {};
      return opts = {
        'element': 'slide',
        'captchaId': getCaptchaId(),
        'width': width,
        'verifyCallback': (function(_this) {
          return function(ret) {
            if (ret['value']) {
              _this._BtnTrue = true;
              _this.checkValid();
              nec.btnFg.find('span').css({
                'backgroundImage': "url('images/login/braceSuccess.png')"
              });
            } else {
              nec.btnFg.find('span').css({
                'backgroundImage': "url('images/login/braceWrong.png')"
              });
              setTimeout(function() {
                return nec.btnFg.find('span').css({
                  'backgroundImage': "url('images/login/brace.png')"
                });
              }, 1000);
            }
          };
        })(this),
        'initCallback': (function(_this) {
          return function() {
            var btn;
            btn = $('<span class="icon"></span>');
            btn.css({
              backgroundImage: "url('images/login/brace.png')"
            });
            nec.bgWrap = _this.els.slideWrap.find('.ncpt_widget');
            nec.bg = _this.els.slideWrap.find('.ncpt_slide_bg');
            nec.text = _this.els.slideWrap.find('.ncpt_hint_txt');
            nec.btnFg = _this.els.slideWrap.find('.ncpt_slide_fg');
            nec.btnFgImg = nec.btnFg.find('img');
            nec.imgBg = _this.els.slideWrap.find('.ncpt_puzzle_bg');
            nec.imgfG = _this.els.slideWrap.find('.ncpt_puzzle_fg');
            nec.iframe = _this.els.slideWrap.find('.ncpt_win_iframe');
            nec.bg.css({
              height: height,
              borderRadius: '50px'
            });
            nec.bgWrap.css({
              height: height
            });
            nec.text.text('请拖动滑块完成拼图 >').css({
              height: height,
              lineHeight: height
            }).addClass('text');
            nec.btnFg.css({
              top: '0.08rem',
              padding: '0 0.08rem'
            }).append(btn);
            nec.btnFgImg.css('display', 'none');
            nec.btnFg.on('touchstart', function() {
              nec.imgBg.css({
                top: '-1rem'
              });
              nec.imgfG.css({
                top: '-1rem'
              });
              return nec.iframe.css({
                width: 0,
                height: 0
              });
            });
            return _this.cssLinearGradient(nec.text);
          };
        })(this)
      };
    };

    Login.prototype.cssTransform = function(el, attr, val) {
      var ref, s, sVal;
      el = el.get(0);
      if (!el.transform) {
        el.transform = {};
      }
      if (arguments.length > 2) {
        el.transform[attr] = val;
        sVal = '';
        ref = el.transform;
        for (s in ref) {
          if (!hasProp.call(ref, s)) continue;
          switch (s) {
            case 'rotate':
            case 'skewX':
            case 'skewY':
              sVal += s + "(" + el.transform[s] + "deg)";
              break;
            case 'translateX':
            case 'translateY':
            case 'translateZ':
              sVal += s + "(" + el.transform[s] + "px)";
              break;
            case 'scaleX':
            case 'scaleY':
            case 'scaleZ':
              sVal += s + "(" + el.transform[s] + ")";
          }
          el.style.transform = sVal;
        }
      } else {
        val = el.transform[attr];
        if (typeof val === 'undefined') {
          if (/^scale[XY]?$/.test(attr)) {
            val = 1;
          } else {
            val = 0;
          }
        }
        return val;
      }
    };

    return Login;

  })();

  $.fn.extend({

    /*
    	  * 设置光标选中文本
    	  * @param selectionStart [Number] 开始下标
    	  * @param selectionEnd [Number] 结束下标
     */
    setSelection: function(selectionStart, selectionEnd) {
      var input, range;
      if (this.lengh === 0) {
        return this;
      }
      input = this[0];
      if (!selectionEnd) {
        selectionEnd = this.val().length;
      }
      if (input.createTextRange) {
        range = input.createTextRange();
        range.collapse(true);
        range.moveEnd('character', selectionEnd);
        range.moveStart('character', selectionStart);
        range.select();
      } else if (input.setSelectionRange) {
        input.focus();
        input.setSelectionRange(selectionStart, selectionEnd);
      }
      return this;
    }
  });

  new Login();

  return;

}).call(this);
