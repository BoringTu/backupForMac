(function() {
  var download, fix,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.md5 = function() {
    return md5.apply(null, [this].concat([].slice.apply(arguments)));
  };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  String.prototype.encodeHTML = String.prototype.encodeHTML || function() {
    var encodeHTMLRules, matchHTML;
    encodeHTMLRules = {
      "&": "&#38;",
      "<": "&#60;",
      ">": "&#62;",
      '"': '&#34;',
      "'": '&#39;',
      "/": '&#47;'
    };
    matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
    if (this) {
      return this.replace(matchHTML, function(m) {
        return encodeHTMLRules[m] || m;
      });
    } else {
      return this;
    }
  };

  fix = location.hostname.match(/(?:^\w+\.|)(\w+)(?:\.\w+$)/);

  fix = fix[1].toLowerCase();

  fix = /test/.test(fix) ? 'rg' : fix.replace(/\d|dev|pvw/g, '');

  download = (function() {
    function download() {
      this.showHint = bind(this.showHint, this);
      this.showIosExplain = bind(this.showIosExplain, this);
      this.box2AnimteOut = bind(this.box2AnimteOut, this);
      this.box2AnimteInit = bind(this.box2AnimteInit, this);
      this.box2Init = bind(this.box2Init, this);
      this.showIssuesAlert = bind(this.showIssuesAlert, this);
      this.box3Init = bind(this.box3Init, this);
      this.initialize = bind(this.initialize, this);
      this.els = {};
      this.els.body = $('body');
      this.els.container = $('.swiper-container.box1');
      this.els.back = this.els.body.find('.back');
      this.els.slide = this.els.container.find('.swiper-slide');
      this.els.buttonPrev = this.els.container.find('.swiper-button-prev');
      this.els.buttonNext = this.els.container.find('.swiper-button-next');
      this.els.downloadBtn = this.els.container.find('.downloadBtn');
      this.els.one = this.els.container.find('.one');
      this.els.rounds = this.els.one.find('.imgsHierarchy div');
      this.els.dlIssues = this.els.one.find('.downloadIssues');
      this.els.iOSSetup = this.els.one.find('.iOSSetup');
      this.els.two = this.els.container.find('.two');
      this.els.phoneImg = this.els.two.find('.phone img');
      this.els.twoLi = this.els.two.find('.phone ul li');
      this.els.three = this.els.container.find('.three');
      this.els.content = this.els.three.find('.content');
      this.els.box3 = $('.box3');
      this.els.explain = this.els.box3.find('.explain');
      this.els.plat = $('.platform');
      this.els.back.on('touchstart', this.eventGoBack);
      this.els.dlIssues.on('touchstart', this.showIssuesAlert);
      this.els.iOSSetup.on('touchstart', this.showIosExplain);
      this.els.phoneImg.attr('src', "/images/download/phone-" + fix + ".png");
      this.isThree = false;
      this.box2 = null;
      setTimeout((function(_this) {
        return function() {
          return _this.initialize();
        };
      })(this), 200);
      this.box2Init();
      this.checkAppVersion();
    }

    download.prototype.eventGoBack = function() {
      window.history.back();
      return false;
    };

    download.prototype.checkAppVersion = function() {
      var arr, i, k, kv, len, map, name, path, str, tmp, ua, v;
      str = location.search;
      if (!(str || window.latestVersion)) {
        $.ajax({
          url: location.origin + "/fapi/appLatestVersion",
          dataType: 'json',
          contentType: 'application/json',
          dataFilter: (function(_this) {
            return function(data) {
              window.latestVersion = data.toJSON().data.version;
              _this.checkAppVersion();
              return '{}';
            };
          })(this)
        });
        return;
      }
      if (!window.latestVersion) {
        arr = str.slice(1).split('&');
        map = {};
        for (i = 0, len = arr.length; i < len; i++) {
          kv = arr[i];
          tmp = kv.split('=');
          k = tmp[0];
          v = tmp[1];
          if (k === 'ver') {
            window.latestVersion = v;
            break;
          }
        }
      }
      ua = navigator.userAgent.toLowerCase();
      if (/iphone|ipad|ipod/.test(ua)) {
        console.log("iphone");
        switch (fix) {
          case 'xh':
            name = 'xinhuang';
            break;
          case 'df':
            name = 'dongfan';
        }
        path = "https://fir.im/" + name;
        return this.els.downloadBtn.attr({
          href: path

          /*
          			@els.downloadBtn.on 'touchstart', =>
          				@showHint 'ios开发中，正在为您跳转到登录页...', ->
          					location.href	= "#{ location.origin }/login.html"
          				, 3000
           */
        });
      } else if (/android/.test(ua)) {
        console.log("android");
        name = fix + "-" + (/arm|aarch64/i.test(navigator.platform) ? 'arm' : 'x86') + "-" + window.latestVersion + ".apk";
        path = 'http://app.109xh.com/';
        path += name;
        return this.els.downloadBtn.attr({
          href: path,
          download: name
        });
      }
    };

    download.prototype.toggleLandscape = function() {
      var orientation;
      orientation = window.orientation;
      if (orientation !== void 0) {
        this[orientation === 0 ? 'hideLandscape' : 'showLandscape']();
      }
      return orientation;
    };

    download.prototype.showLandscape = function() {
      return this.landscape.show();
    };

    download.prototype.hideLandscape = function() {
      return this.landscape.hide();
    };

    download.prototype.initialize = function() {
      var firstScreenInit, firstScreenOut, isFalse, secondScreenInit, secondScreenOut, speed, thirdScreenInit;
      this.landscape = $(' .notice-for-landscape');
      if (this.toggleLandscape() !== void 0) {
        window.addEventListener('orientationchange', (function(_this) {
          return function() {
            return _this.toggleLandscape();
          };
        })(this));
      }
      firstScreenOut = (function(_this) {
        return function() {
          _this.els.rounds.eq(0).removeClass('clockwise');
          _this.els.rounds.eq(1).removeClass('antiClockwise');
          _this.els.rounds.eq(2).removeClass('clockwise2');
          _this.els.buttonNext.removeClass('goods');
          return setTimeout(function() {
            return _this.els.rounds.eq(4).removeClass('aRound');
          }, 1000);
        };
      })(this);
      secondScreenOut = (function(_this) {
        return function() {
          return _this.els.twoLi.attr({
            'style': {
              'opacity': 0
            }
          }).removeClass('goods');
        };
      })(this);
      firstScreenInit = (function(_this) {
        return function() {
          secondScreenOut();
          _this.els.rounds.eq(0).addClass('clockwise');
          _this.els.rounds.eq(1).addClass('antiClockwise');
          _this.els.rounds.eq(2).addClass('clockwise2');
          _this.els.buttonNext.addClass('goods');
          _this.els.twoLi.stop();
          return setTimeout(function() {
            return _this.els.rounds.eq(4).addClass('aRound');
          }, 1000);
        };
      })(this);
      secondScreenInit = (function(_this) {
        return function() {
          firstScreenOut();
          if (_this.isThree) {
            _this.box2AnimteOut();
          }
          $('.fade').hide();
          return setTimeout(function() {
            var init;
            init = function(els) {
              return els.animate({
                'opacity': 1
              }).addClass('goods');
            };
            init(_this.els.twoLi.eq(0));
            setTimeout(function() {
              return init(_this.els.twoLi.eq(1));
            }, 400);
            return setTimeout(function() {
              return init(_this.els.twoLi.eq(2));
            }, 600);
          }, 0);
        };
      })(this);
      thirdScreenInit = (function(_this) {
        return function() {
          _this.els.twoLi.stop();
          _this.isThree = true;
          secondScreenOut();
          _this.box2AnimteInit(_this.box2);
          if (_this.box2 === _this.els.box2Two) {
            return _this.els.box2Middle.css({
              'transform': 'scale(1)'
            });
          }
        };
      })(this);
      this.swiper1 = new Swiper('.box1', {
        direction: 'vertical',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        initialSlide: 0,
        onSlideChangeEnd: (function(_this) {
          return function(swiper) {
            if (swiper.progress !== 0) {
              swiper.nextButton[0].style.display = 'none';
            } else {
              swiper.nextButton[0].style.display = 'block';
            }
            switch (+swiper.progress) {
              case -0:
                return firstScreenInit();
              case 0.5:
                return secondScreenInit();
              case 1:
                return thirdScreenInit();
            }
          };
        })(this)
      });
      speed = 200;
      isFalse = false;
      this.els.twoLi.eq(0).on('touchstart', (function(_this) {
        return function() {
          _this.swiper1.slideNext(isFalse);
          _this.swiper2.slideTo(0, speed, isFalse);
          _this.isThree = true;
          return _this.box2AnimteInit(_this.els.box2One);
        };
      })(this));
      this.els.twoLi.eq(1).on('touchstart', (function(_this) {
        return function() {
          _this.swiper1.slideNext(isFalse);
          _this.swiper2.slideTo(1, speed, isFalse);
          _this.isThree = true;
          _this.box2AnimteInit(_this.els.box2Two);
          return _this.els.box2Middle.css({
            'transform': 'scale(1)'
          });
        };
      })(this));
      this.els.twoLi.eq(2).on('touchstart', (function(_this) {
        return function() {
          _this.swiper1.slideNext(isFalse);
          _this.swiper2.slideTo(2, speed, isFalse);
          _this.box2AnimteInit(_this.els.box2Three);
          return _this.isThree = true;
        };
      })(this));
      firstScreenInit();
      return this.box3Init();
    };

    download.prototype.box3Init = function() {
      return new Swiper('.box3', {
        pagination: '.swiper-pagination',
        initialSlide: 0,
        effect: 'fade'
      });
    };

    download.prototype.showIssuesAlert = function() {
      var speed, target;
      speed = 200;
      target = $("<div class=\"modal-backdrop fade in\" style=\"z-index: 1510;\"></div>\n<div class=\"modal modal-alert fade in\" tabindex=\"-1\" style=\"z-index: 1511;\">\n	<div class=\"modal-dialog\">\n		<div class=\"modal-content\">\n			<div class=\"modal-header\">\n				<h3>常见问题</h3>\n			</div>\n			<div class=\"modal-body\">\n				<p  class=\"clear\" ><i></i><span>请查看您设备是否启用了移动网络或WiFi连接</span></p>\n				<p  class=\"clear\" ><i></i><span>如下载中断导致安装失败，请删除旧的APP后重新扫码下载</span></p>\n				<p  class=\"clear\" ><i></i><span>iPhone系统版本低于8.0或进行过越狱操作，可能导致安装失败</span></p>\n				<p  class=\"clear\" ><i></i><span>如始终无法正常下载安装，请联系客服并提供您的手机型号和系统版本，我们将第一时间为您解决问题</span></p>\n			</div>\n			<div class=\"modal-footer\">\n				<button class=\"btn btn-primary\" btn-type=\"ok\" data-dismiss=\"modal\">我知道了</button>\n			</div>\n		</div>\n	</div>\n</div>");
      return target.appendTo(this.els.one).css({
        marginTop: '-0.32rem',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, speed).on('click', '.close', function() {
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, function() {
          return target.remove();
        });
      }).on('click', '.btn', function() {
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, function() {
          return target.remove();
        });
      });
    };

    download.prototype.box2Init = function() {
      this.els.box2 = $("<div class=\"swiper-container box2\">\n	<div class=\"swiper-wrapper\">\n		<div class=\"swiper-slide one\">\n			<div class=\"layer\">\n				<div class=\"bg imgs\"></div>\n				<div class=\"interface imgs\">\n					<div class=\"leftBox1 left boxTitle\">\n						<span>精彩活动</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"rightBox1 right boxTitle\">\n						<span>众多彩种</span>\n						<i class=\"imgs\"></i>\n					</div>\n				</div>\n			</div>\n		</div>\n		<div class=\"swiper-slide two\">\n			<div class=\"layer\">\n				<div class=\"bg imgs\"></div>\n				<div class=\"interface imgs\">\n					<div class=\"leftBox1 left boxTitle\">\n						<span>快捷选号</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"leftBox2 left boxTitle\">\n						<span>精确选倍</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"rightBox1 right boxTitle\">\n						<span>玩法切换</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"rightBox2 right boxTitle\">\n						<span>批量购彩</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"middle imgs\"></div>\n				</div>\n			</div>\n		</div>\n		<div class=\"swiper-slide three\">\n			<div class=\"layer\">\n				<div class=\"bg imgs\"></div>\n				<div class=\"interface imgs\">\n					<div class=\"leftBox1 left boxTitle\">\n						<span>完整体验</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"rightBox1 right boxTitle\">\n						<span>盈利走势</span>\n						<i class=\"imgs\"></i>\n					</div>\n					<div class=\"rightBox2 right boxTitle\">\n						<span>移动客服</span>\n						<i class=\"imgs\"></i>\n					</div>\n				</div>\n			</div></div>\n	</div>\n	<div class=\"swiper-pagination\"></div>\n</div>");
      this.els.content.append(this.els.box2);
      this.els.box2One = this.els.content.find('.one');
      this.els.box2Two = this.els.content.find('.two');
      this.els.box2Middle = this.els.box2Two.find('.middle');
      this.els.box2Three = this.els.content.find('.three');
      this.box2 = this.els.box2One;
      return setTimeout((function(_this) {
        return function() {
          return _this.swiper2 = new Swiper('.box2', {
            pagination: '.swiper-pagination',
            initialSlide: 0,
            onSlideChangeEnd: function(swiper) {
              _this.box2AnimteOut();
              if (+swiper.progress === 0) {
                return _this.box2AnimteInit(_this.els.box2One);
              } else if (+swiper.progress === 0.5) {
                _this.box2AnimteInit(_this.els.box2Two);
                return _this.els.box2Middle.css({
                  'transform': 'scale(1)'
                });
              } else if (+swiper.progress === 1) {
                return _this.box2AnimteInit(_this.els.box2Three);
              }
            }
          });
        };
      })(this), 200);
    };

    download.prototype.box2AnimteInit = function(els) {
      if (els) {
        delete this.els.left;
        delete this.els.right;
        this.box2 = els;
      } else {
        return false;
      }
      return setTimeout((function(_this) {
        return function() {
          _this.els.left = els.find('.left');
          _this.els.right = els.find('.right');
          _this.els.left.css({
            'transition': '0.5s'
          });
          _this.els.right.css({
            'transition': '0.5s'
          });
          return setTimeout(function() {
            _this.els.left.css({
              'clip': 'rect(0, 1.28rem, 0.64rem, 0)'
            });
            return _this.els.right.css({
              'clip': 'rect(0, 1.28rem, 0.64rem, 0)'
            });
          }, 0);
        };
      })(this), 200);
    };

    download.prototype.box2AnimteOut = function() {
      this.els.left.attr({
        'style': ' '
      });
      this.els.right.attr({
        'style': ' '
      });
      return this.els.box2Middle.css({
        'transform': 'scale(0)'
      });
    };

    download.prototype.showIosExplain = function() {
      var speed;
      speed = 200;
      this.els.box3.css({
        'visibility': 'initial'
      });
      return this.els.explain.css({
        marginTop: '-0.78rem',
        opacity: 0
      }).animate({
        marginTop: '1rem',
        opacity: 1
      }, speed).end().on('click', '.closes', (function(_this) {
        return function() {
          return _this.els.explain.animate({
            marginTop: '-0.78rem',
            opacity: 0
          }, speed, function() {
            return _this.els.box3.css({
              'visibility': 'hidden'
            });
          });
        };
      })(this));
    };

    download.prototype.showHint = function(msg, callback, duration) {
      var speed, target;
      if (duration == null) {
        duration = 2000;
      }
      speed = 200;
      target = $("<div class=\"hint\" >\n	<p style=\"color: #fff;\" >" + (msg.encodeHTML(true)) + "</p>\n</div>");
      target.appendTo('body').css({
        marginTop: '-0.32rem',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, speed, function() {
        return target.removeAttr('style');
      });
      setTimeout((function(_this) {
        return function() {
          return target.animate({
            marginTop: '-0.32rem',
            opacity: 0
          }, speed, function() {
            target.remove();
            return typeof callback === "function" ? callback() : void 0;
          });
        };
      })(this), duration);
    };

    return download;

  })();

  new download();

  return;

}).call(this);
