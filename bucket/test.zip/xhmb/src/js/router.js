(function() {
  var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  require(['jquery', 'backbone', 'views/_body', 'views/_menu', 'jcookie'], function($, Backbone, ViewBody, ViewMenu) {
    var Router;
    Router = (function(superClass) {
      extend(Router, superClass);

      function Router() {
        return Router.__super__.constructor.apply(this, arguments);
      }

      Router.prototype.routes = {
        '': 'api_default',
        ':route1st': 'api_main',
        ':route1st/:route2nd': 'api_main',
        ':route1st/:route2nd/:route3rd': 'api_main',
        '*error': 'api_404'
      };

      Router.prototype.initialize = function() {
        this.utils = CSH.utils;
        CSH.$els['body'] = $('body');
        CSH.$els['content'] = $('.content');
        CSH.$els['menu'] = $('.menu');
        CSH.views['body'] = this.body = new ViewBody();
        CSH.views['menu'] = this.menu = new ViewMenu();
        CSH.scrollToTop = function(speed) {
          if (speed == null) {
            speed = 0;
          }
          return CSH.$els['content'].animate({
            scrollTop: 0
          }, speed);
        };
        CSH.xhrPool = [];
      };

      Router.prototype.refresh = function() {
        var hash;
        hash = location.hash.replace(/^#/, '');
        hash = hash.split('/');
        this.api_main.apply(this, hash);
      };

      Router.prototype.api_default = function() {
        var routePath;
        routePath = 'home';
        if (history.replaceState) {
          history.replaceState(null, null, "#" + routePath);
          this.api_main(routePath);
        } else {
          location.hash = routePath;
        }
      };

      Router.prototype.api_main = function() {
        var route1st, str;
        if (arguments[0] === 'xxx') {
          CSH.hint('亲，试玩账户不享有该权限哦！');
          history.pushState(null, null, 'index.html#mine');
          return;
        }
        route1st = arguments[0];
        CSH.routePath = (function() {
          var i, len, results;
          results = [];
          for (i = 0, len = arguments.length; i < len; i++) {
            str = arguments[i];
            if (str) {
              results.push(str);
            }
          }
          return results;
        }).apply(this, arguments);
        console.log('CSH.routePath: ', CSH.routePath);
        _.each(CSH.xhrPool, function(xhr) {
          if (xhr.readyState > 0 && xhr.readyState < 4) {
            xhr.abort();
          }
        });
        CSH.xhrPool = [];
        CSH.scrollToTop();
        this.body.showLoading();
        $('> .modal', document.body).each(function() {
          $(this).modal('hide');
        });
        this.menu.refreshMenuStyle();
        if (route1st === '404') {
          this.body.show404();
          return;
        } else if (route1st === 'noAuthority') {
          this.body.showNoAuthority();
          return;
        }
        require([route1st ? "controllers/" + route1st : ''], (function(_this) {
          return function() {
            var ctrler, ref;
            CSH.$els['content'].removeClass((ref = _this.oldRoute) != null ? ref[0] : void 0).addClass(route1st);
            _this.oldRoute = CSH.routePath;
            _this.body.removeErrorPage();
            ctrler = CSH.controllers[route1st];
            if (ctrler) {
              ctrler();
            }
          };
        })(this), (function(_this) {
          return function() {
            console.error("Error: 404 Not Found - controllers/" + route1st);
            if (history.replaceState) {
              history.replaceState(null, null, '#404');
              return _this.api_main('404');
            } else {
              return location.hash = '#404';
            }
          };
        })(this));
      };

      Router.prototype.destroyPage = function() {
        console.info('垃圾处理');
        _.each(CSH.models, function(obj, name) {
          delete CSH.models[name];
        });
        _.each(CSH.collections, function(obj, name) {
          delete CSH.collections[name];
        });
        _.each(CSH.views, function(obj, name) {
          var base;
          if (typeof (base = CSH.views[name]).destroy === "function") {
            base.destroy();
          }
          if (!/^body$|^menu$/.test(name)) {
            delete CSH.views[name];
          }
        });
        _.each(CSH.data, function(obj, name) {
          delete CSH.views[name];
        });
        return CSH.$els['content'].empty().off();
      };

      return Router;

    })(Backbone.Router);
    CSH.router = new Router();
    Backbone.history.start();
  });

}).call(this);
