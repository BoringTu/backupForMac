(function() {
  require.config({
    urlArgs: "_=" + window.cacheCode,
    waitSeconds: 0,
    paths: {
      'jquery': '../../assets/jquery.min',
      'json2': '../../assets/json2.min',
      'base64': '../../assets/base64.min',
      'md5': '../../assets/md5.min',
      'qrcode': '../../assets/jquery.qrcode.min',
      'underscore': '../../assets/underscore.min',
      'backbone': '../../assets/backbone.min',
      'doT': '../../assets/doT.min',
      'text': '../../assets/text.min',
      'jcookie': '../../assets/jquery.cookie.min',
      'ZeroClipboard': '../../assets/ZeroClipboard/ZeroClipboard.min',
      'echarts': '../../assets/echarts/echarts.min',
      'moment': '../../assets/moment.min',
      'moment-timezone': '../../assets/moment-timezone.min',
      'datetimepicker': '../../assets/datetimepicker/js/bootstrap-datetimepicker.min',
      'swipe': '../../assets/swipe.min'
    },
    shim: {
      'backbone': {
        deps: ['jquery', 'underscore'],
        exports: 'backbone'
      },
      'jcookie': {
        deps: ['jquery'],
        exports: 'jcookie'
      },
      'qrcode': {
        deps: ['jquery'],
        exports: 'qrcode'
      },
      'swipe': {
        deps: ['jquery'],
        exports: 'swipe'
      }
    }
  });

  require(['CSH', 'common'], function(CSH, Common) {
    require(['router']);
    return Common.initialize();
  });

  return;

}).call(this);
