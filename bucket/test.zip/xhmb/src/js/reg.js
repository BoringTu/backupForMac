(function() {
  var fix, reg,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.md5 = function() {
    return md5.apply(null, [this].concat([].slice.apply(arguments)));
  };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  String.prototype.encodeHTML = String.prototype.encodeHTML || function() {
    var encodeHTMLRules, matchHTML;
    encodeHTMLRules = {
      "&": "&#38;",
      "<": "&#60;",
      ">": "&#62;",
      '"': '&#34;',
      "'": '&#39;',
      "/": '&#47;'
    };
    matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
    if (this) {
      return this.replace(matchHTML, function(m) {
        return encodeHTMLRules[m] || m;
      });
    } else {
      return this;
    }
  };

  fix = location.hostname.match(/(?:^\w+\.|)(\w+)(?:\.\w+$)/);

  fix = fix[1].toLowerCase();

  fix = /test/.test(fix) ? 'rg' : fix.replace(/\d|dev|pvw/g, '');

  reg = (function() {
    function reg() {
      this.eventClauseShow = bind(this.eventClauseShow, this);
      this.eventSee = bind(this.eventSee, this);
      this.intensity = bind(this.intensity, this);
      this.showHint = bind(this.showHint, this);
      this.demoBtn = bind(this.demoBtn, this);
      this.registerBtn = bind(this.registerBtn, this);
      this.eventRegistered = bind(this.eventRegistered, this);
      this.InputEach = bind(this.InputEach, this);
      this.geerBtn = bind(this.geerBtn, this);
      this.eventsBtnReg = bind(this.eventsBtnReg, this);
      this.eventsErrorNot = bind(this.eventsErrorNot, this);
      this.eventPass2Blur = bind(this.eventPass2Blur, this);
      this.eventpassBlur = bind(this.eventpassBlur, this);
      this.eventNameBlur = bind(this.eventNameBlur, this);
      this.eventClearText = bind(this.eventClearText, this);
      this.eventInputBlur = bind(this.eventInputBlur, this);
      this.eventInputKeyup = bind(this.eventInputKeyup, this);
      this.eventInputFocus = bind(this.eventInputFocus, this);
      this.loadAgreement = bind(this.loadAgreement, this);
      this.host = (function(_this) {
        return function() {
          var arr, i, k, kv, len, tmp;
          _this.isLocal = 0;
          arr = location.search.slice(1).split('&');
          for (i = 0, len = arr.length; i < len; i++) {
            kv = arr[i];
            tmp = kv.split('=');
            k = tmp[0];
            if (k === 'test') {
              _this.isLocal = 1;
              break;
            }
          }

          /*
          			if @isLocal
          				"#{ location.protocol }//appapi.#{ location.hostname.replace /^\w+\./, '' }"
          			else
          				location.origin + '/api'
           */
          return location.origin + "/api";
        };
      })(this)();
      this.agreementUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/agreement.tpl";
      this.url = '/openlinkaccount';
      this.urlUser = '/members/username';
      this.hash = window.location.hash.substring(1).split('/');
      this.els = {};
      this.els.regWrapper = $('.regWrapper');
      this.els.reg = $('button.reg');
      this.els.demo = $('button.demo');
      this.els.userName = $('[name="username"]');
      this.els.passWord = $('[name="password"]');
      this.els.passWord2 = $('[name="password2"]');
      this.els.regPassInput = $('.password input', this.els.regWrapper);
      this.els.intensity = $('.password .intensity', this.els.regWrapper);
      this.els.regWrapper_input = $('input', this.els.regWrapper);
      this.els.clearText = $('.clearText');
      this.els.radio = $('.radio');
      this.els.errorWrap = $('.errorWrap');
      this.els.clause_a = $('.clause a');
      this.els.agreement = $('.agreement');
      this.els.goBack = $('.goBack', this.els.agreement);
      this.els.plat = $('.platform');
      setTimeout((function(_this) {
        return function() {
          _this.els.userName.val('');
          return _this.els.passWord.val('');
        };
      })(this), 0);
      this.els.reg.on('click', this.registerBtn);
      this.els.demo.on('click', this.demoBtn);
      this.els.regPassInput.on('keyup', this.intensity);
      $('input').on('focus', this.eventInputFocus).on('blur', this.eventInputBlur).on('keyup', this.eventInputKeyup);
      this.els.userName.on('blur', this.eventNameBlur);
      this.els.passWord.on('blur', this.eventpassBlur);
      this.els.passWord2.on('blur', this.eventPass2Blur);
      this.els.clearText.on('click', this.eventClearText);
      this.els.radio.on('click', this.eventSee);
      this.els.clause_a.on('click', this.eventClauseShow);
      this.els.userName.on('keyup', this.eventRegistered);
      this.intensityNumber = 1;
      this._BtnTrue = false;
      this.els.radio.addClass('icon checked');
      this.els.radio.trigger('click');
      this.loadAgreement();
    }

    reg.prototype.loadAgreement = function() {
      return $.ajax({
        url: this.agreementUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var els, temp;
            temp = $(data);
            els = temp.find('.platform');
            els.text(platform);
            return _this.els.agreement.append(temp);
          };
        })(this)
      });
    };

    reg.prototype.eventInputFocus = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      if (el.val()) {
        return x.show();
      }
    };

    reg.prototype.eventInputKeyup = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      x.toggle(!!el.val());
      return this.checkValid();
    };

    reg.prototype.eventInputBlur = function(event) {
      var el, x;
      el = $(event.currentTarget);
      x = el.next('.clearText');
      return setTimeout((function() {
        return x.hide();
      }), 20);
    };

    reg.prototype.eventClearText = function(event) {
      var el, x;
      x = $(event.currentTarget);
      el = x.prev('input');
      return el.val('').focus();
    };

    reg.prototype.eventNameBlur = function(event) {
      var el, text, userRegex;
      el = $(event.currentTarget);
      userRegex = /^[A-Za-z]\w{5,13}$/;
      if (!el.val()) {
        text = '请设置账号';
        this.eventsErrorNot(el, text);
      } else if (!userRegex.test(el.val())) {
        text = '字母开头：6~14位字母、数字组成';
        this.eventsErrorNot(el, text);
      } else {
        this.els.errorWrap.hide();
      }
    };

    reg.prototype.eventpassBlur = function(event) {
      var el, passWordRegex, text;
      el = $(event.currentTarget);
      passWordRegex = /^\S{6,20}$/;
      if (!el.val()) {
        text = '请设置密码';
        return this.eventsErrorNot(el, text);
      } else if (!passWordRegex.test(el.val())) {
        text = '密码6位数字或英文字母以上,12位以下';
        return this.eventsErrorNot(el, text);
      } else {
        return this.els.errorWrap.hide();
      }
    };

    reg.prototype.eventPass2Blur = function(evnet) {
      var el, text;
      el = $(event.currentTarget);
      if (!el.val()) {
        text = '请再次输入密码';
        return this.eventsErrorNot(el, text);
      } else if (this.els.passWord.val() !== el.val()) {
        text = '输入的两次密码不同';
        return this.eventsErrorNot(el, text);
      } else {
        return this.els.errorWrap.hide();
      }
    };

    reg.prototype.eventsErrorNot = function(el, text) {
      var left, top;
      top = el.offset().top + el.height() * 0.8;
      left = el.offset().left + parseFloat(el.css('padding-left'));
      this.els.errorWrap.css({
        top: top,
        left: left,
        display: 'block'
      }).text(text);
    };

    reg.prototype.eventsBtnReg = function(el, text) {
      var left, top;
      top = el.offset().top + el.height() * 0.8;
      left = el.offset().left + parseFloat(el.css('padding-left'));
      this.els.errorWrap.css({
        top: top,
        left: left,
        display: 'block'
      }).text(text);
    };

    reg.prototype.checkValid = function() {
      var state;
      state = this.els.userName.val() && this.els.passWord.val() && this.els.passWord2.val() && this._BtnTrue;
      return this.els.reg.prop('disabled', !state);
    };

    reg.prototype.geerBtn = function(input, button) {
      input.on('blur', (function(_this) {
        return function() {
          _this.InputEach(input, button);
        };
      })(this));
    };

    reg.prototype.InputEach = function(input, button) {
      var _BtnTrue;
      _BtnTrue = this._BtnTrue;
      input.each(function() {
        if ($(this).val() && _BtnTrue) {
          button.css('color', '#fff');
          return true;
        } else {
          button.removeAttr('style');
        }
      });
    };

    reg.prototype.eventRegistered = function(event) {
      var data, el, userRegex;
      el = $(event.currentTarget);
      userRegex = /[A-Za-z]/;
      if (!userRegex.test(el.val())) {
        this.eventsBtnReg(el, '字母开头：6~14位字母、数字组成');
      }
      if (el.val().length > 5) {
        data = {
          userName: el.val().encodeHTML()
        };
        this.userName(data, el);
      }
    };

    reg.prototype.userName = function(data, el) {
      if (this.xhr) {
        this.xhr.abort();
      }
      $.ajax({
        url: "" + this.host + this.urlUser + "/" + data.userName,
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        beforeSend: (function(_this) {
          return function(xhr) {
            return _this.xhr = xhr;
          };
        })(this),
        dataFilter: (function(_this) {
          return function(data) {
            var temp;
            temp = data.toJSON();
            if (temp.code === 0) {
              _this.eventsBtnReg(el, '该账号已经存在');
            } else {
              _this.els.errorWrap.hide();
            }
            return '{}';
          };
        })(this)
      });
    };

    reg.prototype.registerBtn = function(event) {
      var data, passWordRegex, userRegex;
      event.preventDefault();
      userRegex = /^[A-Za-z]\w{5,13}$/;
      passWordRegex = /^\S{6,20}$/;
      data = {
        userName: this.els.userName.val(),
        password: this.els.passWord.val(),
        safeLevel: this.intensityNumber,
        lid: this.hash[0],
        aid: this.hash[1]
      };
      if (!userRegex.test(this.els.userName.val())) {
        this.eventsBtnReg(this.els.userName, '账号开头英文字母,并且账号长度6~14位英文与数字');
      } else if (!passWordRegex.test(this.els.passWord.val())) {
        this.eventsBtnReg(this.els.passWord, '密码由大小写英文、数字、特殊符号组成');
      } else if (this.els.passWord.val() !== this.els.passWord2.val()) {
        this.eventsBtnReg(this.els.passWord2, '输入的两次密码不同');
      } else {
        this.register(data);
      }
    };

    reg.prototype.register = function(data) {
      var hintEl, passV, userV;
      userV = data.userName;
      passV = data.password;
      hintEl = this.showHint({
        msg: '注册账号中...',
        type: 'loading',
        duration: Infinity,
        color: 'white'
      });
      $.ajax({
        url: "" + this.host + this.url,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processData: false,
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        data: JSON.stringify(data),
        dataFilter: (function(_this) {
          return function(data) {
            var temp;
            temp = data.toJSON();
            hintEl.data('hide')();
            if (temp.code === 0) {
              _this.showHint({
                msg: '注册成功',
                color: 'white',
                callback: function() {
                  return location.href = location.origin + "/login.html";
                }
              });
            } else {
              _this.showHint(temp.message);
            }
            return '{}';
          };
        })(this),
        error: (function(_this) {
          return function() {
            return _this.showHint('服务器暂时无法访问，请检查网络连接');
          };
        })(this)
      });
    };

    reg.prototype.demoBtn = function(event) {
      var hintEl;
      event.preventDefault();
      hintEl = this.showHint({
        msg: '注册账号中...',
        type: 'loading',
        duration: Infinity,
        color: 'white'
      });
      return $.ajax({
        url: this.host + "/members/demo/" + this.hash[0] + "/" + this.hash[1],
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        processDate: false,
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var temp;
            temp = data.toJSON();
            hintEl.data('hide')();
            if (+temp.code === 0) {
              localStorage.setItem('username', temp.data.LoginName);
              localStorage.setItem('balance', temp.data.Balance);
              localStorage.setItem('rebate', temp.data.RebetRate);
              localStorage.setItem('userID', temp.data.UserID);
              localStorage.setItem('stargetID', temp.data.LoginToken);
              localStorage.setItem('lastLoginAddress', temp.data.LastLoginAddress);
              localStorage.setItem('parentId', temp.data.ParentID);
              localStorage.setItem('parentName', temp.data.ParentName);
              if (temp.data.Notice) {
                localStorage.setItem('notice', temp.data.Notice);
              }
              localStorage.setItem('demo', 1);
              location.href = location.origin + "/index.html";
            }
            return data;
          };
        })(this),
        error: (function(_this) {
          return function() {
            return _this.showHint('服务器暂时无法访问，请检查网络连接');
          };
        })(this)
      });
    };

    reg.prototype.showHint = function(param) {
      var target;
      if (typeof param === 'string') {
        param = {
          msg: param
        };
      }
      if (param.speed == null) {
        param.speed = 200;
      }
      if (param.duration == null) {
        param.duration = 2000;
      }
      target = $("<div class=\"hint\">\n	<p style=\"" + (param.color ? 'color: ' + param.color + ';' : '') + "\">\n		" + (param.type === 'loading' ? '<img class="icon icon-spin icon-fast" src="/images/loading.png"/>' : '') + "\n		<label>" + (param.msg.encodeHTML(true)) + "</label>\n	</p>\n</div>");
      target.appendTo('body').data('hide', function() {
        clearTimeout(target.data('timeout'));
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, param.speed, function() {
          target.remove();
          return typeof param.callback === "function" ? param.callback() : void 0;
        });
      }).css({
        marginTop: '-0.32rem',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, param.speed, function() {
        target.removeAttr('style');
        return typeof param.callback === "function" ? param.callback() : void 0;
      });
      if (param.duration !== Infinity) {
        target.data('timeout', setTimeout(function() {
          var fun;
          fun = target.data('hide');
          return fun();
        }, param.duration));
      }
      return target;
    };

    reg.prototype.intensity = function(event) {
      var el, enoughRegex, mediumRegex, strongRegex;
      el = $(event.currentTarget);
      strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
      mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
      enoughRegex = new RegExp("(?=.{6,}).*", "g");
      this.els.intensity.css('opacity', 1);
      if (false === enoughRegex.test(el.val())) {
        this.els.intensity.text('弱').css('background', '#d2d2d2');
        this.intensityNumber = 1;
      } else if (strongRegex.test(el.val())) {
        this.els.intensity.text('强').css('background', '#8fc31f');
        this.intensityNumber = 3;
      } else if (mediumRegex.test(el.val())) {
        this.els.intensity.text('中').css('background', '#f19a38');
        this.intensityNumber = 2;
      } else {
        this.els.intensity.text('弱').css('background', '#d03724');
        this.intensityNumber = 1;
      }
    };

    reg.prototype.eventSee = function(event) {
      var el;
      el = $(event.currentTarget);
      el.addClass('icon checked');
      this._BtnTrue = true;
      this.checkValid();
    };

    reg.prototype.eventClauseShow = function() {
      this.els.agreement.css({
        top: 0,
        opacity: 1
      });
      return this.els.goBack.on('click', (function(_this) {
        return function() {
          return _this.els.agreement.css({
            top: '100%',
            opacity: 0
          });
        };
      })(this));
    };

    return reg;

  })();

  new reg();

  return;

}).call(this);
