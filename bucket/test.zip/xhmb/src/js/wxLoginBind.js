(function() {
  var fix, getCaptchaId, wxLogin,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Base64.extendString();

  String.prototype.md5 = function() {
    return md5.apply(null, [this].concat([].slice.apply(arguments)));
  };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  String.prototype.encodeHTML = function(onlyEncodeScript) {
    var encodeHTMLRules, matchHTML;
    if (!this) {
      return this;
    }
    encodeHTMLRules = {
      "&": "&#38;",
      "<": "&#60;",
      ">": "&#62;",
      '"': '&#34;',
      "'": '&#39;',
      "/": '&#47;'
    };
    if (onlyEncodeScript) {
      matchHTML = /<\/?\s*script\s*>/g;
      return this.replace(matchHTML, function(m) {
        return "" + encodeHTMLRules['<'] + (-1 === m.indexOf('/') ? '' : encodeHTMLRules['/']) + "script" + encodeHTMLRules['>'];
      });
    } else {
      matchHTML = /&(?!#?\w+;)|<|>|"|'|\//g;
      return this.replace(matchHTML, function(m) {
        return encodeHTMLRules[m] || m;
      });
    }
  };

  fix = location.hostname.match(/(?:^\w+\.|)(\w+)(?:\.\w+$)/);

  fix = fix[1].toLowerCase();

  fix = /test/.test(fix) ? 'rg' : fix.replace(/\d|dev|pvw/g, '');

  getCaptchaId = function() {
    return 'e614300cf3de4d36bfa64407470121c5';
  };

  wxLogin = (function() {
    function wxLogin() {
      this.showHint = bind(this.showHint, this);
      this.eventAgreementClose = bind(this.eventAgreementClose, this);
      this.loadResources = bind(this.loadResources, this);
      this.eventJumpUrl = bind(this.eventJumpUrl, this);
      this.eventAgreeLogin = bind(this.eventAgreeLogin, this);
      this.setStorageData = bind(this.setStorageData, this);
      this.weixinBind = bind(this.weixinBind, this);
      this.eventTesting = bind(this.eventTesting, this);
      this.eventPasswordBlur = bind(this.eventPasswordBlur, this);
      this.eventUserNameBlur = bind(this.eventUserNameBlur, this);
      window.v = this;
      $('body').append("<script src=\"" + location.protocol + "//c.dun.163yun.com/js/c.js\"></script>");
      this.host = (function(_this) {
        return function() {
          var arr, i, k, kv, len, tmp;
          _this.isLocal = 0;
          arr = location.search.slice(1).split('&');
          for (i = 0, len = arr.length; i < len; i++) {
            kv = arr[i];
            tmp = kv.split('=');
            k = tmp[0];
            if (k === 'test') {
              _this.isLocal = 1;
              break;
            }
          }

          /*
          			if @isLocal
          				"#{ location.protocol }//appapi.#{ location.hostname.replace /^\w+\./, '' }"
          			else
          				location.origin + '/api'
           */
          return location.origin + "/api";
        };
      })(this)();
      this.agreementUrl = "/" + (this.isLocal ? 'src' : 'dist') + "/templates/agreement.tpl";
      this.data = {};
      this.els = {};
      this.els.input = $('input');
      this.els.userName = $('[name="username"]');
      this.els.password = $('[name="password"]');
      this.els.bind = $('button.bindUseBtn');
      this.urlParameterArr = [];
      this.els.agreement = $('.agreement');
      this.els.cancel = $('.cancel', this.els.agreement);
      this.els.agree = $('.agree', this.els.agreement);
      this.els.input.on('keyup', this.eventTesting);
      this.els.userName.on('blur', this.eventUserNameBlur);
      this.els.password.on('blur', this.eventPasswordBlur);
      this.els.bind.on('click', this.weixinBind);
      this.els.cancel.on('click', this.eventAgreementClose);
      this.pathName = location.pathname;
      if (this.isLocal) {
        this.idx1 = 1;
        this.idx2 = 2;
        this.jumpUrl = location.origin + "/wxbind.html?test=1";
      } else {
        this.idx1 = 0;
        this.idx2 = 1;
        this.jumpUrl = location.origin + "/wxbind.html";
      }

      /*
      			如果拿到本地跑的话 需要后端往所有的重定向url 上加test=1  =>http://www.testxh.com/wxlogin.html?test=1&jumpType=1
      			所有的 @urlParameterArr[0]  数组下边为0的改成1,  为1 的改为2
      			这个跳转地址  /wxbind.html  后边也要加test=1
       */
      this.isWeixinBrowserOpen();
      this.loadResources();
    }

    wxLogin.prototype.isWeixinBrowserOpen = function() {
      var arr, i, kv, len, tmp, ua;
      ua = navigator.userAgent.toLowerCase();
      if (/MicroMessenger/i.test(ua)) {
        arr = location.search.slice(1).split('&');
        for (i = 0, len = arr.length; i < len; i++) {
          kv = arr[i];
          tmp = kv.split('=');
          this.urlParameterArr.push(tmp);
        }
        if (/wxlogin/i.test(this.pathName)) {
          if (this.urlParameterArr.length > this.idx1) {
            if (this.urlParameterArr[this.idx1][1] === 8) {
              return this.weixinLogin(8);
            } else {
              return this.weixinLogin(1);
            }
          }
        } else if (/wxbind/i.test(this.pathName)) {
          return console.log(this.pathName);
        }
      } else {
        return location.href = location.origin + "/wxerror.html";
      }
    };

    wxLogin.prototype.eventUserNameBlur = function(event) {
      var el;
      el = $(event.currentTarget);
      if (!el.val()) {
        return this.showHint({
          msg: '账号不能为空'
        });
      }
    };

    wxLogin.prototype.eventPasswordBlur = function(event) {
      var el;
      el = $(event.currentTarget);
      if (!el.val()) {
        return this.showHint({
          msg: '密码不能为空'
        });
      }
    };

    wxLogin.prototype.eventTesting = function() {
      if (this.els.userName.val() && this.els.password.val()) {
        return this.els.bind.prop('disabled', false);
      }
    };

    wxLogin.prototype.weixinBind = function() {
      var isInitPwd, openId, password, userName;
      userName = this.els.userName.val();
      password = this.els.password.val().md5();
      openId = localStorage.getItem('wxOpenId');
      if (!openId) {
        this.showHint({
          msg: 'openId is null'
        });
        return;
      }
      isInitPwd = password === 'x123456'.md5();
      if (isInitPwd) {
        localStorage.setItem('isInitPwd', 1);
      } else {
        localStorage.setItem('isInitPwd', 0);
      }
      return $.ajax({
        url: this.host + "/wx/bind/" + userName + "/" + password + "/" + openId,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        dataFilter: (function(_this) {
          return function(data) {
            data = data.toJSON();
            if (+data.code !== 0) {
              return _this.showHint({
                msg: data.message
              });
            } else {
              return _this.showHint({
                msg: '绑定成功!',
                callback: function() {
                  return $.ajax({
                    type: 'POST',
                    url: _this.host + "/wx/login/" + openId,
                    dataType: 'JSON',
                    contentType: 'application/json',
                    success: function(data) {
                      data = JSON.stringify(data);
                      data = data.toJSON();
                      if (+data.code === 0) {
                        _this.showHint({
                          msg: data.message,
                          callback: function() {
                            return _this.setStorageData(data);
                          }
                        });
                      }
                      if (+data.code === 6) {
                        return _this.showHint({
                          msg: data.message,
                          callback: function() {
                            return location.href = location.origin + "/login.html";
                          }
                        });
                      }
                    }
                  });
                }
              });
            }
          };
        })(this)
      });
    };

    wxLogin.prototype.weixinLogin = function(num) {
      var code, jumpType;
      if (+num === 1) {
        if (this.urlParameterArr[this.idx1]) {
          jumpType = this.urlParameterArr[this.idx1][1];
        } else {
          jumpType = 1;
        }
      }
      if (+num === 8) {
        jumpType = +num;
      }
      if (this.urlParameterArr[this.idx2]) {
        code = this.urlParameterArr[this.idx2][1];
      } else {
        code = '';
      }
      return $.ajax({
        type: "GET",
        url: this.host + "/wx/openId/" + jumpType + "?code=" + code,
        dataType: 'JSON',
        contentType: 'application/json',
        success: (function(_this) {
          return function(data) {
            var openId;
            if (+data.code !== 0) {
              return;
            }
            if (+data.data.type === 1) {
              return location.href = data.data.data;
            } else if (data.data.type === 2) {
              if (!data.data.data) {
                _this.showHint({
                  msg: 'openId 为空'
                });
                return;
              }
              openId = data.data.data;
              localStorage.setItem('wxOpenId', openId);
              return $.ajax({
                type: 'POST',
                url: _this.host + "/wx/login/" + openId,
                dataType: 'JSON',
                contentType: 'application/json',
                success: function(data) {
                  data = JSON.stringify(data);
                  data = data.toJSON();
                  if (+data.code === 0) {
                    _this.setStorageData(data);
                  }
                  if (+data.code === 6) {
                    return location.href = _this.jumpUrl;
                  }
                }
              });
            }
          };
        })(this)
      });
    };

    wxLogin.prototype.setStorageData = function(data) {
      var isInitPwd, temp;
      temp = data;
      if (+temp.code !== 0) {
        this.showHint({
          msg: temp.message
        });
        return '{}';
      }
      localStorage.setItem('isLocal', this.isLocal);
      localStorage.setItem('username', temp.data.LoginName);
      isInitPwd = localStorage.getItem('isInitPwd');
      if (temp.data) {
        localStorage.setItem('balance', temp.data.Balance);
        localStorage.setItem('rebate', temp.data.RebetRate);
        localStorage.setItem('userID', temp.data.UserID);
        localStorage.setItem('userType', temp.data.UserType);
        localStorage.setItem('stargetID', temp.data.LoginToken);
        localStorage.setItem('isInitPwd', +isInitPwd);
        if (temp.data.Notice) {
          localStorage.setItem('notice', temp.data.Notice);
        }
        localStorage.setItem('dfMonthActivityPop', 1);
        if (+isInitPwd) {
          $('.agreement').css({
            top: '0%',
            opacity: 1
          });
          this.els.agree.on('click', (function(_this) {
            return function() {
              return _this.eventAgreeLogin();
            };
          })(this));
        } else {
          this.eventJumpUrl();
        }
      }
      return data;
    };

    wxLogin.prototype.eventAgreeLogin = function() {
      var isLogin, x;
      isLogin = true;
      x = location.search.slice(1).split('&');
      x.map((function(_this) {
        return function(current, index) {
          var c;
          c = current.split('=');
          if (c[0] === 'backUrl') {
            isLogin = false;
            location.href = "" + location.origin + (decodeURIComponent(c[1])) + (_this.isLocal ? '?test=1' : '');
          }
        };
      })(this));
      if (isLogin) {
        return location.href = location.origin + "/index.html";
      }
    };

    wxLogin.prototype.eventJumpUrl = function() {
      var jumpType, jumpUrl;
      if (/wxbind/i.test(this.pathName)) {
        jumpType = 1;
      } else if (/wxlogin/i.test(this.pathName)) {
        if (this.urlParameterArr.length > this.idx1) {
          jumpType = +this.urlParameterArr[this.idx1][1];
        }
      }
      switch (jumpType) {
        case 1:
          jumpUrl = 'home';
          break;
        case 2:
          jumpUrl = 'past_me';
          break;
        case 3:
          jumpUrl = 'past_chase';
          break;
        case 4:
          jumpUrl = 'past';
          break;
        case 5:
          jumpUrl = 'recharge';
          break;
        case 6:
          jumpUrl = 'sumOperation/transferAccounts';
          break;
        case 7:
          jumpUrl = 'past_property';
          break;
        case 8:
          jumpUrl = 'home';
          break;
        case 9:
          jumpUrl = 'mine';
          break;
        default:
          jumpUrl = 'home';
      }
      return location.href = location.origin + "/index.html#" + jumpUrl;
    };

    wxLogin.prototype.loadResources = function() {
      return $.ajax({
        url: this.agreementUrl,
        dataType: 'text',
        success: (function(_this) {
          return function(data) {
            var els, temp;
            temp = $(data);
            els = temp.find('.platform');
            els.text(platform);
            return _this.els.agreement.append(temp);
          };
        })(this)
      });
    };

    wxLogin.prototype.eventAgreementClose = function() {
      this.els.agreement.css({
        top: '100%',
        opacity: 0
      });
      return location.href = location.origin + "/login.html";
    };

    wxLogin.prototype.showHint = function(param) {
      var target;
      if (param.speed == null) {
        param.speed = 200;
      }
      if (param.duration == null) {
        param.duration = 2000;
      }
      target = $("<div class=\"hint\">\n	<p style=\"" + (param.color ? 'color: ' + param.color + ';' : '') + "\">\n		" + (param.type === 'loading' ? '<img class="icon icon-spin icon-fast" src="/images/loading.png"/>' : '') + "\n		<label>" + (param.msg.encodeHTML(true)) + "</label>\n	</p>\n</div>");
      target.appendTo('body').data('hide', function() {
        clearTimeout(target.data('timeout'));
        return target.animate({
          marginTop: '-0.32rem',
          opacity: 0
        }, param.speed, function() {
          target.remove();
          return typeof param.callback === "function" ? param.callback() : void 0;
        });
      }).css({
        marginTop: '-0.32rem',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      }, param.speed, function() {
        return target.removeAttr('style');
      });
      if (param.duration !== Infinity) {
        target.data('timeout', setTimeout(function() {
          var fun;
          fun = target.data('hide');
          return fun();
        }, param.duration));
      }
      return target;
    };

    return wxLogin;

  })();

  new wxLogin();

}).call(this);
