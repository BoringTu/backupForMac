(function() {
  "use strict";
  var Active, domain,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  domain = location.hostname.replace(/^\w+\./, '');

  Active = (function() {
    function Active() {
      this.eventHideModel = bind(this.eventHideModel, this);
      this.eventShowModel = bind(this.eventShowModel, this);
      this.loginDetection = bind(this.loginDetection, this);
      this.host = (function() {
        var arr, i, isLocal, k, kv, len, tmp;
        isLocal = 0;
        arr = location.search.slice(1).split('&');
        for (i = 0, len = arr.length; i < len; i++) {
          kv = arr[i];
          tmp = kv.split('=');
          k = tmp[0];
          if (k === 'test') {
            isLocal = 1;
            break;
          }
        }
        if (isLocal) {
          return location.protocol + "//appapi." + domain;
        } else {
          return location.origin + '/api';
        }
      })();
      this.els = {};
      this.els.btn = $('.btn');
      this.els.maskWrap = $('.maskWrap');
      this.els.modelCenter = this.els.maskWrap.find('.model-center');
      this.els.close = this.els.maskWrap.find('.close');
      this.els.goBack = $('.goBack');
      this.els.btn.on('click', this.eventShowModel);
      this.els.close.on('click', this.eventHideModel);
      this.els.goBack.on('click', this.eventGoBack);
      this.loginDetection();
      this.loading();
    }

    Active.prototype.loginDetection = function(pageInfo) {
      if (pageInfo == null) {
        pageInfo = 1;
      }
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + pageInfo + "/" + 20.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var pathname, ref;
            data = data.toJSON();
            if ((ref = +data.code) === 2 || ref === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
              return '{}';
            }
            return '{}';
          };
        })(this)
      });
    };

    Active.prototype.eventShowModel = function() {
      this.els.maskWrap.css('visibility', 'visible');
      return this.els.modelCenter.css({
        'marginTop': 0,
        'opacity': 1
      });
    };

    Active.prototype.eventHideModel = function() {
      this.els.maskWrap.css('visibility', 'hidden');
      return this.els.modelCenter.css({
        'marginTop': '-0.3rem',
        'opacity': 0
      });
    };

    Active.prototype.eventGoBack = function() {
      return history.back();
    };

    Active.prototype.loading = function() {
      var bg1, spinner;
      bg1 = $('#bg1');
      bg1.attr('src', '/images/activity/2017082901-df9yhd/bg1.jpg');
      spinner = $('.spinner');
      return bg1.load(function() {
        return spinner.remove();
      });
    };

    return Active;

  })();

  new Active;

}).call(this);
