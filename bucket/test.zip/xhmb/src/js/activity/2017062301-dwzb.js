(function() {
  "use strict";
  var Active, domain,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  domain = location.hostname.replace(/^\w+\./, '');

  Active = (function() {
    function Active() {
      this.countDownTimer = bind(this.countDownTimer, this);
      this.eventTabLiSwitch = bind(this.eventTabLiSwitch, this);
      this.timerData = bind(this.timerData, this);
      this.eventGoBack = bind(this.eventGoBack, this);
      this.rener = bind(this.rener, this);
      this.host = (function() {
        var arr, isLocal, k, kv, len, m, tmp;
        isLocal = 0;
        arr = location.search.slice(1).split('&');
        for (m = 0, len = arr.length; m < len; m++) {
          kv = arr[m];
          tmp = kv.split('=');
          k = tmp[0];
          if (k === 'test') {
            isLocal = 1;
            break;
          }
        }
        if (isLocal) {
          return location.protocol + "//appapi." + domain;
        } else {
          return location.origin + '/api';
        }
      })();
      this.myRanking();
      this.rener();
    }

    Active.prototype.rener = function() {
      this.els = {};
      this.els.back = $('button.back');
      this.els.container = $('.container');
      this.els.tabLi = this.els.container.find('ul.tab li');
      this.els.activitys = this.els.container.find('.activitys');
      this.els.rankingNum = this.els.container.find('.rankingNum span');
      this.els.rankingDate = this.els.container.find('.rankingDate span');
      this.els.swiperWrapper = this.els.container.find('.swiper-wrapper');
      this.els.table2Tbody = this.els.swiperWrapper.find('.table2 tbody');
      this.els.plat = $('.platform');
      this.els.tabLi.on('click', this.eventTabLiSwitch).eq(0).trigger('click');
      this.els.back.on('click', this.eventGoBack);
      return this.timerData();
    };

    Active.prototype.eventGoBack = function() {
      return history.back();
    };

    Active.prototype.timerData = function(pageInfo, async) {
      var i, j, k, list, m, n, tr, trs;
      if (pageInfo == null) {
        pageInfo = 1;
      }
      if (async == null) {
        async = true;
      }
      list = userList;
      for (i = m = 0; m < 5; i = ++m) {
        trs = '';
        for (j = n = 0; n < 15; j = ++n) {
          k = j + i * 15;
          tr = "<tr>\n	<td>" + list[k].orderNum + "</td>\n	<td>" + list[k].userName + "</td>\n	<td>" + list[k].winLoseMoney + "</td>\n</tr>";
          trs += tr;
        }
        console.log(trs);
        this.els.table2Tbody.eq(i).html(trs);
      }
      new Swiper('.swiper-container', {
        pagination: '.swiper-pagination'
      });
      return;
      if (async) {
        this.showHint();
      }
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + pageInfo + "/" + 75.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        async: async,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var dataTh, l, o, once, p, page, pageAll, pathname, ref, ref1, ref2, ref3, results, towe;
            data = data.toJSON();
            if (_this.target) {
              _this.target.remove();
            }
            if ((ref = +data.code) === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
              return '{}';
            }
            if (async) {
              dataTh = data.data.length;
              once = towe = 15;
              page = Math.ceil(dataTh / once);
              k = 0;
              results = [];
              for (i = o = 1, ref1 = page; 1 <= ref1 ? o <= ref1 : o >= ref1; i = 1 <= ref1 ? ++o : --o) {
                trs = '';
                if (i === page) {
                  pageAll = dataTh;
                } else {
                  pageAll = i * once;
                }
                for (l = p = ref2 = k * towe, ref3 = pageAll - 1; ref2 <= ref3 ? p <= ref3 : p >= ref3; l = ref2 <= ref3 ? ++p : --p) {
                  tr = "<tr>\n	<td>" + data.data[l].orderNum + "</td>\n	<td>" + data.data[l].userName + "</td>\n	<td>" + data.data[l].winLoseMoney + "</td>\n</tr>";
                  trs += tr;
                }
                k = i;
                results.push(_this.els.table2Tbody.eq(i - 1).html(trs));
              }
              return results;
            }
          };
        })(this)
      });
    };

    Active.prototype.eventTabLiSwitch = function(event) {
      var el, sm;
      el = $(event.currentTarget);
      sm = el.attr('data-content');
      this.els.tabLi.removeClass('active');
      el.addClass('active');
      this.els.activitys.hide();
      return this.els.activitys.filter("[data-content=\"" + sm + "\"]").show();
    };

    Active.prototype.countDownTimer = function(date) {
      if (date == null) {
        date = 120;
      }
      clearInterval(this.timer);
      return this.timer = setInterval((function(_this) {
        return function() {
          date--;
          _this.els.rankingDate.text(date + "秒");
          if (date === 0) {
            date = 121;
          }
          if (date === 120) {
            _this.timerData();
            return _this.myRanking();
          }
        };
      })(this), 1000);
    };

    Active.prototype.myRanking = function() {
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + 1. + "/" + 1.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        data: JSON.stringify({
          userName: localStorage.getItem('username')
        }),
        dataFilter: (function(_this) {
          return function(data) {
            var pathname, ref;
            data = data.toJSON();
            if ((ref = +data.code) === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
              return '{}';
            }
            _this.els.rankingNum.text(data.data.length ? data.data[0].orderNum + "名" : '未上榜');
            return '{}';
          };
        })(this)
      });
    };

    Active.prototype.showHint = function(msg) {
      var speed;
      if (this.target) {
        this.target.remove();
      }
      speed = 200;
      this.target = $("<div class=\"hint\">\n	<p class=\"loading\">\n		<span></span>\n		<span></span>\n		<span></span>\n		<span></span>\n		<span></span>\n	</p>\n</div>");
      this.target.appendTo('.swiper-container').css({
        marginTop: '-30',
        opacity: 0
      }).animate({
        marginTop: 0,
        opacity: 1
      });
    };

    return Active;

  })();

  new Active();

}).call(this);
