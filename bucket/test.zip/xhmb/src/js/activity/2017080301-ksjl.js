(function() {
  "use strict";
  var Active, domain,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  String.prototype.toJSON = function() {
    return JSON.parse(this);
  };

  domain = location.hostname.replace(/^\w+\./, '');

  Active = (function() {
    function Active() {
      this.eventColse = bind(this.eventColse, this);
      this.eventSeeBtn = bind(this.eventSeeBtn, this);
      this.eventAlerRule = bind(this.eventAlerRule, this);
      this.eventGoBack = bind(this.eventGoBack, this);
      this.loginStatus = bind(this.loginStatus, this);
      this.render = bind(this.render, this);
      this.host = (function() {
        var arr, i, isLocal, k, kv, len, tmp;
        isLocal = 0;
        arr = location.search.slice(1).split('&');
        for (i = 0, len = arr.length; i < len; i++) {
          kv = arr[i];
          tmp = kv.split('=');
          k = tmp[0];
          if (k === 'test') {
            isLocal = 1;
            break;
          }
        }
        if (isLocal) {
          return location.protocol + "//appapi." + domain;
        } else {
          return location.origin + '/api';
        }
      })();
      this.loginStatus();
      this.render();
    }

    Active.prototype.render = function() {
      this.els = {};
      this.els.back = $('a.goBack');
      this.els.plat = $('.platform');
      this.els.ruleBtn = $('.ruleBtn');
      this.els.seeBtn = $('.seeBtn');
      this.els.doBtn = $('.doBtn');
      this.els.maks = $('.maks');
      this.els.Box1 = $('.Box1');
      this.els.Box2 = $('.Box2');
      this.els.Box3 = $('.Box3');
      this.els.colse = $('.colse');
      this.els.linkParentBtn = $('.Box1').find('.btn');
      this.els.linkParentBtn.on('click', this.eventAlerRule);
      this.els.back.on('click', this.eventGoBack);
      this.els.ruleBtn.on('click', this.eventAlerRule);
      this.els.colse.on('click', this.eventColse);
      return this.els.seeBtn.on('click', this.eventSeeBtn);
    };

    Active.prototype.loginStatus = function(pageInfo) {
      if (pageInfo == null) {
        pageInfo = 1;
      }
      return $.ajax({
        url: this.host + "/members/topwinmembers/" + pageInfo + "/" + 20.,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        crossDomain: true,
        headers: {
          'Content-type': 'application/json; charset=utf-8'
        },
        xhrFields: {
          'withCredentials': true
        },
        dataFilter: (function(_this) {
          return function(data) {
            var pathname, ref;
            data = data.toJSON();
            if ((ref = +data.code) === 2 || ref === 403 || ref === 405) {
              pathname = encodeURIComponent(location.pathname);
              location.href = location.origin + "/login.html?backUrl=" + pathname;
            }
            return '{}';
          };
        })(this)
      });
    };

    Active.prototype.eventGoBack = function() {
      return history.back();
    };

    Active.prototype.eventAlerRule = function(event) {
      var el;
      el = $(event.currentTarget);
      this.els.maks.css({
        'visibility': 'visible',
        'opacity': '0.6'
      });
      return this.els.Box3.css({
        'visibility': 'visible',
        'opacity': '1'
      });
    };

    Active.prototype.eventSeeBtn = function(event) {
      var el, userType;
      el = $(event.currentTarget);
      userType = localStorage.getItem('userType');
      if (+userType === 1) {
        this.els.maks.css({
          'visibility': 'visible',
          'opacity': '0.6'
        });
        this.els.Box1.css({
          'visibility': 'visible',
          'opacity': '1'
        });
        return;
      }
      return el.attr("href", "/#past_property");
    };

    Active.prototype.eventColse = function(event) {
      var el;
      el = $(event.currentTarget);
      el.parent('.dialog').css({
        'visibility': 'hidden',
        'opacity': '0'
      });
      return this.els.maks.css({
        'visibility': 'hidden',
        'opacity': '0'
      });
    };

    return Active;

  })();

  new Active();

}).call(this);
